// Service worker (ES module). Requests from the dashboard / popup:
//   { type: 'FETCH_INCIDENT', instanceUrl, incidentNumber, source?: 'search'|'refresh' }
//     -> { ok: true, record } | { ok: false, error: { code, message } }
//   { type: 'POST_TICKET_UPDATE', instanceUrl, incidentNumber, field: 'comments'|'work_notes', text, dryRun }
//     -> { ok: true, result: { status, field, dryRun, verified, message, entry } } | { ok: false, error }
//   { type: 'REFRESH_ALL', reason?: 'manual' } -> { ok: true, started, job }
//   { type: 'CANCEL_REFRESH' }                 -> { ok: true }
//   { type: 'LIST_OPEN_INCIDENTS', instanceUrl, config? }
//     -> { ok: true, result: { numbers, listed, keptByState, skippedByState, pages, total, truncated, query,
//                              rows, columnLabels } }
//      | { ok: false, error }   (reads ServiceNow's classic incident list in one background tab; the worker
//        stores nothing of it, then applies the retention setting - see pruneByRetention. The dashboard
//        stores the list-row cells of tickets that then fail to fetch in queueTracking.lastErrors, and the
//        listed numbers in queueTracking.tickets: dashboard/opentickets.js)
// Browser events: the toolbar icon opens the dashboard; at browser start data older than the
// retention setting is removed, then the stored tickets are refreshed when the session is still
// logged in.
//
// Fetch flow: validate -> host permission -> background tab on the user's logged-in session -> wait
// for load and redirects -> run the extractor in the page -> analyse -> store -> always close the tab.
// Ticket update flow: the same up to the loaded page, then lib/worknote.js sets the field and
// schedules Save; the tab is closed only AFTER the page navigated and the note was looked up again.
// Logging is limited to the incident number and a status/code: never ticket content, URLs or
// anything session related. Correctness never depends on module state (the worker can restart):
// the refresh job lives in chrome.storage.local, the maps below only avoid duplicate work.
import {
  ACTIVITY_SELECTORS,
  DEFAULT_BUSINESS_HOURS,
  BUILD_ID,
  ERROR_CODES,
  FETCH_LOG_MAX,
  FIELD_CANDIDATES,
  FIELD_LABELS,
  STORAGE_KEYS,
  TIMEOUTS,
  UPDATE_ATTEMPTS_MAX,
} from './lib/config.js';
import { buildRecord, normalizeIncidentNumber } from './lib/analyze.js';
import {
  applyFieldMapping, candidatesWithMapping, labelsWithMapping, mappingPreview, normalizeFieldMapping,
} from './lib/fieldMapping.js';
import { SETTINGS_STORAGE_KEY, normalizeServiceNowSettings } from './lib/settings.js';
import { extractIncident } from './lib/extractor.js';
import { extractListPage } from './lib/listExtractor.js';
import {
  buildIncidentListUrl, buildOpenIncidentsQuery, nextFirstRow, normalizeOpenTicketsConfig, parseListRange, stateMatches,
} from './lib/openTickets.js';
import { FOLLOW_UP_STORAGE_KEYS } from './lib/followup.js';
import { buildIncidentUrl, isAllowedInjectionOrigin, isLoginUrl, parseInstanceUrl } from './lib/instance.js';
import { parseServiceNowDateTime, getSystemTimeZone } from './lib/timeUtils.js';
import { postWorkNote } from './lib/worknote.js';
import { openDashboard } from './bg/dashboardTab.js';
import { MESSAGES, noPermissionMessage } from './bg/messages.js';
import { mergeRecordMetadata, normalizeSource, withRefreshError } from './bg/records.js';
import {
  REFRESH_CONCURRENCY,
  REFRESH_GAP_MS,
  REFRESH_MAX,
  UNUSABLE_REASON,
  createJob,
  isFinished,
  planRefresh,
  skipReason,
  stateAfterProbe,
  stateAfterTicket,
  withCancelRequested,
  withCurrent,
  withError,
  withFinished,
  withOrigin,
  withRead,
  withSkipped,
} from './bg/refreshjob.js';
import {
  NOTE_FIELDS,
  classifyInspect,
  dryRunResult,
  hasNavigated,
  interpretSubmit,
  makeBaseline,
  parseUpdateRequest,
  postedResult,
  requestSignature,
  saveFailedMessage,
  unknownOutcomeMessage,
  verifyAgainstBaseline,
} from './bg/ticketupdate.js';

const POLL_MS = 250; // fallback poll while waiting for tab events (events can be missed)
const SETTLE_MS = 600; // quiet period after "complete" to catch SSO / JS redirects
const MAX_SETTLE_ROUNDS = 5; // redirect hops tolerated before taking the last loaded state
const SCRIPT_GRACE_MS = 5000; // extra time on top of the extractor's own internal waits
const KEEPALIVE_MS = 20000; // keeps the service worker alive during a long fetch

// Ticket update timing, from measurements in Brave 154 (a hidden tab runs its timers about 1 s late).
const SAVE_DELAY_MS = 50; // the page calls g_form.save() this long after it answered
const SAVE_WAIT_MS = 15000; // longest wait for the page to navigate and load after Save
const INSPECT_AFTER_MS = 1500; // the save timer has fired by then, even in a throttled tab
const BLOCKED_GRACE_MS = 3000; // "still holds the note" must persist this long before it counts as blocked
const INSPECT_TIMEOUT_MS = 3000; // inspect is an instant read: a call that hangs means the page is being replaced
const SUBMIT_SCRIPT_MS = TIMEOUTS.formReadyMs + 10000; // the page waits for the form, then checks the field
const POST_SETTLE_MS = 10000; // budget for the page that Save led to to become stable
// activityMoreMs 0: the baseline read before Save and the re-read after it look at the first page of the
// activity stream only. The new note is always the newest entry, and both reads then see the same depth.
const VERIFY_TIMEOUTS = { ...TIMEOUTS, formReadyMs: 8000, callerRefMs: 2000, activityMs: 6000, activityMoreMs: 0 };
const RECENT_ENOUGH_MS = 10 * 60 * 1000; // verification baseline sanity bound (section 13.5 item B)

// Listing open incidents (LIST_OPEN_INCIDENTS). The list page is server-rendered, so reading it is a
// plain DOM walk: a generous budget still catches a frame that never answers.
const LIST_SCRIPT_MS = 15000;
const LIST_MAX_PAGES = 100; // hard stop whatever the page size: a runaway pager can never loop forever
// v0.5: when the list's total DROPS between two pages (a ticket was resolved or reassigned while the list
// was being read), the rows after it slid up by that many places and the ones at the page boundary would
// be skipped; a skipped ticket would then look "moved out of the queue" after a complete run. The page is
// read again that many rows earlier (duplicates are dropped anyway), at most this many times per run.
const LIST_MAX_REREADS = 5;
// The Next Experience shell can add the classic list's iframe only AFTER the tab reported "complete":
// a page where no frame shows a list (and none a login) is looked at again a few times before it counts
// as unreadable.
// Eight looks 1.5 s apart give a slow shell about ten seconds to add its list frame.
const LIST_READ_ATTEMPTS = 8;
const LIST_RETRY_MS = 1500;
// Field names of the State column: 'state' on current releases, 'incident_state' on older list views
// (lib/listExtractor.js reads the State text from either).
const LIST_STATE_COLUMNS = ['state', 'incident_state'];
// v0.5: the list cells handed back with every kept ticket (the Fetch errors view shows a ticket that
// could not be fetched as the list showed it). The extractor caps them too; the worker never trusts that.
const LIST_MAX_CELLS = 20;
const LIST_MAX_CELL_TEXT = 200;

// Durable records (section 13.5): neither is part of STORAGE_KEYS (lib/config.js) because they are
// owned by the write-safety / diagnostics flows, not the incident records.
const UPDATE_ATTEMPTS_KEY = 'updateAttempts';
const FETCH_LOG_KEY = 'fetchLog';

// chrome.storage.session records every tab we open so a restarted worker can close orphans.
const PENDING_TAB_PREFIX = 'pendingTab:';
const WORKER_ID = Math.random().toString(36).slice(2);

/** Error carrying one of ERROR_CODES; everything thrown inside the flows ends up as one. */
class FetchError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'FetchError';
    this.code = code;
  }
}

/** A page script call that did not answer within its budget. */
class ScriptTimeout extends Error {}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const isObject = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);

// Date.now() is the one clock; new Date(ms) cannot yield an invalid date.
const nowIso = () => new Date(Date.now()).toISOString();

function describe(err) {
  return err && err.message ? String(err.message) : String(err);
}

function withTimeout(promise, ms, makeError) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(makeError()), ms);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

function log(incidentNumber, status) {
  console.info('[QueueSenseITOps]', incidentNumber, status);
}

// ---------------------------------------------------------------------------------------------
// Input and permission checks
// ---------------------------------------------------------------------------------------------

function validateRequest(message) {
  const instance = parseInstanceUrl(message.instanceUrl);
  if (!instance.ok) throw new FetchError('INVALID_INPUT', instance.message);
  const incidentNumber = normalizeIncidentNumber(message.incidentNumber);
  if (!incidentNumber) throw new FetchError('INVALID_INPUT', MESSAGES.BAD_INCIDENT_NUMBER);
  const source = normalizeSource(message.source);
  if (!source) throw new FetchError('INVALID_INPUT', MESSAGES.BAD_SOURCE);
  return { instance, incidentNumber, source };
}

async function ensureHostPermission(instance) {
  let granted;
  try {
    granted = await chrome.permissions.contains({ origins: [instance.pattern] });
  } catch (err) {
    throw new FetchError('NO_PERMISSION', `${noPermissionMessage(instance.origin)} (${describe(err)})`);
  }
  if (!granted) throw new FetchError('NO_PERMISSION', noPermissionMessage(instance.origin));
}

// ---------------------------------------------------------------------------------------------
// Tab lifecycle
// ---------------------------------------------------------------------------------------------

/**
 * Listens to tab events for the duration of one flow. It is started BEFORE tabs.create so events
 * for the new tab cannot be missed; the events only wake the waiter, the authoritative state is
 * always re-read with tabs.get. Removals are remembered so a tab closed early is noticed.
 * watchNavigation(tabId) arms a sticky flag: once the tab starts a navigation (status 'loading' or a
 * new URL) navigated(tabId) stays true, even when the load is over before anybody looked.
 */
function createTabEvents() {
  const waiters = new Set();
  const closed = new Set();
  const navigations = new Map();
  const wake = () => {
    for (const resolve of [...waiters]) resolve();
  };
  const onUpdated = (tabId, changeInfo) => {
    const started = changeInfo && (changeInfo.status === 'loading' || typeof changeInfo.url === 'string');
    if (started && navigations.has(tabId)) navigations.set(tabId, true);
    wake();
  };
  const onRemoved = (tabId) => {
    closed.add(tabId);
    wake();
  };
  return {
    start() {
      chrome.tabs.onUpdated.addListener(onUpdated);
      chrome.tabs.onRemoved.addListener(onRemoved);
    },
    stop() {
      chrome.tabs.onUpdated.removeListener(onUpdated);
      chrome.tabs.onRemoved.removeListener(onRemoved);
      wake();
    },
    wasClosed: (tabId) => closed.has(tabId),
    watchNavigation: (tabId) => navigations.set(tabId, false),
    navigated: (tabId) => navigations.get(tabId) === true,
    /** Resolves on the next tab event or after `ms`, whichever comes first. */
    nextEvent(ms) {
      return new Promise((resolve) => {
        const done = () => {
          clearTimeout(timer);
          waiters.delete(done);
          resolve();
        };
        const timer = setTimeout(done, ms);
        waiters.add(done);
      });
    },
  };
}

function tabClosedError(detail) {
  const suffix = detail ? ` (${detail})` : '';
  return new FetchError('TAB_ERROR', `The incident tab was closed before the data could be read.${suffix}`);
}

async function readTab(events, tabId) {
  if (events.wasClosed(tabId)) throw tabClosedError();
  try {
    return await chrome.tabs.get(tabId);
  } catch (err) {
    throw tabClosedError(describe(err));
  }
}

async function openIncidentTab(url) {
  try {
    const tab = await chrome.tabs.create({ url, active: false });
    if (!tab || typeof tab.id !== 'number') throw new Error('the browser did not return a tab id');
    return tab;
  } catch (err) {
    throw new FetchError('TAB_ERROR', `Could not open a background tab: ${describe(err)}`);
  }
}

async function closeTab(tabId) {
  try {
    await chrome.tabs.remove(tabId);
  } catch (err) {
    // Already closed (by the user or the browser): nothing left to do.
  }
}

async function withSessionStorage(action) {
  try {
    if (chrome.storage && chrome.storage.session) await action(chrome.storage.session);
  } catch (err) {
    // Orphan tracking is best effort and must never fail a fetch.
  }
}

const trackTab = (tabId) => withSessionStorage((area) => area.set({ [PENDING_TAB_PREFIX + tabId]: WORKER_ID }));
const untrackTab = (tabId) => withSessionStorage((area) => area.remove(PENDING_TAB_PREFIX + tabId));

/** Closes tabs left behind by a worker that was killed mid-fetch. Runs once per worker start. */
async function closeOrphanTabs() {
  await withSessionStorage(async (area) => {
    const all = await area.get(null);
    const stale = Object.keys(all).filter((key) => key.startsWith(PENDING_TAB_PREFIX) && all[key] !== WORKER_ID);
    for (const key of stale) await closeTab(Number(key.slice(PENDING_TAB_PREFIX.length)));
    if (stale.length) await area.remove(stale);
  });
}

function startKeepAlive() {
  const timer = setInterval(() => {
    try {
      Promise.resolve(chrome.runtime.getPlatformInfo()).catch(() => {});
    } catch (err) {
      // Not available: the tab polling still resets the idle timer.
    }
  }, KEEPALIVE_MS);
  return () => clearInterval(timer);
}

// ---------------------------------------------------------------------------------------------
// Waiting for the page
// ---------------------------------------------------------------------------------------------

const isErrorPage = (url) => typeof url === 'string' && url.startsWith('chrome-error://');
const hasRealUrl = (tab) => Boolean(tab.url) && tab.url !== 'about:blank';

/** Resolves with the tab once it reports status 'complete' on a real URL. Tracks the last URL. */
async function waitForComplete(events, tabId, deadline, seen) {
  for (;;) {
    const tab = await readTab(events, tabId);
    if (tab.url) seen.url = tab.url;
    if (tab.status === 'complete' && hasRealUrl(tab)) return tab;
    const left = deadline - Date.now();
    if (left <= 0) throw new FetchError('TIMEOUT', MESSAGES.TIMEOUT);
    await events.nextEvent(Math.min(POLL_MS, left));
  }
}

/**
 * Waits until the tab is loaded AND stable: after "complete" it waits SETTLE_MS and re-reads the
 * tab; if a redirect started meanwhile (SSO hops, JS redirects) it waits for the next "complete".
 * Login detection happens only on the stable state so a transparent SSO round trip still works.
 */
async function waitForSettledTab(events, tabId, instanceOrigin, deadline) {
  const seen = { url: '' };
  try {
    let tab = await waitForComplete(events, tabId, deadline, seen);
    for (let round = 0; round < MAX_SETTLE_ROUNDS; round += 1) {
      if (isErrorPage(tab.url)) break;
      await sleep(Math.max(0, Math.min(SETTLE_MS, deadline - Date.now())));
      const next = await readTab(events, tabId);
      if (next.status === 'complete' && next.url === tab.url) {
        tab = next;
        break;
      }
      tab = await waitForComplete(events, tabId, deadline, seen);
    }
    assertUsablePage(tab, instanceOrigin);
    return tab;
  } catch (err) {
    // A slow identity provider is still "login required", not a generic timeout.
    if (err.code === 'TIMEOUT' && isLoginUrl(seen.url, instanceOrigin)) throw loginRequired();
    throw err;
  }
}

function loginRequired() {
  return new FetchError('LOGIN_REQUIRED', MESSAGES.LOGIN_REQUIRED);
}

// ---------------------------------------------------------------------------------------------
// Origin guard (section 13.5): re-checked immediately before EVERY script injection, on the read
// AND the write path. A settle check minutes (or even milliseconds) earlier is not enough: the tab
// can navigate in the instant between that check and chrome.scripting.executeScript (a slow-landing
// redirect, a TOCTOU race). Fails closed: data:/blob:/javascript:/file:/view-source:/other tenants
// never reach the page script, even with a host permission that would otherwise allow the injection.
// ---------------------------------------------------------------------------------------------

async function assertInjectionOrigin(events, tabId, origin) {
  const tab = await readTab(events, tabId);
  if (isAllowedInjectionOrigin(tab.url, origin)) return tab;
  if (isLoginUrl(tab.url, origin)) throw loginRequired();
  throw new FetchError(
    'PAGE_UNSUPPORTED',
    `The tab is no longer on ${origin}: the origin guard refused to run the page script. ${MESSAGES.PAGE_UNSUPPORTED}`,
  );
}

function assertUsablePage(tab, instanceOrigin) {
  if (isErrorPage(tab.url)) throw new FetchError('TAB_ERROR', MESSAGES.LOAD_FAILED);
  if (isLoginUrl(tab.url, instanceOrigin)) throw loginRequired();
}

// ---------------------------------------------------------------------------------------------
// Running the extractor
// ---------------------------------------------------------------------------------------------

// The extractor's own waits, one after the other: the form, the caller record, the first batch of the
// activity stream and (v0.4) the "Show more" paging budget, plus a grace period.
function extractorTimeoutMs(timeouts) {
  const moreMs = Number.isFinite(timeouts.activityMoreMs) && timeouts.activityMoreMs > 0 ? timeouts.activityMoreMs : 0;
  return timeouts.formReadyMs + timeouts.callerRefMs + timeouts.activityMs + moreMs + SCRIPT_GRACE_MS;
}

function classifyScriptError(err, events, tabId, origin) {
  if (err instanceof FetchError) return err;
  const text = describe(err);
  if (events.wasClosed(tabId) || /no tab with id|tab was closed|tabs cannot be edited/i.test(text)) {
    return tabClosedError(text);
  }
  if (/error page|chrome-error/i.test(text)) return new FetchError('TAB_ERROR', `${MESSAGES.LOAD_FAILED} (${text})`);
  if (/cannot access (the )?contents|extension manifest must request/i.test(text)) {
    return new FetchError('NO_PERMISSION', `${noPermissionMessage(origin)} (${text})`);
  }
  return new FetchError('EXTRACT_FAILED', `Could not read the incident page: ${text}`);
}

/**
 * `options.fieldMapping` (Settings -> Column to field mapping) adds the mapped fields to what the
 * extractor reads; `options.collectInventory` also lists every field on the form (PROBE_INCIDENT).
 */
async function runExtractor(events, tabId, incidentNumber, origin, timeouts = TIMEOUTS, options = {}) {
  const mapping = options.fieldMapping || {};
  const config = {
    incidentNumber,
    fieldCandidates: candidatesWithMapping(FIELD_CANDIDATES, mapping),
    activitySelectors: ACTIVITY_SELECTORS,
    timeouts,
    fieldLabels: labelsWithMapping(FIELD_LABELS, mapping),
  };
  if (options.collectInventory === true) config.collectInventory = true;
  let results;
  try {
    await assertInjectionOrigin(events, tabId, origin);
    const injection = chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: extractIncident,
      args: [config],
    });
    results = await withTimeout(injection, extractorTimeoutMs(timeouts), () => new FetchError('TIMEOUT', MESSAGES.TIMEOUT));
  } catch (err) {
    throw classifyScriptError(err, events, tabId, origin);
  }
  const first = Array.isArray(results) ? results[0] : null;
  if (first && first.error) {
    throw new FetchError('EXTRACT_FAILED', `Could not read the incident page: ${describe(first.error)}`);
  }
  const raw = first ? first.result : null;
  if (!raw || typeof raw !== 'object' || typeof raw.status !== 'string') {
    throw new FetchError('EXTRACT_FAILED', 'Could not read the incident page: it returned no data.');
  }
  return raw;
}

/**
 * Opens the incident in a background tab, waits for it, runs the extractor and returns its raw
 * result. Whatever happens, listeners, timers and the tab are cleaned up before returning.
 */
async function readIncidentPage(instance, incidentNumber, extractorOptions = {}) {
  const events = createTabEvents();
  const stopKeepAlive = startKeepAlive();
  let tabId = null;
  try {
    const deadline = Date.now() + TIMEOUTS.pageLoadMs;
    events.start();
    const tab = await openIncidentTab(buildIncidentUrl(instance.origin, incidentNumber));
    tabId = tab.id;
    await trackTab(tabId);
    await waitForSettledTab(events, tabId, instance.origin, deadline);
    return await runExtractor(events, tabId, incidentNumber, instance.origin, TIMEOUTS, extractorOptions);
  } finally {
    stopKeepAlive();
    events.stop();
    if (tabId !== null) {
      await closeTab(tabId);
      await untrackTab(tabId);
    }
  }
}

// ---------------------------------------------------------------------------------------------
// Result mapping, analysis, storage
// ---------------------------------------------------------------------------------------------

function assertExtracted(raw) {
  switch (raw.status) {
    case 'ok':
      if (raw.incident && typeof raw.incident === 'object') return;
      throw new FetchError('EXTRACT_FAILED', 'Could not read the incident page: no incident data was returned.');
    case 'login':
      throw loginRequired();
    case 'notfound':
      throw new FetchError('NOT_FOUND', MESSAGES.NOT_FOUND);
    case 'unsupported':
      throw new FetchError('PAGE_UNSUPPORTED', MESSAGES.PAGE_UNSUPPORTED);
    case 'error':
      throw new FetchError('EXTRACT_FAILED', `Could not read the incident page: ${raw.message || 'unknown error'}`);
    default:
      throw new FetchError('EXTRACT_FAILED', `Could not read the incident page: unexpected status "${raw.status}".`);
  }
}

/** The owner's Settings tab values (lib/settings.js); defaults when nothing usable is stored. */
async function loadServiceNowSettings() {
  try {
    const stored = await chrome.storage.local.get(SETTINGS_STORAGE_KEY);
    return normalizeServiceNowSettings(stored ? stored[SETTINGS_STORAGE_KEY] : undefined);
  } catch (err) {
    return normalizeServiceNowSettings(undefined);
  }
}

function analyse(raw, settings = {}) {
  try {
    const record = buildRecord(raw, {
      now: new Date(),
      businessHours: DEFAULT_BUSINESS_HOURS,
      systemTimeZone: getSystemTimeZone(),
      userSource: settings.userSource,
    });
    // Round-trip so the caller gets exactly what storage will hold.
    return JSON.parse(JSON.stringify(record));
  } catch (err) {
    throw new FetchError('EXTRACT_FAILED', `Could not analyse the incident data: ${describe(err)}`);
  }
}

// Read-modify-write on the incidents: serialised so concurrent reads never lose a record.
let storageQueue = Promise.resolve();

function enqueueStorage(task) {
  const run = storageQueue.then(task);
  storageQueue = run.catch(() => {}); // one failed write must not block later ones
  return run;
}

const plainMap = (value) => (isObject(value) ? value : {});

const STORED_RECORDS = [STORAGE_KEYS.incidents, STORAGE_KEYS.lastIncident];

// ---------------------------------------------------------------------------------------------
// Durable attempt record (section 13.5 item B) and fetch log (item E): small ring buffers in
// chrome.storage.local. Both go through the same write queue as the incident records so a crash or
// a concurrent write never loses an entry. Writes here are always best effort: a storage hiccup must
// never fail (or retry) a fetch or a post.
// ---------------------------------------------------------------------------------------------

/** SHA-256 hex digest of `text` via the Web Crypto API (available in a service worker). Never the text itself. */
async function textHash(text) {
  try {
    const bytes = new TextEncoder().encode(String(text));
    const digest = await crypto.subtle.digest('SHA-256', bytes);
    return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, '0')).join('');
  } catch (err) {
    return ''; // best effort: the ring entry is still written, just without a hash
  }
}

/**
 * Prepends an entry to the ring buffer at `key`, capped at `max`. Never throws. `makeEntry` may be
 * the entry itself, or a (possibly async) function producing it: entering the write QUEUE happens
 * synchronously, before `makeEntry` is awaited, so two calls (e.g. recordAttemptStarted then a later
 * updateAttemptStatus) are always applied in the order they were CALLED, never in the order their
 * own async work (such as hashing the text) happens to finish.
 */
function pushRing(key, makeEntry, max) {
  return enqueueStorage(async () => {
    const entry = typeof makeEntry === 'function' ? await makeEntry() : makeEntry;
    const stored = await chrome.storage.local.get(key);
    const list = Array.isArray(plainMap(stored)[key]) ? plainMap(stored)[key] : [];
    const next = [entry, ...list].slice(0, max);
    await chrome.storage.local.set({ [key]: next });
  }).catch(() => {});
}

/** A fresh id for one updateAttempts entry (so a later updateAttemptStatus can find it again). */
const startAttemptId = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

/**
 * Begins a 'started' updateAttempts entry BEFORE the page is touched (section 13.5 item B): even a
 * browser crash mid-post leaves a durable record that an attempt was made. Never the note text
 * itself, only its SHA-256 hash (computed inside the queued write, see pushRing: this call itself
 * does not need to be awaited for the entry to end up ordered correctly before a later status
 * update - deliberately fire-and-forget, so hashing the text never delays the actual post).
 * @param {string} id @param {string} incidentNumber @param {string} field @param {string} text
 */
function recordAttemptStarted(id, incidentNumber, field, text) {
  return pushRing(UPDATE_ATTEMPTS_KEY, async () => ({
    id, incidentNumber, field, textHash: await textHash(text), at: nowIso(), status: 'started',
  }), UPDATE_ATTEMPTS_MAX);
}

/** Updates a previously started attempt's status in place. A missing id or entry is a silent no-op. */
function updateAttemptStatus(id, status) {
  if (!id) return Promise.resolve();
  return enqueueStorage(async () => {
    const stored = await chrome.storage.local.get(UPDATE_ATTEMPTS_KEY);
    const list = Array.isArray(plainMap(stored)[UPDATE_ATTEMPTS_KEY]) ? plainMap(stored)[UPDATE_ATTEMPTS_KEY] : [];
    const next = list.map((item) => (isObject(item) && item.id === id ? { ...item, status, updatedAt: nowIso() } : item));
    await chrome.storage.local.set({ [UPDATE_ATTEMPTS_KEY]: next });
  }).catch(() => {});
}

/**
 * Appends one fetchLog entry (section 13.5 item E): success/failure, incident number, time, error
 * code - explicitly NEVER ticket content (no field values, no note text). Best effort, never throws.
 * @param {{incidentNumber: string, source: string, ok: boolean, code?: string}} info
 */
function recordFetchLog(info) {
  const entry = {
    incidentNumber: String(info.incidentNumber || ''),
    source: String(info.source || ''),
    ok: Boolean(info.ok),
    code: info.ok ? '' : String(info.code || ''),
    at: nowIso(),
  };
  return pushRing(FETCH_LOG_KEY, entry, FETCH_LOG_MAX);
}

/**
 * Stores a freshly read record, merged with the search bookkeeping of the stored one. A search also
 * becomes `lastIncident`; a refresh only updates `lastIncident` when it already is that incident.
 * @returns {Promise<object>} the record exactly as stored
 */
function saveRecord(incidentNumber, record, source) {
  const task = enqueueStorage(async () => {
    const stored = (await chrome.storage.local.get(STORED_RECORDS)) || {};
    const incidents = plainMap(stored[STORAGE_KEYS.incidents]);
    const at = Number.isNaN(Date.parse(record.fetchedAt)) ? nowIso() : record.fetchedAt;
    const merged = mergeRecordMetadata(incidents[incidentNumber], record, source, at);
    incidents[incidentNumber] = merged;
    const changes = { [STORAGE_KEYS.incidents]: incidents };
    const last = stored[STORAGE_KEYS.lastIncident];
    if (source === 'search' || (isObject(last) && last.incidentNumber === incidentNumber)) {
      changes[STORAGE_KEYS.lastIncident] = merged;
    }
    await chrome.storage.local.set(changes);
    return merged;
  });
  return task.catch((err) => {
    throw new FetchError('EXTRACT_FAILED', `Could not save the incident locally: ${describe(err)}`);
  });
}

/**
 * Marks stored records with `refreshError` (their data stays as it is). Records that are not stored
 * (any more) are ignored. One storage write for the whole batch.
 * @param {{incidentNumber: string, error: {code: string, message: string}}[]} entries
 */
function recordRefreshErrors(entries) {
  if (!entries.length) return Promise.resolve();
  return enqueueStorage(async () => {
    const stored = (await chrome.storage.local.get(STORED_RECORDS)) || {};
    const incidents = plainMap(stored[STORAGE_KEYS.incidents]);
    const at = nowIso();
    const changes = {};
    let last = stored[STORAGE_KEYS.lastIncident];
    for (const { incidentNumber, error } of entries) {
      const marked = withRefreshError(incidents[incidentNumber], error, at);
      if (!marked) continue;
      incidents[incidentNumber] = marked;
      changes[STORAGE_KEYS.incidents] = incidents;
      if (isObject(last) && last.incidentNumber === incidentNumber) {
        last = marked;
        changes[STORAGE_KEYS.lastIncident] = marked;
      }
    }
    if (Object.keys(changes).length) await chrome.storage.local.set(changes);
  });
}

/** A failed refresh keeps the stored data and only remembers why it failed. Never throws. */
async function markRefreshFailed(incidentNumber, err) {
  try {
    await recordRefreshErrors([{ incidentNumber, error: toFailure(err).error }]);
  } catch (writeError) {
    // The refresh failure itself is what the caller reports; this note is best effort.
  }
}

async function runFetch(instance, incidentNumber, source) {
  try {
    await ensureHostPermission(instance);
    const settings = await loadServiceNowSettings();
    const read = await readIncidentPage(instance, incidentNumber, { fieldMapping: settings.fieldMapping });
    assertExtracted(read);
    const { raw } = applyFieldMapping(read, settings.fieldMapping);
    const record = analyse(raw, settings);
    return await saveRecord(incidentNumber, record, source);
  } catch (err) {
    if (source === 'refresh') await markRefreshFailed(incidentNumber, err);
    throw err;
  }
}

// Identical concurrent requests (double click, two popups, a row refresh during "Refresh all") share
// one tab. A search and a refresh of the same incident do not: they book different metadata.
const inflight = new Map();

function fetchOnce(instance, incidentNumber, source) {
  const key = `${instance.origin}|${incidentNumber}|${source}`;
  const running = inflight.get(key);
  if (running) return running;
  const promise = runFetch(instance, incidentNumber, source).finally(() => inflight.delete(key));
  inflight.set(key, promise);
  return promise;
}

function toFailure(err) {
  const known = err instanceof FetchError && ERROR_CODES.includes(err.code);
  return {
    ok: false,
    error: known
      ? { code: err.code, message: err.message }
      : { code: 'EXTRACT_FAILED', message: `Unexpected error: ${describe(err)}` },
  };
}

/**
 * Handle one FETCH_INCIDENT request. Never rejects: failures come back as { ok: false, error }.
 * `source` 'search' (default) books a user search on the record; 'refresh' leaves the search
 * metadata alone and, when it fails, keeps the stored data and only sets record.refreshError.
 * @param {{instanceUrl: string, incidentNumber: string, source?: 'search'|'refresh'}} message
 * @returns {Promise<{ok: true, record: object} | {ok: false, error: {code: string, message: string}}>}
 */
export async function handleFetchRequest(message) {
  let label = 'invalid input';
  try {
    const { instance, incidentNumber, source } = validateRequest(message || {});
    label = incidentNumber;
    const record = await fetchOnce(instance, incidentNumber, source);
    log(label, 'ok');
    return { ok: true, record };
  } catch (err) {
    const failure = toFailure(err);
    log(label, failure.error.code);
    return failure;
  }
}

// ---------------------------------------------------------------------------------------------
// Field discovery and mapping test (PROBE_INCIDENT)
// ---------------------------------------------------------------------------------------------

const INVENTORY_KEYS = ['name', 'label', 'reference', 'readonly', 'hasValue'];

/**
 * Read one incident WITHOUT storing anything, for Diagnostics -> Discover fields and Settings ->
 * Column to field mapping: the form's field inventory (names, labels, flags - no values) plus, per
 * mappable column, the field it would read and the value it shows (the Settings "Test" button).
 * `message.fieldMapping` (optional) tests an unsaved mapping; otherwise the saved one is used.
 * @returns {Promise<{ok:true, result:{inventory:object[], env:object|null, preview:object[], contactPerson:string}}
 *   | {ok:false, error:{code:string, message:string}}>}
 */
export async function handleProbeRequest(message) {
  let label = 'invalid input';
  try {
    const { instance, incidentNumber } = validateRequest({ ...(message || {}), source: 'search' });
    label = incidentNumber;
    await ensureHostPermission(instance);
    const settings = await loadServiceNowSettings();
    const mapping = message && message.fieldMapping !== undefined
      ? normalizeFieldMapping(message.fieldMapping)
      : settings.fieldMapping;
    const read = await readIncidentPage(instance, incidentNumber, { fieldMapping: mapping, collectInventory: true });
    assertExtracted(read);
    const { raw, applied } = applyFieldMapping(read, mapping);
    const record = analyse(raw, settings);
    const inventory = (Array.isArray(read.incident.inventory) ? read.incident.inventory : [])
      .filter((f) => f && typeof f === 'object' && typeof f.name === 'string')
      .map((f) => Object.fromEntries(INVENTORY_KEYS.map((k) => [k, k === 'name' || k === 'label' ? String(f[k] || '') : f[k] === true])));
    log(label, 'probe');
    return {
      ok: true,
      result: {
        inventory,
        env: read.incident.env && typeof read.incident.env === 'object' ? read.incident.env : null,
        preview: mappingPreview(record, applied, mapping),
        contactPerson: record.contactPerson,
      },
    };
  } catch (err) {
    const failure = toFailure(err);
    log(label, failure.error.code);
    return failure;
  }
}

// ---------------------------------------------------------------------------------------------
// Listing the open incidents of the owner's queues (LIST_OPEN_INCIDENTS)
// ---------------------------------------------------------------------------------------------
// ServiceNow's CLASSIC list page (incident_list.do) is opened in ONE background tab and walked page
// by page with sysparm_first_row: the encoded query does the coarse filtering server-side (active,
// not resolved/closed/canceled, the queues), lib/listExtractor.js reads each page's rows by DOM and
// the finer, label-based State filter (lib/openTickets.js stateMatches) runs here. The worker stores
// nothing of the list: the dashboard fetches the returned numbers through FETCH_INCIDENT, the same path
// as a search, and keeps the queue tracking (listed numbers, and the row cells of tickets that failed to
// fetch, in queueTracking.lastErrors) itself.

const listUnreadable = (detail) =>
  new FetchError('LIST_UNREADABLE', detail ? `${MESSAGES.LIST_UNREADABLE} (${detail})` : MESSAGES.LIST_UNREADABLE);

const plainList = (value) => (Array.isArray(value) ? value : []);

/** A range object as the extractor reported it, only when all three parts are sane integers. */
function cleanRange(range) {
  if (!isObject(range)) return null;
  const { first, last, total } = range;
  const ints = [first, last, total].every((n) => Number.isInteger(n) && n >= 0);
  return ints && first <= last && last <= total ? { first, last, total } : null;
}

/**
 * One page as the background uses it, from the frames' answers. The first frame ON THE INSTANCE'S
 * ORIGIN that found a list wins (the classic UI may sit in an iframe of the Next Experience shell, hence
 * allFrames; the origin guard only checks the tab's top-level URL, so a list reported by a frame of any
 * other origin is ignored). A login page in any frame only counts when no frame found a list, because a
 * list proves the session works.
 */
function pickListFrame(results, origin) {
  const answers = plainList(results).map((entry) => (isObject(entry) && isObject(entry.result) ? entry.result : null));
  const found = answers.find((answer) => answer && answer.status === 'ok' && isAllowedInjectionOrigin(answer.origin, origin));
  if (!found) {
    if (answers.some((answer) => answer && answer.status === 'login')) throw loginRequired();
    return null; // no list (yet): the caller decides whether to look again
  }
  const columns = plainList(found.columns).filter((name) => typeof name === 'string');
  const rows = plainList(found.rows).filter(isObject);
  const range = cleanRange(found.range) || parseListRange(typeof found.rangeText === 'string' ? found.rangeText : '');
  // rowCount (when the extractor reports it) counts every data row, also those whose number could not
  // be read: it is the real page size when no range is known, and tells "empty" from "unreadable".
  const rowCount = Number.isInteger(found.rowCount) && found.rowCount > rows.length ? found.rowCount : rows.length;
  return { columns, rows, range, rowCount, columnLabels: cleanTextMap(found.columnLabels) };
}

/**
 * A { field: text } map from a page answer (row cells, column labels): string values only, at most
 * LIST_MAX_CELLS entries, each text whitespace-collapsed and cut to LIST_MAX_CELL_TEXT characters.
 * Anything else becomes {}.
 */
function cleanTextMap(raw) {
  const out = {};
  if (!isObject(raw) || Array.isArray(raw)) return out;
  let count = 0;
  for (const [key, value] of Object.entries(raw)) {
    if (count >= LIST_MAX_CELLS) break;
    if (typeof key !== 'string' || !key || key === '__proto__' || key.length > 200 || typeof value !== 'string') continue;
    out[key] = value.replace(/\s+/g, ' ').trim().slice(0, LIST_MAX_CELL_TEXT);
    count += 1;
  }
  return out;
}

/** One kept ticket of the result: what the list showed for it (the number is already normalised). */
function keptRow(number, row) {
  const text = (value) => (typeof value === 'string' ? value.replace(/\s+/g, ' ').trim().slice(0, LIST_MAX_CELL_TEXT) : '');
  const sysId = typeof row.sysId === 'string' && /^[0-9a-f]{32}$/i.test(row.sysId) ? row.sysId.toLowerCase() : '';
  return { number, sysId, state: text(row.state), assignmentGroup: text(row.assignmentGroup), cells: cleanTextMap(row.cells) };
}

/** Runs lib/listExtractor.js once in every frame of the tab (origin guard first, like every injection). */
async function readListFrames(events, tabId, origin) {
  let results;
  try {
    await assertInjectionOrigin(events, tabId, origin);
    const injection = chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      func: extractListPage,
      args: [{ table: 'incident' }],
    });
    results = await withTimeout(injection, LIST_SCRIPT_MS, () => new FetchError('TIMEOUT', MESSAGES.TIMEOUT));
  } catch (err) {
    const classified = classifyScriptError(err, events, tabId, origin);
    // classifyScriptError words a generic failure for the incident FORM; on the list it is this code.
    throw classified.code === 'EXTRACT_FAILED' ? listUnreadable(describe(err)) : classified;
  }
  return pickListFrame(results, origin);
}

/** One list page, looked at up to LIST_READ_ATTEMPTS times while no frame shows the list yet. */
async function runListExtractor(events, tabId, origin) {
  for (let attempt = 1; ; attempt += 1) {
    const page = await readListFrames(events, tabId, origin);
    if (page) return page;
    if (attempt >= LIST_READ_ATTEMPTS) throw listUnreadable();
    await sleep(LIST_RETRY_MS);
  }
}

/**
 * Sends the SAME tab to the next list page and waits until that page is loaded and stable. The
 * sticky navigation flag is armed before tabs.update: without it, a tab that is still "complete" on
 * the previous page would look settled at once and the previous page would be read twice.
 */
async function navigateListTab(events, tabId, origin, url) {
  const before = await readTab(events, tabId);
  const deadline = Date.now() + TIMEOUTS.pageLoadMs;
  events.watchNavigation(tabId);
  try {
    await chrome.tabs.update(tabId, { url });
  } catch (err) {
    throw tabClosedError(describe(err));
  }
  for (;;) {
    const tab = await readTab(events, tabId);
    if (events.navigated(tabId) || tab.status !== 'complete' || tab.url !== before.url) break;
    const left = deadline - Date.now();
    if (left <= 0) throw new FetchError('TIMEOUT', MESSAGES.TIMEOUT);
    await events.nextEvent(Math.min(POLL_MS, left));
  }
  await waitForSettledTab(events, tabId, origin, deadline);
}

/**
 * Adds one page's rows to the tally: de-duplicated by incident number (a page boundary that shifts
 * while ServiceNow is being edited can repeat a row), State-filtered unless the list shows no State
 * column (then every row is kept: the filter cannot be applied, and dropping everything would be
 * worse), and never past config.maxTickets. Returns how many NEW numbers the page contributed and
 * whether wanted rows were left over because the cap was reached.
 */
function tallyListPage(tally, page, config) {
  // Column labels: the first page that names a column wins (every page of one list has the same header).
  for (const [field, label] of Object.entries(page.columnLabels || {})) {
    if (!Object.hasOwn(tally.columnLabels, field) && Object.keys(tally.columnLabels).length < LIST_MAX_CELLS) tally.columnLabels[field] = label;
  }
  // ... and their order, as an ARRAY: an object's keys come back sorted from executeScript and runtime
  // messaging (Chrome passes them as base::Value dictionaries), so only page.columns keeps the list's order.
  if (!tally.columnOrder.length) {
    tally.columnOrder = page.columns.filter((name) => Object.hasOwn(tally.columnLabels, name)).slice(0, LIST_MAX_CELLS);
  }
  const filterByState = LIST_STATE_COLUMNS.some((name) => page.columns.includes(name));
  let added = 0;
  for (const row of page.rows) {
    const number = normalizeIncidentNumber(row.number);
    if (!number) {
      tally.unreadableRows += 1;
      continue;
    }
    if (tally.seen.has(number)) continue;
    tally.seen.add(number);
    if (filterByState && !stateMatches(row.state, config.states)) {
      tally.listed += 1;
      tally.skippedByState += 1;
      added += 1;
      continue;
    }
    if (tally.numbers.length >= config.maxTickets) return { added, capped: true };
    tally.listed += 1;
    tally.keptByState += 1;
    tally.numbers.push(number);
    tally.rows.push(keptRow(number, row));
    added += 1;
  }
  return { added, capped: false };
}

/** Walks the list pages in one background tab; whatever happens the tab is closed and untracked. */
async function readOpenIncidentList(instance, config, query) {
  const events = createTabEvents();
  const stopKeepAlive = startKeepAlive();
  const tally = {
    numbers: [], seen: new Set(), listed: 0, keptByState: 0, skippedByState: 0, pages: 0, total: null, truncated: false, rows: [], columnLabels: {},
    unreadableRows: 0, columnOrder: [],
  };
  let tabId = null;
  try {
    let firstRow = 1;
    let previousTotal = null;
    let rereads = 0;
    let reread = false;
    events.start();
    const tab = await openIncidentTab(buildIncidentListUrl(instance.origin, query, firstRow));
    tabId = tab.id;
    await trackTab(tabId);
    await waitForSettledTab(events, tabId, instance.origin, Date.now() + TIMEOUTS.pageLoadMs);
    for (;;) {
      const page = await runListExtractor(events, tabId, instance.origin);
      tally.pages += 1;
      if (page.range) tally.total = page.range.total;
      // Data rows whose incident number could not be read: those tickets are missing from the result,
      // so the dashboard must not conclude they left the queue (it treats the run as incomplete).
      tally.unreadableRows += Math.max(0, (Number.isInteger(page.rowCount) ? page.rowCount : 0) - page.rows.length);
      const { added, capped } = tallyListPage(tally, page, config);
      // Data rows but not one usable incident number on the FIRST page: answering "0 open tickets" would
      // be a silent wrong answer, so it is reported as an unreadable list instead.
      if (tally.pages === 1 && page.rowCount > 0 && tally.seen.size === 0) throw listUnreadable('no incident numbers could be read');
      const next = nextFirstRow(firstRow, page.range, page.rowCount);
      if (capped) {
        tally.truncated = true;
        break;
      }
      // The list shrank since the previous page: read this page again from `dropped` rows earlier, so the
      // rows that slid onto the previous page are not skipped (also on the last page).
      const wasReread = reread;
      reread = false;
      const dropped = page.range && previousTotal !== null ? previousTotal - page.range.total : 0;
      if (page.range) previousTotal = page.range.total;
      if (dropped > 0 && page.range.first > 1 && rereads < LIST_MAX_REREADS && tally.pages < LIST_MAX_PAGES
        && tally.numbers.length < config.maxTickets) {
        rereads += 1;
        reread = true;
        firstRow = Math.max(1, page.range.first - dropped);
        await navigateListTab(events, tabId, instance.origin, buildIncidentListUrl(instance.origin, query, firstRow));
        continue;
      }
      if (next === null) break;
      // More pages exist but this run stops here: the cap is full or the page limit is reached.
      if (tally.numbers.length >= config.maxTickets || tally.pages >= LIST_MAX_PAGES) {
        tally.truncated = true;
        break;
      }
      // A page with nothing new would repeat forever. With a known range the server ignored
      // sysparm_first_row while reporting more rows (truncated); without one, a request past the end
      // that ServiceNow answered with the last page again is the most likely cause, i.e. the list is done.
      // (A re-read page may legitimately add nothing: what left the list was further down.)
      if (added === 0 && !wasReread) {
        tally.truncated = page.range !== null;
        break;
      }
      firstRow = next;
      await navigateListTab(events, tabId, instance.origin, buildIncidentListUrl(instance.origin, query, firstRow));
    }
  } finally {
    stopKeepAlive();
    events.stop();
    if (tabId !== null) {
      await closeTab(tabId);
      await untrackTab(tabId);
    }
  }
  const { seen, ...result } = tally;
  return { ...result, query };
}

async function listOpenIncidents(message) {
  const instance = parseInstanceUrl(message.instanceUrl);
  if (!instance.ok) throw new FetchError('INVALID_INPUT', instance.message);
  await ensureHostPermission(instance);
  // An unsaved config from the dashboard wins; otherwise the owner's saved Settings value.
  const raw = message.config ?? (await loadServiceNowSettings()).openTickets;
  const config = normalizeOpenTicketsConfig(raw);
  // Never list the whole instance: without queues there is nothing the owner asked for.
  if (!config.queues.length) throw new FetchError('INVALID_INPUT', 'No queues are set: add them in Settings -> "Open tickets to load".');
  return readOpenIncidentList(instance, config, buildOpenIncidentsQuery(config));
}

/**
 * Handle one LIST_OPEN_INCIDENTS request: the incident numbers of every open ticket of the configured
 * queues, State-filtered, at most config.maxTickets. Never rejects and stores nothing of the list;
 * afterwards it applies the retention setting (pruneByRetention), which may REMOVE old entries. Logs
 * only the subject 'list' and a status code (never a number, a queue or a URL).
 * v0.5: `rows` repeats the kept tickets (same order as `numbers`) with what the list showed for each:
 * sysId, State and Assignment group text, and `cells` ({ field: display text } of the first 20 named
 * columns, each at most 200 characters); `columnLabels` names those columns ({ field: header text }) and
 * `columnOrder` lists them in the list's order (an array, because object keys arrive sorted).
 * `unreadableRows` counts list rows whose incident number could not be read (the dashboard then never
 * marks a ticket "moved out" from this run). The dashboard uses them for queue tracking and to show a ticket that failed to fetch.
 * @param {{instanceUrl: string, config?: object}} message
 * @returns {Promise<{ok: true, result: {numbers: string[], listed: number, keptByState: number,
 *   skippedByState: number, pages: number, total: number|null, truncated: boolean, query: string,
 *   rows: {number: string, sysId: string, state: string, assignmentGroup: string, cells: Object<string,string>}[],
 *   columnLabels: Object<string,string>, columnOrder: string[], unreadableRows: number}}
 *   | {ok: false, error: {code: string, message: string}}>}
 */
export async function handleListOpenIncidents(message) {
  let response;
  try {
    const result = await listOpenIncidents(isObject(message) ? message : {});
    log('list', 'ok');
    response = { ok: true, result };
  } catch (err) {
    response = toFailure(err);
    log('list', response.error.code);
  }
  // A run is about to store many tickets: the moment to drop the ones past the retention period.
  // pruneByRetention never throws, so it cannot turn a listing into a failure.
  await pruneByRetention();
  return response;
}

// ---------------------------------------------------------------------------------------------
// Data retention (Settings -> retentionDays)
// ---------------------------------------------------------------------------------------------

const DAY_MS = 24 * 60 * 60 * 1000;
const FOLLOW_UP_LOG_KEY = FOLLOW_UP_STORAGE_KEYS.log;

/** Milliseconds of an ISO instant, or NaN. */
const instantMs = (value) => (typeof value === 'string' && value ? Date.parse(value) : NaN);

/** When a record was last touched: the newer of its searchedAt / fetchedAt, NaN when neither is a date. */
function lastTouchedMs(record) {
  const times = [instantMs(record.searchedAt), instantMs(record.fetchedAt)].filter((ms) => Number.isFinite(ms));
  return times.length ? Math.max(...times) : NaN;
}

/**
 * Applies Settings -> "Keep data for N days" (serviceNowSettings.retentionDays): stored incidents
 * whose newest searchedAt / fetchedAt is older than N days are removed, and so are follow-up log
 * entries whose `at` is older. 0 (the default) keeps everything. It matters since "Load all open
 * tickets" can store hundreds of tickets per run: without it they would pile up for ever.
 * Deliberately conservative: an entry without a readable date is KEPT (its age is unknown, and data is
 * never removed on a guess), a value that is not the expected shape is left untouched, and nothing
 * is written when nothing is old enough. `lastIncident` goes too when it is one of the removed
 * records, so the popup never shows a ticket the dashboard no longer has. Runs inside the storage
 * write queue (no fetch can save a record between this read and write). Never throws and logs
 * nothing: a failed pruning simply tries again next time.
 * @returns {Promise<{incidents: number, followUps: number}>} how many entries were removed
 */
export async function pruneByRetention() {
  const removed = { incidents: 0, followUps: 0 };
  try {
    const { retentionDays } = await loadServiceNowSettings();
    if (!Number.isInteger(retentionDays) || retentionDays <= 0) return removed;
    const cutoff = Date.now() - retentionDays * DAY_MS;
    await enqueueStorage(async () => {
      const keys = [...STORED_RECORDS, FOLLOW_UP_LOG_KEY];
      const stored = plainMap(await chrome.storage.local.get(keys));
      const changes = {};
      const incidents = stored[STORAGE_KEYS.incidents];
      const gone = new Set();
      if (isObject(incidents)) {
        const kept = {};
        for (const [number, record] of Object.entries(incidents)) {
          if (isObject(record) && lastTouchedMs(record) < cutoff) gone.add(number);
          else kept[number] = record;
        }
        if (gone.size) changes[STORAGE_KEYS.incidents] = kept;
      }
      const followUps = stored[FOLLOW_UP_LOG_KEY];
      if (Array.isArray(followUps)) {
        const kept = followUps.filter((entry) => !(isObject(entry) && instantMs(entry.at) < cutoff));
        if (kept.length !== followUps.length) changes[FOLLOW_UP_LOG_KEY] = kept;
      }
      const last = stored[STORAGE_KEYS.lastIncident];
      const dropLast = isObject(last) && gone.has(last.incidentNumber);
      if (Object.keys(changes).length) await chrome.storage.local.set(changes);
      if (dropLast) await chrome.storage.local.remove(STORAGE_KEYS.lastIncident);
      // Counted only once written: a failed write removed nothing.
      removed.incidents = gone.size;
      if (changes[FOLLOW_UP_LOG_KEY]) removed.followUps = followUps.length - changes[FOLLOW_UP_LOG_KEY].length;
    });
  } catch (err) {
    // Unreadable settings or storage: keep everything; the next startup / listing tries again.
  }
  return removed;
}

// ---------------------------------------------------------------------------------------------
// Ticket update (POST_TICKET_UPDATE)
// ---------------------------------------------------------------------------------------------

const noun = (request) => NOTE_FIELDS[request.field].noun;

const unknownError = (code, request, cause) => new FetchError(code, unknownOutcomeMessage(request.field, cause));

/**
 * A live snapshot of the activity stream, read from the SAME page load, right before Save (section
 * 13.5 item B: the "stale baseline" fix). Storage (worknotes.latest) is never used for this any
 * more: it can be empty, missing or outdated relative to the live page, which is exactly how a
 * pre-existing identical entry could once be mistaken for freshly-posted evidence. This read is
 * purely additive safety information for the later verification step: whatever goes wrong while
 * taking it (login, an unreadable page, a slow activity stream, the tab itself in trouble) degrades
 * to an empty baseline rather than aborting the post - postWorkNote runs its own independent checks
 * (login, form, incident number, editability) and raises the correct failure for those on its own.
 */
async function readActivityBaseline(ctx) {
  const { events, tabId, instance, request } = ctx;
  try {
    const raw = await runExtractor(events, tabId, request.incidentNumber, instance.origin, VERIFY_TIMEOUTS);
    assertExtracted(raw);
    const entries = raw && raw.activity ? raw.activity.entries : null;
    return makeBaseline(entries, request.text, request.field);
  } catch (err) {
    return makeBaseline(null, request.text, request.field);
  }
}

/**
 * A predicate for verifyAgainstBaseline's sanity bound (section 13.5 item B): the chosen entry's own
 * timestamp must be >= postStartedAt - RECENT_ENOUGH_MS. An entry whose time cannot be parsed never
 * fails this check (parsing is a best-effort secondary signal; the key-based baseline comparison is
 * the primary evidence) - it is noted as a limitation, not treated as a reason to distrust the entry.
 *
 * The extension is never told which timezone ServiceNow rendered the activity stream's wall-clock
 * text in (only a date FORMAT is available, not a zone), so this is necessarily a best-effort guess.
 * The browser's own system timezone is the most likely guess (ServiceNow's display timezone usually
 * matches the logged-in user's own locale), but is tried alongside a plain UTC reading: a genuinely
 * fresh entry is accepted once EITHER reading lands within the bound, while a truly stale pre-existing
 * entry (the attack this check defends against) is hours-to-days old and fails under both readings
 * regardless of which guess is "right" - only the single-reading guess was fragile to the exact
 * UTC-offset of the machine/instance pair (observed: false negatives when the two differ by many
 * hours, e.g. a browser in Pacific/Auckland against UTC-rendered ServiceNow text).
 */
function isRecentEnough(postStartedAt) {
  const bound = postStartedAt - RECENT_ENOUGH_MS;
  const timeZones = [...new Set([getSystemTimeZone(), 'UTC'])];
  return (timeRaw) => {
    const text = String(timeRaw === undefined || timeRaw === null ? '' : timeRaw);
    let parseable = false;
    for (const timeZone of timeZones) {
      const parsed = parseServiceNowDateTime(text, { timeZone });
      if (!parsed || !parsed.ok || !(parsed.date instanceof Date) || Number.isNaN(parsed.date.getTime())) continue;
      parseable = true;
      if (parsed.date.getTime() >= bound) return true;
    }
    return !parseable;
  };
}

/**
 * Runs postWorkNote in the page; resolves with the InjectionResult (or null) and rejects on script
 * errors. Origin guard (section 13.5): re-reads the tab and refuses to inject unless it is still on
 * `origin` right now (same TOCTOU protection as the read path; see assertInjectionOrigin).
 */
async function callPostWorkNote(events, tabId, origin, config, timeoutMs) {
  await assertInjectionOrigin(events, tabId, origin);
  const injection = chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    func: postWorkNote,
    args: [config],
  });
  const results = await withTimeout(injection, timeoutMs, () => new ScriptTimeout('the page did not answer in time'));
  return Array.isArray(results) && results[0] ? results[0] : null;
}

function submitConfig(request, origin) {
  return {
    mode: 'submit',
    incidentNumber: request.incidentNumber,
    field: request.field,
    text: request.text,
    dryRun: request.dryRun,
    expectedOrigin: origin,
    timeouts: { formReadyMs: TIMEOUTS.formReadyMs, submitDelayMs: SAVE_DELAY_MS },
  };
}

// Why the submit call itself failed. Before the page answered nothing can have been posted, unless
// the tab vanished or the call hung: then the outcome is unknown.
function classifySubmitError(err, ctx) {
  const { events, tabId, instance, request } = ctx;
  if (err instanceof FetchError) return err; // incl. the origin guard (LOGIN_REQUIRED / PAGE_UNSUPPORTED)
  if (err instanceof ScriptTimeout) {
    return unknownError('TIMEOUT', request, 'The incident page did not answer in time.');
  }
  const text = describe(err);
  if (events.wasClosed(tabId) || /no tab with id|tab was closed|tabs cannot be edited|was removed/i.test(text)) {
    return unknownError('TAB_ERROR', request, 'The incident tab was closed before the page answered.');
  }
  if (/error page|chrome-error/i.test(text)) return new FetchError('TAB_ERROR', `${MESSAGES.LOAD_FAILED} Nothing was posted.`);
  if (/cannot access (the )?contents|extension manifest must request/i.test(text)) {
    return new FetchError('NO_PERMISSION', `${noPermissionMessage(instance.origin)} Nothing was posted.`);
  }
  return new FetchError('EXTRACT_FAILED', `Could not add the ${noun(request)}: ${text}`);
}

/**
 * Runs the page script that sets the field and schedules Save.
 * @returns {Promise<{kind: 'dryrun'|'submitted', confirmed: boolean, dirtyFields?: string[],
 *   editableFields?: string[]|null, warnings?: string[]}>} confirmed is false when the page was
 *   replaced before it could answer (the save most likely started, but nobody confirmed it)
 */
async function submitStep(ctx) {
  const { events, tabId, instance, request } = ctx;
  let first;
  try {
    first = await callPostWorkNote(events, tabId, instance.origin, submitConfig(request, instance.origin), SUBMIT_SCRIPT_MS);
  } catch (err) {
    throw classifySubmitError(err, ctx);
  }
  if (first && first.error) {
    throw new FetchError('EXTRACT_FAILED', `Could not add the ${noun(request)}: ${describe(first.error)}`);
  }
  const raw = first ? first.result : null;
  if (raw === null || raw === undefined) {
    if (request.dryRun) throw new FetchError('EXTRACT_FAILED', `Could not check the ${noun(request)}: the page returned no data.`);
    return { kind: 'submitted', confirmed: false };
  }
  if (!isObject(raw) || typeof raw.status !== 'string') {
    throw new FetchError('EXTRACT_FAILED', `Could not add the ${noun(request)}: the page returned no usable answer.`);
  }
  // Kept for a list-landing reload (section 13.5 item B(d)): the exact sys_id of the incident that
  // was just posted to, so the reload targets it precisely rather than a (re-resolved) number query.
  if (typeof raw.sysId === 'string' && raw.sysId) ctx.sysId = raw.sysId;
  const outcome = interpretSubmit(raw, request.field, request.incidentNumber);
  if (outcome.kind === 'failed') throw new FetchError(outcome.code, outcome.message);
  return {
    kind: outcome.kind,
    confirmed: true,
    dirtyFields: outcome.dirtyFields,
    editableFields: outcome.editableFields,
    warnings: outcome.warnings,
  };
}

async function readTabAfterSubmit(ctx) {
  try {
    return await readTab(ctx.events, ctx.tabId);
  } catch (err) {
    throw unknownError('TAB_ERROR', ctx.request, 'The incident tab was closed after Save was pressed.');
  }
}

// What a failed inspect call says about the page: replaced (navigated), broken, or nothing useful.
function inspectFailure(err, ctx) {
  if (err instanceof ScriptTimeout) return 'navigated';
  // The origin guard refusing to inject means the tab is no longer on the instance: treat it the
  // same as a navigation away (the usual post-Save handling then decides login-required vs unknown).
  if (err instanceof FetchError && (err.code === 'LOGIN_REQUIRED' || err.code === 'PAGE_UNSUPPORTED')) return 'navigated';
  const text = describe(err);
  if (/error page|chrome-error/i.test(text)) {
    throw unknownError('TAB_ERROR', ctx.request, 'The incident page showed an error after Save.');
  }
  if (/cannot access (the )?contents|extension manifest must request|was removed|no tab with id/i.test(text)) {
    return 'navigated'; // another origin (a login), or the document was replaced
  }
  return 'pending';
}

/**
 * One look at the page while no navigation was seen. Updates ctx.wait (navigating, heldSince).
 * Throws SAVE_FAILED when save() threw, or when the page kept the note for BLOCKED_GRACE_MS without
 * the tab loading (re-checked AFTER the inspect, because a slow POST looks the same as a block).
 */
async function inspectAfterSave(ctx) {
  const { events, tabId, instance, request, wait } = ctx;
  let verdict;
  let value = null;
  try {
    const first = await callPostWorkNote(events, tabId, instance.origin, { mode: 'inspect', field: request.field }, INSPECT_TIMEOUT_MS);
    value = first && !first.error ? first.result : null;
    verdict = value === null || value === undefined ? 'navigated' : classifyInspect(value); // null: replaced before it answered
  } catch (err) {
    verdict = inspectFailure(err, ctx);
  }
  if (verdict === 'navigated') {
    wait.navigating = true;
    return;
  }
  if (verdict === 'threw') {
    throw new FetchError('SAVE_FAILED', saveFailedMessage(request.field, request.incidentNumber, value, true));
  }
  if (verdict !== 'held') {
    wait.heldSince = 0;
    return;
  }
  const again = await readTabAfterSubmit(ctx);
  if (hasNavigated({ sticky: events.navigated(tabId), tab: again, urlBefore: ctx.urlBefore })) {
    wait.navigating = true;
    wait.heldSince = 0;
    return;
  }
  if (!wait.heldSince) wait.heldSince = Date.now();
  if (Date.now() - wait.heldSince >= BLOCKED_GRACE_MS) {
    throw new FetchError('SAVE_FAILED', saveFailedMessage(request.field, request.incidentNumber, value, false));
  }
}

/**
 * Waits for the navigation that Save causes and for the page to load. The tab must stay open: closing
 * it right after the page answered cancels the save. Resolves with the loaded tab.
 */
async function waitForSave(ctx) {
  const { events, tabId, request } = ctx;
  const startedAt = Date.now();
  const deadline = startedAt + SAVE_WAIT_MS;
  const wait = { navigating: false, heldSince: 0 };
  ctx.wait = wait;
  let lastInspectAt = 0;
  for (;;) {
    const tab = await readTabAfterSubmit(ctx);
    wait.navigating = wait.navigating || hasNavigated({ sticky: events.navigated(tabId), tab, urlBefore: ctx.urlBefore });
    if (wait.navigating && tab.status === 'complete') return tab;
    if (Date.now() >= deadline) {
      throw unknownError('TIMEOUT', request, `The page did not finish loading within ${SAVE_WAIT_MS / 1000} seconds after Save.`);
    }
    const now = Date.now();
    if (!wait.navigating && now - startedAt >= INSPECT_AFTER_MS && now - lastInspectAt >= POLL_MS) {
      lastInspectAt = now;
      await inspectAfterSave(ctx);
    }
    await events.nextEvent(Math.max(1, Math.min(POLL_MS, deadline - Date.now())));
  }
}

// What a failure while looking at the page after Save means (section 13.5 item B(f)): "NOT saved" is
// claimed ONLY on evidence the POST was refused (save() threw, or the field still holds the text
// past the grace period: both already raise SAVE_FAILED elsewhere, in inspectAfterSave). A
// login-looking page, an off-origin redirect, a timeout or any other inconclusive landing here is
// reported as UNKNOWN, never as a certain failure: the page merely could not be re-read, which says
// nothing about whether the POST itself was accepted (the security review's "NOT-saved-vs-UNKNOWN"
// finding). The error `code` is kept (LOGIN_REQUIRED etc.) for the caller's own hints; only the
// WORDING changes to never overclaim.
function afterSaveFailure(err, request) {
  const code = err instanceof FetchError ? err.code : '';
  if (code === 'TIMEOUT') return unknownError('TIMEOUT', request, 'The page did not finish loading after Save.');
  if (code === 'LOGIN_REQUIRED') {
    return unknownError('LOGIN_REQUIRED', request, 'ServiceNow showed a sign-in-looking or off-origin page after Save.');
  }
  return unknownError('TAB_ERROR', request, 'The page showed an error or was closed after Save.');
}

// True once `pathname` looks like the classic incident form (what buildIncidentUrl opens and the
// sys_id form both end with). Anything else on the SAME origin (a list view, a dashboard the Save
// redirected to, ...) is not assumed to be a failure: reloadIncidentFormIfNeeded below acts on it.
const looksLikeIncidentForm = (pathname) => /\/incident\.do$/i.test(String(pathname || ''));

/**
 * Section 13.5 item B(d): a Save that lands on a list page (or any other non-form, same-origin page)
 * must not be assumed to be a failure - it is reloaded (incident.do?sys_id=<id> when the sys_id is
 * known, else the number query) in the SAME tab and re-verified from there. By the time this runs,
 * waitForSettledTab has already thrown for an off-origin or login-looking landing (see
 * afterSaveFailure), so `tab` here is always still on the instance origin.
 */
async function reloadIncidentFormIfNeeded(ctx, tab) {
  const { instance, request, events, tabId } = ctx;
  let url = null;
  try {
    url = new URL(tab.url);
  } catch (err) {
    return tab; // an unparseable URL is not this function's problem: let the caller read it as-is
  }
  if (url.origin !== instance.origin || looksLikeIncidentForm(url.pathname)) return tab;
  const target = ctx.sysId ? `${instance.origin}/incident.do?sys_id=${encodeURIComponent(ctx.sysId)}` : buildIncidentUrl(instance.origin, request.incidentNumber);
  const beforeUrl = tab.url;
  // Armed BEFORE the reload call (same sticky-flag pattern waitForSave uses for Save's own
  // navigation): waitForSettledTab below only waits for the tab to be "loaded and stable", which is
  // trivially already true for the tab exactly as it is right now (still on the list page). Without
  // this, a tabs.update() that for any reason never actually starts a navigation (closed tab, a
  // worker race, a browser that silently ignores the call) would settle instantly on the SAME old
  // list-page tab and be read as "reloaded successfully" - a false verified:true. The sticky flag
  // (or, failing that, an observed URL change) is the only honest signal that the reload began.
  events.watchNavigation(tabId);
  try {
    await chrome.tabs.update(tabId, { url: target });
    const settled = await waitForSettledTab(events, tabId, instance.origin, Date.now() + POST_SETTLE_MS);
    if (!events.navigated(tabId) && settled.url === beforeUrl) {
      // The reload cannot be confirmed to have happened at all: honestly a timeout, not a silent
      // pass-through of the stale (still-list) page.
      throw new FetchError('TIMEOUT', MESSAGES.TIMEOUT);
    }
    return settled;
  } catch (err) {
    throw afterSaveFailure(err, request);
  }
}

/** Re-reads the incident after Save and verifies the posted text against the live baseline. */
async function verifyAfterSave(ctx, confirmed, warnings) {
  const { events, tabId, instance, request } = ctx;
  let tab;
  try {
    tab = await waitForSettledTab(events, tabId, instance.origin, Date.now() + POST_SETTLE_MS);
    tab = await reloadIncidentFormIfNeeded(ctx, tab);
  } catch (err) {
    throw afterSaveFailure(err, request);
  }
  let raw;
  try {
    raw = await runExtractor(events, tabId, request.incidentNumber, instance.origin, VERIFY_TIMEOUTS);
    assertExtracted(raw);
  } catch (err) {
    const code = err instanceof FetchError ? err.code : '';
    if (['LOGIN_REQUIRED', 'TIMEOUT', 'TAB_ERROR', 'NO_PERMISSION', ''].includes(code)) throw afterSaveFailure(err, request);
    raw = null; // the page loaded but could not be read back: submitted, not verified
  }
  const entries = raw && raw.activity ? raw.activity.entries : null;
  const entry = verifyAgainstBaseline(entries, request.text, request.field, ctx.baseline, isRecentEnough(ctx.postStartedAt));
  if (entry === null && !confirmed) {
    throw unknownError('TAB_ERROR', request, 'The incident page was replaced before it could answer.');
  }
  return postedResult(request.field, entry, warnings);
}

async function submitAndVerify(ctx) {
  const { events, tabId, request } = ctx;
  events.watchNavigation(tabId); // the sticky flag must be armed BEFORE the submit call
  // Durable attempt record (section 13.5 item B): begun here, BEFORE the submit call, so even a
  // crash mid-post leaves a trace. Deliberately not awaited: the write (including hashing the text)
  // must never delay the actual post, and pushRing's queuing guarantees the later status update
  // below is still applied strictly after this one, whichever finishes its own work first.
  let attemptId = '';
  if (!request.dryRun) {
    attemptId = startAttemptId();
    recordAttemptStarted(attemptId, request.incidentNumber, request.field, request.text);
  }
  try {
    ctx.postStartedAt = Date.now();
    const submitted = await submitStep(ctx);
    if (submitted.kind === 'dryrun') return dryRunResult(request.field, submitted);
    await waitForSave(ctx);
    const result = await verifyAfterSave(ctx, submitted.confirmed, submitted.warnings);
    await updateAttemptStatus(attemptId, result.verified ? 'verified' : 'unknown');
    return result;
  } catch (err) {
    if (attemptId) {
      const code = err instanceof FetchError ? err.code : '';
      await updateAttemptStatus(attemptId, code === 'SAVE_FAILED' ? 'refused' : 'unknown');
    }
    throw err;
  }
}

async function runUpdate(instance, request) {
  await ensureHostPermission(instance);
  const events = createTabEvents();
  const stopKeepAlive = startKeepAlive();
  let tabId = null;
  try {
    const deadline = Date.now() + TIMEOUTS.pageLoadMs;
    events.start();
    const tab = await openIncidentTab(buildIncidentUrl(instance.origin, request.incidentNumber));
    tabId = tab.id;
    await trackTab(tabId);
    const loaded = await waitForSettledTab(events, tabId, instance.origin, deadline);
    const ctx = { events, tabId, instance, request, urlBefore: loaded.url, sysId: '' };
    // Verification baseline (section 13.5 item B(e)): read in the SAME page load, before Save, so a
    // pre-existing identical entry can never be mistaken for freshly-posted evidence (the "stale
    // baseline" bug). Dry runs never post, so they never need one.
    if (!request.dryRun) ctx.baseline = await readActivityBaseline(ctx);
    return await submitAndVerify(ctx);
  } finally {
    stopKeepAlive();
    events.stop();
    if (tabId !== null) {
      await closeTab(tabId);
      await untrackTab(tabId);
    }
  }
}

// One update per (instance, incident) at a time. The identical request joins the running one; a
// different one is refused: two saves racing on one ticket could post twice or in the wrong field.
const updating = new Map();

function updateOnce(parsed) {
  const { instance, incidentNumber } = parsed;
  const key = `${instance.origin}|${incidentNumber}`;
  const running = updating.get(key);
  const signature = requestSignature(parsed);
  if (running) {
    if (running.signature === signature) return running.promise;
    throw new FetchError('SAVE_FAILED', `Another update for ${incidentNumber} is still in progress.`);
  }
  const promise = runUpdate(instance, parsed).finally(() => updating.delete(key));
  updating.set(key, { signature, promise });
  return promise;
}

/**
 * Handle one POST_TICKET_UPDATE request: add an Additional comment (customer visible, ServiceNow
 * emails the user) or a work note (internal) to an incident through the user's logged-in session.
 * Never rejects and never retries: a Save is submitted at most once per request.
 * @param {{instanceUrl: string, incidentNumber: string, field: 'comments'|'work_notes', text: string, dryRun: boolean}} message
 * @returns {Promise<{ok: true, result: {status: 'posted'|'dryrun', field: string, dryRun: boolean,
 *   verified: boolean|null, message: string, entry: object|null}} | {ok: false, error: {code: string, message: string}}>}
 */
export async function handleUpdateRequest(message) {
  let label = 'invalid input';
  try {
    const parsed = parseUpdateRequest(message);
    if (parsed.incidentNumber) label = parsed.incidentNumber;
    if (!parsed.ok) throw new FetchError('INVALID_INPUT', parsed.message);
    const result = await updateOnce(parsed);
    log(label, result.dryRun ? 'dryrun' : result.verified ? 'posted' : 'unverified');
    return { ok: true, result };
  } catch (err) {
    const failure = toFailure(err);
    log(label, failure.error.code);
    return failure;
  }
}

// ---------------------------------------------------------------------------------------------
// Refresh of all stored tickets (REFRESH_ALL, browser start)
// ---------------------------------------------------------------------------------------------

const JOB_KEY = FOLLOW_UP_STORAGE_KEYS.refreshJob;
const REFRESH_SETTINGS_KEY = FOLLOW_UP_STORAGE_KEYS.refreshSettings;

// The job is the only state: every step reads it from storage, changes it and writes it back through
// this queue (the loop and CANCEL_REFRESH never overwrite each other). `activeRun` only says that THIS
// worker is running a job: a job in storage without one belongs to a worker that died.
let jobQueue = Promise.resolve();
let activeRun = null;

async function readJob() {
  const stored = await chrome.storage.local.get(JOB_KEY);
  const job = plainMap(stored)[JOB_KEY];
  return isObject(job) ? job : null;
}

/**
 * Applies `change` to the stored job `id` and writes it with a new updatedAt (the dashboard calls a job
 * 'stalled' when that stops moving). Resolves with the new job, or null when the stored job is gone or
 * belongs to another job (the user cleared the data, or a newer job replaced it).
 */
function updateJob(id, change) {
  const run = jobQueue.then(async () => {
    const job = await readJob();
    if (!job || job.id !== id) return null;
    const next = { ...change(job), updatedAt: nowIso() };
    await chrome.storage.local.set({ [JOB_KEY]: next });
    return next;
  });
  jobQueue = run.catch(() => {});
  return run;
}

async function hasPermission(instance) {
  try {
    return Boolean(await chrome.permissions.contains({ origins: [instance.pattern] }));
  } catch (err) {
    return false;
  }
}

/** One refresh of one stored ticket through the same code path as a row's Refresh button. */
async function refreshTicket(instance, incidentNumber) {
  try {
    await fetchOnce(instance, incidentNumber, 'refresh');
    log(incidentNumber, 'ok');
    return { ok: true, code: '', message: '' };
  } catch (err) {
    const { error } = toFailure(err);
    log(incidentNumber, error.code);
    return { ok: false, code: error.code, message: error.message };
  }
}

async function skipTickets(id, incidentNumbers, reason) {
  if (!incidentNumbers.length) return null;
  await recordRefreshErrors(incidentNumbers.map((incidentNumber) => ({ incidentNumber, error: reason })));
  return updateJob(id, (job) => withSkipped(job, incidentNumbers.length));
}

async function finishJob(id, cancelled) {
  return updateJob(id, (job) => withFinished(job, { cancelled: cancelled || job.cancelled === true, now: nowIso() }));
}

/** Waits the pause between two steps (the probe, then each batch of tickets) - not before the first one. */
async function pace(run) {
  if (run.started) await sleep(REFRESH_GAP_MS);
  run.started = true;
}

/** Applies one ticket's outcome to the stored job: counts it and reports any instance-state change. */
async function applyRead(id, origin, incidentNumber, result, state) {
  return updateJob(id, (j) => {
    const next = withRead(j, { ok: result.ok, incidentNumber, code: result.code });
    const message = result.ok || !state || state === 'active' ? '' : result.message;
    return state ? withOrigin(next, origin, state, message, nowIso()) : next;
  });
}

/**
 * Refreshes one instance's tickets AFTER its session-probe ticket already proved it usable (contract
 * 16.6): the rest are fetched in small, bounded-concurrency batches (chunked Promise.all - never
 * unlimited at once) instead of strictly one at a time, so a page of stored tickets comes back to the
 * user faster. Every ticket of a batch is started together, regardless of which one actually answers
 * first (real concurrency races), but outcomes are applied to the job in the batch's own fixed order
 * (the array order Promise.all already preserves) so done/failed/skipped/percent stay arithmetically
 * exact no matter which promise settles first. A login/permission problem found anywhere in a batch
 * stops the NEXT batch from ever starting (those tickets are skipped, untried); tickets already
 * running in the SAME batch as the one that revealed the problem are still seen through to their own
 * real result (per-ticket error isolation) rather than retroactively overwritten as skipped.
 */
async function refreshRemaining(id, origin, instance, tickets, run) {
  for (let start = 0; start < tickets.length; start += REFRESH_CONCURRENCY) {
    const chunk = tickets.slice(start, start + REFRESH_CONCURRENCY);
    await pace(run);
    let job = await updateJob(id, (j) => withCurrent(j, chunk.join(', ')));
    if (!job) return 'stop';
    if (job.cancelled === true) {
      await finishJob(id, true);
      return 'stop';
    }
    const settled = await Promise.all(
      chunk.map((incidentNumber) => refreshTicket(instance, incidentNumber).then((result) => ({ incidentNumber, result }))),
    );
    let instanceDown = null;
    for (const { incidentNumber, result } of settled) {
      const state = stateAfterTicket(result.code);
      job = await applyRead(id, origin, incidentNumber, result, state);
      if (!job) return 'stop';
      if (!instanceDown && state && state !== 'active') instanceDown = { state, result };
    }
    if (instanceDown) {
      await skipTickets(id, tickets.slice(start + chunk.length), skipReason(instanceDown.state, origin, instanceDown.result));
      return 'next';
    }
  }
  return 'next';
}

/**
 * Refreshes the tickets of one instance. The first one is the session probe, run alone: a login page,
 * a missing permission or an unreachable page stops the instance (its other tickets are skipped,
 * never tried in a tab at all). The rest are refreshed concurrently in bounded batches (see
 * refreshRemaining, contract 16.6). Resolves 'next' to go on with the next instance, 'stop' when the
 * job ended.
 */
async function refreshInstance(id, group, run) {
  const { origin, instance, tickets } = group;
  let job = await updateJob(id, (j) => withOrigin(j, origin, 'checking', '', nowIso()));
  if (!job) return 'stop';
  if (!(await hasPermission(instance))) {
    const message = noPermissionMessage(origin);
    await updateJob(id, (j) => withOrigin(j, origin, 'no-permission', message, nowIso()));
    await skipTickets(id, tickets, skipReason('no-permission', origin));
    return 'next';
  }
  const [probe, ...rest] = tickets;
  await pace(run);
  job = await updateJob(id, (j) => withCurrent(j, probe));
  if (!job) return 'stop';
  if (job.cancelled === true) {
    await finishJob(id, true);
    return 'stop';
  }
  const probeResult = await refreshTicket(instance, probe);
  const probeState = stateAfterProbe(probeResult.ok ? null : probeResult.code);
  job = await applyRead(id, origin, probe, probeResult, probeState);
  if (!job) return 'stop';
  if (probeState !== 'active') {
    await skipTickets(id, rest, skipReason(probeState, origin, probeResult));
    return 'next';
  }
  if (!rest.length) return 'next';
  return refreshRemaining(id, origin, instance, rest, run);
}

async function runRefresh(id, plan) {
  const stopKeepAlive = startKeepAlive();
  const run = { started: false };
  try {
    if (plan.capped) log('refresh', `${plan.capped} tickets over the cap of ${REFRESH_MAX} skipped`);
    await skipTickets(id, plan.unusable, UNUSABLE_REASON);
    for (const group of plan.groups) {
      if ((await refreshInstance(id, group, run)) === 'stop') return;
    }
    await finishJob(id, false);
  } catch (err) {
    log('refresh', toFailure(err).error.code);
    try {
      await updateJob(id, (job) => withFinished(withError(job, 'EXTRACT_FAILED'), { cancelled: job.cancelled === true, now: nowIso() }));
    } catch (writeError) {
      // Storage is unusable: the job stays unfinished and the dashboard shows it as stalled.
    }
  } finally {
    stopKeepAlive();
  }
}

async function beginRefresh(reason, run) {
  const stored = await chrome.storage.local.get(STORAGE_KEYS.incidents);
  const plan = planRefresh(plainMap(stored)[STORAGE_KEYS.incidents]);
  const now = nowIso();
  const id = `${Date.parse(now).toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  let job = createJob({ id, reason, now, total: plan.total, capped: plan.capped });
  const nothingToDo = plan.groups.length === 0 && plan.unusable.length === 0;
  if (nothingToDo) job = withFinished(job, { cancelled: false, now });
  await chrome.storage.local.set({ [JOB_KEY]: job });
  if (nothingToDo) {
    activeRun = null;
    return job;
  }
  run.done = runRefresh(id, plan).finally(() => {
    if (activeRun === run) activeRun = null;
  });
  return job;
}

/**
 * Starts a refresh of every stored ticket unless this worker is already running one. A job that a dead
 * worker left unfinished is simply replaced.
 * @param {{reason?: 'startup'|'manual'}} [options]
 * @returns {Promise<{started: boolean, job: object}>} the job as stored at its start, or the running one
 */
export async function startRefreshAll({ reason = 'manual' } = {}) {
  if (activeRun) return { started: false, job: await activeRun.created };
  const run = { created: null, done: null };
  activeRun = run;
  run.created = beginRefresh(reason, run);
  try {
    return { started: true, job: await run.created };
  } catch (err) {
    if (activeRun === run) activeRun = null;
    throw err;
  }
}

/**
 * Asks the running refresh to stop after the ticket it is reading. A job without a running loop (its
 * worker died) is closed at once. Never throws for "nothing to cancel".
 * @returns {Promise<{ok: true}>}
 */
export async function cancelRefresh() {
  const job = await readJob();
  if (!job || isFinished(job)) return { ok: true };
  if (activeRun) {
    await updateJob(job.id, (current) => (isFinished(current) ? current : withCancelRequested(current)));
  } else {
    await updateJob(job.id, (current) => withFinished(current, { cancelled: true, now: nowIso() }));
  }
  return { ok: true };
}

/** Handle one REFRESH_ALL message. Never rejects. */
export async function handleRefreshAll(message) {
  try {
    const reason = isObject(message) && message.reason !== undefined ? message.reason : 'manual';
    if (reason !== 'manual' && reason !== 'startup') throw new FetchError('INVALID_INPUT', MESSAGES.BAD_REASON);
    const { started, job } = await startRefreshAll({ reason });
    return { ok: true, started, job };
  } catch (err) {
    return toFailure(err);
  }
}

/** Handle one CANCEL_REFRESH message. Never rejects. */
export async function handleCancelRefresh() {
  try {
    return await cancelRefresh();
  } catch (err) {
    return toFailure(err);
  }
}

async function refreshOnBrowserStart() {
  let settings = null;
  try {
    settings = plainMap(await chrome.storage.local.get(REFRESH_SETTINGS_KEY))[REFRESH_SETTINGS_KEY];
  } catch (err) {
    settings = null; // unreadable settings: the default (refresh) applies
  }
  if (isObject(settings) && settings.onStartup === false) return;
  await startRefreshAll({ reason: 'startup' });
}

// ---------------------------------------------------------------------------------------------
// Wiring
// ---------------------------------------------------------------------------------------------

function respondOnce(promise, sendResponse) {
  let sent = false;
  const send = (payload) => {
    if (sent) return;
    sent = true;
    try {
      sendResponse(payload);
    } catch (err) {
      // The popup closed before the answer arrived; the record is stored regardless.
    }
  };
  promise.then(send, (err) => send(toFailure(err)));
}

/** PING: which code build this service worker runs (the dashboard warns when it differs from its own). */
export async function handlePing() {
  return { ok: true, build: BUILD_ID };
}

const HANDLERS = {
  PING: handlePing,
  FETCH_INCIDENT: handleFetchRequest,
  PROBE_INCIDENT: handleProbeRequest,
  POST_TICKET_UPDATE: handleUpdateRequest,
  REFRESH_ALL: handleRefreshAll,
  CANCEL_REFRESH: handleCancelRefresh,
  LIST_OPEN_INCIDENTS: handleListOpenIncidents,
};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const type = message ? message.type : undefined;
  if (typeof type !== 'string' || !Object.hasOwn(HANDLERS, type)) return false;
  if (sender && sender.id && chrome.runtime.id && sender.id !== chrome.runtime.id) return false;
  respondOnce(HANDLERS[type](message), sendResponse);
  return true; // the response is sent asynchronously
});

chrome.runtime.onStartup.addListener(() => {
  // Old data goes first, so the startup refresh never spends a tab on a ticket that is then removed.
  pruneByRetention()
    .then(() => refreshOnBrowserStart())
    .catch((err) => log('refresh', toFailure(err).error.code));
});

chrome.action.onClicked.addListener((tab) => {
  openDashboard(tab).catch(() => log('dashboard', 'TAB_ERROR'));
});

closeOrphanTabs();
