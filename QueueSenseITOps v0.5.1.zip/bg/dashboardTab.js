// The toolbar icon opens the dashboard page in a tab: an existing dashboard tab is focused (together
// with its window), otherwise a new tab is created. Stateless; uses the global `chrome` at call time.

/** Path of the dashboard page inside the extension. */
export const DASHBOARD_PATH = 'dashboard/dashboard.html';

// A tab URL pattern ignores the #fragment, so '#view=history' variants match the plain pattern; a
// '?query' is part of the path and needs its own pattern.
function dashboardPatterns(url) {
  return [url, `${url}?*`];
}

// Prefer a dashboard tab in the window where the icon was clicked, else the first one found.
function pickTab(tabs, clicked) {
  const list = Array.isArray(tabs) ? tabs.filter((tab) => tab && typeof tab.id === 'number') : [];
  const sameWindow = clicked && typeof clicked.windowId === 'number' ? list.find((tab) => tab.windowId === clicked.windowId) : null;
  return sameWindow || list[0] || null;
}

async function focusExisting(tab) {
  await chrome.tabs.update(tab.id, { active: true });
  if (typeof tab.windowId === 'number' && chrome.windows && chrome.windows.update) {
    try {
      await chrome.windows.update(tab.windowId, { focused: true });
    } catch (err) {
      // The window vanished or cannot take focus: the tab itself is active already.
    }
  }
}

// A double click must not open two dashboards: a click while one is being opened joins it.
let opening = null;

/**
 * Open the dashboard, or bring the open one to the front.
 * @param {{windowId?: number}} [clickedTab] the tab that was active when the icon was clicked
 * @returns {Promise<'focused'|'created'>}
 */
export function openDashboard(clickedTab) {
  if (!opening) opening = openOnce(clickedTab).finally(() => (opening = null));
  return opening;
}

async function openOnce(clickedTab) {
  const url = chrome.runtime.getURL(DASHBOARD_PATH);
  let existing = null;
  try {
    existing = pickTab(await chrome.tabs.query({ url: dashboardPatterns(url) }), clickedTab);
  } catch (err) {
    existing = null; // cannot look: opening one more tab is better than doing nothing
  }
  if (existing) {
    try {
      await focusExisting(existing);
      return 'focused';
    } catch (err) {
      // The tab was closed meanwhile: open a new one below.
    }
  }
  await chrome.tabs.create({ url, active: true });
  return 'created';
}
