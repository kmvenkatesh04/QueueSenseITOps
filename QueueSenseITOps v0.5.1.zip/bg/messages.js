// Texts the service worker shows to the user (popup and dashboard print them as they are).
// Pure constants, no imports, no chrome.* access.

export const MESSAGES = {
  NOT_FOUND: 'No incident with that number was found, or it is not accessible to you.',
  LOGIN_REQUIRED: 'ServiceNow asked for a login. Log in to ServiceNow in a normal tab, then try again.',
  TIMEOUT: 'Timed out waiting for the incident page to load.',
  PAGE_UNSUPPORTED: 'This page is not the classic incident form (Agent Workspace is not supported yet).',
  BAD_INCIDENT_NUMBER: 'Incident number is invalid. Use INC followed by at least 6 digits, for example INC0012345.',
  LOAD_FAILED: 'The incident page failed to load (network or DNS error). Check the instance URL and your connection.',
  BAD_SOURCE: 'source must be "search" or "refresh".',
  BAD_FIELD: 'field must be "comments" or "work_notes".',
  BAD_DRY_RUN: 'dryRun must be true or false.',
  BAD_REASON: 'reason must be "manual" or "startup".',
  DRY_RUN_OK: 'Dry run OK - nothing was posted',
  VERIFIED: 'Posted and verified in the activity stream.',
  UNVERIFIED: 'Submitted, but the new note was not visible yet. Open the incident to confirm.',
  LIST_UNREADABLE: 'Could not read the ServiceNow incident list page.',
  NO_USABLE_URL: 'The stored incident has no usable ServiceNow address, so it was not refreshed.',
};

/** @param {string} origin */
export function noPermissionMessage(origin) {
  return `Permission to access ${origin} was not granted.`;
}
