// Pure helpers for the bookkeeping that is stored next to an incident record (contract 10.2).
//
// Every successful read replaces the stored record as a whole. Only the search metadata is carried
// over from the previous version; `refreshError` is never carried over (a successful read clears
// it). A FAILED refresh never replaces data: it only adds `refreshError` to the stored record.
// No imports, no chrome.* access, inputs are never mutated.

/** Where a read came from: a user search, or a refresh (startup, "Refresh all", a row's Refresh). */
export const FETCH_SOURCES = Object.freeze(['search', 'refresh']);

const ERROR_MESSAGE_MAX = 300;

const isObject = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);

// An ISO-like string that Date can read; anything else is treated as missing.
function validInstant(value) {
  return typeof value === 'string' && value !== '' && !Number.isNaN(new Date(value).getTime()) ? value : '';
}

const validCount = (value) => Number.isInteger(value) && value >= 0;

/**
 * Merge the metadata of the stored record into a freshly analysed one.
 *   search : searchedAt = at, searchCount + 1, firstSearchedAt kept (else the old searchedAt, else at)
 *   refresh: searchedAt / firstSearchedAt / searchCount stay exactly as stored (absent stays absent)
 * `refreshError` is dropped in both cases.
 * @param {object|undefined|null} existing the stored record (anything else counts as "none")
 * @param {object} record the freshly analysed record
 * @param {'search'|'refresh'} source
 * @param {string} at ISO time of this read
 * @returns {object} a new record
 */
export function mergeRecordMetadata(existing, record, source, at) {
  const merged = { ...record };
  delete merged.refreshError;
  const prior = isObject(existing) ? existing : {};
  const searchedAt = validInstant(prior.searchedAt);
  const first = validInstant(prior.firstSearchedAt);
  const count = validCount(prior.searchCount) ? prior.searchCount : null;
  if (source === 'search') {
    merged.searchedAt = at;
    merged.firstSearchedAt = first || searchedAt || at;
    merged.searchCount = (count === null ? 0 : count) + 1;
    return merged;
  }
  delete merged.searchedAt;
  delete merged.firstSearchedAt;
  delete merged.searchCount;
  if (searchedAt) merged.searchedAt = searchedAt;
  if (first) merged.firstSearchedAt = first;
  if (count !== null) merged.searchCount = count;
  return merged;
}

/**
 * The stored record with `refreshError` set and every other key untouched.
 * @param {*} existing the stored record
 * @param {{code: string, message: string}} error
 * @param {string} at ISO time of the failed refresh
 * @returns {object|null} a new record, or null when there is no stored record to mark
 */
export function withRefreshError(existing, error, at) {
  if (!isObject(existing)) return null;
  return {
    ...existing,
    refreshError: {
      at,
      code: String(error && error.code),
      message: String(error && error.message).slice(0, ERROR_MESSAGE_MAX),
    },
  };
}

/**
 * Whether a message value names a known fetch source. Absent (undefined) means 'search'.
 * @param {*} source
 * @returns {'search'|'refresh'|null} null for anything unknown
 */
export function normalizeSource(source) {
  if (source === undefined) return 'search';
  return typeof source === 'string' && FETCH_SOURCES.includes(source) ? source : null;
}
