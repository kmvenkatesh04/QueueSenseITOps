// Pure logic of the "refresh all stored tickets" job (contract 10.8): which tickets, in which order,
// grouped by ServiceNow instance, and how the persisted job object changes step by step.
// The service worker runs the browser work and stores the job after EVERY step; the job is the only
// state (a restarted worker must never need anything else). No chrome.* access; every reducer
// returns a new job and never mutates its input.
import { normalizeIncidentNumber } from '../lib/analyze.js';
import { parseInstanceUrl } from '../lib/instance.js';
import { MESSAGES, noPermissionMessage } from './messages.js';

/** Most tickets one job refreshes (the newest ones); the rest are reported as skipped. */
export const REFRESH_MAX = 300;

/** Pause between two tickets so the instance is never hammered and the browser stays calm. */
export const REFRESH_GAP_MS = 400;

/** Failed tickets listed in job.errors (the first ones; the counters stay exact). */
export const REFRESH_ERRORS_MAX = 20;

/**
 * Bounded concurrency for one instance's tickets, AFTER the session-probe ticket (contract 16.6): a
 * small, modest worker-pool/chunk size, never unlimited - ServiceNow instances rate-limit and a flood
 * of simultaneous tab/script injections is its own problem. The probe ticket is always run alone first
 * (see background.js's refreshInstance) so a dead/locked-out session is discovered before any of the
 * instance's other tickets open a tab at all.
 */
export const REFRESH_CONCURRENCY = 3;

const isObject = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);

// Newest search first: searchedAt, else fetchedAt (a refresh only moves fetchedAt). No time = last.
function rankOf(record) {
  for (const value of [record.searchedAt, record.fetchedAt]) {
    const time = typeof value === 'string' ? Date.parse(value) : NaN;
    if (Number.isFinite(time)) return time;
  }
  return -Infinity;
}

/**
 * Choose and group the tickets of a refresh job.
 * @param {*} incidents the stored map { INC...: record }
 * @param {number} [max] cap (REFRESH_MAX)
 * @returns {{total: number, capped: number, groups: {origin: string, instance: object, tickets: string[]}[],
 *   unusable: string[]}} total = tickets in the job (<= max), capped = tickets left out because of the cap,
 *   groups = one per instance origin (in order of the newest ticket, tickets newest first, the first
 *   ticket of a group is the session probe), unusable = tickets whose incidentUrl is not a usable address
 */
export function planRefresh(incidents, max = REFRESH_MAX) {
  const ranked = [];
  for (const [key, record] of isObject(incidents) ? Object.entries(incidents) : []) {
    const incidentNumber = normalizeIncidentNumber(key);
    if (!incidentNumber || !isObject(record)) continue;
    const parsed = parseInstanceUrl(record.incidentUrl);
    ranked.push({ incidentNumber, instance: parsed.ok ? parsed : null, rank: rankOf(record) });
  }
  ranked.sort((a, b) => (b.rank === a.rank ? (a.incidentNumber < b.incidentNumber ? -1 : 1) : b.rank > a.rank ? 1 : -1));
  const chosen = ranked.slice(0, max);
  const byOrigin = new Map();
  const unusable = [];
  for (const { incidentNumber, instance } of chosen) {
    if (!instance) {
      unusable.push(incidentNumber);
      continue;
    }
    if (!byOrigin.has(instance.origin)) byOrigin.set(instance.origin, { origin: instance.origin, instance, tickets: [] });
    byOrigin.get(instance.origin).tickets.push(incidentNumber);
  }
  return { total: chosen.length, capped: ranked.length - chosen.length, groups: [...byOrigin.values()], unusable };
}

// ---------------------------------------------------------------------------------------------
// The persisted job
// ---------------------------------------------------------------------------------------------

/**
 * A fresh job. `done` counts tickets that were read (successfully or not), `failed` those among them
 * that failed, `skipped` tickets that were not read (login/permission/address problems, and the
 * `capped` ones beyond the cap), so for a finished job done + skipped - capped === total.
 * @param {{id: string, reason: 'startup'|'manual', now: string, total: number, capped: number}} fields
 */
export function createJob({ id, reason, now, total, capped }) {
  return {
    id,
    reason,
    startedAt: now,
    updatedAt: now,
    finishedAt: null,
    cancelled: false,
    total,
    done: 0,
    failed: 0,
    skipped: capped,
    capped,
    current: '',
    origins: {},
    errors: [],
  };
}

/** @param {*} job @returns {boolean} true once the job has a finish time */
export function isFinished(job) {
  return isObject(job) && typeof job.finishedAt === 'string' && job.finishedAt !== '';
}

export const withCurrent = (job, incidentNumber) => ({ ...job, current: incidentNumber });

export const withCancelRequested = (job) => ({ ...job, cancelled: true });

/** Marks the state of one instance: 'checking' | 'active' | 'login-required' | 'no-permission' | 'error'. */
export function withOrigin(job, origin, state, message, now) {
  return { ...job, origins: { ...job.origins, [origin]: { state, checkedAt: now, message: message || '' } } };
}

/** One ticket was read: counts it, remembers the first REFRESH_ERRORS_MAX failures. */
export function withRead(job, { ok, incidentNumber, code }) {
  const errors = ok || job.errors.length >= REFRESH_ERRORS_MAX ? job.errors : [...job.errors, { incidentNumber, code }];
  return { ...job, done: job.done + 1, failed: job.failed + (ok ? 0 : 1), errors, current: '' };
}

/** Something outside one ticket went wrong (kept in the same list as the failed tickets). */
export function withError(job, code) {
  const errors = job.errors.length >= REFRESH_ERRORS_MAX ? job.errors : [...job.errors, { incidentNumber: job.current || '', code }];
  return { ...job, errors };
}

/** `count` tickets will not be read. */
export const withSkipped = (job, count) => ({ ...job, skipped: job.skipped + count });

/** The job is over (finished, or cancelled before it was). */
export const withFinished = (job, { cancelled, now }) => ({ ...job, finishedAt: now, cancelled, current: '' });

// ---------------------------------------------------------------------------------------------
// Session state of one instance
// ---------------------------------------------------------------------------------------------

/**
 * The session state to record after the probe (the first ticket of an instance) failed or not.
 * An unreachable page (TAB_ERROR, TIMEOUT) stops the instance as well: its other tickets would fail
 * the same way. Anything else (the ticket was deleted, a changed page) proves a page loaded: active.
 * @param {string|null} code error code of the probe, null when it succeeded
 * @returns {'active'|'login-required'|'no-permission'|'error'}
 */
export function stateAfterProbe(code) {
  if (code === 'LOGIN_REQUIRED') return 'login-required';
  if (code === 'NO_PERMISSION') return 'no-permission';
  if (code === 'TAB_ERROR' || code === 'TIMEOUT') return 'error';
  return 'active';
}

/**
 * The session state to record when a later ticket of an active instance failed: only a lost login or a
 * lost permission changes it (null = stay active). The remaining tickets are skipped then.
 * @param {string} code
 * @returns {'login-required'|'no-permission'|null}
 */
export function stateAfterTicket(code) {
  if (code === 'LOGIN_REQUIRED') return 'login-required';
  if (code === 'NO_PERMISSION') return 'no-permission';
  return null;
}

/**
 * The refreshError to store on tickets that are skipped because their instance cannot be used.
 * @param {'login-required'|'no-permission'|'error'} state
 * @param {string} origin
 * @param {{code: string, message: string}} [probe] the failed probe, for state 'error'
 * @returns {{code: string, message: string}}
 */
export function skipReason(state, origin, probe) {
  if (state === 'login-required') return { code: 'LOGIN_REQUIRED', message: MESSAGES.LOGIN_REQUIRED };
  if (state === 'no-permission') return { code: 'NO_PERMISSION', message: noPermissionMessage(origin) };
  const code = probe && probe.code ? probe.code : 'TAB_ERROR';
  return { code, message: `Not refreshed: ${probe && probe.message ? probe.message : 'the instance could not be reached.'}` };
}

/** The refreshError of a ticket whose stored address cannot be used. */
export const UNUSABLE_REASON = Object.freeze({ code: 'INVALID_INPUT', message: MESSAGES.NO_USABLE_URL });
