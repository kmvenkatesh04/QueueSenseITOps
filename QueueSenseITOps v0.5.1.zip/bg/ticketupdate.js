// Pure decisions of the POST_TICKET_UPDATE flow (adding an Additional comment or a work note to an
// incident). The service worker does the browser work (tabs, executeScript, waiting); everything
// that can be decided from plain data lives here so it can be tested without a browser.
//
// Honesty rules: "saved" is only ever claimed with evidence (the text found in the activity stream),
// "not saved" only when the page or the server said so, and everything else is reported as UNKNOWN.
import { normalizeIncidentNumber } from '../lib/analyze.js';
import { validateNoteText } from '../lib/followup.js';
import { parseInstanceUrl } from '../lib/instance.js';
import { MESSAGES } from './messages.js';

/** The two journal fields a ticket update can write, with the words used in messages. */
export const NOTE_FIELDS = Object.freeze({
  comments: Object.freeze({ label: 'Additional comments', noun: 'comment', kind: /comment/i, other: 'work_notes' }),
  work_notes: Object.freeze({ label: 'Work notes', noun: 'work note', kind: /work\s*note/i, other: 'comments' }),
});

/** How many of the newest activity entries are searched for the posted text. */
export const VERIFY_ENTRIES = 5;

/** How many characters of the posted text identify its entry in the activity stream. */
export const MATCH_PREFIX_CHARS = 80;

const ENTRY_TEXT_MAX = 500;
const PAGE_MESSAGE_MAX = 300;

const isObject = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);

/** @param {*} field @returns {boolean} */
export function isNoteField(field) {
  return typeof field === 'string' && Object.hasOwn(NOTE_FIELDS, field);
}

/**
 * Validate a POST_TICKET_UPDATE message. dryRun must be an explicit boolean: a missing or truthy
 * value must never decide between "check only" and "really post".
 * @param {*} message
 * @returns {{ok: true, instance: object, incidentNumber: string, field: string, text: string, dryRun: boolean}
 *   | {ok: false, message: string, incidentNumber: string}} incidentNumber is '' until it was valid
 */
export function parseUpdateRequest(message) {
  const input = isObject(message) ? message : {};
  const instance = parseInstanceUrl(input.instanceUrl);
  if (!instance.ok) return { ok: false, message: instance.message, incidentNumber: '' };
  const incidentNumber = normalizeIncidentNumber(input.incidentNumber);
  if (!incidentNumber) return { ok: false, message: MESSAGES.BAD_INCIDENT_NUMBER, incidentNumber: '' };
  const fail = (text) => ({ ok: false, message: text, incidentNumber });
  if (!isNoteField(input.field)) return fail(MESSAGES.BAD_FIELD);
  if (typeof input.dryRun !== 'boolean') return fail(MESSAGES.BAD_DRY_RUN);
  const text = validateNoteText(input.text, NOTE_FIELDS[input.field].noun);
  if (!text.ok) return fail(text.message);
  return { ok: true, instance, incidentNumber, field: input.field, text: text.text, dryRun: input.dryRun };
}

/** Two requests are "the same update" when field, cleaned text and dry-run flag all match. */
export function requestSignature({ field, text, dryRun }) {
  return JSON.stringify([field, text, dryRun]);
}

// ---------------------------------------------------------------------------------------------
// What the page said
// ---------------------------------------------------------------------------------------------

const failed = (code, message) => ({ kind: 'failed', code, message });

// lib/worknote.js echoes the field it handled; a script that predates `field` only knows work notes.
const echoedField = (raw) => (raw.field === undefined ? 'work_notes' : raw.field);

const clip = (text) => String(text === undefined || text === null ? '' : text).slice(0, PAGE_MESSAGE_MAX);

/** Plain strings of `value`, or [] (junk/missing never escapes into the result). */
const stringsOf = (value) => (Array.isArray(value) ? value.filter((item) => typeof item === 'string') : []);

/** Like stringsOf, but a non-array stays null (section 13.5 item B: editableFields can be "unknown"). */
const stringsOrNull = (value) => (Array.isArray(value) ? value.filter((item) => typeof item === 'string') : null);

/**
 * Interpret the answer of postWorkNote({ mode: 'submit' }).
 * @param {{status: string, message?: string, field?: string, dirtyFields?: string[],
 *           editableFields?: string[]|null, warnings?: string[]}} raw
 * @param {string} field requested field
 * @param {string} incidentNumber
 * @returns {{kind: 'dryrun', dirtyFields: string[], editableFields: string[]|null, warnings: string[]}
 *   | {kind: 'submitted', warnings: string[]} | {kind: 'failed', code: string, message: string}}
 */
export function interpretSubmit(raw, field, incidentNumber) {
  const { label, noun } = NOTE_FIELDS[field];
  if ((raw.status === 'dryrun' || raw.status === 'submitted') && echoedField(raw) !== field) {
    return failed('EXTRACT_FAILED', `The page script answered for "${echoedField(raw)}" instead of "${field}": reload the extension and try again.`);
  }
  switch (raw.status) {
    case 'dryrun':
      // Write safety (section 13.5 item B): the dry run reports the dirty fields and the editable
      // list it found, so the caller can show a warning - it never refuses by itself.
      return { kind: 'dryrun', dirtyFields: stringsOf(raw.dirtyFields), editableFields: stringsOrNull(raw.editableFields), warnings: stringsOf(raw.warnings) };
    case 'submitted':
      return { kind: 'submitted', warnings: stringsOf(raw.warnings) };
    case 'login':
      return failed('LOGIN_REQUIRED', MESSAGES.LOGIN_REQUIRED);
    case 'unsupported':
      return failed('PAGE_UNSUPPORTED', MESSAGES.PAGE_UNSUPPORTED);
    case 'notfound':
      return failed('NOT_FOUND', MESSAGES.NOT_FOUND);
    case 'readonly':
      return failed('NOT_EDITABLE', `${label} cannot be added to ${incidentNumber}: the field is read-only or missing on this form (the incident may be closed or restricted).`);
    case 'dirty':
      // Write safety (section 13.5 item B): the page itself refused before anything was touched
      // (another field changed since it was rendered, or the other journal field already holds
      // text). raw.message already names the field(s); nothing was written on either side.
      return failed('SAVE_FAILED', clip(raw.message) || `${label} was not saved on ${incidentNumber}: the page refused the post.`);
    case 'invalid':
      return failed('INVALID_INPUT', `The ${noun} was rejected: ${clip(raw.message)}`);
    case 'error':
      return failed('EXTRACT_FAILED', `Could not add the ${noun}: ${clip(raw.message) || 'unknown error'}`);
    default:
      return failed('EXTRACT_FAILED', `Could not add the ${noun}: unexpected status "${clip(raw.status)}".`);
  }
}

/**
 * True when the tab shows that the Save started a navigation: ANY of the sticky flag set by a
 * tabs.onUpdated listener that was armed before the submit, status 'loading', or a URL that differs
 * from the one before. No particular final URL is expected (ServiceNow decides where Save lands).
 * @param {{sticky: boolean, tab: {status?: string, url?: string}, urlBefore: string}} state
 */
export function hasNavigated({ sticky, tab, urlBefore }) {
  if (sticky === true) return true;
  if (tab.status === 'loading') return true;
  return typeof tab.url === 'string' && tab.url !== '' && tab.url !== urlBefore;
}

/**
 * Classify the answer of postWorkNote({ mode: 'inspect' }), an instant read of the page after Save:
 *   'navigated' the call ran in a NEW document (status 'error', sysId '')
 *   'threw'     g_form.save() threw
 *   'pending'   the save timer has not fired yet (or another transient error): keep waiting
 *   'held'      save() ran and the page still holds the text: blocked/rejected, OR a slow POST in flight
 *   'gone'      the text left the field without a navigation
 *   'unknown'   not an inspect answer
 * @param {*} value
 * @returns {'navigated'|'threw'|'pending'|'held'|'gone'|'unknown'}
 */
export function classifyInspect(value) {
  if (!isObject(value) || typeof value.status !== 'string') return 'unknown';
  if (value.status === 'error') {
    if (value.sysId === '') return 'navigated';
    return /threw/i.test(String(value.message)) ? 'threw' : 'pending';
  }
  if (value.status === 'submitted') return value.fieldHasText === true ? 'held' : 'gone';
  return 'unknown';
}

// ---------------------------------------------------------------------------------------------
// Messages
// ---------------------------------------------------------------------------------------------

function pageDetails(inspected) {
  const alerts = Array.isArray(inspected && inspected.alerts) ? inspected.alerts.map(clip).filter(Boolean) : [];
  const banner = /Form message: .*$/s.exec(String(inspected && inspected.message));
  const parts = [];
  if (alerts.length) parts.push(`Message from the page: ${alerts.map((alert) => `"${alert}"`).join('; ')}.`);
  if (banner) parts.push(banner[0]);
  return parts.join(' ');
}

// 'g_form.save() threw: boom. Page message: "x". Form message: "y".' -> 'g_form.save() threw: boom'
function thrownText(message) {
  return clip(String(message).replace(/\s*(?:Page|Form) message:.*$/s, '')).replace(/[.\s]+$/, '');
}

/**
 * Text of SAVE_FAILED when ServiceNow blocked the save or save() threw.
 * @param {string} field
 * @param {string} incidentNumber
 * @param {{alerts?: string[], message?: string}} inspected the inspect answer
 * @param {boolean} threw true when g_form.save() threw
 */
export function saveFailedMessage(field, incidentNumber, inspected, threw) {
  const { noun } = NOTE_FIELDS[field];
  const reason = threw ? `Save threw an error (${thrownText(inspected.message)})` : 'ServiceNow blocked or rejected the save';
  const details = pageDetails(inspected);
  return `The ${noun} was not saved on ${incidentNumber}: ${reason}.${details ? ` ${details}` : ''}`;
}

/**
 * Text for every outcome that cannot be known (error page after Save, timeout, tab closed).
 * @param {string} field
 * @param {string} cause what was observed, a full sentence
 */
export function unknownOutcomeMessage(field, cause) {
  return `${cause} It is UNKNOWN whether the ${NOTE_FIELDS[field].noun} was saved: open the incident to check before posting again.`;
}

/** Text of LOGIN_REQUIRED after Save: the POST was answered with a login page, so nothing was saved. */
export function loginAfterSaveMessage(field) {
  return `ServiceNow asked for a login while saving, so the ${NOTE_FIELDS[field].noun} was NOT saved. Log in to ServiceNow in a normal tab, then try again.`;
}

// ---------------------------------------------------------------------------------------------
// Finding the posted text in the activity stream
// ---------------------------------------------------------------------------------------------

/** Collapses every whitespace run to one space and trims. */
export function normalizeForMatch(value) {
  return String(value === undefined || value === null ? '' : value).replace(/\s+/g, ' ').trim();
}

const entryKey = (entry) =>
  [normalizeForMatch(entry.author), String(entry.timeRaw === undefined ? '' : entry.timeRaw).trim(), normalizeForMatch(entry.text).slice(0, MATCH_PREFIX_CHARS)].join('|');

function kindOf(entry, field) {
  const kind = normalizeForMatch(entry.kind);
  if (NOTE_FIELDS[field].kind.test(kind)) return 'same';
  if (NOTE_FIELDS[NOTE_FIELDS[field].other].kind.test(kind)) return 'other';
  return 'unknown';
}

/**
 * Find the entry that the update just created among the newest activity entries: the first
 * MATCH_PREFIX_CHARS characters of the posted text (whitespace-normalised) must be the start of the
 * entry's text. An entry whose kind matches the field is preferred, an entry of unrecognised kind is
 * accepted, an entry of the OTHER kind never is. Entries that were already stored before the post
 * (same author, time and text) are ignored: a follow-up template is often posted twice, and the old
 * copy must not count as proof that the new one was saved.
 * @param {*} entries activity entries of the re-read incident, newest first
 * @param {string} text the posted text
 * @param {string} field 'comments' | 'work_notes'
 * @param {*} [previous] entries stored before the post (worknotes.latest)
 * @returns {{author: string, timeRaw: string, text: string, kind: string}|null}
 */
export function findPostedEntry(entries, text, field, previous) {
  if (!Array.isArray(entries) || !isNoteField(field)) return null;
  const needle = normalizeForMatch(text).slice(0, MATCH_PREFIX_CHARS);
  if (!needle) return null;
  const known = new Set((Array.isArray(previous) ? previous : []).filter(isObject).map(entryKey));
  const matches = entries
    .slice(0, VERIFY_ENTRIES)
    .filter(isObject)
    .filter((entry) => normalizeForMatch(entry.text).startsWith(needle))
    .filter((entry) => !known.has(entryKey(entry)));
  const chosen = matches.find((entry) => kindOf(entry, field) === 'same') || matches.find((entry) => kindOf(entry, field) === 'unknown');
  if (!chosen) return null;
  const copy = (value) => (value === undefined || value === null ? '' : String(value));
  return { author: copy(chosen.author), timeRaw: copy(chosen.timeRaw), text: copy(chosen.text).slice(0, ENTRY_TEXT_MAX), kind: copy(chosen.kind) };
}

// ---------------------------------------------------------------------------------------------
// Verification baseline (section 13.5 item B: the "stale baseline" fix)
// ---------------------------------------------------------------------------------------------
//
// findPostedEntry (above) only excludes entries that match something already seen in STORAGE
// (worknotes.latest), which can be empty, missing or outdated relative to the live page at the
// moment of the post - exactly the bug the security review found (a pre-existing identical entry
// on the page, unknown to storage, could be mistaken for freshly-posted evidence). The fix is to
// stop trusting storage for this and instead snapshot the activity stream from the SAME page load,
// right before Save runs: makeBaseline() takes that snapshot, verifyAgainstBaseline() re-checks the
// post-save read against it. "Verified" then requires either (i) an entry whose key was not in that
// baseline, or (ii) a higher count of entries matching the posted text than the baseline had -
// never merely "the text is somewhere in the stream" (which a stale/pre-existing identical entry
// would also satisfy).

/** How many of the newest baseline entries' keys are remembered (section 13.5 item B: "first ~10"). */
export const BASELINE_KEYS = 10;

/**
 * Snapshot of the activity stream taken BEFORE a real post, in the same page load. `identicalCount`
 * is computed over every entry the caller read (not only the first BASELINE_KEYS), so a stale
 * identical entry sitting further back in the stream is still caught by the "no increase" rule.
 * @param {*} entries activity entries as read from the live page before Save (newest first), or null
 * @param {string} text the text about to be posted
 * @param {string} field 'comments' | 'work_notes'
 * @returns {{count: number, keys: string[], identicalCount: number}}
 */
export function makeBaseline(entries, text, field) {
  const list = Array.isArray(entries) ? entries.filter(isObject) : [];
  const needle = isNoteField(field) ? normalizeForMatch(text).slice(0, MATCH_PREFIX_CHARS) : '';
  const identicalCount = needle ? list.filter((entry) => normalizeForMatch(entry.text).startsWith(needle)).length : 0;
  return { count: list.length, keys: list.slice(0, BASELINE_KEYS).map(entryKey), identicalCount };
}

/**
 * Decide whether the post is verified against a LIVE baseline taken before Save (section 13.5 item
 * B). Unlike findPostedEntry's storage-sourced `previous`, this baseline reflects the exact page the
 * post was attempted on, so a pre-existing identical entry is correctly excluded even when nothing
 * was ever stored locally for this incident.
 *   (i)  an entry matching the posted text whose key is NOT among the baseline's recorded keys, or
 *   (ii) the count of entries matching the posted text increased versus the baseline,
 *   AND (both cases) the chosen entry passes `isRecentEnough(timeRaw)` - a sanity bound (section
 *   13.5: the entry's time must be >= post-start minus ~10 minutes). An entry that fails this bound
 *   is exactly the "stale baseline" shape (old text, old timestamp) and must not verify.
 * @param {*} entries activity entries of the re-read incident, newest first
 * @param {string} text the posted text
 * @param {string} field 'comments' | 'work_notes'
 * @param {{count: number, keys: string[], identicalCount: number}} baseline from makeBaseline()
 * @param {(timeRaw: string) => boolean} [isRecentEnough] default: always true (no bound applied)
 * @returns {{author: string, timeRaw: string, text: string, kind: string}|null}
 */
export function verifyAgainstBaseline(entries, text, field, baseline, isRecentEnough) {
  if (!Array.isArray(entries) || !isNoteField(field)) return null;
  const needle = normalizeForMatch(text).slice(0, MATCH_PREFIX_CHARS);
  if (!needle) return null;
  const baseKeys = new Set(baseline && Array.isArray(baseline.keys) ? baseline.keys : []);
  const baselineIdentical = baseline && Number.isFinite(baseline.identicalCount) ? baseline.identicalCount : 0;
  const matchesAll = entries.filter(isObject).filter((entry) => normalizeForMatch(entry.text).startsWith(needle));
  const afterIdentical = matchesAll.length;
  const matches = entries.slice(0, VERIFY_ENTRIES).filter(isObject).filter((entry) => normalizeForMatch(entry.text).startsWith(needle));
  const fresh = matches.filter((entry) => !baseKeys.has(entryKey(entry)));
  // (i) a genuinely new entry, by key; else (ii) fall back to the newest matching entry when the
  // count increased (activity streams are newest-first, so the new entry is the first candidate).
  const candidates = fresh.length ? fresh : (afterIdentical > baselineIdentical ? matches : []);
  const check = typeof isRecentEnough === 'function' ? isRecentEnough : () => true;
  const eligible = candidates.filter((entry) => check(entry.timeRaw));
  const chosen = eligible.find((entry) => kindOf(entry, field) === 'same') || eligible.find((entry) => kindOf(entry, field) === 'unknown');
  if (!chosen) return null;
  const copy = (value) => (value === undefined || value === null ? '' : String(value));
  return { author: copy(chosen.author), timeRaw: copy(chosen.timeRaw), text: copy(chosen.text).slice(0, ENTRY_TEXT_MAX), kind: copy(chosen.kind) };
}

// ---------------------------------------------------------------------------------------------
// Result shapes
// ---------------------------------------------------------------------------------------------

/**
 * @param {string} field
 * @param {{dirtyFields?: string[], editableFields?: string[]|null, warnings?: string[]}} [extra]
 *   section 13.5 item B: what the page found, for the caller to show as a warning. Never a refusal.
 */
export function dryRunResult(field, extra = {}) {
  return {
    status: 'dryrun',
    field,
    dryRun: true,
    verified: null,
    message: MESSAGES.DRY_RUN_OK,
    entry: null,
    dirtyFields: stringsOf(extra.dirtyFields),
    editableFields: stringsOrNull(extra.editableFields),
    warnings: stringsOf(extra.warnings),
  };
}

/**
 * @param {string} field
 * @param {object|null} entry the verified entry, or null when it was not (yet) visible
 * @param {string[]} [warnings] e.g. "field not listed in getEditableFields() but allowed" (section 13.5 item B)
 */
export function postedResult(field, entry, warnings = []) {
  return {
    status: 'posted',
    field,
    dryRun: false,
    verified: entry !== null,
    message: entry !== null ? MESSAGES.VERIFIED : MESSAGES.UNVERIFIED,
    entry,
    warnings: stringsOf(warnings),
  };
}
