// Auto refresh of "Load all open tickets" (v0.5) and the one place the rest of the page asks about a
// run: whether one is going on, how far it got, when the next automatic one is due, and why automatic
// runs are paused. The Overview (auto refresh controls, "Refresh now"), the Fetch errors tab ("Retry")
// and anything else import ONLY this module for it.
//
// Split of work:
//   - dashboard/opentickets.js owns THE run function (header button, auto refresh and retry all go
//     through it: listing, fetching, retry rounds, re-check, queue tracking, the progress panel). It
//     registers itself here at load time (registerOpenTicketsRunner) and starts the scheduler from
//     wireLoadOpenTickets(), so this module never imports it: no import cycle, and the pure helpers
//     below load in node with no DOM at all (tests/autorefresh.test.mjs).
//   - This module keeps the run's status (reportOpenLoadState), the auto refresh settings as last
//     saved (noteAutoRefreshConfig, fed from the Settings paint), the pause reason, and the scheduler.
//
// The scheduler lives in the dashboard page itself (chrome.alarms is not used): auto refresh runs while
// ANY dashboard tab is open. Every CHECK_INTERVAL_MS it asks a cheap, synchronous question first
// (enabled? not running? due by the last run in state.data.queueTracking?) and only when the answer is
// "due" reads queueTracking from storage once more, because another dashboard tab may have finished a
// run a moment ago, or the page may not have read storage yet. Runs across tabs are kept apart by a Web
// Lock (withLoadLock, 'snic-open-tickets-load'); when another tab holds it the status says so.
//
// "Due" means: enabled, nothing running, and now >= (the newer of the last recorded run and this tab's
// last attempt) + the interval. The last recorded run is queueTracking.runs[0].at, shared by every tab
// through storage; the last attempt covers a run that recorded nothing (the list failed, a login page)
// so a failing run is not retried every 30 seconds. Enabled with no run at all: due at once.
//
// An automatic run never asks for a permission, never moves focus, never switches view and never resets
// the Tickets filters (opentickets.js enforces that); this module only decides WHEN.
import * as openTicketsLib from '../lib/openTickets.js';
import { state } from './state.js';
import { KEY, storageGet } from './store.js';

// ---------------------------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------------------------

const FALLBACK_MINUTES = Object.freeze([15, 30, 45, 60, 75, 90, 105, 120]);

/** The intervals a person can choose, in minutes (lib/openTickets.js owns the list). */
export const AUTO_REFRESH_MINUTES = Array.isArray(openTicketsLib.AUTO_REFRESH_MINUTES) && openTicketsLib.AUTO_REFRESH_MINUTES.length
  ? openTicketsLib.AUTO_REFRESH_MINUTES
  : FALLBACK_MINUTES;

const libInt = (value, fallback) => (Number.isInteger(value) && value >= 0 ? value : fallback);

/** Default interval when nothing usable is saved. */
export const DEFAULT_AUTO_REFRESH_MINUTES = libInt(openTicketsLib.DEFAULT_AUTO_REFRESH_MINUTES, 60);
/** How often the scheduler asks "is a run due?". */
export const CHECK_INTERVAL_MS = 30 * 1000;
/** The first check after the page starts: late enough for the page to have read storage. */
export const FIRST_CHECK_MS = 5 * 1000;
/** Automatic retry rounds for failed tickets when Settings has no usable value. */
export const DEFAULT_RETRY_ROUNDS = libInt(openTicketsLib.DEFAULT_RETRY_ROUNDS, 2);
/** Upper bound of openTickets.retryRounds. */
export const MAX_RETRY_ROUNDS = libInt(openTicketsLib.MAX_RETRY_ROUNDS, 5);
/** Tickets retried at the same time (gentler than the main pass: these already failed once). */
export const RETRY_CONCURRENCY = 2;
/** Pause before each retry round: a busy instance gets a moment to recover. */
export const RETRY_PAUSE_MS = 3000;
/** Web Lock name: one run at a time across every dashboard tab of this browser profile. */
export const LOAD_LOCK_NAME = 'snic-open-tickets-load';
/** Progress-only status changes reach listeners at most this often (phase changes go out at once). */
const PROGRESS_EMIT_MS = 1000;

/** Sentences of the pause reasons (also used by tests and by opentickets.js). */
export const PAUSE_TEXT = Object.freeze({
  noOrigin: 'Enter your ServiceNow address first',
  noQueues: 'Save at least one queue in Settings',
  busy: 'Another dashboard tab is already loading open tickets',
});

const MINUTE_MS = 60 * 1000;
const isObject = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
const toInt = (value) => (Number.isInteger(value) && value >= 0 ? value : 0);
const msOf = (value) => {
  if (value instanceof Date) return value.getTime();
  if (typeof value === 'number') return Number.isFinite(value) ? value : NaN;
  if (typeof value === 'string' && value) return Date.parse(value);
  return NaN;
};
const isoOf = (ms) => (Number.isFinite(ms) ? new Date(ms).toISOString() : null);
const plural = (count, one, many) => `${count} ${count === 1 ? one : many}`;

// ---------------------------------------------------------------------------------------------
// Pure helpers (exported for tests/autorefresh.test.mjs). Total: garbage in, a safe value out.
// ---------------------------------------------------------------------------------------------

/**
 * The auto refresh setting, cleaned: lib/openTickets.js normalizeAutoRefresh when it exists (it is the
 * one rule), else the same rule here (minutes rounded to the nearest 15 and clamped to 15..120).
 * @param {*} raw
 * @returns {{enabled: boolean, minutes: number}}
 */
export function normalizeAutoRefreshConfig(raw) {
  if (typeof openTicketsLib.normalizeAutoRefresh === 'function') {
    try {
      const clean = openTicketsLib.normalizeAutoRefresh(raw);
      if (isObject(clean) && typeof clean.enabled === 'boolean' && Number.isInteger(clean.minutes)) {
        return { enabled: clean.enabled, minutes: clean.minutes };
      }
    } catch {
      // fall through to the local rule
    }
  }
  const source = isObject(raw) ? raw : {};
  let minutes = typeof source.minutes === 'number' ? source.minutes
    : (typeof source.minutes === 'string' && /^\s*\d+(\.\d+)?\s*$/.test(source.minutes) ? Number(source.minutes) : NaN);
  minutes = Number.isFinite(minutes) ? Math.min(120, Math.max(15, Math.round(minutes / 15) * 15)) : DEFAULT_AUTO_REFRESH_MINUTES;
  return { enabled: source.enabled === true, minutes };
}

/**
 * openTickets.retryRounds, cleaned (integer 0..MAX_RETRY_ROUNDS, DEFAULT_RETRY_ROUNDS otherwise).
 * @param {*} raw
 * @returns {number}
 */
export function normalizeRetryRounds(raw) {
  return Number.isInteger(raw) && raw >= 0 ? Math.min(MAX_RETRY_ROUNDS, raw) : DEFAULT_RETRY_ROUNDS;
}

/**
 * When the newest recorded "Load all open tickets" run happened: queueTracking.runs[0].at (runs are
 * newest first), or null when there is none or it is not a date.
 * @param {*} tracking a (normalised) queue tracking object
 * @returns {string|null}
 */
export function lastRunAtOf(tracking) {
  try {
    const runs = isObject(tracking) && Array.isArray(tracking.runs) ? tracking.runs : [];
    const first = runs.find((run) => isObject(run) && Number.isFinite(msOf(run.at)));
    if (!first) return null;
    // A run that recorded when it ended (finishedAt: after the fetch, the retries and the re-check)
    // counts from its end, so a run that took longer than the interval is not followed by another at once.
    const finished = msOf(first.finishedAt);
    return isoOf(Number.isFinite(finished) ? Math.max(finished, msOf(first.at)) : msOf(first.at));
  } catch {
    return null;
  }
}

/**
 * When the next automatic run is due, as an ISO string; null when auto refresh is off. With no run and
 * no attempt yet it is `now` (the first run starts at once).
 * @param {{enabled?: boolean, minutes?: number, lastRunAt?: *, lastAttemptAt?: *, now?: *}} input
 * @returns {string|null}
 */
export function computeNextRunAt(input) {
  const source = isObject(input) ? input : {};
  if (source.enabled !== true) return null;
  const { minutes } = normalizeAutoRefreshConfig({ enabled: true, minutes: source.minutes });
  const times = [msOf(source.lastRunAt), msOf(source.lastAttemptAt)].filter(Number.isFinite);
  if (!times.length) {
    const now = msOf(source.now);
    return isoOf(Number.isFinite(now) ? now : Date.now());
  }
  return isoOf(Math.max(...times) + minutes * MINUTE_MS);
}

/**
 * Whether an automatic run should start now: enabled, nothing running, and the next run time reached.
 * @param {{enabled?: boolean, minutes?: number, running?: boolean, lastRunAt?: *, lastAttemptAt?: *, now?: *}} input
 * @returns {boolean}
 */
export function isAutoRefreshDue(input) {
  const source = isObject(input) ? input : {};
  if (source.enabled !== true || source.running === true) return false;
  const now = msOf(source.now);
  if (!Number.isFinite(now)) return false;
  const next = msOf(computeNextRunAt(source));
  return Number.isFinite(next) && now >= next;
}

/**
 * Why an automatic run cannot start, or '' when it can. Checked in this order: the address, the saved
 * queues, then the host permission (an automatic run never asks for one: the person grants it once with
 * the header button).
 * @param {{origin?: string, queues?: *, permitted?: boolean, host?: string}} input
 * @returns {string}
 */
export function autoRefreshPreflight(input) {
  const source = isObject(input) ? input : {};
  if (typeof source.origin !== 'string' || !source.origin) return PAUSE_TEXT.noOrigin;
  if (!Array.isArray(source.queues) || !source.queues.length) return PAUSE_TEXT.noQueues;
  if (source.permitted !== true) {
    let host = typeof source.host === 'string' && source.host ? source.host : '';
    if (!host) {
      try {
        host = new URL(source.origin).host;
      } catch {
        host = source.origin;
      }
    }
    return `Allow access to ${host} once with Load all open tickets`;
  }
  return '';
}

/** "10:15" in `timeZone` (the browser's own zone when it is missing or unknown). */
export function clockText(ms, timeZone) {
  if (!Number.isFinite(ms)) return '';
  const options = { hour: '2-digit', minute: '2-digit', hourCycle: 'h23' };
  try {
    return new Intl.DateTimeFormat('en-GB', timeZone ? { ...options, timeZone } : options).format(new Date(ms));
  } catch {
    return new Intl.DateTimeFormat('en-GB', options).format(new Date(ms));
  }
}

/**
 * "ServiceNow asked for a login at 10:15; trying again at 10:30".
 * @param {*} at when the login page was met
 * @param {*} nextAt the next automatic try (omitted when auto refresh is off)
 * @param {string} [timeZone]
 * @returns {string}
 */
export function loginPauseReason(at, nextAt, timeZone) {
  const when = clockText(msOf(at), timeZone);
  const next = clockText(msOf(nextAt), timeZone);
  let text = when ? `ServiceNow asked for a login at ${when}` : 'ServiceNow asked for a login';
  text += next ? `; trying again at ${next}` : '; log in to ServiceNow in a normal tab';
  return text;
}

/**
 * The tickets an automatic retry round should try again: outcome 'error' only. 'notfound' would only
 * fail the same way, 'login' needs the person, 'cancelled' was never tried (the run stopped).
 * @param {*} outcomes runBulkFetch() outcomes
 * @returns {string[]} numbers, in outcome order, de-duplicated
 */
export function retryCandidates(outcomes) {
  const seen = new Set();
  const numbers = [];
  if (!Array.isArray(outcomes)) return numbers;
  for (const item of outcomes) {
    if (!isObject(item) || item.outcome !== 'error' || typeof item.number !== 'string' || !item.number) continue;
    if (seen.has(item.number)) continue;
    seen.add(item.number);
    numbers.push(item.number);
  }
  return numbers;
}

/**
 * The automatic retry rounds after a fetch pass. Each round waits (`wait(round)`, ~RETRY_PAUSE_MS),
 * then fetches the tickets whose outcome is still 'error' through `fetchRound(numbers, round)` (which
 * resolves with runBulkFetch-style outcomes). A ticket that now succeeds (or answers 'notfound') takes
 * its new outcome; a 'cancelled' result (never started) keeps the old one; a 'login' result keeps the
 * old error and ends the rounds, since every further try would meet the same login page. Never throws:
 * a fetchRound that rejects ends the rounds and keeps what was known.
 * @param {*} outcomes the pass's outcomes (input order is kept)
 * @param {{rounds?: number, fetchRound: Function, wait?: Function, isStopped?: Function, onRound?: Function,
 *   attempts?: Object<string, number>}} options `attempts` = attempts already made per ticket (default 1
 *   for every ticket that was tried)
 * @returns {Promise<{outcomes: object[], attempts: Object<string, number>, recovered: string[],
 *   retried: string[], roundsRun: number, stoppedForLogin: boolean}>}
 */
export async function runRetryRounds(outcomes, options = {}) {
  const opts = isObject(options) ? options : {};
  const merged = Array.isArray(outcomes) ? outcomes.filter(isObject).map((o) => ({ ...o })) : [];
  const rounds = normalizeRetryRounds(opts.rounds);
  const fetchRound = typeof opts.fetchRound === 'function' ? opts.fetchRound : null;
  const wait = typeof opts.wait === 'function' ? opts.wait : () => undefined;
  const isStopped = typeof opts.isStopped === 'function' ? opts.isStopped : () => false;
  const onRound = typeof opts.onRound === 'function' ? opts.onRound : () => {};
  const given = isObject(opts.attempts) ? opts.attempts : {};
  const index = new Map();
  merged.forEach((o, i) => { if (typeof o.number === 'string' && !index.has(o.number)) index.set(o.number, i); });
  const attempts = {};
  for (const o of merged) {
    if (typeof o.number !== 'string' || !o.number) continue;
    const prior = Number.isInteger(given[o.number]) && given[o.number] > 0 ? given[o.number] : 0;
    attempts[o.number] = prior || (o.outcome === 'cancelled' ? 0 : 1);
  }
  const recovered = [];
  const retried = new Set();
  let roundsRun = 0;
  let stoppedForLogin = merged.some((o) => o.outcome === 'login');
  for (let round = 1; round <= rounds && fetchRound; round += 1) {
    if (stoppedForLogin || safeCall(isStopped)) break;
    const numbers = retryCandidates(merged);
    if (!numbers.length) break;
    safeCall(() => onRound({ round, rounds, numbers, phase: 'wait' }));
    try {
      // eslint-disable-next-line no-await-in-loop -- rounds run one after another, with a pause between
      await wait(round);
    } catch {
      // a broken wait only shortens the pause
    }
    if (safeCall(isStopped)) break;
    roundsRun = round;
    safeCall(() => onRound({ round, rounds, numbers, phase: 'fetch' }));
    let results;
    try {
      // eslint-disable-next-line no-await-in-loop -- see above
      results = await fetchRound(numbers, round);
    } catch {
      break;
    }
    for (const result of Array.isArray(results) ? results : []) {
      if (!isObject(result) || !index.has(result.number)) continue;
      if (result.outcome === 'cancelled') continue;
      if (result.outcome === 'login') {
        stoppedForLogin = true;
        continue;
      }
      attempts[result.number] = (attempts[result.number] || 1) + 1;
      retried.add(result.number);
      if (result.outcome === 'ok') recovered.push(result.number);
      merged[index.get(result.number)] = { ...result };
    }
  }
  return { outcomes: merged, attempts, recovered, retried: [...retried], roundsRun, stoppedForLogin };
}

function safeCall(fn) {
  try {
    return fn();
  } catch {
    return undefined;
  }
}

/**
 * The tickets of a run that could not be fetched, for the Fetch errors tab (recordFetchResult's
 * failedItems): outcome 'error' and 'notfound' (listed by ServiceNow, yet its form could not be read).
 * Tickets never started (cancel, login stop) are not failures: the next run tries them.
 * @param {*} outcomes final outcomes
 * @param {*} attempts attempts per number (runRetryRounds)
 * @returns {{number: string, code: string, message: string, attempts: number}[]}
 */
export function failedItemsOf(outcomes, attempts) {
  const tries = isObject(attempts) ? attempts : {};
  const items = [];
  const seen = new Set();
  for (const o of Array.isArray(outcomes) ? outcomes : []) {
    if (!isObject(o) || (o.outcome !== 'error' && o.outcome !== 'notfound')) continue;
    if (typeof o.number !== 'string' || !o.number || seen.has(o.number)) continue;
    seen.add(o.number);
    const code = typeof o.code === 'string' && o.code ? o.code : (o.outcome === 'notfound' ? 'NOT_FOUND' : 'FETCH_FAILED');
    items.push({
      number: o.number,
      code,
      message: typeof o.message === 'string' && o.message ? o.message : 'Could not be fetched.',
      attempts: Number.isInteger(tries[o.number]) && tries[o.number] > 0 ? tries[o.number] : 1,
    });
  }
  return items;
}

/**
 * The sentence about automatic retries for the end-of-run summary ('' when nothing was retried and
 * nothing is still failing).
 * "Retried 18 tickets that failed (2 rounds): 15 fetched on retry, 3 still failing - see the Fetch errors tab."
 * @param {{retried?: number, recovered?: number, stillFailing?: number, rounds?: number}} input
 * @returns {string}
 */
export function retrySentence(input) {
  const source = isObject(input) ? input : {};
  const retried = toInt(source.retried);
  const recovered = toInt(source.recovered);
  const failing = toInt(source.stillFailing);
  const rounds = toInt(source.rounds);
  if (!retried && !failing) return '';
  const see = 'see the Fetch errors tab';
  if (!retried) return `${plural(failing, 'ticket', 'tickets')} could not be fetched - ${see}.`;
  let text = `Retried ${plural(retried, 'ticket that failed', 'tickets that failed')}${rounds ? ` (${plural(rounds, 'round', 'rounds')})` : ''}: ${recovered} fetched on retry`;
  text += failing ? `, ${failing} still failing - ${see}.` : '.';
  return text;
}

/**
 * The one-line summary of a run (status.lastSummary, shown by the Overview):
 * "Listed 275 · fetched 275 (15 after retry)", "... · 3 still failing: see Fetch errors".
 * @param {{listed?: number, fetched?: number, recovered?: number, stillFailing?: number, notFetched?: number,
 *   cancelled?: boolean, stoppedForLogin?: boolean, truncated?: boolean}} input
 * @returns {string}
 */
export function shortRunSummary(input) {
  const source = isObject(input) ? input : {};
  const parts = [`Listed ${toInt(source.listed)}`];
  const recovered = toInt(source.recovered);
  parts.push(`fetched ${toInt(source.fetched)}${recovered ? ` (${recovered} after retry)` : ''}`);
  const failing = toInt(source.stillFailing);
  if (failing) parts.push(`${failing} still failing: see Fetch errors`);
  const notFetched = toInt(source.notFetched);
  if (source.stoppedForLogin === true) parts.push(`stopped: ServiceNow asked for a login${notFetched ? ` (${notFetched} not fetched)` : ''}`);
  else if (source.cancelled === true) parts.push(`cancelled${notFetched ? ` (${notFetched} not fetched)` : ''}`);
  if (source.truncated === true) parts.push('more open tickets may exist');
  return parts.join(' · ');
}

/**
 * The one-line summary of a RECORDED run (queueTracking.runs[] entry), for a tab that did not run it
 * itself (another dashboard tab ran it, or this page was reloaded since): same wording as
 * shortRunSummary, from the counts the run entry keeps. '' for garbage.
 * "Listed 275 · fetched 272 (12 after retry) · 3 still failing: see Fetch errors"
 * @param {*} run a normalised runs[] entry
 * @returns {string}
 */
export function summaryOfRun(run) {
  if (!isObject(run) || !Number.isFinite(msOf(run.at))) return '';
  const parts = [`Listed ${toInt(run.listed)}`];
  if (Number.isInteger(run.fetched)) {
    const recovered = toInt(run.retried);
    parts.push(`fetched ${run.fetched}${recovered ? ` (${recovered} after retry)` : ''}`);
  }
  if (toInt(run.failed)) parts.push(`${toInt(run.failed)} still failing: see Fetch errors`);
  if (run.complete !== true) parts.push('the list was not read to the end');
  return parts.join(' · ');
}

/**
 * The queue-change sentence after a run's tracking was saved ('' when nothing changed).
 * "Queue: 3 new to the queue, 2 moved out, 1 back in the queue."
 * @param {{entered?: *, movedOut?: *, reentered?: *}} input lists (or counts) from applyListRun
 * @returns {string}
 */
export function queueChangeSentence(input) {
  const source = isObject(input) ? input : {};
  const count = (value) => (Array.isArray(value) ? value.length : toInt(value));
  const parts = [];
  if (count(source.entered)) parts.push(`${count(source.entered)} new to the queue`);
  if (count(source.movedOut)) parts.push(`${count(source.movedOut)} moved out`);
  if (count(source.reentered)) parts.push(`${count(source.reentered)} back in the queue`);
  return parts.length ? `Queue: ${parts.join(', ')}.` : '';
}

/**
 * Run `fn` holding the cross-tab lock LOAD_LOCK_NAME (ifAvailable: never waits for another tab).
 * Without Web Locks a module flag keeps this tab from running twice.
 * @param {Function} fn async work
 * @param {{locks?: *}} [options] `locks` = a LockManager (default navigator.locks); null forces the fallback
 * @returns {Promise<{acquired: boolean, value?: *}>} rejects only when `fn` does
 */
export async function withLoadLock(fn, options = {}) {
  const locks = isObject(options) && 'locks' in options ? options.locks : defaultLocks();
  if (locks && typeof locks.request === 'function') {
    let acquired = false;
    let value;
    try {
      await locks.request(LOAD_LOCK_NAME, { ifAvailable: true }, async (lock) => {
        if (!lock) return;
        acquired = true;
        value = await fn();
      });
      return acquired ? { acquired, value } : { acquired: false };
    } catch (err) {
      // A failure of `fn` itself is the caller's; a LockManager that refuses the request (blocked by
      // the browser, a security error) falls back to the per-tab flag below instead of failing the run.
      if (acquired) throw err;
    }
  }
  if (fallbackLockHeld) return { acquired: false };
  fallbackLockHeld = true;
  try {
    return { acquired: true, value: await fn() };
  } finally {
    fallbackLockHeld = false;
  }
}

let fallbackLockHeld = false;

function defaultLocks() {
  try {
    return typeof navigator !== 'undefined' && navigator && navigator.locks ? navigator.locks : null;
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------------------------
// Status: what a run is doing, the saved setting, the pause reason
// ---------------------------------------------------------------------------------------------

let config = { enabled: false, minutes: DEFAULT_AUTO_REFRESH_MINUTES };
let loadState = { running: false, auto: false, phase: '', done: 0, total: 0, lastSummary: '' };
// { kind: '' | 'preflight' | 'busy' | 'login', reason: string, at: number }
let pause = { kind: '', reason: '', at: NaN };
let lastAttemptAt = NaN; // this tab's newest run start (see the module comment)
// runs[0].at when this tab's own lastSummary was reported: a newer recorded run (another tab, or a
// reload) is summarised from its run entry instead (summaryOfRun), so "Last refresh" and the summary
// beside it always describe the same run.
let summaryRunAt = null;
let statusTimeZone = ''; // the zone the dashboard shows times in (noteStatusTimeZone); '' = the browser's
let runner = null; // { run(options), save(autoRefresh) } from dashboard/opentickets.js
const listeners = new Set();
let lastEmitAt = 0;
let lastEmitKey = '';
let trailingTimer = 0;

/**
 * The status of "Load all open tickets" and its auto refresh, for the Overview and the Fetch errors tab.
 * @param {Date|number|string} [now]
 * @returns {{enabled: boolean, minutes: number, lastRunAt: string|null, nextRunAt: string|null,
 *   running: boolean, auto: boolean, phase: ''|'list'|'fetch'|'retry'|'recheck', done: number, total: number,
 *   pausedReason: string, lastSummary: string}}
 */
export function getAutoRefreshStatus(now = new Date()) {
  const nowMs = Number.isFinite(msOf(now)) ? msOf(now) : Date.now();
  const lastRunAt = lastRunAtOf(state && state.data ? state.data.queueTracking : null);
  const nextRunAt = computeNextRunAt({
    enabled: config.enabled, minutes: config.minutes, lastRunAt, lastAttemptAt, now: nowMs,
  });
  // Only while auto refresh is on: with it off nothing is "paused" (the run's own panel said what happened).
  let pausedReason = '';
  if (config.enabled && pause.kind === 'login') pausedReason = loginPauseReason(pause.at, nextRunAt, statusTimeZone);
  else if (config.enabled && pause.kind) pausedReason = pause.reason;
  let lastSummary = loadState.lastSummary;
  if (lastRunAt && (!lastSummary || summaryRunAt !== lastRunAt)) {
    const runs = state && state.data && isObject(state.data.queueTracking) && Array.isArray(state.data.queueTracking.runs)
      ? state.data.queueTracking.runs : [];
    const newest = runs.find((run) => isObject(run) && Number.isFinite(msOf(run.at)));
    const derived = summaryOfRun(newest);
    if (derived) lastSummary = derived;
  }
  return {
    enabled: config.enabled,
    minutes: config.minutes,
    lastRunAt,
    nextRunAt,
    running: loadState.running,
    auto: loadState.running && loadState.auto,
    phase: loadState.running ? loadState.phase : '',
    done: loadState.done,
    total: loadState.total,
    pausedReason,
    lastSummary,
  };
}

/**
 * Subscribe to status changes (running, phase, progress, the setting, the pause reason). The listener
 * is called with getAutoRefreshStatus(); progress-only changes at most once a second.
 * @param {Function} listener
 * @returns {Function} unsubscribe
 */
export function onOpenLoadState(listener) {
  if (typeof listener !== 'function') return () => {};
  listeners.add(listener);
  return () => listeners.delete(listener);
}

function emit({ progressOnly = false } = {}) {
  if (!listeners.size) return;
  const now = Date.now();
  if (progressOnly && now - lastEmitAt < PROGRESS_EMIT_MS) {
    if (!trailingTimer) {
      trailingTimer = setTimeout(() => {
        trailingTimer = 0;
        emit();
      }, PROGRESS_EMIT_MS - (now - lastEmitAt));
    }
    return;
  }
  const status = getAutoRefreshStatus(now);
  const key = JSON.stringify(status);
  if (key === lastEmitKey) return;
  lastEmitKey = key;
  lastEmitAt = now;
  if (trailingTimer) {
    clearTimeout(trailingTimer);
    trailingTimer = 0;
  }
  for (const listener of [...listeners]) {
    try {
      listener(status);
    } catch {
      // one broken listener must not silence the others
    }
  }
}

/**
 * The runner reports what it is doing (dashboard/opentickets.js). Only known fields are taken.
 * @param {{running?: boolean, auto?: boolean, phase?: string, done?: number, total?: number, lastSummary?: string}} patch
 */
export function reportOpenLoadState(patch) {
  if (!isObject(patch)) return;
  const next = { ...loadState };
  if (typeof patch.running === 'boolean') next.running = patch.running;
  if (typeof patch.auto === 'boolean') next.auto = patch.auto;
  if (typeof patch.phase === 'string') next.phase = patch.phase;
  if (Number.isInteger(patch.done) && patch.done >= 0) next.done = patch.done;
  if (Number.isInteger(patch.total) && patch.total >= 0) next.total = patch.total;
  if (typeof patch.lastSummary === 'string') {
    next.lastSummary = patch.lastSummary;
    summaryRunAt = lastRunAtOf(state && state.data ? state.data.queueTracking : null);
  }
  const progressOnly = next.running === loadState.running && next.auto === loadState.auto
    && next.phase === loadState.phase && next.lastSummary === loadState.lastSummary;
  loadState = next;
  emit({ progressOnly });
}

/** A run really started in this tab (it holds the lock): the next automatic one counts from here. */
export function noteRunAttempt(at = Date.now()) {
  const ms = msOf(at);
  if (Number.isFinite(ms)) lastAttemptAt = ms;
  if (pause.kind) pause = { kind: '', reason: '', at: NaN };
  emit();
}

/**
 * Pause (or un-pause, with kind '') automatic runs with a reason the Overview shows. A login pause is
 * worded at status time ("trying again at ..." follows the current interval).
 * @param {''|'preflight'|'busy'|'login'} kind
 * @param {string} [reason]
 * @param {*} [at]
 */
export function setAutoRefreshPause(kind, reason = '', at = Date.now()) {
  const known = ['', 'preflight', 'busy', 'login'];
  pause = known.includes(kind) && kind
    ? { kind, reason: typeof reason === 'string' ? reason : '', at: msOf(at) }
    : { kind: '', reason: '', at: NaN };
  emit();
}

/**
 * The auto refresh setting as last saved (the Settings paint feeds it in through opentickets.js). Turning
 * it on, or changing the interval, asks the scheduler to check at once.
 * @param {*} raw serviceNowSettings.openTickets.autoRefresh
 */
export function noteAutoRefreshConfig(raw) {
  const next = normalizeAutoRefreshConfig(raw);
  if (next.enabled === config.enabled && next.minutes === config.minutes) return;
  config = next;
  if (!next.enabled && pause.kind !== 'login') pause = { kind: '', reason: '', at: NaN };
  emit();
  if (next.enabled) scheduleSoonCheck();
}

/**
 * The time zone the dashboard shows its times in (the Settings override, else the browser's), so the
 * login pause's "at 10:15; trying again at 10:30" reads in the same zone as every other time on the
 * page. Fed from the Settings paint through opentickets.js; an unknown zone falls back to the browser's.
 * @param {*} timeZone IANA zone name, or '' for the browser's own
 */
export function noteStatusTimeZone(timeZone) {
  const next = typeof timeZone === 'string' ? timeZone : '';
  if (next === statusTimeZone) return;
  statusTimeZone = next;
  if (pause.kind === 'login') emit();
}

/**
 * dashboard/opentickets.js hands its run function and its settings save in (at module load).
 * @param {{run: Function, save: Function}} impl
 * @returns {object|null} the runner registered before (tests put it back afterwards)
 */
export function registerOpenTicketsRunner(impl) {
  const previous = runner;
  runner = isObject(impl) && typeof impl.run === 'function' ? impl : null;
  return previous;
}

// ---------------------------------------------------------------------------------------------
// The API other UI uses
// ---------------------------------------------------------------------------------------------

/**
 * Turn auto refresh on or off and/or change its interval; persisted into
 * serviceNowSettings.openTickets.autoRefresh through the same save the Settings tab uses.
 * @param {{enabled?: boolean, minutes?: number}} change
 * @returns {Promise<void>} rejects when the setting could not be saved
 */
export async function setAutoRefresh(change) {
  const source = isObject(change) ? change : {};
  const next = normalizeAutoRefreshConfig({
    enabled: typeof source.enabled === 'boolean' ? source.enabled : config.enabled,
    minutes: source.minutes !== undefined ? source.minutes : config.minutes,
  });
  if (!runner || typeof runner.save !== 'function') throw new Error('the auto refresh setting cannot be saved on this page');
  await runner.save(next);
  noteAutoRefreshConfig(next);
}

/**
 * The same run as the header button, without moving focus (the progress panel shows as usual). Call it
 * straight from a click handler: the first run may need to ask for the host permission.
 * @returns {Promise<*>} the run's result ({started: false, reason} when one is already going on)
 */
export function refreshNow() {
  if (!runner) return Promise.resolve({ started: false, reason: 'The open-ticket loader is not available on this page.' });
  return runner.run({ kind: 'manual', moveFocus: false });
}

/**
 * Fetch the tickets of the last run that could not be fetched once more (default: every one listed on
 * the Fetch errors tab), with the automatic retry rounds after that pass. Call it from a click handler.
 * A retry that could not run at all (another run going on here or in another tab, the permission not
 * confirmed, a failure before any ticket was tried) REJECTS with the reason, so the Fetch errors tab
 * says why instead of "nothing was retried". `failed` counts every ticket still on the list afterwards
 * (still failing, or not tried because Cancel or a login page stopped the retry).
 * @param {string[]} [numbers]
 * @returns {Promise<{ok: number, failed: number}>}
 */
export async function retryFailedTickets(numbers) {
  if (!runner) throw new Error('the open-ticket loader is not available on this page');
  const result = await runner.run({ kind: 'retry', numbers: Array.isArray(numbers) ? numbers : undefined });
  const notRun = !isObject(result) || result.started === false
    || (typeof result.reason === 'string' && result.reason && !Number.isInteger(result.ok));
  if (notRun) throw new Error(isObject(result) && typeof result.reason === 'string' && result.reason ? result.reason : 'the retry did not start');
  return {
    ok: isObject(result) ? toInt(result.ok) : 0,
    failed: isObject(result) ? toInt(result.failed) : 0,
  };
}

// ---------------------------------------------------------------------------------------------
// Scheduler
// ---------------------------------------------------------------------------------------------

let intervalTimer = 0;
let firstTimer = 0;
let soonTimer = 0;
let schedulerOn = false;
let checking = false;
let readTracking = async () => {
  const stored = await storageGet([KEY.queueTracking]);
  return stored === null ? null : (isObject(stored[KEY.queueTracking]) ? stored[KEY.queueTracking] : {});
};

function scheduleSoonCheck() {
  if (!schedulerOn) return;
  clearTimeout(soonTimer);
  soonTimer = setTimeout(() => {
    soonTimer = 0;
    void checkAutoRefresh();
  }, 0);
}

/**
 * One scheduler tick. Cheap unless a run is due: then queueTracking is read from storage once more and,
 * when still due, an automatic run starts (opentickets.js does the preflight, the lock and the pause).
 * Exported for tests; `deps` replaces the storage read.
 * @param {*} [now]
 * @param {{readTracking?: Function}} [deps]
 * @returns {Promise<boolean>} whether a run was started
 */
export async function checkAutoRefresh(now = Date.now(), deps = {}) {
  if (checking || !runner || !config.enabled || loadState.running) return false;
  const nowMs = Number.isFinite(msOf(now)) ? msOf(now) : Date.now();
  const local = {
    enabled: config.enabled, minutes: config.minutes, running: loadState.running, lastAttemptAt, now: nowMs,
  };
  if (!isAutoRefreshDue({ ...local, lastRunAt: lastRunAtOf(state.data.queueTracking) })) {
    if (pause.kind === 'busy') setAutoRefreshPause('');
    return false;
  }
  checking = true;
  try {
    const read = isObject(deps) && typeof deps.readTracking === 'function' ? deps.readTracking : readTracking;
    let fresh;
    try {
      fresh = await read();
    } catch {
      fresh = null;
    }
    if (fresh === null || fresh === undefined) return false; // unreadable: never run on a guess
    if (!isAutoRefreshDue({ ...local, lastRunAt: lastRunAtOf(fresh) })) return false;
    if (!config.enabled || loadState.running) return false;
    await runner.run({ kind: 'auto', moveFocus: false });
    return true;
  } catch {
    return false;
  } finally {
    checking = false;
  }
}

/**
 * Start (or restart) the scheduler: a first check shortly after the page loads, then every
 * CHECK_INTERVAL_MS. Calling it again replaces the timers, never doubles them.
 * @param {{checkMs?: number, firstCheckMs?: number}} [options]
 */
export function startAutoRefreshScheduler(options = {}) {
  stopAutoRefreshScheduler();
  const opts = isObject(options) ? options : {};
  const checkMs = Number.isFinite(opts.checkMs) && opts.checkMs > 0 ? opts.checkMs : CHECK_INTERVAL_MS;
  const firstMs = Number.isFinite(opts.firstCheckMs) && opts.firstCheckMs >= 0 ? opts.firstCheckMs : FIRST_CHECK_MS;
  schedulerOn = true;
  firstTimer = setTimeout(() => {
    firstTimer = 0;
    void checkAutoRefresh();
  }, firstMs);
  intervalTimer = setInterval(() => void checkAutoRefresh(), checkMs);
}

/** Stop the scheduler (tests; a page that goes away clears its timers anyway). */
export function stopAutoRefreshScheduler() {
  schedulerOn = false;
  clearTimeout(firstTimer);
  clearTimeout(soonTimer);
  clearInterval(intervalTimer);
  firstTimer = 0;
  soonTimer = 0;
  intervalTimer = 0;
}

/** Test seam: forget the module state (the scheduler is stopped too; the registered runner stays). */
export function resetAutoRefreshForTests({ readTrackingImpl } = {}) {
  stopAutoRefreshScheduler();
  config = { enabled: false, minutes: DEFAULT_AUTO_REFRESH_MINUTES };
  loadState = { running: false, auto: false, phase: '', done: 0, total: 0, lastSummary: '' };
  pause = { kind: '', reason: '', at: NaN };
  lastAttemptAt = NaN;
  summaryRunAt = null;
  statusTimeZone = '';
  listeners.clear();
  lastEmitAt = 0;
  lastEmitKey = '';
  clearTimeout(trailingTimer);
  trailingTimer = 0;
  checking = false;
  fallbackLockHeld = false;
  if (typeof readTrackingImpl === 'function') readTracking = readTrackingImpl;
}
