// The inline composer under a ticket row: a Teams message, or a ticket update (a comment ServiceNow
// emails to the user, or an internal work note). Nothing is saved or opened without an explicit
// click; a real ticket update needs a SEPARATE review step (its own panel, its own button) before
// anything is posted, so a double click or a held key on one control can never post by accident.
//
// For a Teams message and for a comment to the user the composer offers a "Guide me" switch (on by
// default): a short yes/no question flow (dashboard/guide.js) writes the message into the textarea.
// The textarea stays editable; a manual edit detaches the guide until "Regenerate". An internal work
// note never uses the guide.
//
// The composer is a small state machine whose DOM is built once and then only synced
// (syncComposer never recreates nodes), so focus, caret, text and the guide's own state survive every
// repaint. The guide's answers are also kept per incident (state.guides), so they survive closing and
// reopening and a rebuilt composer.
import {
  NOTE_TYPES, WORKNOTE_MAX, appendFollowUp, buildTeamsLink, defaultTemplate, normalizeSettings,
  renderTemplate, validateNoteText,
} from '../lib/followup.js';
import { MAX_TEAMS_CHARS, buildMessage } from '../lib/messageTemplates.js';
import {
  button, create, errorText, hostOf, isObject, previewOf, safeHttpUrl, setText, str,
} from './dom.js';
import { ensureOriginPermissionConfirmed } from './confirmHost.js';
import { mountFollowUpGuide, restoreAnswers } from './guide.js';
import {
  MSG, copyText, openUrl, replyError, sendRuntimeMessage,
} from './messaging.js';
import { hooks, state } from './state.js';
import { currentSettings } from './settings.js';
import { persistFollowUp, persistSettings } from './store.js';
import { TABLE_COLUMNS } from './table.js';

// ---- the real-post confirm step (contract 13.6, security findings H1/M1) ----
// Clicking "Review and send" opens a SEPARATE panel; it never posts by itself. The panel's own
// button stays disabled for CONFIRM_ARM_MS (a visible countdown), ignores a double click
// (event.detail > 1) and a held key (event.repeat), and is bound to a snapshot taken when it
// opened: any later change (settings, note type, the text, the row's origin) disarms it.
export const CONFIRM_ARM_MS = 800;
const CONFIRM_TICK_MS = 100;
// A recent identical post warns and needs an extra acknowledgement (contract 13.5/13.6, finding M4).
const DUP_WINDOW_MS = 24 * 60 * 60 * 1000;
const TEAMS_MESSAGE_MAX = MAX_TEAMS_CHARS; // lib/followup.js cuts the Teams message here
// The placeholders the guide shows for answers that are still missing (lib/messageTemplates.js).
const GUIDE_PLACEHOLDER = /\[(?:Issue description|User education steps|Ticket creation link|Alternate ticket number|Additional information required|Incident number)\]/;

const TEXT = {
  teamsEnded: 'Business hours ended for this user: Teams IM is no longer offered',
  noEmail: 'No usable email address for this user, so Teams IM cannot be opened.',
  noInstance: 'This incident has no usable ServiceNow address, so it cannot be updated from here.',
  teamsOpened: 'Teams chat opened. Press Send in Teams.',
  dryRunOk: 'Dry run OK - nothing was posted',
  verifiedComment: 'Comment posted and verified in the activity stream. ServiceNow emails the user if notifications are enabled on your instance.',
  verifiedNote: 'Work note added and verified',
  unverified: 'Submitted, but the new note was not visible yet. Open the incident to confirm.',
  emptyMessage: 'Write a message first.',
  guideWaiting: 'Answer the guide questions to enable sending, or edit the message yourself, or switch "Guide me" off.',
  copied: 'Message copied. Paste it into the Teams chat yourself.',
  copyFailed: 'Could not copy to the clipboard. Select the text in the box and copy it by hand.',
  switchedToTicket: 'Moved to a ticket update: the message is a comment the user is emailed.',
  settingsChanged: 'Settings changed: review again.',
  unknownOutcome: 'The update may or may not have been saved. Open the incident to check before posting again.',
  dupWarning: 'You may have already sent this update recently (within the last 24 hours). Check the incident before sending it again.',
};

const isComments = () => state.data.settings.noteType === 'comments';
const noteInfo = () => NOTE_TYPES[state.data.settings.noteType] || NOTE_TYPES.comments;

// ---- the guide: availability, context, state ----

/** The guide writes messages for the user (Teams, or a comment ServiceNow emails); never the internal note. */
const guideAvailable = (composer) => composer.channel === 'teams' || isComments();
const guideActive = (composer) => Boolean(composer.guide) && guideAvailable(composer) && composer.guideWanted;
const isEdited = (composer) => composer.text !== composer.template;

/** Everything the templates need to know about the row (lib/messageTemplates.js ctx). */
function guideCtx(composer, row) {
  const last = isObject(row.lastContact) ? row.lastContact : {};
  const atContact = isObject(last.atContact) ? last.atContact : null;
  const now = isObject(row.nowStatus) ? row.nowStatus : {};
  let lastContactStatus = 'none';
  if (last.has) lastContactStatus = atContact ? str(atContact.status) || 'unknown' : 'unknown';
  return {
    incidentNumber: str(row.incidentNumber),
    shortDescription: str(row.shortDescription),
    userName: str(row.callerName),
    preferredContactMethod: str(row.preferredContactMethod),
    nowStatus: str(now.status),
    openedStatus: str(row.openedStatus),
    lastContactStatus,
    channel: composer.channel === 'teams' ? 'teams' : 'comment',
    serviceDeskName: str(currentSettings().serviceDeskName), // Settings -> Service desk name
  };
}

/** The text the guide shows at the start (restored answers when this ticket had a guide before). */
function guideStartText(ctx, snapshot) {
  const message = buildMessage(restoreAnswers(ctx, snapshot), ctx);
  return message.ok ? message.text : message.previewText;
}

function saveGuideState(composer) {
  if (composer.finished) return; // a posted follow-up is over: its answers must not come back
  if (composer.guide) composer.guideSnapshot = composer.guide.getSnapshot();
  state.guides.set(composer.incidentNumber, { snapshot: composer.guideSnapshot, wanted: composer.guideWanted });
}

function templateText(channel, row) {
  const key = channel === 'teams' ? 'teams' : (isComments() ? 'comment' : 'worknote');
  return renderTemplate(defaultTemplate(key), row.vars || {});
}

function composerLock(composer, row) {
  if (composer.channel === 'teams') {
    if (!Array.isArray(row.actions) || !row.actions.includes('teams')) return TEXT.teamsEnded;
    return row.canTeams ? '' : TEXT.noEmail;
  }
  return row.instanceOrigin ? '' : TEXT.noInstance;
}

function createComposer(row, channel, carry = null) {
  state.composerSeq += 1;
  const stored = state.guides.get(row.incidentNumber);
  const composer = {
    id: state.composerSeq,
    incidentNumber: row.incidentNumber,
    channel,
    text: '',
    template: '', // what the box was last filled with (by a template or the guide): differs from `text` once the user edits
    guideWanted: carry ? carry.guideWanted : (stored ? stored.wanted : true),
    guideSnapshot: carry ? carry.guideSnapshot : (stored ? stored.snapshot : null),
    guide: null,
    guideMessage: null, // buildMessage() result of the guide's last change
    guideCtxKey: '',
    confirm: null, // the open review panel: { snapshot, openRawText, openedAt, tickTimer, dup } | null
    working: false,
    finished: false, // a real update was posted: sending the same text again needs a new composer
    syncing: false,
    result: null, // { state, message, link }; null shows the idle message
    needsFocus: true,
    node: null,
    refs: null,
  };
  if (carry) {
    composer.text = carry.text;
    composer.template = carry.template;
  } else if (guideAvailable(composer) && composer.guideWanted) {
    composer.template = guideStartText(guideCtx(composer, row), composer.guideSnapshot);
    composer.text = composer.template;
  } else {
    composer.template = templateText(channel, row);
    composer.text = composer.template;
  }
  return composer;
}

// ---- DOM ----

function labelled(forId, text) {
  const label = create('label', 'composer-label', text);
  label.htmlFor = forId;
  return label;
}

function buildSwitch(role, title, hint) {
  const wrap = create('label', 'switch');
  const input = create('input');
  input.type = 'checkbox';
  input.dataset.role = role;
  input.setAttribute('role', 'switch');
  const text = create('span', 'switch-text');
  text.append(create('strong', '', title), create('small', '', hint));
  wrap.append(input, create('span', 'switch-ui'), text);
  return { wrap, input };
}

function buildDryRunSwitch() {
  return buildSwitch('dryRun', 'Dry run', 'Check everything, save nothing');
}

function buildNoteTypeSelect() {
  const select = create('select', 'composer-select');
  select.id = 'composerNoteType';
  select.dataset.role = 'noteType';
  for (const [value, info] of Object.entries(NOTE_TYPES)) {
    const option = create('option', '', info.label);
    option.value = value;
    select.append(option);
  }
  const badge = create('span', 'type-badge');
  badge.dataset.role = 'typeBadge';
  const row = create('div', 'composer-type');
  row.append(labelled(select.id, 'Type of update'), select, badge);
  return { row, select, badge };
}

function buildTextArea() {
  const textarea = create('textarea', 'composer-text');
  textarea.id = 'composerMessage';
  textarea.rows = 6;
  textarea.dataset.role = 'message';
  textarea.spellcheck = true;
  textarea.setAttribute('aria-describedby', 'composerHint');
  return textarea;
}

/** The "Guide me" switch and the place the guide is mounted in. */
function buildGuideSection() {
  const toggle = buildSwitch('guideToggle', 'Guide me', 'Answer a few questions and the message is written for you');
  const bar = create('div', 'composer-guide-bar');
  bar.append(toggle.wrap);
  const host = create('div', 'composer-guide-host');
  host.dataset.role = 'guideHost';
  const section = create('div', 'composer-guide');
  section.dataset.role = 'guideSection';
  section.append(bar, host);
  return { section, toggle: toggle.input, host };
}

/** The warning for a Teams message that does not fit a Teams link (never cut silently). */
function buildLimitBlock() {
  const text = create('p', 'composer-limit-text');
  text.dataset.role = 'teamsLimitText';
  const copy = button('Copy message', 'btn-secondary btn-sm', {});
  copy.dataset.role = 'copyMessage';
  const instead = button('Use ticket update instead', 'btn-secondary btn-sm', {});
  instead.dataset.role = 'useTicket';
  const buttons = create('div', 'composer-limit-buttons');
  buttons.append(copy, instead);
  const block = create('div', 'composer-limit');
  block.dataset.role = 'teamsLimit';
  block.setAttribute('role', 'alert');
  block.hidden = true;
  block.append(text, buttons);
  return { block, text, copy, instead };
}

/** "Edited manually - Regenerate": shown above the textarea when it no longer matches the guide. */
function buildEditedNote() {
  const regenerate = create('button', 'composer-regenerate', 'Regenerate');
  regenerate.type = 'button';
  regenerate.dataset.role = 'regenerateMessage';
  regenerate.setAttribute('aria-label', 'Regenerate the message from the guide answers (replaces your edits)');
  const note = create('p', 'composer-edited');
  note.dataset.role = 'manualEdit';
  note.hidden = true;
  note.append(create('span', '', 'Edited manually - '), regenerate);
  return { note, regenerate };
}

/**
 * The review panel of a real ticket update (contract 13.6): a DISTINCT region, never the same
 * button clicked twice. It shows exactly what will happen and is bound to a snapshot by the caller.
 */
function buildConfirmPanel() {
  const panel = create('section', 'composer-confirm');
  panel.dataset.role = 'confirmPanel';
  panel.setAttribute('role', 'group');
  panel.setAttribute('aria-label', 'Review before sending');
  panel.hidden = true;
  const heading = create('h4', 'confirm-heading', 'Review before sending');
  heading.tabIndex = -1;
  const target = create('p', 'confirm-line');
  target.dataset.role = 'confirmTarget';
  const kind = create('p', 'confirm-line confirm-kind');
  kind.dataset.role = 'confirmKind';
  const visible = create(
    'p',
    'confirm-visible',
    'VISIBLE TO THE USER; ServiceNow normally emails the caller (if the notification is active).',
  );
  visible.dataset.role = 'confirmVisible';
  visible.setAttribute('role', 'alert');
  visible.hidden = true; // toggled by syncConfirmPanel once a panel actually opens
  const dry = create('p', 'confirm-dry', 'This is a dry run: nothing will be posted.');
  dry.dataset.role = 'confirmDryRun';
  dry.hidden = true; // toggled by syncConfirmPanel once a panel actually opens
  const textLabel = create('p', 'composer-label', 'Exact text that will be posted');
  const text = create('pre', 'confirm-text');
  text.dataset.role = 'confirmText';
  const dup = create('div', 'confirm-dup');
  dup.dataset.role = 'confirmDup';
  dup.setAttribute('role', 'alert');
  dup.hidden = true;
  const dupText = create('p', 'confirm-dup-text', TEXT.dupWarning);
  dupText.dataset.role = 'confirmDupText';
  const ackLabel = create('label', 'confirm-ack');
  const ack = create('input');
  ack.type = 'checkbox';
  ack.dataset.role = 'confirmAck';
  ackLabel.append(ack, create('span', '', 'Send it again anyway'));
  dup.append(dupText, ackLabel);
  const back = button('Back', 'btn-secondary', {});
  back.dataset.role = 'confirmBack';
  const send = button('Confirm and post', 'btn-primary', {});
  send.dataset.role = 'confirmSend';
  const buttons = create('div', 'composer-buttons confirm-buttons');
  buttons.append(back, send);
  panel.append(heading, target, kind, visible, dry, textLabel, text, dup, buttons);
  return {
    panel, heading, target, kind, visible, dry, text, dup, ack, back, send,
  };
}

function buildComposerNode(composer) {
  const ticket = composer.channel === 'ticket';
  const tr = create('tr', 'composer-row');
  tr.id = 'composerRow';
  tr.dataset.composerFor = composer.incidentNumber;
  tr.dataset.channel = composer.channel;
  const td = create('td', 'composer-cell');
  td.colSpan = TABLE_COLUMNS;
  const panel = create('section', 'composer');

  const title = create('h3', 'composer-title');
  const sub = create('p', 'composer-sub');
  const head = create('div', 'composer-head');
  head.append(title, sub);

  const guide = buildGuideSection();
  const textarea = buildTextArea();
  const hint = create('p', 'composer-hint');
  hint.id = 'composerHint';
  hint.dataset.role = 'hint';
  const count = create('span', 'composer-count');
  count.dataset.role = 'count';
  const editLabel = labelled('composerMessage', '');
  const labelRow = create('div', 'composer-labelrow');
  labelRow.append(editLabel, count);
  const edited = buildEditedNote();
  const limit = buildLimitBlock();
  const edit = create('div', 'composer-edit');
  edit.append(labelRow, edited.note, textarea, hint, limit.block);

  const preview = create('pre', 'composer-preview');
  preview.dataset.role = 'preview';
  preview.tabIndex = 0;
  preview.setAttribute('aria-label', 'Preview of the exact text');
  const previewLabel = create('p', 'composer-label');
  const previewBox = create('div', 'composer-previewbox');
  previewBox.append(previewLabel, preview);

  const grid = create('div', 'composer-grid');
  grid.append(edit, previewBox);

  const send = button('', 'btn-primary', {});
  send.dataset.role = 'send';
  const cancel = button('Cancel', 'btn-secondary', {});
  cancel.dataset.role = 'cancel';
  const buttons = create('div', 'composer-buttons');
  buttons.append(cancel, send);
  const foot = create('div', 'composer-foot');
  const refs = {
    title,
    sub,
    textarea,
    hint,
    count,
    editLabel,
    preview,
    previewLabel,
    send,
    cancel,
    dryRun: null,
    noteType: null,
    typeBadge: null,
    dryRunBanner: null,
    guideSection: guide.section,
    guideToggle: guide.toggle,
    guideHost: guide.host,
    editedNote: edited.note,
    regenerate: edited.regenerate,
    limit: limit.block,
    limitText: limit.text,
    copy: limit.copy,
    useTicket: limit.instead,
    confirmPanel: null,
    confirmHeading: null,
    confirmTarget: null,
    confirmKind: null,
    confirmVisible: null,
    confirmDryRun: null,
    confirmText: null,
    confirmDup: null,
    confirmAck: null,
    confirmBack: null,
    confirmSend: null,
  };
  let dryBanner = null;
  let confirmParts = null;
  let typeRow = null;
  if (ticket) {
    const sw = buildDryRunSwitch();
    refs.dryRun = sw.input;
    foot.append(sw.wrap);
    dryBanner = create('p', 'composer-dry-banner', 'Dry run is ON: nothing will be posted');
    dryBanner.dataset.role = 'dryRunBanner';
    dryBanner.setAttribute('role', 'status');
    dryBanner.hidden = true;
    confirmParts = buildConfirmPanel();
    const type = buildNoteTypeSelect();
    refs.noteType = type.select;
    refs.typeBadge = type.badge;
    typeRow = type.row;
  } else {
    foot.append(create('span', 'composer-spacer'));
  }
  foot.append(buttons);

  const result = create('p', 'composer-result');
  result.dataset.role = 'result';
  result.dataset.state = 'idle';
  result.setAttribute('role', 'status');
  refs.result = result;
  const resultLink = create('a', 'composer-result-link', 'Open the incident');
  resultLink.dataset.role = 'resultLink';
  resultLink.target = '_blank';
  resultLink.rel = 'noopener noreferrer';
  resultLink.hidden = true;
  refs.resultLink = resultLink;

  panel.append(head);
  if (ticket) {
    panel.append(typeRow, dryBanner);
    refs.dryRunBanner = dryBanner;
  }
  panel.append(guide.section, grid, foot);
  if (ticket) {
    panel.append(confirmParts.panel);
    refs.confirmPanel = confirmParts.panel;
    refs.confirmHeading = confirmParts.heading;
    refs.confirmTarget = confirmParts.target;
    refs.confirmKind = confirmParts.kind;
    refs.confirmVisible = confirmParts.visible;
    refs.confirmDryRun = confirmParts.dry;
    refs.confirmText = confirmParts.text;
    refs.confirmDup = confirmParts.dup;
    refs.confirmAck = confirmParts.ack;
    refs.confirmBack = confirmParts.back;
    refs.confirmSend = confirmParts.send;
  }
  panel.append(result, resultLink);
  td.append(panel);
  tr.append(td);
  composer.node = tr;
  composer.refs = refs;
}

// ---- the guide inside the composer ----

/** The guide produced `text`: it goes into the box unless the user has edited the box. */
function adoptGenerated(composer, text) {
  const untouched = composer.text === composer.template;
  composer.template = text;
  if (untouched) composer.text = text;
}

const shownMessage = (message) => (message.ok ? message.text : message.previewText || '');

function onGuideChange(composer, { message }) {
  if (composer.finished) return; // what was posted stays on screen as it was sent
  composer.guideMessage = message;
  adoptGenerated(composer, shownMessage(message));
  saveGuideState(composer);
  if (!composer.working) composer.result = null;
  if (!composer.syncing && composer === state.composer) syncActiveComposer();
}

/** "Use this message" / "Regenerate": the guide's text replaces the box, which is then in step again. */
function takeGuideText(composer, text, { focusSend = false } = {}) {
  composer.text = text;
  composer.template = text;
  if (!composer.working) composer.result = null;
  if (composer === state.composer) syncActiveComposer();
  if (focusSend && composer.refs && !composer.refs.send.disabled) composer.refs.send.focus();
}

function mountGuide(composer, row) {
  const ctx = guideCtx(composer, row);
  composer.guideCtxKey = JSON.stringify(ctx);
  composer.guide = mountFollowUpGuide(composer.refs.guideHost, {
    ctx,
    snapshot: composer.guideSnapshot || undefined,
    onChange: (change) => onGuideChange(composer, change),
    onUse: (text) => takeGuideText(composer, text, { focusSend: true }),
    onRegenerate: (text) => takeGuideText(composer, text),
  });
  composer.guideMessage = composer.guide.getMessage();
  adoptGenerated(composer, shownMessage(composer.guideMessage));
  saveGuideState(composer);
}

function unmountGuide(composer) {
  if (!composer.guide) return;
  saveGuideState(composer);
  composer.guide.destroy();
  composer.guide = null;
  composer.guideMessage = null;
  composer.guideCtxKey = '';
}

/** Mount, unmount and feed the guide so that it matches the channel, the note type and the row. */
function syncGuide(composer, row) {
  const { refs } = composer;
  const available = guideAvailable(composer);
  const want = available && composer.guideWanted;
  refs.guideSection.hidden = !available;
  refs.guideHost.hidden = !want;
  refs.guideToggle.checked = composer.guideWanted;
  if (want && !composer.guide) mountGuide(composer, row);
  else if (!want && composer.guide) unmountGuide(composer);
  if (!composer.guide || composer.working || composer.finished) return; // nothing changes under a request or a posted text
  const ctx = guideCtx(composer, row);
  const key = JSON.stringify(ctx);
  if (key !== composer.guideCtxKey) {
    composer.guideCtxKey = key;
    composer.guide.setCtx(ctx);
  }
  composer.guide.setEdited(isEdited(composer));
}

/** Free the guide of a composer that is closed or replaced (the answers stay in state.guides). */
function releaseComposer(composer) {
  teardownConfirm(composer);
  unmountGuide(composer);
}

// ---- drafts ----

function placeholderHint(text) {
  const found = GUIDE_PLACEHOLDER.exec(text);
  return found ? `The message still contains ${found[0]}. Fill it in or remove it before sending.` : '';
}

function checkTicketDraft(text) {
  const note = validateNoteText(text, isComments() ? 'comment' : 'work note');
  const empty = !text.trim();
  let hint = '';
  if (!note.ok) hint = empty ? TEXT.emptyMessage : note.message;
  else hint = placeholderHint(text);
  return {
    ok: note.ok,
    preview: note.ok ? note.text : '',
    hint,
    limit: WORKNOTE_MAX,
    over: false,
  };
}

function checkTeamsDraft(row, text) {
  const message = text.trim();
  const over = message.length > TEAMS_MESSAGE_MAX;
  const link = message && !over ? buildTeamsLink({ email: row.callerEmail, message: text }) : null;
  let preview = '';
  if (link) {
    try {
      preview = new URL(link).searchParams.get('message') || '';
    } catch {
      preview = '';
    }
  } else if (over) {
    preview = message; // nothing is sent shortened: show all of it
  }
  let hint = '';
  if (!message) hint = TEXT.emptyMessage;
  else if (!over && !buildTeamsLink({ email: row.callerEmail, message: 'x' })) hint = TEXT.noEmail;
  else if (!over) hint = placeholderHint(text);
  return { ok: Boolean(link), preview, hint, limit: TEAMS_MESSAGE_MAX, over, length: message.length };
}

// ---- wording that depends on the channel and the note type ----

function headWording(composer, row) {
  if (composer.channel === 'teams') {
    return {
      title: `Teams message to ${str(row.callerName) || str(row.callerEmail) || 'the user'}`,
      sub: `Opens a Teams chat with ${str(row.callerEmail)} in a new tab, with this message already in the link. `
        + 'You still press Send inside Teams; until then the message only sits in that link and in your browser history.',
      edit: 'Message (editable)',
      preview: 'Preview: exactly what the Teams chat is prefilled with',
    };
  }
  const n = composer.incidentNumber;
  if (isComments()) {
    return {
      title: `Update ticket ${n}: comment to the user`,
      sub: 'Adds an additional comment through your logged-in ServiceNow session. The user can see it and ServiceNow emails it to them. Nothing is saved until you review and confirm.',
      edit: 'Comment to the user (editable)',
      preview: `Preview: exactly what is added to ${n}`,
    };
  }
  return {
    title: `Update ticket ${n}: internal work note`,
    sub: 'Adds a work note through your logged-in ServiceNow session. It is internal: the user does not see it and no email is sent. Nothing is saved until you review and confirm.',
    edit: 'Work note (editable)',
    preview: `Preview: exactly what is added to ${n}`,
  };
}

function idleMessage(composer, dryRun) {
  if (composer.channel === 'teams') return 'Teams opens in a new tab with this message. You press Send there.';
  if (dryRun) return 'Dry run is on: every check runs, but nothing is saved to ServiceNow.';
  return isComments()
    ? 'Review the exact text before it goes out: the user sees it and ServiceNow emails it to them.'
    : 'Review the exact text before it is added: it is internal, the user does not see it and no email is sent.';
}

function effectiveResult(composer, lock, dryRun, waiting) {
  if (composer.working && composer.result) return composer.result;
  if (lock) return { state: 'warn', message: lock, link: '' };
  if (composer.result) return composer.result;
  if (waiting) return { state: 'idle', message: TEXT.guideWaiting, link: '' };
  return { state: 'idle', message: idleMessage(composer, dryRun), link: '' };
}

function sendLabel(composer) {
  if (composer.channel === 'teams') return 'Open Teams chat';
  if (composer.finished) return 'Posted';
  if (composer.working) return 'Working...';
  return 'Review and send';
}

function limitSentence(draft) {
  return `This message has ${draft.length} characters, but a Teams link holds at most ${draft.limit}, so Teams would cut it off. It is not sent shortened: copy it and paste it into Teams yourself, shorten it, or send it as a ticket update.`;
}

// ---- the confirm panel: arming, the snapshot, disarming ----

// performance.now(): a real, monotonic elapsed-time clock, deliberately NOT window.Date (which the e2e
// rig freezes to simulate a fixed "now" for business-hours/row calculations). The 800ms arm delay is a
// real human-reaction-time guard, not part of that simulated ticket clock, and must keep advancing
// under a frozen Date exactly as it would for a real person waiting out the countdown.
const monotonicNow = () => (typeof performance !== 'undefined' && typeof performance.now === 'function' ? performance.now() : Date.now());

function confirmRemainingMs(composer) {
  return composer.confirm ? Math.max(0, CONFIRM_ARM_MS - (monotonicNow() - composer.confirm.openedAt)) : 0;
}

/** Repaint every tick while the panel's own button is still disabled, so the countdown is visible. */
function scheduleConfirmTick(composer) {
  const tick = () => {
    if (!composer.confirm) return;
    if (composer === state.composer) syncActiveComposer();
    const left = CONFIRM_ARM_MS - (monotonicNow() - composer.confirm.openedAt);
    if (left > 0) composer.confirm.tickTimer = setTimeout(tick, Math.min(CONFIRM_TICK_MS, left));
  };
  composer.confirm.tickTimer = setTimeout(tick, CONFIRM_TICK_MS);
}

/** Close the panel without sending; a non-empty `notice` is shown as the reason (a live disarm). */
function closeConfirmPanel(composer, notice = '') {
  if (!composer.confirm) return;
  clearTimeout(composer.confirm.tickTimer);
  composer.confirm = null;
  if (notice) composer.result = { state: 'warn', message: notice, link: '' };
  else if (!composer.working) composer.result = null;
  if (composer === state.composer) syncActiveComposer();
}

/** Tear the panel down with no side effect on `result` (the composer itself is being destroyed). */
function teardownConfirm(composer) {
  if (composer.confirm) clearTimeout(composer.confirm.tickTimer);
  composer.confirm = null;
}

async function sha256Hex(text) {
  const bytes = new TextEncoder().encode(text);
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

/**
 * chrome.storage.local 'updateAttempts' (a ring buffer another part of the extension writes; contract
 * 13.5): warn and require an extra acknowledgement when the same incident + field + text was already
 * attempted in the last 24 hours. Absent/garbage storage is read as "no recent attempt", never a crash.
 */
async function checkRecentAttempt(composer, snapshot) {
  let found = false;
  try {
    const hash = await sha256Hex(snapshot.text);
    const stored = await chrome.storage.local.get('updateAttempts');
    const list = Array.isArray(stored.updateAttempts) ? stored.updateAttempts : [];
    const now = Date.now();
    found = list.some((entry) => isObject(entry)
      && entry.incidentNumber === snapshot.incidentNumber
      && entry.field === snapshot.field
      && entry.textHash === hash
      && typeof entry.at === 'string'
      && now - Date.parse(entry.at) >= 0
      && now - Date.parse(entry.at) < DUP_WINDOW_MS);
  } catch {
    found = false; // storage or crypto unavailable: never block a send on a check that could not run
  }
  if (!composer.confirm || composer.confirm.snapshot !== snapshot) return; // disarmed / replaced meanwhile
  composer.confirm.dup.checking = false;
  composer.confirm.dup.found = found;
  if (composer === state.composer) syncActiveComposer();
}

function focusConfirmPanel(composer) {
  if (composer.refs && composer.refs.confirmHeading) composer.refs.confirmHeading.focus({ preventScroll: true });
}

/**
 * Open the review panel for a real ticket update: a snapshot of exactly what will be sent, bound at
 * this moment. Never auto-focuses the panel's send button; focus goes to the panel's heading.
 */
function openConfirmPanel(composer, row) {
  if (composer.confirm) {
    focusConfirmPanel(composer);
    return;
  }
  const note = validateNoteText(composer.text, isComments() ? 'comment' : 'work note');
  if (!note.ok) {
    setResult(composer, 'error', note.message);
    return;
  }
  const info = noteInfo();
  const snapshot = {
    dryRun: state.data.settings.dryRun,
    field: info.field,
    text: note.text,
    incidentNumber: composer.incidentNumber,
    origin: row.instanceOrigin,
  };
  composer.confirm = {
    snapshot,
    openRawText: composer.text,
    openedAt: monotonicNow(),
    tickTimer: 0,
    dup: { checking: !snapshot.dryRun, found: false, acked: false },
  };
  composer.result = null;
  scheduleConfirmTick(composer);
  syncActiveComposer();
  focusConfirmPanel(composer);
  if (!snapshot.dryRun) void checkRecentAttempt(composer, snapshot);
}

function onConfirmBack() {
  const composer = state.composer;
  if (!composer || !composer.confirm) return;
  closeConfirmPanel(composer);
  if (composer.refs.send && !composer.refs.send.disabled) composer.refs.send.focus();
}

function onConfirmAckChange(composer, checked) {
  if (!composer.confirm) return;
  composer.confirm.dup.acked = checked;
  syncActiveComposer();
}

// ---- open / close / settle ----

/** Put focus where the person works next: the review panel, the guide's current question, else the box. */
function focusComposer(composer) {
  if (composer.confirm) focusConfirmPanel(composer);
  else if (guideActive(composer)) composer.guide.focusCurrent();
  else composer.refs.textarea.focus();
}

/**
 * Open the composer of a row for a channel ('teams' | 'ticket'); an open one is replaced unless it is
 * busy. `carry` hands the text and the guide of the replaced composer over (Teams -> ticket update).
 */
export function openComposer(row, channel, carry = null) {
  const current = state.composer;
  if (current && current.working) {
    focusComposer(current);
    return;
  }
  if (current && current.incidentNumber === row.incidentNumber && current.channel === channel) {
    focusComposer(current);
    return;
  }
  if (current) releaseComposer(current);
  state.composer = createComposer(row, channel, carry);
  hooks.paint();
}

/** Close the open composer; `returnFocus` puts focus back on the button that opened it. */
function closeComposer({ returnFocus = false } = {}) {
  const composer = state.composer;
  if (!composer) return;
  releaseComposer(composer);
  state.composer = null;
  if (returnFocus) state.pendingFocus = { incident: composer.incidentNumber, action: composer.channel };
  hooks.paint();
}

/**
 * A composer whose row has disappeared (cleared storage, another day, ...) cannot stay open; one that
 * is mid-request is kept until the request has finished so its result is not lost.
 */
export function settleComposer() {
  const composer = state.composer;
  if (!composer || composer.working || state.rowsByNumber.has(composer.incidentNumber)) return;
  const what = composer.channel === 'teams' ? 'Teams message' : 'ticket update';
  releaseComposer(composer);
  state.composer = null;
  hooks.showNotice(`The ${what} for ${composer.incidentNumber} was closed because that ticket is no longer listed.`, 'info');
}

/** The DOM node of the composer for the ticket table's reconcile (built on first use). */
export function composerNodeFor(composer) {
  if (!composer.node) buildComposerNode(composer);
  return composer.node;
}

// ---- follow-up log ----

function recordFollowUp(composer, info) {
  let channel = 'teams';
  if (composer.channel !== 'teams') channel = info.field === 'comments' ? 'comment' : 'worknote';
  const entry = {
    at: new Date().toISOString(),
    incidentNumber: composer.incidentNumber,
    channel,
    dryRun: info.dryRun === true,
    // `ok` keeps its plain boolean meaning (lib/followup.js); an UNKNOWN outcome (the background never
    // answered a REAL post) is never claimed as "ok" either, and is flagged separately so it reads as
    // UNKNOWN, not as a plain failure (contract 13.6 UNKNOWN OUTCOMES; lib/followup.js describeFollowUp).
    ok: info.ok === true,
    unknown: info.ok === null,
    verified: info.verified === undefined ? null : info.verified,
    textPreview: previewOf(info.text),
    note: info.note || '',
  };
  state.data = { ...state.data, log: appendFollowUp(state.data.log, entry) };
  hooks.paint();
  persistFollowUp(entry).catch(() => {});
}

// ---- sending ----

async function sendTeams(composer, row) {
  const draft = checkTeamsDraft(row, composer.text);
  const link = draft.ok ? buildTeamsLink({ email: row.callerEmail, message: composer.text }) : null;
  if (!link) return;
  composer.working = true;
  setResult(composer, 'working', 'Opening Teams ...');
  try {
    await openUrl(link);
  } catch (err) {
    composer.working = false;
    setResult(composer, 'error', `Could not open Teams: ${errorText(err)}`);
    return;
  }
  composer.working = false;
  setResult(composer, 'ok', TEXT.teamsOpened);
  recordFollowUp(composer, { ok: true, verified: null, text: draft.preview, note: 'Teams chat opened' });
}

function failure(message) {
  return {
    state: 'error', message, ok: false, posted: false, dryRun: false, verified: null, link: '',
  };
}

/** A transport failure of a REAL post: the background may have received and even saved it. Never call this "failed". */
function unknownResult(message, link) {
  return {
    state: 'unknown', message, ok: null, posted: null, dryRun: false, verified: null, link,
  };
}

/** Maps the POST_TICKET_UPDATE reply to what is shown and logged. The reply, not the request, decides. */
function interpretUpdateReply(reply, field) {
  if (!isObject(reply)) return failure(MSG.noResponse);
  if (!reply.ok) return failure(replyError(reply, 'The ticket could not be updated.'));
  const result = isObject(reply.result) ? reply.result : {};
  if (result.status === 'dryrun' || result.dryRun === true) {
    return {
      state: 'ok', message: TEXT.dryRunOk, ok: true, posted: false, dryRun: true, verified: null, link: '',
    };
  }
  if (result.status !== 'posted') {
    // An unrecognised status: never claim success, but this is not a transport failure either.
    return failure('The extension returned an unexpected answer. Open the incident to check it.');
  }
  if (result.verified === true) {
    const message = field === 'comments' ? TEXT.verifiedComment : TEXT.verifiedNote;
    return {
      state: 'ok', message, ok: true, posted: true, dryRun: false, verified: true, link: '',
    };
  }
  return {
    state: 'warn', message: str(result.message) || TEXT.unverified, ok: true, posted: true, dryRun: false, verified: false, link: '',
  };
}

async function requestUpdate(row, field, text, dryRun) {
  // First awaited work in the click handler chain: permissions.request needs the click's user gesture.
  // Gated by confirmHost.js's in-app dialog for a host outside *.service-now.com (contract 13.5).
  const permission = await ensureOriginPermissionConfirmed(row.instanceOrigin);
  if (!permission.ok) return failure(permission.message);
  const { reply, failure: failed } = await sendRuntimeMessage({
    type: 'POST_TICKET_UPDATE',
    instanceUrl: permission.origin,
    incidentNumber: row.incidentNumber,
    field,
    text,
    dryRun,
  });
  if (failed) {
    // A dry run writes nothing even if the message did get through, so the plain failure wording is
    // honest; a REAL post that we never heard back from is reported as UNKNOWN, never as "not saved".
    if (dryRun) return failure(failed);
    return unknownResult(TEXT.unknownOutcome, row.incidentUrl);
  }
  return interpretUpdateReply(reply, field);
}

/** Sends exactly the reviewed snapshot (never a possibly-edited `composer.text`). */
async function postUpdate(composer, row, snapshot) {
  const { field, text, dryRun } = snapshot;
  composer.working = true;
  setResult(composer, 'working', dryRun
    ? 'Running the dry run ...'
    : `Adding the ${field === 'comments' ? 'comment' : 'work note'} to ${composer.incidentNumber} ... this can take up to half a minute.`);
  const outcome = await requestUpdate(row, field, text, dryRun);
  composer.working = false;
  composer.finished = outcome.posted === true;
  // A real post ends this follow-up: the next one starts with fresh questions.
  if (outcome.posted) state.guides.delete(composer.incidentNumber);
  setResult(composer, outcome.state, outcome.message, outcome.link || '');
  recordFollowUp(composer, {
    field, ok: outcome.ok, verified: outcome.verified, dryRun: outcome.dryRun, text, note: outcome.message,
  });
  if (outcome.posted) void hooks.refreshRow(row);
}

function setResult(composer, resultState, message, link = '') {
  composer.result = { state: resultState, message, link };
  if (composer === state.composer) syncActiveComposer();
}

function onSend() {
  const composer = state.composer;
  const row = composer && state.rowsByNumber.get(composer.incidentNumber);
  if (!composer || !row || composer.working || composer.finished || composerLock(composer, row)) return;
  if (composer.refs.send.disabled) return;
  if (composer.channel === 'teams') {
    void sendTeams(composer, row);
    return;
  }
  openConfirmPanel(composer, row);
}

/** The panel's own confirm button: ignores a double click (detail > 1) and never re-sends a snapshot. */
function onConfirmSend(event) {
  const composer = state.composer;
  const row = composer && state.rowsByNumber.get(composer.incidentNumber);
  if (!composer || !row || !composer.confirm || composer.working || composer.finished) return;
  if (event && typeof event.detail === 'number' && event.detail > 1) return; // the double click's 2nd event
  if (composer.refs.confirmSend.disabled) return; // still arming, or the duplicate box is unacknowledged
  const { snapshot, tickTimer } = composer.confirm;
  clearTimeout(tickTimer);
  composer.confirm = null; // consumed: a later click (its own detail reset to 1) opens a FRESH panel
  syncActiveComposer();
  void postUpdate(composer, row, snapshot);
}

// ---- the Teams message that is too long ----

async function onCopyMessage(composer) {
  const text = composer.text.trim();
  if (!text) return;
  const copied = await copyText(text);
  if (composer === state.composer && !composer.working) setResult(composer, copied ? 'ok' : 'error', copied ? TEXT.copied : TEXT.copyFailed);
}

/** The same message as a comment the user is emailed: a new ticket composer takes the text and the guide over. */
function onUseTicketInstead(composer, row) {
  if (composer.working || !row.instanceOrigin) return;
  if (composer.guide) saveGuideState(composer);
  const carry = {
    text: composer.text,
    template: composer.template,
    guideWanted: composer.guideWanted,
    guideSnapshot: composer.guideSnapshot,
  };
  if (state.data.settings.noteType !== 'comments') {
    // The message is for the user: it must go out as a comment, never as an internal note.
    state.data = { ...state.data, settings: normalizeSettings({ ...state.data.settings, noteType: 'comments' }) };
    persistSettings({ noteType: 'comments' }).catch(() => {});
  }
  releaseComposer(composer);
  state.composer = createComposer(row, 'ticket', carry);
  state.composer.result = { state: 'idle', message: TEXT.switchedToTicket, link: '' };
  hooks.paint();
}

// ---- events (delegated from the table body) ----

/**
 * Click on a button inside the composer row (Cancel / send / the panel's Back and Confirm / the
 * Teams-limit buttons / Regenerate). `event` (when given) is the real click, so the panel's own send
 * can tell a genuine click from the second event of a double click.
 */
export function onComposerClick(target, event) {
  const composer = state.composer;
  const row = composer && state.rowsByNumber.get(composer.incidentNumber);
  const { role } = target.dataset;
  if (role === 'cancel') {
    closeComposer({ returnFocus: true });
    return;
  }
  if (role === 'send') {
    onSend();
    return;
  }
  if (role === 'confirmSend') {
    onConfirmSend(event);
    return;
  }
  if (role === 'confirmBack') {
    onConfirmBack();
    return;
  }
  if (!composer || !row) return;
  if (role === 'copyMessage') {
    void onCopyMessage(composer);
  } else if (role === 'useTicket') {
    onUseTicketInstead(composer, row);
  } else if (role === 'regenerateMessage' && composer.guide) {
    takeGuideText(composer, shownMessage(composer.guide.getMessage()));
    composer.refs.textarea.focus();
  }
}

/** Typing in the composer: keep the draft; the review panel (if open) disarms on its own next sync. */
export function onComposerInput(event) {
  const composer = state.composer;
  if (!composer || !event.target.matches('textarea[data-role="message"]')) return;
  composer.text = event.target.value;
  if (!composer.working) composer.result = null;
  syncActiveComposer();
}

function changeNoteType(composer, value) {
  const row = state.rowsByNumber.get(composer.incidentNumber);
  const untouched = composer.text === composer.template;
  state.data = { ...state.data, settings: normalizeSettings({ ...state.data.settings, noteType: value }) };
  // Without the guide (an internal work note, or "Guide me" switched off) the plain template of the new
  // type replaces an unedited text; with the guide, it writes the text itself once it is mounted.
  if (untouched && row && !(guideAvailable(composer) && composer.guideWanted)) {
    composer.template = templateText('ticket', row);
    composer.text = composer.template;
  }
  if (!composer.working) composer.result = null;
  syncActiveComposer();
  persistSettings({ noteType: state.data.settings.noteType }).catch(() => {});
}

function changeGuideToggle(composer, checked) {
  composer.guideWanted = checked;
  state.guides.set(composer.incidentNumber, { snapshot: composer.guideSnapshot, wanted: checked });
  if (!composer.working) composer.result = null;
  syncActiveComposer();
}

/** The dry-run switch, the note-type select, the "Guide me" switch or the duplicate ack box changed. */
export function onComposerChange(event) {
  const composer = state.composer;
  if (!composer) return;
  const { target } = event;
  if (target.matches('input[data-role="dryRun"]')) {
    state.data = { ...state.data, settings: normalizeSettings({ ...state.data.settings, dryRun: target.checked }) };
    if (!composer.working) composer.result = null;
    syncActiveComposer();
    persistSettings({ dryRun: target.checked }).catch(() => {});
  } else if (target.matches('select[data-role="noteType"]')) {
    changeNoteType(composer, target.value);
  } else if (target.matches('input[data-role="guideToggle"]')) {
    changeGuideToggle(composer, target.checked);
  } else if (target.matches('input[data-role="confirmAck"]')) {
    onConfirmAckChange(composer, target.checked);
  }
}

/**
 * Escape closes just the review panel (back to editing) when it is open; otherwise it closes the
 * whole composer, as before. A held Enter/Space on the panel's own send button is ignored (a repeat
 * keydown must never re-trigger its activation): Chromium re-fires a button's click on every repeated
 * Enter keydown while the key is held, so this is the keyboard half of the double-click defence.
 */
export function onComposerKeydown(event) {
  const composer = state.composer;
  if (!composer) return;
  const { target } = event;
  if (target && target.dataset && target.dataset.role === 'confirmSend' && event.repeat && (event.key === 'Enter' || event.key === ' ')) {
    event.preventDefault();
    return;
  }
  // A newline in the message box is just a newline: there is no submit-on-Enter here to defuse, but
  // this makes the intent explicit and gives the regression rig something concrete to pin down.
  if (target && target.matches && target.matches('textarea[data-role="message"]') && event.key === 'Enter') return;
  if (event.key !== 'Escape' || composer.working || event.isComposing) return;
  if (!event.target.closest('tr[data-composer-for]')) return;
  event.preventDefault();
  if (composer.confirm) {
    closeConfirmPanel(composer);
    if (composer.refs.send && !composer.refs.send.disabled) composer.refs.send.focus();
    return;
  }
  closeComposer({ returnFocus: true });
}

/** Focus what a composer that has just been put on screen starts with (the guide's question, or the box). */
export function focusNewComposer() {
  const composer = state.composer;
  if (!composer || !composer.needsFocus || !composer.node || !composer.node.isConnected) return;
  composer.needsFocus = false;
  if (guideActive(composer)) {
    composer.guide.focusCurrent();
  } else {
    const { textarea } = composer.refs;
    textarea.focus({ preventScroll: true });
    textarea.setSelectionRange(textarea.value.length, textarea.value.length);
  }
  composer.node.scrollIntoView({ block: 'nearest' });
}

// ---- syncing the DOM to the state ----

/** The panel is bound to the snapshot it opened with: any live change disarms it immediately. */
function checkConfirmStillValid(composer, row) {
  if (!composer.confirm) return '';
  const { snapshot, openRawText } = composer.confirm;
  const changed = state.data.settings.dryRun !== snapshot.dryRun
    || noteInfo().field !== snapshot.field
    || row.instanceOrigin !== snapshot.origin
    || composer.text !== openRawText;
  if (!changed) return '';
  clearTimeout(composer.confirm.tickTimer);
  composer.confirm = null;
  return TEXT.settingsChanged;
}

function syncConfirmPanel(composer) {
  const { refs, confirm } = composer;
  const open = Boolean(confirm);
  refs.confirmPanel.hidden = !open;
  if (!open) return;
  const { snapshot, dup } = confirm;
  const host = hostOf(snapshot.origin) || snapshot.origin || 'this instance';
  setText(refs.confirmTarget, `${snapshot.incidentNumber} on ${host}`);
  setText(refs.confirmKind, snapshot.field === 'comments' ? 'Comment to the user' : 'Internal work note');
  refs.confirmVisible.hidden = snapshot.field !== 'comments';
  refs.confirmDryRun.hidden = !snapshot.dryRun;
  setText(refs.confirmText, snapshot.text);
  const remaining = confirmRemainingMs(composer);
  const seconds = Math.ceil(remaining / 1000);
  refs.confirmDup.hidden = !dup.found;
  if (dup.found) refs.confirmAck.checked = dup.acked;
  setText(refs.confirmSend, remaining > 0 ? `Confirm and post (${seconds}s)` : 'Confirm and post');
  refs.confirmSend.disabled = remaining > 0 || dup.checking || (dup.found && !dup.acked);
  refs.confirmSend.classList.toggle('is-dry', snapshot.dryRun);
}

/** Bring the composer's DOM in line with its state. Never recreates nodes, so focus and caret stay. */
function syncComposer(composer, row) {
  const { refs } = composer;
  const ticket = composer.channel === 'ticket';
  composer.syncing = true;
  try {
    syncGuide(composer, row);
  } finally {
    composer.syncing = false;
  }

  const disarmNotice = checkConfirmStillValid(composer, row);
  if (disarmNotice) composer.result = { state: 'warn', message: disarmNotice, link: '' };

  const lock = composerLock(composer, row);
  const draft = ticket ? checkTicketDraft(composer.text) : checkTeamsDraft(row, composer.text);
  const { dryRun } = state.data.settings;
  const busy = composer.working;
  const locked = busy || composer.finished;
  const words = headWording(composer, row);
  const guided = guideActive(composer);
  const edited = isEdited(composer);
  const waiting = guided && !edited && !(composer.guideMessage && composer.guideMessage.ok);

  setText(refs.title, words.title);
  setText(refs.sub, words.sub);
  setText(refs.editLabel, words.edit);
  setText(refs.previewLabel, words.preview);
  if (refs.noteType) {
    if (refs.noteType.value !== state.data.settings.noteType) refs.noteType.value = state.data.settings.noteType;
    refs.noteType.disabled = locked;
    setText(refs.typeBadge, isComments() ? 'The user is emailed' : 'Internal only');
    refs.typeBadge.dataset.kind = isComments() ? 'email' : 'internal';
  }
  if (refs.dryRunBanner) refs.dryRunBanner.hidden = !dryRun;

  refs.guideToggle.disabled = locked;
  refs.guideHost.inert = locked;
  refs.editedNote.hidden = !(guided && edited);
  refs.regenerate.disabled = locked;

  if (refs.textarea.value !== composer.text) refs.textarea.value = composer.text;
  refs.textarea.readOnly = locked;
  const showInvalid = !draft.ok && Boolean(composer.text.trim());
  if (showInvalid) refs.textarea.setAttribute('aria-invalid', 'true');
  else refs.textarea.removeAttribute('aria-invalid');
  setText(refs.hint, draft.hint);
  refs.hint.hidden = !draft.hint;
  setText(refs.count, `${composer.text.trim().length} / ${draft.limit}`);
  refs.count.classList.toggle('is-over', composer.text.trim().length > draft.limit);
  setText(refs.preview, draft.preview);

  refs.limit.hidden = !draft.over;
  if (draft.over) setText(refs.limitText, limitSentence(draft));
  refs.copy.disabled = busy;
  refs.useTicket.disabled = busy || !row.instanceOrigin;
  refs.useTicket.title = row.instanceOrigin ? 'Open a ticket update (a comment the user is emailed) with this message' : TEXT.noInstance;

  if (refs.dryRun) {
    refs.dryRun.checked = dryRun;
    refs.dryRun.disabled = locked;
  }

  setText(refs.send, sendLabel(composer));
  refs.send.disabled = locked || Boolean(lock) || !draft.ok || waiting || Boolean(composer.confirm);
  refs.send.classList.toggle('is-dry', dryRun);
  if (busy) refs.send.setAttribute('aria-busy', 'true');
  else refs.send.removeAttribute('aria-busy');
  setText(refs.cancel, composer.finished || (composer.result && composer.result.state === 'ok') ? 'Close' : 'Cancel');
  refs.cancel.disabled = busy;

  if (refs.confirmPanel) syncConfirmPanel(composer);

  const result = effectiveResult(composer, lock, dryRun, waiting);
  refs.result.dataset.state = result.state;
  setText(refs.result, result.message);
  const href = result.link ? safeHttpUrl(result.link) : '';
  refs.resultLink.hidden = !href;
  if (href) refs.resultLink.href = href;
}

/** Sync the open composer (if any) with its row and the current settings. */
export function syncActiveComposer() {
  const composer = state.composer;
  const row = composer && state.rowsByNumber.get(composer.incidentNumber);
  if (composer && composer.refs && row) syncComposer(composer, row);
}
