// An in-app confirmation shown before this page asks the browser for permission to read a
// ServiceNow address that is not *.service-now.com (contract 13.5 MANIFEST / 13.6 ROWS: "for any
// origin outside service-now.com the dashboard shows an in-app confirmation naming the host BEFORE
// permissions.request"). The actual chrome.permissions.request call stays in messaging.js (owned by
// the module doing the confirm-panel hardening of this pass); this file only gates the files that
// call it (search.js, tickets.js, refreshbar.js), and only when the permission is not already held
// (so a returning user who already granted access is never re-prompted, and the dev/e2e mock, whose
// localhost origin is a manifest host_permission rather than an optional one, is never prompted
// either: chrome.permissions.contains already answers true for it).
import { parseInstanceUrl } from '../lib/instance.js';
import { isServiceNowHost } from '../lib/instance.js';
import { create } from './dom.js';
import { ensureOriginPermission, ensureOriginsPermission } from './messaging.js';

let activeDialog = null;

function buildDialog(host, resolve) {
  if (activeDialog) activeDialog.remove();
  const backdrop = create('div', 'host-confirm-backdrop');
  const dialog = create('div', 'host-confirm');
  dialog.setAttribute('role', 'alertdialog');
  dialog.setAttribute('aria-modal', 'true');
  dialog.setAttribute('aria-labelledby', 'hostConfirmTitle');
  dialog.setAttribute('aria-describedby', 'hostConfirmText');
  const heading = create('h2', 'host-confirm-title', 'Allow access to this address?');
  heading.id = 'hostConfirmTitle';
  const text = create('p', 'host-confirm-text');
  text.id = 'hostConfirmText';
  text.append(create('strong', '', host), ' is not a ', create('code', '', '*.service-now.com'),
    ' address. The browser will ask you to allow this extension to read pages on that site. Continue only if this is your own ServiceNow instance.');
  const buttons = create('div', 'host-confirm-buttons');
  const cancel = create('button', 'btn btn-secondary', 'Cancel');
  cancel.type = 'button';
  const proceed = create('button', 'btn btn-primary', 'Continue');
  proceed.type = 'button';
  buttons.append(cancel, proceed);
  dialog.append(heading, text, buttons);
  backdrop.append(dialog);

  const finish = (value) => {
    backdrop.remove();
    document.removeEventListener('keydown', onKeydown, true);
    if (activeDialog === backdrop) activeDialog = null;
    resolve(value);
  };
  function onKeydown(event) {
    if (event.key === 'Escape') {
      event.preventDefault();
      finish(false);
    }
  }
  cancel.addEventListener('click', () => finish(false));
  proceed.addEventListener('click', () => finish(true));
  backdrop.addEventListener('click', (event) => {
    if (event.target === backdrop) finish(false);
  });
  document.addEventListener('keydown', onKeydown, true);
  document.body.append(backdrop);
  proceed.focus();
  activeDialog = backdrop;
  return backdrop;
}

/** True at once for a *.service-now.com host; otherwise shows the dialog and resolves with the choice. */
function confirmForeignHost(host) {
  if (!host || isServiceNowHost(host)) return Promise.resolve(true);
  return new Promise((resolve) => buildDialog(host, resolve));
}

async function alreadyGranted(pattern) {
  try {
    return await chrome.permissions.contains({ origins: [pattern] });
  } catch {
    return false;
  }
}

/**
 * ensureOriginPermission, gated by an in-app confirmation for a non-service-now.com host that is not
 * already permitted. Must be called straight from a click handler, same as ensureOriginPermission:
 * the Continue button's own click keeps the user gesture alive into the permissions.request call
 * that follows in the same microtask continuation.
 */
export async function ensureOriginPermissionConfirmed(origin) {
  const parsed = parseInstanceUrl(origin);
  if (!parsed.ok) return { ok: false, message: parsed.message };
  if (!(await alreadyGranted(parsed.pattern)) && !(await confirmForeignHost(parsed.host))) {
    return { ok: false, message: `Not confirmed: permission to access ${parsed.host} was not requested.` };
  }
  return ensureOriginPermission(origin);
}

/** ensureOriginsPermission, gated the same way for every origin that would otherwise need a prompt. */
export async function ensureOriginsPermissionConfirmed(origins) {
  const allowed = [];
  for (const origin of origins) {
    const parsed = parseInstanceUrl(origin);
    if (!parsed.ok) continue;
    // eslint-disable-next-line no-await-in-loop -- one dialog at a time, in order, is the point
    if ((await alreadyGranted(parsed.pattern)) || (await confirmForeignHost(parsed.host))) allowed.push(origin);
  }
  return ensureOriginsPermission(allowed);
}
