// Dashboard page (a full-page extension tab opened from the toolbar icon). Everything shown here
// originates from ServiceNow pages and is untrusted: it is written with textContent / setAttribute
// only, never parsed as HTML.
//
// Data flow: chrome.storage.local -> state.data (render) -> model (lib/dashboardModel.js, always with
// the CURRENT clock) -> DOM (paint). paint() never reads storage, so filters, composers and the
// 60-second tick do not wait for it. The page keeps no data of its own beyond what storage holds.
import { BUILD_ID } from '../lib/config.js';
import { buildRows } from '../lib/dashboardModel.js';
import { STALE_WORKER_TEXT, sendRuntimeMessage } from './messaging.js';
import { settleComposer } from './composer.js';
import { paintData, wireData } from './dataview.js';
import { initDiagnostics, paintDiagnostics, wireDiagnostics } from './diagnostics.js';
import { MIDDOT, errorText, systemTimeZone } from './dom.js';
import { els, missingElements } from './els.js';
import { paintHistory, wireHistory } from './history.js';
import { paintOverview, wireOverview } from './overview.js';
import { paintRedFlags, wireRedFlags } from './redflags.js';
import { paintFetchErrors, wireFetchErrors } from './fetcherrors.js';
// A namespace import for the tab badge, so a fetcherrors.js without it (an older build) cannot stop
// this whole page from loading over one missing named export.
import * as fetchErrorsView from './fetcherrors.js';
import {
  ALL_VIEWS, onTabClick, onTabKeydown, readHash, statusFilterValues, syncControls, tabElement, writeHash,
} from './nav.js';
import { paintRefreshBar, wireRefreshBar } from './refreshbar.js';
import { prefillSearch, wireBulkFetch, wireSearch } from './search.js';
import { wireLoadOpenTickets } from './opentickets.js';
import {
  effectiveBusinessHours, effectiveTimeZone, initSettings, paintSettings, wireSettings,
} from './settings.js';
import { hooks, state } from './state.js';
import { WATCHED_KEYS, applyStored, storageGet } from './store.js';
import {
  flashRow, paintTickets, refreshRow, scrollRowIntoView, wireTickets,
} from './tickets.js';

const TICK_MS = 60000;
const NOTICE_TTL_MS = 9000;
const CHANGE_DEBOUNCE_MS = 60;
// The QueueSenseITOps splash (dashboard.html #brandSplash) stays at least this long, fades out after
// the first paint, and is removed after SPLASH_MAX_MS whatever happens. It never takes clicks.
const SPLASH_MIN_MS = 900;
const SPLASH_MAX_MS = 4000;
const SPLASH_FADE_MS = 400;
const splashShownAt = Date.now();
let splashDismissed = false;

const CLOCK_FORMAT = new Intl.DateTimeFormat('en-GB', {
  hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23',
});

// ---- notice banner ----

function showNotice(message, noticeState) {
  clearTimeout(state.noticeTimer);
  els.notice.textContent = message;
  els.notice.dataset.state = noticeState;
  els.notice.hidden = false;
  state.noticeTimer = setTimeout(() => {
    els.notice.hidden = true;
  }, NOTICE_TTL_MS);
}

// ---- painting ----

/** Rebuild the model from the cached storage data and the current clock, then update the page. */
function paint() {
  const now = new Date();
  // The Settings tab (contract 13.1 / 13.6) lets the owner override the zone ServiceNow's times are
  // read in and the default business hours; every repaint picks up the latest saved value so a
  // settings change is reflected at once, with no special-case reload path.
  const timeZone = effectiveTimeZone(systemTimeZone());
  const businessHours = effectiveBusinessHours();
  let all;
  try {
    // queueTracking (v0.5, lib/queueTracking.js): which tickets the "Load all open tickets" runs found in
    // the saved queues; each row gains row.queue (new to the queue / moved out) and the agent's quiet time.
    all = buildRows(state.data.incidents, now, {
      businessHours, timeZone, day: state.day, queueTracking: state.data.queueTracking,
    });
  } catch (err) {
    document.body.classList.remove('is-loading');
    showNotice(`The ticket list could not be built: ${errorText(err)}`, 'error');
    return;
  }
  state.rowsByNumber = new Map(all.map((row) => [row.incidentNumber, row]));
  settleComposer();
  els.updatedAt.textContent = `Updated ${CLOCK_FORMAT.format(now)}`;
  els.dashSubtitle.textContent = `Tickets you looked up ${MIDDOT} times shown in your time zone, ${timeZone}`;
  paintRefreshBar(now);
  // The "Fetch errors (N)" tab label is visible from every view, so it follows every paint.
  try {
    if (typeof fetchErrorsView.syncFetchErrorsBadge === 'function') fetchErrorsView.syncFetchErrorsBadge();
  } catch {
    // the tab keeps its previous label until the next paint
  }
  if (state.view === 'tickets') paintTickets(now, timeZone, all);
  else if (state.view === 'overview') paintOverview(now, timeZone, all, businessHours);
  else if (state.view === 'flags') paintRedFlags(now, timeZone, businessHours);
  else if (state.view === 'errors') paintFetchErrors(now, timeZone);
  else if (state.view === 'history') paintHistory(now, timeZone);
  else if (state.view === 'diagnostics') paintDiagnostics();
  else if (state.view === 'settings') paintSettings();
  else paintData();
  syncScrollRegions();
  document.body.classList.remove('is-loading');
}

/** A table that scrolls sideways is a keyboard stop (to scroll it); one that fits is not. */
function syncScrollRegions() {
  for (const wrap of document.querySelectorAll('.table-wrap')) {
    wrap.tabIndex = wrap.scrollWidth > wrap.clientWidth ? 0 : -1;
  }
}

// ---- reading storage ----

let newestRender = Promise.resolve();

/**
 * Read chrome.storage.local into state.data and paint. Keys whose newest value has not been read yet
 * are remembered, so a newer render never loses an older one's keys; our own pending writes land first.
 * A render that a newer one supersedes resolves only when the newer one is done, so `await render()`
 * always means "what is stored now is on screen".
 */
function render(keys = WATCHED_KEYS) {
  for (const key of keys) state.pendingKeys.add(key);
  state.loadSeq += 1;
  newestRender = readAndPaint(state.loadSeq);
  return newestRender;
}

async function readAndPaint(seq) {
  for (;;) {
    do {
      await state.writeChain;
    } while (state.pendingWrites > 0);
    const wanted = [...state.pendingKeys];
    const stored = await storageGet(wanted);
    if (seq !== state.loadSeq) return newestRender;
    if (state.pendingWrites > 0) continue;
    if (stored === null) {
      // storage is unreadable right now: keep showing what we have; the next tick tries again
      showNotice('The stored tickets could not be read just now. The list shows what was loaded before.', 'error');
      return undefined;
    }
    for (const key of wanted) state.pendingKeys.delete(key);
    applyStored(stored, wanted);
    paint();
    return undefined;
  }
}

function onStorageChanged(changes, area) {
  if (area !== 'local') return;
  const keys = WATCHED_KEYS.filter((key) => key in changes);
  if (!keys.length) return;
  for (const key of keys) state.pendingKeys.add(key);
  clearTimeout(state.changeTimer);
  state.changeTimer = setTimeout(() => void render([]), CHANGE_DEBOUNCE_MS);
}

// ---- jumping between views ----

/**
 * Show a ticket's row in the Tickets view: leave a day filter that would hide it (a search always
 * lands on today; an older ticket from the history widens the day filter to all days), drop a status
 * filter that would hide it, then flash and scroll to it.
 */
async function showTicket(number, { flash = false, details = false } = {}) {
  await render();
  state.view = 'tickets';
  if (!['today', 'last7', 'all'].includes(state.day)) state.day = 'today';
  paint();
  let row = state.rowsByNumber.get(number);
  if (!row && state.day !== 'all') {
    state.day = 'all';
    paint();
    row = state.rowsByNumber.get(number);
  }
  // The business-hours filter is a list (empty = all): drop it only when it would hide this ticket.
  const statuses = statusFilterValues();
  if (row && statuses.length && !statuses.includes(row.nowStatus.status)) state.status = [];
  if (details) state.details.add(number);
  syncControls();
  writeHash();
  paint();
  if (!row) return;
  if (flash) flashRow(number);
  paint();
  scrollRowIntoView(number);
}

function showJson(scope, { focus = true } = {}) {
  state.scope = scope === 'all' || state.records.has(scope) ? scope : 'all';
  state.view = 'data';
  syncControls();
  writeHash();
  paint();
  if (focus) els.jsonView.focus({ preventScroll: true });
}

// ---- events ----

async function onReload() {
  els.reloadBtn.disabled = true;
  els.reloadBtn.setAttribute('aria-busy', 'true');
  try {
    await render(WATCHED_KEYS);
  } finally {
    els.reloadBtn.disabled = false;
    els.reloadBtn.removeAttribute('aria-busy');
  }
}

function wireEvents() {
  for (const view of ALL_VIEWS) {
    const tab = tabElement(view);
    if (!tab) continue;
    tab.addEventListener('click', onTabClick);
    tab.addEventListener('keydown', onTabKeydown);
  }
  els.reloadBtn.addEventListener('click', () => void onReload());
  wireSearch();
  wireBulkFetch();
  wireLoadOpenTickets();
  wireRefreshBar();
  wireTickets();
  wireHistory();
  wireOverview();
  wireRedFlags();
  wireFetchErrors();
  wireData();
  wireDiagnostics();
  wireSettings();
  window.addEventListener('resize', syncScrollRegions);
  window.addEventListener('hashchange', () => {
    readHash();
    syncControls();
    paint();
  });
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') void render(WATCHED_KEYS);
  });
  window.addEventListener('focus', () => void render(WATCHED_KEYS));
  chrome.storage.onChanged.addListener(onStorageChanged);
}

/** Fades the splash out (once), no sooner than SPLASH_MIN_MS after the page started. */
function dismissSplash() {
  if (splashDismissed) return;
  splashDismissed = true;
  const splash = document.getElementById('brandSplash');
  if (!splash) return;
  const wait = Math.max(0, SPLASH_MIN_MS - (Date.now() - splashShownAt));
  setTimeout(() => {
    splash.classList.add('is-leaving');
    setTimeout(() => splash.remove(), SPLASH_FADE_MS);
  }, wait);
}

function showUnavailable() {
  dismissSplash();
  document.body.classList.remove('is-loading');
  els.incidentTable.hidden = true;
  els.emptyState.hidden = false;
  els.emptyTitle.textContent = 'The extension APIs are not available here';
  els.emptyText.textContent = 'Open the dashboard by clicking the extension icon in the toolbar.';
  els.emptyReset.hidden = true;
}

/** Warn when the service worker runs older code than this page (an unpacked extension that was not
 * reloaded after an update): every newer feature would otherwise fail with confusing errors. */
async function checkWorkerBuild() {
  const banner = document.getElementById('staleWorker');
  if (!banner) return;
  const { reply } = await sendRuntimeMessage({ type: 'PING' });
  const build = reply && typeof reply === 'object' ? reply.build : undefined;
  if (build === BUILD_ID) return;
  banner.textContent = STALE_WORKER_TEXT;
  banner.hidden = false;
}

async function init() {
  setTimeout(dismissSplash, SPLASH_MAX_MS);
  const missing = missingElements();
  if (missing.length) console.error(`dashboard.html is missing: ${missing.join(', ')}`);
  hooks.paint = paint;
  hooks.render = render;
  hooks.showNotice = showNotice;
  hooks.showTicket = showTicket;
  hooks.showJson = showJson;
  hooks.refreshRow = refreshRow;
  readHash();
  syncControls();
  if (!globalThis.chrome || !chrome.storage) {
    showUnavailable();
    return;
  }
  wireEvents();
  await initSettings();
  await initDiagnostics();
  await render(WATCHED_KEYS);
  dismissSplash();
  await prefillSearch();
  void checkWorkerBuild();
  setInterval(() => void render(), TICK_MS);
}

init();
