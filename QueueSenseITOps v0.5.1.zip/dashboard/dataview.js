// The Data view: everything stored about the tickets, as JSON, with copy, export to a file and import
// from a file. Import never executes anything: the file is parsed and validated by lib/dataIO.js and
// merged into storage (newer data wins per ticket).
import { STORAGE_KEYS } from '../lib/config.js';
import {
  buildExport, exportFileName, mergeFollowUps, mergeIncidents, parseImport,
} from '../lib/dataIO.js';
import { AGE_BUCKETS, AGE_UNKNOWN, UPDATED_BUCKETS, UPDATED_NONE, ageBucketOf, updatedBucketOf } from '../lib/metrics.js';
import { getZoneParts } from '../lib/timeUtils.js';
import { buildWorkbookXlsx } from '../lib/xlsx.js';
import {
  MIDDOT, capitalize, create, errorText, isObject, plural, str, systemTimeZone,
} from './dom.js';
import { els } from './els.js';
import { copyText } from './messaging.js';
import { effectiveTimeZone } from './settings.js';
import { hooks, state } from './state.js';
import { KEY, isLastIncidentOf, queueWrite, storageRead } from './store.js';
import { visibleTicketRows } from './tickets.js';

// The import-confirmation panel (contract 13.6) was added after els.js's fixed id registry; its own
// elements are looked up directly rather than there, same reasoning as dashboard/settings.js.
const importEls = {
  panel: document.getElementById('importConfirm'),
  summary: document.getElementById('importConfirmSummary'),
  details: document.getElementById('importConfirmDetails'),
  confirmBtn: document.getElementById('jsonImportConfirmBtn'),
  cancelBtn: document.getElementById('jsonImportCancelBtn'),
};

// Excel export (contract 15.2/15.6) and the delete-ticket/clear-all gap (contract 13.6/13.9), added
// after els.js's fixed id registry: same reasoning as importEls above.
const exportExcelBtn = document.getElementById('exportExcelBtn');
const deleteTicketBtn = document.getElementById('deleteTicketBtn');
const clearAllBtn = document.getElementById('clearAllBtn');

/** Characters of JSON shown at most; copy and export always include everything. */
export const VIEW_LIMIT_CHARS = 1.5 * 1024 * 1024;
/** Most tickets one import file may bring in. */
export const IMPORT_MAX_INCIDENTS = 2000;
/** Largest import file read at all. */
export const IMPORT_MAX_BYTES = 5 * 1024 * 1024;
const URL_REVOKE_MS = 10000;
const COPIED_MS = 1600;
const REASON_GROUPS = 3;

const mb = (chars) => (chars / (1024 * 1024)).toFixed(1);
const sizeText = (chars) => {
  if (chars < 1024) return `${chars} bytes`;
  return chars < 1024 * 1024 ? `${Math.round(chars / 1024)} KB` : `${mb(chars)} MB`;
};

let shownText = null; // what #jsonView currently holds
let copyTimer = 0;

// ---- scope ----

function recency(record) {
  const time = Date.parse(str(record.searchedAt) || str(record.fetchedAt));
  return Number.isFinite(time) ? time : -Infinity;
}

function scopeList() {
  const entries = [...state.records.entries()].sort(([an, a], [bn, b]) => (recency(b) - recency(a)) || (an < bn ? -1 : 1));
  return entries.map(([number, record]) => {
    const description = str(record.shortDescription);
    return [number, description ? `${number} ${MIDDOT} ${description.slice(0, 70)}` : number];
  });
}

function syncScopeOptions() {
  const list = scopeList();
  const sig = JSON.stringify(list);
  if (els.jsonScope.dataset.sig !== sig) {
    els.jsonScope.dataset.sig = sig;
    const options = [['all', 'All tickets'], ...list].map(([value, label]) => {
      const option = create('option', '', label);
      option.value = value;
      return option;
    });
    els.jsonScope.replaceChildren(...options);
  }
  if (state.scope !== 'all' && !state.records.has(state.scope)) {
    state.scope = 'all';
    setJsonStatus('info', 'That ticket is no longer stored, so all tickets are shown.');
  }
  els.jsonScope.value = state.scope;
}

// ---- JSON text of the scope ----

function scopeValue(scope) {
  return scope === 'all' ? state.data.incidents : state.records.get(scope);
}

/** Pretty JSON of the scope: the stored records exactly as kept (cached until the stored data changes). */
function scopeJson(scope) {
  const source = state.data.incidents;
  const cache = state.jsonCache;
  if (cache.source === source && cache.scope === scope) return cache.text;
  const value = scopeValue(scope);
  const text = JSON.stringify(value === undefined ? null : value, null, 2);
  state.jsonCache = { source, scope, text };
  return text;
}

function visibleSlice(text) {
  if (text.length <= VIEW_LIMIT_CHARS) return { shown: text, cut: false };
  const head = text.slice(0, VIEW_LIMIT_CHARS);
  const lastBreak = head.lastIndexOf('\n');
  return { shown: lastBreak > 0 ? head.slice(0, lastBreak) : head, cut: true };
}

/** Update the Data view. Cheap when nothing changed; only called while the view is on screen. */
export function paintData() {
  syncScopeOptions();
  syncDangerButtons();
  const text = scopeJson(state.scope);
  const { shown, cut } = visibleSlice(text);
  if (shownText !== shown) {
    els.jsonView.textContent = shown;
    shownText = shown;
  }
  const count = state.scope === 'all' ? state.records.size : 1;
  els.jsonSize.textContent = `${plural(count, 'ticket', 'tickets')} ${MIDDOT} ${sizeText(text.length)}`;
  els.jsonTruncated.hidden = !cut;
  els.jsonTruncated.textContent = cut
    ? `Showing the first ${mb(shown.length)} MB of ${mb(text.length)} MB so the page stays responsive. Copy JSON and Export file include everything.`
    : '';
}

function setJsonStatus(stateName, message) {
  els.jsonStatus.dataset.state = stateName;
  els.jsonStatus.textContent = message;
}

// ---- copy ----

async function onCopy() {
  if (!state.records.size) {
    setJsonStatus('warn', 'Nothing to copy yet: no tickets are stored.');
    return;
  }
  const text = scopeJson(state.scope);
  const copied = await copyText(text);
  setJsonStatus(copied ? 'ok' : 'error', copied
    ? `Copied the JSON of ${state.scope === 'all' ? 'all tickets' : state.scope} to the clipboard (${text.length.toLocaleString('en-US')} characters).`
    : 'Could not copy to the clipboard. Select the text and copy it by hand.');
  if (copied) {
    clearTimeout(copyTimer);
    els.jsonCopyBtn.textContent = 'Copied';
    copyTimer = setTimeout(() => {
      els.jsonCopyBtn.textContent = 'Copy JSON';
    }, COPIED_MS);
  }
}

// ---- export ----

function exportParts() {
  if (state.scope === 'all') {
    return { incidents: Object.fromEntries(state.records), followUps: state.data.log };
  }
  const record = state.records.get(state.scope);
  return {
    incidents: record ? { [state.scope]: record } : {},
    followUps: state.data.log.filter((entry) => isObject(entry) && entry.incidentNumber === state.scope),
  };
}

function onExport() {
  const now = new Date();
  const parts = exportParts();
  const text = JSON.stringify(buildExport({ ...parts, now }), null, 2);
  const url = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
  const link = document.createElement('a');
  link.href = url;
  link.download = exportFileName(now);
  link.hidden = true;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), URL_REVOKE_MS);
  const count = Object.keys(parts.incidents).length;
  setJsonStatus('ok', `Exported ${plural(count, 'ticket', 'tickets')} and ${plural(parts.followUps.length, 'follow-up', 'follow-ups')} to ${link.download}.`);
}

// ---- Excel export (contract 15.2/15.6) ----
// Exports exactly the currently visible/filtered Tickets rows (day, business-hours status, ticket
// status and the free-text filter all applied -- tickets.js's visibleTicketRows is the single source
// of truth the Tickets table itself paints from), as a real .xlsx built by lib/xlsx.js's
// buildWorkbookXlsx (zero dependencies, inline-string text cells only -- see that module for why a
// value that looks like a formula can never be interpreted as one). Mirrors onExport()'s own
// Blob+download-link mechanism exactly, just with a different MIME type, extension and byte source.

// Exported for direct unit testing (tests/dataview.test.mjs): the shape and VIP mapping of one Excel
// row, without needing the real xlsx writer, DOM or visibleTicketRows() plumbing.
export const EXCEL_COLUMNS = [
  { key: 'incidentNumber', header: 'Incident Number' },
  { key: 'shortDescription', header: 'Short Description' },
  { key: 'status', header: 'Status' },
  { key: 'priority', header: 'Priority' },
  { key: 'assignmentGroup', header: 'Assignment Group' },
  { key: 'vip', header: 'VIP' },
  { key: 'caller', header: 'User' },
  { key: 'userIs', header: 'User Is' },
  { key: 'preferredContact', header: 'Preferred Contact' },
  { key: 'country', header: 'Country' },
  { key: 'location', header: 'Location' },
  { key: 'lastUpdateByAgent', header: 'Last Update By Agent' },
  { key: 'lastUpdateServiceNow', header: 'Last Update Time ServiceNow' },
  { key: 'lastUpdateLocal', header: "Last Update Time User's Local" },
  { key: 'lastContactBusinessHours', header: 'Last Contact Business Hours' },
  { key: 'businessHoursNow', header: 'Business Hours Now' },
  // v0.4 (the Overview's numbers, per ticket): the newest update written by a person (else
  // ServiceNow's Updated time), the follow-up flag and the assigned agent's own updates judged
  // against the user's business hours.
  { key: 'lastUpdate', header: 'Last Update' },
  { key: 'lastUpdateBy', header: 'Last Update By' },
  { key: 'lastUpdatedBucket', header: 'Last Updated' },
  { key: 'followUpNow', header: 'Follow Up Now' },
  { key: 'followUpReason', header: 'Follow Up Reason' },
  { key: 'agentUpdatesBusiness', header: 'Agent Updates In Business Hours' },
  { key: 'agentUpdatesOff', header: 'Agent Updates Off Hours' },
  { key: 'userUpdates', header: 'User Updates' },
  { key: 'userResponse', header: 'User Response' },
  { key: 'negativeSentiment', header: 'Negative Sentiment' },
  { key: 'sentimentKeywords', header: 'Sentiment Keywords' },
  // v0.5: queue membership (row.queue: lib/queueTracking.js via lib/dashboardModel.js, from the "Load all
  // open tickets" runs) and the assigned agent's quiet time (working hours, weekends left out).
  { key: 'firstSeenInQueue', header: 'First seen in queue' },
  { key: 'enteredQueue', header: 'Entered queue' },
  { key: 'newToQueue', header: 'New to queue' },
  { key: 'movedOutAt', header: 'Moved out at' },
  { key: 'movedOutReason', header: 'Moved out reason' },
  { key: 'agentQuietHours', header: 'Agent quiet (working hours)' },
  { key: 'agentNotUpdatingDaily', header: 'Agent not updating daily' },
  // The 4 newest ticket updates (activity stream, newest first): when, then who + what.
  ...[1, 2, 3, 4].flatMap((n) => [
    { key: `update${n}Time`, header: `Update ${n} Time` },
    { key: `update${n}`, header: `Update ${n}` },
  ]),
  { key: 'openedAt', header: 'Opened At' },
  { key: 'ageDays', header: 'Age (Days)' },
  { key: 'ageBucket', header: 'Age Bucket' },
  { key: 'searchedAt', header: 'Searched At' },
  { key: 'fetchedAt', header: 'Fetched At' },
];

const pad2 = (n) => String(n).padStart(2, '0');
const AGE_LABELS = Object.fromEntries([...AGE_BUCKETS, AGE_UNKNOWN].map((b) => [b.key, b.label]));
const UPDATED_LABELS = Object.fromEntries([...UPDATED_BUCKETS, UPDATED_NONE].map((b) => [b.key, b.label]));

/**
 * 'YYYY-MM-DD HH:MM' of an ISO instant on the clock of `timeZone` (the dashboard's zone), '' for
 * anything unusable. Exported for tests/dataview.test.mjs.
 * @param {string} iso
 * @param {string} timeZone
 * @returns {string}
 */
export function localStamp(iso, timeZone) {
  const time = typeof iso === 'string' ? Date.parse(iso) : NaN;
  if (!Number.isFinite(time)) return '';
  try {
    const p = getZoneParts(new Date(time), timeZone);
    return `${String(p.year).padStart(4, '0')}-${pad2(p.month)}-${pad2(p.day)} ${pad2(p.hour)}:${pad2(p.minute)}`;
  } catch {
    return '';
  }
}

/** A metrics.js bucket function's label for a row, '' when it throws or returns an unknown key. */
function bucketLabel(fn, row, now, labels) {
  try {
    return labels[fn(row, now)] || '';
  } catch {
    return '';
  }
}

/** The v0.4 cells of a row (row.priority, ageDays, lastUpdate, followUp, updateSplit), each blank when
 * the row predates that field. */
function overviewCells(row, ctx) {
  const now = ctx.now instanceof Date ? ctx.now : new Date();
  const priority = isObject(row.priority) ? row.priority : null;
  const details = isObject(row.details) ? row.details : {};
  const last = isObject(row.lastUpdate) ? row.lastUpdate : null;
  const followUp = isObject(row.followUp) ? row.followUp : null;
  const split = isObject(row.updateSplit) && isObject(row.updateSplit.assignee) ? row.updateSplit.assignee : null;
  // Age from row.openedAt and the export's `now` (exactly what metrics.js ageBucketOf measures, so the
  // number and the Age Bucket column never disagree), else the row's own ageDays (taken at paint time).
  // (only an instant WITH a zone, like metrics.js: a zone-less text would be read in the machine's zone)
  const opened = typeof row.openedAt === 'string' && /(Z|[+-]\d{2}:?\d{2})$/.test(row.openedAt.trim())
    ? Date.parse(row.openedAt) : NaN;
  let age = null;
  if (Number.isFinite(opened) && Number.isFinite(now.getTime())) age = Math.max(0, (now.getTime() - opened) / 86400000);
  else if (typeof row.ageDays === 'number' && Number.isFinite(row.ageDays)) age = Math.max(0, row.ageDays);
  const hasAge = Object.hasOwn(row, 'ageDays') || Object.hasOwn(row, 'openedAt'); // a v0.4 row
  let lastBy = '';
  if (last && last.at) lastBy = last.source === 'record' ? '(ServiceNow Updated time)' : str(last.author);
  const splitCount = (key) => (split && Number.isFinite(split[key]) ? split[key] : '');
  return {
    priority: (priority && str(priority.label) && priority.key !== 'none' ? str(priority.label) : '') || str(details.priority),
    // A real number (Excel sorts and filters it numerically; text '10.0' would sort before '4.5'),
    // cut DOWN to one decimal, so 2.96 days reads 2.9 next to 'Under 3 days', never 3.0.
    ageDays: age === null ? '' : Math.floor(age * 10 + 1e-9) / 10,
    ageBucket: hasAge ? bucketLabel(ageBucketOf, row, now, AGE_LABELS) : '',
    lastUpdate: last ? localStamp(last.at, ctx.timeZone) : '',
    lastUpdateBy: lastBy,
    lastUpdatedBucket: last ? bucketLabel(updatedBucketOf, row, now, UPDATED_LABELS) : '',
    followUpNow: followUp ? (followUp.now === true ? 'Yes' : 'No') : '',
    followUpReason: followUp && followUp.now === true ? str(followUp.text) : '',
    agentUpdatesBusiness: splitCount('business'),
    agentUpdatesOff: splitCount('off'),
  };
}

/** 'Resolved (Closed)' / 'Moved to Network' / 'No longer listed (On Hold)' for a moved-out row.queue
 * (movedTo: the State, or the new group for a reassignment); ''. */
function movedOutReasonCell(queue) {
  if (!queue || queue.movedOut !== true) return '';
  const movedTo = str(queue.movedTo);
  // the State is usually 'Resolved' itself: 'Resolved (Resolved)' would only repeat it
  if (queue.movedOutReason === 'resolved') return movedTo && movedTo.toLowerCase() !== 'resolved' ? `Resolved (${movedTo})` : 'Resolved';
  if (queue.movedOutReason === 'reassigned') return movedTo ? `Moved to ${movedTo}` : 'Moved to another group';
  if (queue.movedOutReason === 'left-list') return movedTo ? `No longer listed (${movedTo})` : 'No longer listed';
  return '';
}

/** The v0.5 cells of a row (row.queue, row.agentQuietHours, row.agentStale), each blank when the row
 * predates the field or the ticket was never tracked in a queue. */
function queueCells(row, timeZone) {
  const queue = isObject(row.queue) ? row.queue : null;
  const quiet = row.agentQuietHours;
  let agentQuiet = '';
  // A real number (Excel sorts it), cut down to one decimal like Age (Days); an assignee who never
  // updated the ticket says so in words.
  if (typeof quiet === 'number' && Number.isFinite(quiet)) agentQuiet = Math.floor(Math.max(0, quiet) * 10 + 1e-9) / 10;
  else if (quiet === null && Object.hasOwn(row, 'agentQuietHours') && str(row.assignedTo)) agentQuiet = 'Never updated';
  let entered = '';
  if (queue) entered = str(queue.enteredAt) ? localStamp(str(queue.enteredAt), timeZone) : 'Baseline (present at the first refresh)';
  return {
    firstSeenInQueue: queue ? localStamp(str(queue.firstSeenAt), timeZone) : '',
    enteredQueue: entered,
    newToQueue: queue ? (queue.isNew === true ? 'Yes' : 'No') : '',
    movedOutAt: queue && queue.movedOut === true ? localStamp(str(queue.movedOutAt), timeZone) : '',
    movedOutReason: movedOutReasonCell(queue),
    agentQuietHours: agentQuiet,
    agentNotUpdatingDaily: Object.hasOwn(row, 'agentStale') ? (row.agentStale === true ? 'Yes' : 'No') : '',
  };
}

/** One Excel row of a Tickets row. `details.state`/`details.assignmentGroup`/`details.vip` read the
 * same field path as table.js's Status/Assignment group columns and VIP star (contract 13.4/16.1/16.4,
 * landed and verified by lib/analyze.js's buildRecord) and render blank/No until the data says
 * otherwise -- never a guess. `ctx` = { now, timeZone } for the v0.4 columns (age and last-updated
 * buckets, the local last-update time); both default (current time, browser zone). */
export function excelRow(row, ctx = {}) {
  const context = isObject(ctx) ? ctx : {};
  const zone = str(context.timeZone) || systemTimeZone();
  const details = isObject(row.details) ? row.details : {};
  const last = isObject(row.lastContact) ? row.lastContact : {};
  const atContact = isObject(last.atContact) ? last.atContact : null;
  const nowStatus = isObject(row.nowStatus) ? row.nowStatus : {};
  const engagement = isObject(row.engagement) ? row.engagement : {};
  const known = engagement.level && engagement.level !== 'unknown';
  const hits = Array.isArray(engagement.negativeHits) ? engagement.negativeHits : [];
  const updates = Array.isArray(row.recentUpdates) ? row.recentUpdates.filter(isObject) : [];
  const updateCells = {};
  for (let n = 1; n <= 4; n += 1) {
    const update = updates[n - 1];
    updateCells[`update${n}Time`] = update ? str(update.timeRaw) : '';
    updateCells[`update${n}`] = update
      ? [str(update.author), str(update.text)].filter(Boolean).join(': ')
      : '';
  }
  return {
    incidentNumber: str(row.incidentNumber),
    shortDescription: str(row.shortDescription),
    status: str(details.state),
    assignmentGroup: str(details.assignmentGroup),
    vip: details.vip === true ? 'Yes' : 'No',
    caller: str(row.callerName) || str(row.callerEmail),
    userIs: row.contactPerson === 'impacted'
      ? `Impacted User${str(row.reportedByName) ? ` (reported by ${str(row.reportedByName)})` : ''}`
      : 'Caller',
    preferredContact: str(row.preferredContactMethod),
    country: str(row.country),
    location: str(row.locationText) || str(row.country),
    lastUpdateByAgent: str(last.author),
    lastUpdateServiceNow: str(last.timeLabel) || str(last.timeRaw),
    lastUpdateLocal: str(last.localTimeAtContact),
    lastContactBusinessHours: last.has === false ? 'No update yet' : capitalize(str(atContact && atContact.status)),
    businessHoursNow: capitalize(str(nowStatus.status)),
    userUpdates: known ? Number(engagement.callerUpdates) || 0 : '',
    userResponse: known ? str(engagement.label) : '',
    negativeSentiment: engagement.negative === true ? 'Yes' : 'No',
    sentimentKeywords: hits.map((hit) => `${str(hit.term)} (${str(hit.author)})`).join('; '),
    ...queueCells(row, zone),
    ...updateCells,
    openedAt: str(row.openedAtLabel) || str(row.openedAgo),
    ...overviewCells(row, { now: context.now, timeZone: zone }),
    searchedAt: str(row.searchedAtLabel),
    fetchedAt: str(row.fetchedAtLabel),
  };
}

/** 'queuesenseitops-YYYYMMDD-HHMM.json' -> '...-tickets-YYYYMMDD-HHMM.xlsx', reusing
 * exportFileName's own date formatting so the two exports share one naming convention. */
function excelFileName(now) {
  return exportFileName(now)
    .replace(/^queuesenseitops-/, 'queuesenseitops-tickets-')
    .replace(/\.json$/, '.xlsx');
}

// The Tickets toolbar has its own Export button and status line, so the result is shown where the
// person clicked; the Data view's button keeps reporting in the Data view's status line.
const tableExportBtn = document.getElementById('tableExportExcelBtn');
const tableExportStatus = document.getElementById('tableExportStatus');

function setTableExportStatus(stateName, message) {
  if (!tableExportStatus) return;
  tableExportStatus.dataset.state = stateName;
  tableExportStatus.textContent = message;
  tableExportStatus.hidden = !message;
}

function onExportExcel(setStatus = setJsonStatus) {
  const now = new Date();
  const rows = visibleTicketRows();
  if (!rows.length) {
    setStatus('warn', 'Nothing to export: no tickets match the current filters.');
    return;
  }
  let bytes;
  try {
    const ctx = { now, timeZone: effectiveTimeZone(systemTimeZone()) };
    bytes = buildWorkbookXlsx(rows.map((row) => excelRow(row, ctx)), { columns: EXCEL_COLUMNS, sheetName: 'Tickets' });
  } catch (err) {
    setStatus('error', `The Excel export failed: ${errorText(err)}`);
    return;
  }
  const url = URL.createObjectURL(new Blob([bytes], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  }));
  const link = document.createElement('a');
  link.href = url;
  link.download = excelFileName(now);
  link.hidden = true;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), URL_REVOKE_MS);
  setStatus('ok', `Exported ${plural(rows.length, 'ticket', 'tickets')} (the currently visible table) to ${link.download}.`);
}

// ---- delete ticket / clear all (contract 13.6/13.9 Data tab gap) ----
// A simple two-step confirm: the first click turns the button into its own confirmation label
// (data-confirm="1") and reverts after a few seconds; only the second, unmodified click (before it
// reverts) does anything. Mirrors the composer's own "Confirm: add to INC..." convention (contract
// 13.6) without touching composer.js: same user-facing shape, a separate, self-contained
// implementation local to this file.
const CONFIRM_REVERT_MS = 6000;

function disarmConfirm(btn) {
  if (!btn || btn.dataset.confirm !== '1') return;
  clearTimeout(Number(btn.dataset.confirmTimer) || 0);
  delete btn.dataset.confirm;
  delete btn.dataset.confirmTimer;
  if (btn.dataset.idleLabel) btn.textContent = btn.dataset.idleLabel;
}

/** First click arms (label -> confirmLabel, data-confirm="1", reverts after CONFIRM_REVERT_MS);
 * the second click (while still armed) disarms and runs `onConfirm`. */
function armOrConfirm(btn, confirmLabel, onConfirm) {
  if (btn.dataset.confirm === '1') {
    disarmConfirm(btn);
    onConfirm();
    return;
  }
  btn.dataset.idleLabel = btn.dataset.idleLabel || btn.textContent;
  btn.dataset.confirm = '1';
  btn.textContent = confirmLabel;
  btn.dataset.confirmTimer = String(setTimeout(() => disarmConfirm(btn), CONFIRM_REVERT_MS));
}

const CLEAR_ALL_KEEP_NOTE = 'Cleared all stored tickets, follow-ups, job history and queue history on this computer. '
  + 'Your instance address and settings were kept.';
// Keys this page knows the names of directly (not yet in store.js's KEY, same reasoning as
// diagnostics.js's own FETCH_LOG_KEY constant): contract 13.5/13.9 added them after store.js's
// registry was written, and store.js is outside this pass's file set.
const FETCH_LOG_KEY = 'fetchLog';
const UPDATE_ATTEMPTS_KEY = 'updateAttempts';
// v0.5: the queue tracking too (KEY.queueTracking, lib/queueTracking.js): its runs are job history, its
// tickets map lists ticket numbers, and its lastErrors items hold the cells of the ServiceNow list rows
// (caller, short description, ...), so "clear all stored tickets" that kept it would keep ticket data.
// The next "Load all open tickets" run (or auto refresh) then starts a fresh baseline.
export const CLEAR_ALL_KEYS = Object.freeze([
  KEY.incidents, STORAGE_KEYS.lastIncident, KEY.log, KEY.refreshJob, FETCH_LOG_KEY, UPDATE_ATTEMPTS_KEY, KEY.queueTracking,
]);

// What a per-ticket Delete leaves behind, said plainly: queue tracking keeps the number (with its group
// and dates) so a later refresh does not report the ticket as "new to the queue", and the content-free
// diagnostics logs keep the number with status codes. Clear all removes those too.
export const DELETE_TICKET_NOTE = (number) => `Deleted ${number} (and its follow-up history) from this computer. `
  + 'The queue history keeps its number, queue and dates for up to 30 days, and the diagnostics logs keep its number; '
  + 'Clear all removes those too.';

async function doDeleteTicket(number) {
  setJsonStatus('loading', `Deleting ${number} ...`);
  try {
    await queueWrite(async () => {
      const stored = await storageRead([KEY.incidents, KEY.log, STORAGE_KEYS.lastIncident]);
      const incidents = isObject(stored[KEY.incidents]) ? { ...stored[KEY.incidents] } : {};
      delete incidents[number];
      const log = Array.isArray(stored[KEY.log])
        ? stored[KEY.log].filter((entry) => !(isObject(entry) && entry.incidentNumber === number))
        : [];
      await chrome.storage.local.set({ [KEY.incidents]: incidents, [KEY.log]: log });
      // The worker's copy of the last searched record goes too when it is this ticket.
      if (isLastIncidentOf(stored[STORAGE_KEYS.lastIncident], number)) await chrome.storage.local.remove(STORAGE_KEYS.lastIncident);
    });
    state.scope = 'all';
    setJsonStatus('ok', DELETE_TICKET_NOTE(number));
    await hooks.render([KEY.incidents, KEY.log]);
  } catch (err) {
    setJsonStatus('error', `Could not delete ${number}: ${errorText(err)}`);
  }
}

// Which ticket number the delete confirm is armed for, so changing the scope while armed disarms it
// (contract 13.6: "disarm on blur/scope change") instead of deleting whatever ticket is now shown.
let deleteArmedFor = '';

function onDeleteTicket() {
  if (!deleteTicketBtn || deleteTicketBtn.disabled) return;
  const number = state.scope;
  if (number === 'all' || !state.records.has(number)) return;
  deleteArmedFor = number;
  armOrConfirm(deleteTicketBtn, `Confirm delete ${number}`, () => void doDeleteTicket(number));
}

async function doClearAll() {
  setJsonStatus('loading', 'Clearing all stored tickets ...');
  try {
    await queueWrite(async () => chrome.storage.local.remove([...CLEAR_ALL_KEYS]));
    state.scope = 'all';
    setJsonStatus('ok', CLEAR_ALL_KEEP_NOTE);
    await hooks.render();
  } catch (err) {
    setJsonStatus('error', `Could not clear the stored data: ${errorText(err)}`);
  }
}

function onClearAll() {
  if (!clearAllBtn || clearAllBtn.disabled) return;
  armOrConfirm(clearAllBtn, 'Confirm: clear all stored tickets', () => void doClearAll());
}

function syncDangerButtons() {
  if (!deleteTicketBtn) return;
  const canDelete = state.scope !== 'all' && state.records.has(state.scope);
  deleteTicketBtn.disabled = !canDelete;
  deleteTicketBtn.title = canDelete
    ? `Delete ${state.scope} and its follow-up history from this computer.`
    : 'Choose one ticket above (not "All tickets") to delete it.';
  if (!canDelete || deleteArmedFor !== state.scope) disarmConfirm(deleteTicketBtn);
}

// ---- import ----

function reasonSummary(skipped) {
  const counts = new Map();
  for (const item of skipped) {
    const reason = isObject(item) ? str(item.reason) || 'unusable entry' : 'unusable entry';
    counts.set(reason, (counts.get(reason) || 0) + 1);
  }
  const groups = [...counts.entries()].map(([reason, n]) => `${n} ${reason}`);
  const shown = groups.slice(0, REASON_GROUPS).join('; ');
  return groups.length > REASON_GROUPS ? `${shown}; and ${groups.length - REASON_GROUPS} more reasons` : shown;
}

function importSummary(parsed) {
  const imported = Object.keys(parsed.incidents).length;
  const skipped = Array.isArray(parsed.skipped) ? parsed.skipped : [];
  let text = `Imported ${imported}, skipped ${skipped.length}`;
  if (skipped.length) text += ` (${reasonSummary(skipped)})`;
  const followUps = Array.isArray(parsed.followUps) ? parsed.followUps.length : 0;
  if (followUps) text += `. ${plural(followUps, 'follow-up entry', 'follow-up entries')} merged into the history`;
  const notes = Array.isArray(parsed.notes) ? parsed.notes.map(str).filter(Boolean) : [];
  if (notes.length) text += `. ${notes.join(' ')}`;
  return { text, state: imported === 0 || skipped.length ? 'warn' : 'ok' };
}

// ---- import confirmation (contract 13.6 DATA TAB: "shows a confirmation summary before merging") ----

/** The one file currently parsed and awaiting the person's confirmation, or null. Cleared by a
 * cancel, a confirmed merge, or picking a different file. */
let pendingImport = null;

/** Per-reason skip counts as their own lines (never one run-on sentence), so dropped URLs and
 * clamped dates -- reported by lib/dataIO.js's `skipped`/`notes`, landing in parallel with this file
 * (contract 13.4) -- are each legible on their own line once that module reports them; today's
 * `skipped`/`notes` shape already renders correctly through the same generic code. */
function importDetailLines(parsed) {
  const lines = [];
  const imported = Object.keys(parsed.incidents).length;
  lines.push(`${plural(imported, 'ticket', 'tickets')} will be imported.`);
  const skipped = Array.isArray(parsed.skipped) ? parsed.skipped : [];
  if (skipped.length) {
    const counts = new Map();
    for (const item of skipped) {
      const reason = isObject(item) ? str(item.reason) || 'unusable entry' : 'unusable entry';
      counts.set(reason, (counts.get(reason) || 0) + 1);
    }
    for (const [reason, n] of counts) lines.push(`${plural(n, 'ticket', 'tickets')} will be skipped: ${reason}.`);
  }
  const followUps = Array.isArray(parsed.followUps) ? parsed.followUps.length : 0;
  if (followUps) lines.push(`${plural(followUps, 'follow-up entry', 'follow-up entries')} will be merged into the history.`);
  for (const note of Array.isArray(parsed.notes) ? parsed.notes.map(str).filter(Boolean) : []) lines.push(note);
  return lines;
}

function showImportConfirm(parsed, fileName) {
  pendingImport = parsed;
  const imported = Object.keys(parsed.incidents).length;
  const skipped = Array.isArray(parsed.skipped) ? parsed.skipped.length : 0;
  importEls.panel.hidden = false;
  importEls.summary.textContent = `${fileName}: ${plural(imported, 'ticket', 'tickets')} to import, ${plural(skipped, 'ticket', 'tickets')} to skip.`;
  importEls.details.replaceChildren(...importDetailLines(parsed).map((line) => create('li', '', line)));
  importEls.confirmBtn.disabled = imported === 0;
  importEls.panel.focus({ preventScroll: true });
}

function hideImportConfirm() {
  pendingImport = null;
  importEls.panel.hidden = true;
  importEls.summary.textContent = '';
  importEls.details.replaceChildren();
}

async function mergeIntoStorage(parsed) {
  await queueWrite(async () => {
    const stored = await storageRead([KEY.incidents, KEY.log]);
    const existing = isObject(stored[KEY.incidents]) ? stored[KEY.incidents] : {};
    const log = Array.isArray(stored[KEY.log]) ? stored[KEY.log] : [];
    await chrome.storage.local.set({
      [KEY.incidents]: mergeIncidents(existing, parsed.incidents),
      [KEY.log]: mergeFollowUps(log, parsed.followUps || []),
    });
  });
}

function setImportBusy(busy) {
  state.importBusy = busy;
  els.jsonImportBtn.disabled = busy;
  els.jsonImportInput.disabled = busy;
  if (busy) els.jsonImportBtn.setAttribute('aria-busy', 'true');
  else els.jsonImportBtn.removeAttribute('aria-busy');
}

async function readImportFile(file) {
  if (file.size > IMPORT_MAX_BYTES) {
    return { error: `That file is ${mb(file.size)} MB. Files above ${mb(IMPORT_MAX_BYTES)} MB are not imported.` };
  }
  try {
    return { text: await file.text() };
  } catch (err) {
    return { error: `The file could not be read: ${errorText(err)}` };
  }
}

/** Read and validate the chosen file, then show the confirmation summary (contract 13.6: "import
 * shows a confirmation summary ... before merging"). Nothing is written to storage here. */
async function onImport() {
  if (state.importBusy) return;
  hideImportConfirm();
  const file = els.jsonImportInput.files && els.jsonImportInput.files[0];
  if (!file) {
    setJsonStatus('error', 'Choose a .json file first (an export from this dashboard).');
    els.jsonImportInput.focus();
    return;
  }
  setImportBusy(true);
  setJsonStatus('loading', `Reading ${file.name} ...`);
  try {
    const { text, error } = await readImportFile(file);
    if (error) {
      setJsonStatus('error', error);
      return;
    }
    const parsed = parseImport(text, { maxIncidents: IMPORT_MAX_INCIDENTS, maxBytes: IMPORT_MAX_BYTES });
    if (!parsed.ok) {
      setJsonStatus('error', `Nothing was imported. ${parsed.message}`);
      return;
    }
    setJsonStatus('info', 'Review the summary below, then confirm to import.');
    showImportConfirm(parsed, file.name);
  } catch (err) {
    setJsonStatus('error', `The import failed: ${errorText(err)}`);
  } finally {
    setImportBusy(false);
  }
}

/** The confirmation's own "Import these tickets" button: only now is anything merged into storage. */
async function onConfirmImport() {
  if (state.importBusy || !pendingImport) return;
  const parsed = pendingImport;
  setImportBusy(true);
  try {
    await mergeIntoStorage(parsed);
    const summary = importSummary(parsed);
    hideImportConfirm();
    setJsonStatus(summary.state, summary.text);
    els.jsonImportInput.value = '';
    await hooks.render([KEY.incidents, KEY.log]);
  } catch (err) {
    setJsonStatus('error', `The import failed: ${errorText(err)}`);
  } finally {
    setImportBusy(false);
  }
}

function onCancelImport() {
  hideImportConfirm();
  els.jsonImportInput.value = '';
  setJsonStatus('idle', 'Import cancelled: nothing was changed.');
}

/** Attach the Data view's event listeners. */
export function wireData() {
  els.jsonScope.addEventListener('change', () => {
    disarmConfirm(deleteTicketBtn);
    hooks.showJson(els.jsonScope.value, { focus: false });
  });
  els.jsonCopyBtn.addEventListener('click', () => void onCopy());
  els.jsonExportBtn.addEventListener('click', onExport);
  if (exportExcelBtn) exportExcelBtn.addEventListener('click', () => onExportExcel(setJsonStatus));
  if (tableExportBtn) tableExportBtn.addEventListener('click', () => onExportExcel(setTableExportStatus));
  els.jsonImportBtn.addEventListener('click', () => void onImport());
  els.jsonImportInput.addEventListener('change', hideImportConfirm);
  importEls.confirmBtn.addEventListener('click', () => void onConfirmImport());
  importEls.cancelBtn.addEventListener('click', onCancelImport);
  if (deleteTicketBtn) {
    deleteTicketBtn.addEventListener('click', onDeleteTicket);
    deleteTicketBtn.addEventListener('blur', () => disarmConfirm(deleteTicketBtn));
  }
  if (clearAllBtn) {
    clearAllBtn.addEventListener('click', onClearAll);
    clearAllBtn.addEventListener('blur', () => disarmConfirm(clearAllBtn));
  }
}
