// The details drawer of a ticket: key facts from the stored record and a compact timeline of the
// updates PEOPLE wrote on the ticket, newest first. The timeline itself comes from lib/dashboardModel.js
// (buildTimeline: person updates only since v0.4 -- 'System', integration and workflow entries are left
// out, and so are the searches, which are a fact now); this module only draws it.
//
// Compact timeline (v0.4): one short line per update -- a business-hours dot, the author (marked
// "assigned agent" / "user"), the kind of update and when -- so a long history takes a few lines of the
// drawer instead of a page. The update's TEXT is shown on demand, in a popover next to its line, when the
// line is hovered or has keyboard focus (WCAG 1.4.13 content on hover or focus):
//   - the line is focusable (tabindex=0), so keyboard and touch (a tap focuses it) reach the text too;
//   - the popover is a child of the same list item, so moving the pointer from the line onto the popover
//     keeps it open (hoverable), and it stays until the pointer or focus leaves (persistent);
//   - Escape hides it without moving focus or pointer (dismissible: on the focused line, and anywhere on
//     the page for a popover shown by hover); it comes back once the item is left and hovered / focused again;
//   - aria-describedby links the line to the text, so a screen reader reads it on focus;
//   - it is placed below the line, or above it when there is no room below inside the scrolling table,
//     and shifted left when it would cross the right edge (its width is clamped in CSS).
// Everything from ServiceNow is untrusted and goes in through textContent only.
import { namesMatch } from '../lib/analyze.js';
import { buildTimeline, describeElapsed } from '../lib/dashboardModel.js';
import { isPersonAuthor } from '../lib/people.js';
import {
  MIDDOT, create, idPart, isObject, str,
} from './dom.js';
import { TABLE_COLUMNS, detailsId, movedOutWords } from './table.js';

const TONES = ['green', 'red', 'amber', 'grey'];
const STATUSES = ['business', 'non-business', 'uncertain', 'unknown'];
const STATUS_WORDS = {
  business: "inside the user's business hours",
  'non-business': "outside the user's business hours",
  uncertain: "business hours uncertain at the user's location",
  unknown: 'business hours unknown',
};
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
// 'Thu 2026-10-08 15:04:05' (lib/dashboardModel.js exactTimeLabel)
const EXACT_LABEL = /^([A-Za-z]{3}) (\d{4})-(\d{2})-(\d{2}) (\d{2}:\d{2})(?::\d{2})?$/;
const EDGE_GAP = 8;

/**
 * Timeline items of one ticket; an unexpected model failure shows an empty timeline, not a broken page.
 * Items of a kind other than 'activity' and items whose author is not a person are dropped here too,
 * so the drawer stays "people only" whatever model version produced them.
 */
export function timelineItems(row, record, followUps, now, opts) {
  try {
    const items = buildTimeline(record, followUps, now, { ...opts, incidentNumber: row.incidentNumber });
    if (!Array.isArray(items)) return [];
    return items.filter((item) => isObject(item) && (item.kind === undefined || item.kind === 'activity') && isPersonAuthor(item.author));
  } catch {
    return [];
  }
}

function fact(label, value, note) {
  const wrap = create('div', 'fact');
  const dd = create('dd', value ? 'fact-value' : 'fact-value is-empty', value || '—');
  if (value && note) dd.append(create('span', 'fact-note', ` ${MIDDOT} ${note}`));
  wrap.append(create('dt', 'fact-label', label), dd);
  return wrap;
}

/** How the Location text was used, plus the conflict and doubt sentences in full (the table shortens them). */
function locationNote(place) {
  const how = {
    'location-field': 'used for the country and time zone: the phone number gave no country',
    'phone+location': 'country from the phone number, time zone from this text',
    phone: 'the phone number decides the country; this text is not used',
  }[str(place.source) || 'phone'] || '';
  return [how, str(place.conflict), str(place.locationNote)].filter(Boolean).join('. ');
}

/** 'Thu 8 Oct 15:04' for an ISO instant in `timeZone` (the browser's zone when that is unusable); ''. */
function dateTimeLabel(iso, timeZone) {
  const date = new Date(typeof iso === 'string' ? iso : NaN);
  if (Number.isNaN(date.getTime())) return '';
  const options = { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' };
  try {
    return new Intl.DateTimeFormat('en-GB', { ...options, timeZone: timeZone || undefined }).format(date).replace(/,/g, '');
  } catch {
    return new Intl.DateTimeFormat('en-GB', options).format(date).replace(/,/g, '');
  }
}

/** '57 entries read, 41 by people' (+ the note when not every "show more" page could be loaded). */
function activityFact(notes) {
  if (notes.loaded !== true) return ['activity stream not read', ''];
  const count = Number.isInteger(notes.count) && notes.count >= 0 ? notes.count : 0;
  const people = Number.isInteger(notes.personCount) && notes.personCount >= 0 ? notes.personCount : null;
  const value = `${count} ${count === 1 ? 'entry' : 'entries'} read${people === null ? '' : `, ${people} by people`}`;
  return [value, notes.complete === false ? 'not every page could be loaded' : ''];
}

/** 'Thu 8 Oct 15:04' + '3 times in total' (the searches left the timeline in v0.4). */
function searchedFact(source, timeZone) {
  const last = dateTimeLabel(str(source.searchedAt), timeZone);
  const count = Number.isInteger(source.searchCount) && source.searchCount > 0 ? source.searchCount : 0;
  const first = dateTimeLabel(str(source.firstSearchedAt), timeZone);
  const notes = [
    count > 1 ? `${count} times in total` : count === 1 ? 'once' : '',
    first && first !== last && count > 1 ? `first ${first}` : '',
  ];
  return [last, notes.filter(Boolean).join(', ')];
}

/** 'Thu 8 Oct 15:04' + '2h ago' for a queue instant ([value, note]); ['', ''] when unusable. */
function queueMoment(iso, timeZone, now) {
  const value = dateTimeLabel(iso, timeZone);
  if (!value) return ['', ''];
  return [value, now ? describeElapsed(iso, now) : ''];
}

/**
 * The queue facts of a ticket (v0.5, row.queue from lib/dashboardModel.js / lib/queueTracking.js) as
 * [label, value, note] triples: when a "Load all open tickets" run first found it in a saved queue,
 * when it entered the queue (or that it was already there at the queue's first complete run, the
 * baseline), and when and why it moved out. [] for a ticket no run has tracked. Never throws.
 * @param {object|null} queue row.queue
 * @param {{timeZone?:string, now?:Date}} [opts]
 * @returns {Array<[string, string, string]>}
 */
export function queueFactsOf(queue, opts = {}) {
  if (!isObject(queue)) return [];
  const options = isObject(opts) ? opts : {};
  const zone = str(options.timeZone);
  const now = options.now instanceof Date && !Number.isNaN(options.now.getTime()) ? options.now : null;
  const facts = [];
  const [since, sinceAgo] = queueMoment(str(queue.firstSeenAt), zone, now);
  facts.push(['In queue since', since, sinceAgo]);
  const [entered, enteredAgo] = queueMoment(str(queue.enteredAt), zone, now);
  if (entered) facts.push(['Entered the queue', entered, [enteredAgo, queue.isNew === true ? 'new to the queue' : ''].filter(Boolean).join(', ')]);
  else facts.push(['Entered the queue', 'present at the first refresh (baseline)', '']);
  if (queue.movedOut === true || str(queue.movedOutAt)) {
    const [out, outAgo] = queueMoment(str(queue.movedOutAt), zone, now);
    facts.push(['Moved out', out || 'yes', [outAgo, movedOutWords({ ...queue, movedOut: true }, { long: true })].filter(Boolean).join(', ')]);
  }
  return facts;
}

/**
 * Key facts as [label, value, note] triples, straight from the stored record (plus, since v0.5, the
 * queue facts of opts.queue right after 'Searched').
 * @param {object} record stored incident record
 * @param {{timeZone?:string, queue?:object|null, now?:Date}} [opts] zone the times are shown in (default:
 *   the browser's); queue = row.queue; now = the reference of the queue facts' "ago"
 */
export function factsOf(record, opts = {}) {
  const source = isObject(record) ? record : {};
  const caller = isObject(source.caller) ? source.caller : {};
  const opened = isObject(source.openedAt) ? str(source.openedAt.raw) : '';
  const notes = isObject(source.worknotes) ? source.worknotes : {};
  const [activity, activityNote] = activityFact(notes);
  const [searched, searchedNote] = searchedFact(source, isObject(opts) ? str(opts.timeZone) : '');
  const place = isObject(source.userLocation) ? source.userLocation : {};
  const field = isObject(source.locationField) ? source.locationField : {};
  const locationText = str(place.locationText) || str(field.value);
  const location = locationText ? [['Location', locationText, locationNote(place)]] : [];
  return [
    ['Caller', str(caller.name), str(caller.email)],
    ['Contact number', str(source.contactNumber), str(source.contactNumberSource)],
    ...location,
    ['Preferred contact', str(source.preferredContactMethod), str(source.preferredContactSource)],
    ['Assigned to', str(source.assignedTo), ''],
    ['Opened', opened, ''],
    ['Searched', searched, searchedNote],
    ...queueFactsOf(isObject(opts) ? opts.queue : null, opts),
    ['Activity', activity, activityNote],
  ];
}

// ---- one compact line ----

/** 'Thu 2026-10-08 15:04:05' -> 'Thu 8 Oct 15:04'; anything else is shown as it is. */
function compactTime(label) {
  const match = EXACT_LABEL.exec(str(label));
  if (!match) return str(label);
  const month = MONTHS[Number(match[3]) - 1] || match[3];
  return `${match[1]} ${Number(match[4])} ${month} ${match[5]}`;
}

/** 'Work notes' from 'Work notes by Ravi Kumar (assigned agent)'; 'Update' when the title has no kind. */
function kindOf(item) {
  const title = str(item.title);
  const author = str(item.author);
  const cut = author ? title.lastIndexOf(` by ${author}`) : title.indexOf(' by ');
  const kind = cut > 0 ? title.slice(0, cut) : '';
  return kind || 'Update';
}

/** 'assigned agent' | 'user' | '' for the author of an item, against the row's assignee and user. */
function roleOf(item, row) {
  const author = str(item.author);
  if (!author) return '';
  if (item.isAssignee === true || namesMatch(author, row.assignedTo)) return 'assigned agent';
  if (item.isUser === true || namesMatch(author, row.callerName) || namesMatch(author, row.impactedName)) return 'user';
  return '';
}

function timelineItem(item, index, row) {
  const li = create('li', 'tl-item');
  li.dataset.kind = 'activity';
  const tone = TONES.includes(item.tone) ? item.tone : 'grey';
  li.dataset.tone = tone;
  const status = STATUSES.includes(item.status) ? item.status : 'unknown';
  const role = roleOf(item, row);
  if (role) li.dataset.role = role === 'user' ? 'user' : 'assignee';
  const author = str(item.author);
  const kind = kindOf(item);
  const when = compactTime(item.atLabel);
  const ago = str(item.ago);
  const textId = `tl-${idPart(row.incidentNumber)}-${index}`;

  const line = create('div', 'tl-line');
  line.tabIndex = 0;
  line.dataset.tlIndex = String(index); // table.js restores focus to it when the drawer is rebuilt
  // ... preferably by this key, so a new update arriving at the top (which shifts every index) does not
  // move the focus to a different update than the one the person was reading.
  line.dataset.tlKey = `${str(item.at)}|${author}`;
  line.setAttribute('role', 'group');
  // What the line shows, in the order it shows it, plus the business-hours word the dot stands for.
  const spoken = [author, role, kind, when || 'time unknown', ago, item.status ? STATUS_WORDS[status] : ''].filter(Boolean);
  line.setAttribute('aria-label', spoken.join(', '));
  line.setAttribute('aria-describedby', textId);
  const dot = create('span', 'tl-dot');
  dot.dataset.status = status;
  dot.setAttribute('aria-hidden', 'true');
  const who = create('span', 'tl-who', author);
  line.append(dot, who);
  if (role) line.append(create('span', 'tl-role', role));
  line.append(create('span', 'tl-kind', kind));
  const time = create('span', 'tl-when', when || 'time unknown');
  if (ago) time.append(create('span', 'tl-ago', ` ${MIDDOT} ${ago}`));
  line.append(time);

  const pop = create('div', 'tl-pop');
  pop.setAttribute('role', 'tooltip');
  const box = create('div', 'tl-pop-box');
  box.append(create('p', 'tl-pop-head', str(item.title) || `${kind} by ${author}`));
  const meta = [str(item.atLabel) || 'time unknown', ago, str(item.pillLabel)].filter(Boolean).join(` ${MIDDOT} `);
  box.append(create('p', 'tl-pop-meta', meta));
  const detail = str(item.detail);
  const text = create('p', detail ? 'tl-pop-text' : 'tl-pop-text is-empty', detail || 'No text was recorded for this update.');
  text.id = textId;
  box.append(text);
  pop.append(box);
  li.append(line, pop);
  return li;
}

// ---- showing / placing / dismissing the popover ----

/** True when `wrap` clips what overflows it: any overflow other than visible (below 1160 px the table
 * wrapper is overflow-x: auto, which also clips vertically, even while it does not scroll sideways). */
function clips(wrap) {
  try {
    if (typeof getComputedStyle !== 'function') return wrap.scrollWidth > wrap.clientWidth;
    const style = getComputedStyle(wrap);
    return style.overflowX !== 'visible' || style.overflowY !== 'visible';
  } catch {
    return false;
  }
}

/** The box the popover must stay inside: the table area when it clips (see clips()), else the window. */
function boundsOf(node) {
  const width = globalThis.innerWidth || 0;
  const height = globalThis.innerHeight || 0;
  let bounds = { left: 0, top: 0, right: width, bottom: height };
  try {
    const wrap = typeof node.closest === 'function' ? node.closest('.table-wrap') : null;
    if (wrap && typeof wrap.getBoundingClientRect === 'function' && clips(wrap)) {
      const rect = wrap.getBoundingClientRect();
      bounds = {
        left: Math.max(bounds.left, rect.left),
        top: Math.max(bounds.top, rect.top),
        right: Math.min(bounds.right || rect.right, rect.right),
        bottom: Math.min(bounds.bottom || rect.bottom, rect.bottom),
      };
    }
  } catch {
    // the window is a good enough bound
  }
  return bounds;
}

/** Below the line by default, above when it would not fit below but does above; shifted left when it
 * would cross the right edge (never past the left one). A hidden popover is display:none (so it never
 * adds scroll overflow); data-measuring lays it out invisibly for the measurement. Cosmetic: any
 * failure leaves the CSS default. */
function placePopover(li) {
  try {
    const pop = li.querySelector('.tl-pop');
    const line = li.querySelector('.tl-line');
    if (!pop || !line || typeof pop.getBoundingClientRect !== 'function') return;
    pop.style.setProperty('--tl-shift', '0px');
    delete li.dataset.place;
    li.dataset.measuring = '1';
    const bounds = boundsOf(li);
    const lineRect = line.getBoundingClientRect();
    const popRect = pop.getBoundingClientRect();
    delete li.dataset.measuring;
    const below = bounds.bottom - lineRect.bottom;
    const above = lineRect.top - bounds.top;
    if (popRect.height > below - EDGE_GAP && above > below) li.dataset.place = 'above';
    const overflow = popRect.right - (bounds.right - EDGE_GAP);
    if (overflow > 0) {
      const room = Math.max(0, popRect.left - (bounds.left + EDGE_GAP));
      pop.style.setProperty('--tl-shift', `${-Math.min(overflow, room)}px`);
    }
  } catch {
    // placement is cosmetic
  }
}

function itemOf(event) {
  const target = event && event.target;
  return target && typeof target.closest === 'function' ? target.closest('.tl-item') : null;
}

/** `node.matches(selector)`, false when the selector or the method is not supported (never throws). */
function safeMatches(node, selector) {
  try {
    return Boolean(node && typeof node.matches === 'function' && node.matches(selector));
  } catch {
    return false;
  }
}

/** Dismiss the popovers shown because the pointer is over their item (Escape pressed anywhere: WCAG
 * 1.4.13 asks for dismissal without moving the pointer, and the hovered item rarely holds the focus).
 * Returns how many were dismissed. */
function dismissHovered(scope) {
  let count = 0;
  try {
    for (const li of scope.querySelectorAll('.tl-item:hover')) {
      if (li.dataset.dismissed !== '1') count += 1;
      li.dataset.dismissed = '1';
    }
  } catch {
    // no :hover support (tests): only the focused item's popover is dismissed
  }
  return count;
}

// One listener for the whole page (drawers are rebuilt every minute; a listener per drawer would pile up).
let documentEscapeWired = false;

function wireDocumentEscape() {
  if (documentEscapeWired) return;
  try {
    if (typeof document === 'undefined' || typeof document.addEventListener !== 'function') return;
    document.addEventListener('keydown', (event) => {
      if (event && event.key === 'Escape') dismissHovered(document);
    });
    documentEscapeWired = true;
  } catch {
    // Escape on the focused line (below) still dismisses its popover
  }
}

/** Wire one timeline list: placement on hover / focus, Escape to dismiss, re-arm when left. */
function wireTimeline(list) {
  if (typeof list.addEventListener !== 'function') return;
  wireDocumentEscape();
  const show = (event) => {
    const li = itemOf(event);
    if (li) placePopover(li);
  };
  list.addEventListener('mouseover', (event) => {
    const li = itemOf(event);
    if (li && !li.contains(event.relatedTarget)) show(event);
  });
  list.addEventListener('focusin', show);
  list.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape') return;
    const li = itemOf(event);
    let dismissed = dismissHovered(list);
    if (li && li.dataset.dismissed !== '1') {
      li.dataset.dismissed = '1';
      dismissed += 1;
    }
    if (!dismissed) return; // nothing was showing: let the Escape do whatever it does further up
    event.preventDefault();
    event.stopPropagation(); // this Escape only closes the popover, nothing further up the page
  });
  // Re-arm (show again on the next hover / focus) only once the item has neither the pointer nor the
  // focus: a popover dismissed while focused must not pop back up just because the pointer moved away.
  const rearm = (event) => {
    const li = itemOf(event);
    if (!li || li.contains(event.relatedTarget)) return;
    if (event.type === 'mouseout' && typeof document !== 'undefined' && li.contains(document.activeElement)) return;
    if (event.type === 'focusout' && safeMatches(li, ':hover')) return;
    delete li.dataset.dismissed;
  };
  list.addEventListener('mouseout', rearm);
  list.addEventListener('focusout', rearm);
}

/** The drawer row `tr[data-details-for]` shown directly under a ticket row. `opts.timeZone` is the zone
 * the Searched and queue facts are shown in; `opts.queue` / `opts.now` add the queue facts (factsOf). */
export function buildDetailsNode(row, record, items, opts = {}) {
  const tr = create('tr', 'details-row');
  tr.id = detailsId(row.incidentNumber);
  tr.dataset.detailsFor = row.incidentNumber;
  const td = create('td', 'details-cell');
  td.colSpan = TABLE_COLUMNS;
  const panel = create('section', 'details');
  panel.setAttribute('aria-label', `Details of ${row.incidentNumber}`);

  const facts = create('dl', 'facts');
  for (const [label, value, note] of factsOf(record, opts)) facts.append(fact(label, value, note));

  const heading = create('h3', 'details-title', 'Timeline');
  const sub = create('p', 'details-sub', "Updates written by people, newest first. Hover or focus an update to read it. Green / red = inside / outside the user's business hours.");
  const list = create('ol', 'timeline');
  list.dataset.role = 'timeline';
  list.setAttribute('aria-label', `Updates by people on ${row.incidentNumber}`);
  (Array.isArray(items) ? items : []).filter(isObject).forEach((item, index) => list.append(timelineItem(item, index, row)));
  wireTimeline(list);
  panel.append(facts, heading, sub);
  if (list.children.length) panel.append(list);
  else panel.append(list, create('p', 'details-empty', 'No updates by people recorded for this ticket yet.'));
  td.append(panel);
  tr.append(td);
  return tr;
}
