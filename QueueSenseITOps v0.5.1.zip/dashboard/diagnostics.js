// The Diagnostics tab (contract 13.5 / 13.6): the content-free 'fetchLog' ring buffer background.js
// keeps (incident number, timestamp, outcome, field/frame names -- never ticket content or values)
// and a "Discover fields" action (PROBE_INCIDENT) that shows what a form exposes to help debug field
// mapping on a real instance.
//
// Both the 'fetchLog' storage key and the PROBE_INCIDENT message are additions to background.js from
// contract 13.5 that are landing in parallel with this file. This module reads/sends them
// defensively: a missing key reads as an empty log, and a reply that never arrives (an older
// background that does not recognise PROBE_INCIDENT) is shown as "Discover fields is not available in
// this version of the extension yet," never as a crash.
//
// SECURITY: nothing here is ever allowed to render ticket content. The fields shown are an explicit
// allow-list (never "whatever keys the object happens to have"), and any text value that LOOKS like it
// might be personal data (an email address, a long run of digits, or simply too long to be a field
// name or a short diagnostic line) is redacted and flagged rather than displayed -- see `looksSensitive`.
// If that ever fires against real background.js output, it means fetchLog itself leaked content: a bug
// in the other half of this hardening pass, not something to paper over here.
import { parseInstanceUrl } from '../lib/instance.js';
import { ensureOriginPermissionConfirmed } from './confirmHost.js';
import {
  create, errorText, isObject, str,
} from './dom.js';
import { STALE_WORKER_TEXT, copyText, sendRuntimeMessage } from './messaging.js';

const FETCH_LOG_KEY = 'fetchLog'; // contract 13.5 (not yet in lib/config.js's STORAGE_KEYS)
const DIAG_LINE_MAX = 220; // a content-free diagnostic line is documented as <= 200 chars; a margin
const EMAIL_LIKE = /[^\s@]+@[^\s@]+\.[^\s@]+/;
const DIGIT_RUN = /\d[\d\s().-]{6,}\d/; // a phone-number-shaped run of digits

let log = [];
let inventory = [];
let probeResult = null; // { env, frame } of the last successful probe, or null
let probing = false;
let inventoryQuery = '';

/** A text value that looks like it could be personal data rather than a field name / short code. */
function looksSensitive(text) {
  const value = str(text);
  return value.length > DIAG_LINE_MAX || EMAIL_LIKE.test(value) || DIGIT_RUN.test(value);
}

/** `text`, or a redacted placeholder (and true) when it looks sensitive. */
function safeText(text) {
  const value = str(text);
  return looksSensitive(value) ? { text: '[redacted: looked like personal data, not shown]', flagged: true } : { text: value, flagged: false };
}

function els() {
  return {
    list: document.getElementById('diagList'),
    empty: document.getElementById('diagEmpty'),
    copy: document.getElementById('diagCopy'),
    discoverIncident: document.getElementById('discoverIncident'),
    discoverBtn: document.getElementById('discoverBtn'),
    status: document.getElementById('discoverStatus'),
    wrap: document.getElementById('inventoryWrap'),
    rows: document.getElementById('inventoryRows'),
    search: document.getElementById('inventorySearch'),
    inventoryCopy: document.getElementById('inventoryCopyBtn'),
  };
}

// ---- fetch log ----

function sortedLog() {
  // Newest first; entries whose 'at' cannot be parsed keep their stored order at the end.
  return [...log].sort((a, b) => {
    const ta = Date.parse(isObject(a) ? a.at : '');
    const tb = Date.parse(isObject(b) ? b.at : '');
    const na = Number.isFinite(ta);
    const nb = Number.isFinite(tb);
    if (na && nb) return tb - ta;
    if (na) return -1;
    if (nb) return 1;
    return 0;
  });
}

function fieldLine(label, value) {
  const line = create('p', 'diag-line');
  line.append(create('span', 'diag-line-label', `${label}: `), create('span', 'diag-line-value', value));
  return line;
}

function diagEntryNode(entry) {
  const li = create('li', 'diag-entry');
  if (!isObject(entry)) {
    li.append(create('p', 'diag-line', 'Unreadable entry (not an object) - skipped.'));
    return li;
  }
  const ok = entry.ok === true;
  li.dataset.ok = String(ok);
  const head = create('div', 'diag-entry-head');
  const at = str(entry.at);
  const when = at && !Number.isNaN(Date.parse(at)) ? new Date(at).toLocaleString() : (at || 'unknown time');
  head.append(
    create('span', `diag-outcome ${ok ? 'is-ok' : 'is-fail'}`, ok ? 'OK' : 'Failed'),
    create('span', 'diag-when', when),
    create('span', 'diag-number', str(entry.incidentNumber) || '(no number)'),
    create('span', 'diag-source', str(entry.source) || ''),
  );
  li.append(head);
  if (!ok && str(entry.code)) li.append(fieldLine('Code', str(entry.code)));
  if (str(entry.pathname)) li.append(fieldLine('Page path', str(entry.pathname)));
  if (str(entry.title)) {
    const { text, flagged } = safeText(entry.title);
    const line = fieldLine('Page title', text);
    if (flagged) line.classList.add('is-flagged');
    li.append(line);
  }
  if (Number.isFinite(Number(entry.frameCount))) li.append(fieldLine('Frames seen', String(entry.frameCount)));
  if (str(entry.frameUsed)) li.append(fieldLine('Frame used', str(entry.frameUsed)));
  const warnings = Array.isArray(entry.warnings) ? entry.warnings.filter(Boolean) : [];
  if (warnings.length) li.append(fieldLine('Warnings', warnings.map(str).join(', ')));
  const env = isObject(entry.env) ? entry.env : null;
  if (env) {
    const flags = Object.entries(env)
      .filter(([, v]) => typeof v === 'boolean')
      .map(([k, v]) => `${k}=${v}`)
      .join(', ');
    if (flags) li.append(fieldLine('Form API surfaces', flags));
  }
  const diagnostics = Array.isArray(entry.diagnostics) ? entry.diagnostics : [];
  if (diagnostics.length) {
    const details = create('details', 'diag-details');
    const summary = create('summary', '', `${diagnostics.length} diagnostic line${diagnostics.length === 1 ? '' : 's'}`);
    details.append(summary);
    const list = create('ul', 'diag-sublist');
    for (const item of diagnostics) {
      const { text, flagged } = safeText(item);
      const sub = create('li', flagged ? 'is-flagged' : '', text);
      list.append(sub);
    }
    details.append(list);
    li.append(details);
  }
  return li;
}

export function paintDiagnosticsLog() {
  const { list, empty } = els();
  if (!list) return;
  const rows = sortedLog();
  list.replaceChildren(...rows.map(diagEntryNode));
  if (empty) empty.hidden = rows.length > 0;
  list.hidden = rows.length === 0;
}

async function onCopyLog() {
  const { copy } = els();
  if (!copy) return;
  const copied = await copyText(JSON.stringify(log, null, 2));
  const original = copy.textContent;
  copy.textContent = copied ? 'Copied' : 'Could not copy';
  setTimeout(() => {
    copy.textContent = original;
  }, 1600);
}

async function loadLog() {
  try {
    const stored = await chrome.storage.local.get([FETCH_LOG_KEY]);
    log = Array.isArray(stored[FETCH_LOG_KEY]) ? stored[FETCH_LOG_KEY] : [];
  } catch {
    log = [];
  }
  paintDiagnosticsLog();
}

function onStorageChanged(changes, area) {
  if (area === 'local' && FETCH_LOG_KEY in changes) {
    log = Array.isArray(changes[FETCH_LOG_KEY].newValue) ? changes[FETCH_LOG_KEY].newValue : [];
    paintDiagnosticsLog();
  }
}

// ---- discover fields (PROBE_INCIDENT) ----

function setDiscoverStatus(stateName, message) {
  const { status } = els();
  if (!status) return;
  status.dataset.state = stateName;
  status.textContent = message;
}

function inventoryRowNode(entry) {
  const tr = document.createElement('tr');
  const cells = [
    str(entry.name),
    str(entry.label),
    entry.reference ? 'Yes' : 'No',
    entry.readonly ? 'Yes' : 'No',
    entry.hasValue ? 'Yes' : 'No',
  ];
  for (const text of cells) tr.append(create('td', '', text));
  return tr;
}

function paintInventory() {
  const { wrap, rows } = els();
  if (!rows) return;
  const query = inventoryQuery.trim().toLowerCase();
  const filtered = query
    ? inventory.filter((item) => `${str(item.name)} ${str(item.label)}`.toLowerCase().includes(query))
    : inventory;
  rows.replaceChildren(...filtered.map(inventoryRowNode));
  if (wrap) wrap.hidden = inventory.length === 0;
}

async function onDiscoverCopy() {
  const { inventoryCopy } = els();
  if (!inventoryCopy) return;
  const copied = await copyText(JSON.stringify({ env: probeResult && probeResult.env, inventory }, null, 2));
  const original = inventoryCopy.textContent;
  inventoryCopy.textContent = copied ? 'Copied' : 'Could not copy';
  setTimeout(() => {
    inventoryCopy.textContent = original;
  }, 1600);
}

async function storedInstanceUrl() {
  try {
    const stored = await chrome.storage.local.get(['instanceUrl']);
    return str(stored.instanceUrl);
  } catch {
    return '';
  }
}

async function onDiscover() {
  if (probing) return;
  const { discoverIncident } = els();
  const incidentNumber = discoverIncident ? discoverIncident.value.trim() : '';
  if (!incidentNumber) {
    setDiscoverStatus('error', 'Enter an incident number first.');
    if (discoverIncident) discoverIncident.focus();
    return;
  }
  const origin = await storedInstanceUrl();
  const parsed = parseInstanceUrl(origin);
  if (!parsed.ok) {
    setDiscoverStatus('error', 'No ServiceNow address is known yet. Search for a ticket in the Tickets tab first.');
    return;
  }
  probing = true;
  setDiscoverStatus('loading', `Probing ${incidentNumber} ... a background tab opens for a moment.`);
  try {
    // First awaited work of the click handler: permissions.request needs the user gesture.
    const permission = await ensureOriginPermissionConfirmed(parsed.origin);
    if (!permission.ok) {
      setDiscoverStatus('error', permission.message);
      return;
    }
    const { reply, failure } = await sendRuntimeMessage({ type: 'PROBE_INCIDENT', instanceUrl: permission.origin, incidentNumber });
    if (failure) {
      setDiscoverStatus('error', failure);
      return;
    }
    if (reply === undefined) {
      setDiscoverStatus('error', STALE_WORKER_TEXT);
      return;
    }
    if (!isObject(reply) || !reply.ok) {
      setDiscoverStatus('error', errorText(isObject(reply) && isObject(reply.error) ? reply.error : 'The probe did not succeed.'));
      return;
    }
    const result = isObject(reply.result) ? reply.result : {};
    inventory = Array.isArray(result.inventory) ? result.inventory.filter(isObject) : [];
    probeResult = { env: isObject(result.env) ? result.env : null, frame: result.frame };
    paintInventory();
    setDiscoverStatus('success', `Found ${inventory.length} field${inventory.length === 1 ? '' : 's'} on the form.`);
  } catch (err) {
    setDiscoverStatus('error', `The probe failed: ${errorText(err)}`);
  } finally {
    probing = false;
  }
}

// ---- lifecycle ----

/** Load the fetch log and start watching storage for new entries. Safe to call once at startup. */
export async function initDiagnostics() {
  await loadLog();
  if (globalThis.chrome && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener(onStorageChanged);
  }
}

/** Repaint the Diagnostics tab (called when it becomes visible; cheap when nothing changed). */
export function paintDiagnostics() {
  paintDiagnosticsLog();
  paintInventory();
}

/** Attach the Diagnostics tab's event listeners. */
export function wireDiagnostics() {
  const { copy, discoverBtn, search, inventoryCopy } = els();
  if (copy) copy.addEventListener('click', () => void onCopyLog());
  if (discoverBtn) discoverBtn.addEventListener('click', () => void onDiscover());
  if (search) {
    search.addEventListener('input', () => {
      inventoryQuery = search.value;
      paintInventory();
    });
  }
  if (inventoryCopy) inventoryCopy.addEventListener('click', () => void onDiscoverCopy());
}
