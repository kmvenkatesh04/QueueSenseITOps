// Small DOM and value helpers shared by the dashboard modules. Everything that reaches the page comes
// from ServiceNow and is untrusted: it is written with textContent / setAttribute only, never parsed
// as HTML.

/** Shown instead of a missing value. */
export const EM_DASH = '—';
/** Separator inside one line of meta text. */
export const MIDDOT = '·';

/** True for plain (non-array) objects. */
export const isObject = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
/** The message of anything thrown. */
export const errorText = (err) => (err && err.message) || String(err);

/** Trimmed string for strings and finite numbers, '' for anything else. */
export function str(value) {
  if (typeof value === 'string') return value.trim();
  if (typeof value === 'number' && Number.isFinite(value)) return String(value);
  return '';
}

/** createElement with a class and text (textContent: never HTML). */
export function create(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

/** Assign text only when it changed, so live regions are not re-announced by every repaint. */
export function setText(node, text) {
  if (node.textContent !== text) node.textContent = text;
}

/** Mark an element with data-field so tests and styles can find it. */
export function withField(node, name) {
  node.dataset.field = name;
  return node;
}

/** A type="button" button; `attrs` are set with setAttribute. */
export function button(label, className, attrs = {}) {
  const node = create('button', `btn ${className}`, label);
  node.type = 'button';
  for (const [name, value] of Object.entries(attrs)) node.setAttribute(name, value);
  return node;
}

/** The href of an http(s) URL, '' for anything else (javascript:, data:, garbage). */
export function safeHttpUrl(value) {
  try {
    const url = new URL(str(value));
    return url.protocol === 'https:' || url.protocol === 'http:' ? url.href : '';
  } catch {
    return '';
  }
}

/** Link that opens in a new tab and cannot reach back into this page. */
export function externalLink(href, className, text) {
  const node = create('a', className, text);
  node.href = href;
  node.target = '_blank';
  node.rel = 'noopener noreferrer';
  return node;
}

/** First letter upper-cased. */
export function capitalize(text) {
  return text ? text.charAt(0).toUpperCase() + text.slice(1) : '';
}

/** IANA id of the browser's time zone. */
export function systemTimeZone() {
  return new Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
}

/** One line of at most `max` characters; a cut ends with an ellipsis. */
export function previewOf(text, max = 120) {
  const flat = str(text).replace(/\s+/g, ' ');
  return flat.length > max ? `${flat.slice(0, max - 1)}…` : flat;
}

/** 'https://x.service-now.com' -> 'x.service-now.com' (anything unparseable is returned as it is). */
export function hostOf(origin) {
  try {
    return new URL(origin).host;
  } catch {
    return str(origin);
  }
}

/** Safe fragment for an element id built from untrusted text. */
export function idPart(text) {
  return str(text).replace(/[^A-Za-z0-9_-]/g, '_');
}

/** '1 ticket' / '3 tickets'. */
export function plural(count, one, many) {
  return `${count} ${count === 1 ? one : many}`;
}
