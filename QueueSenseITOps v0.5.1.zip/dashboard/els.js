// Registry of the page's static elements, looked up once (modules run after the document is parsed).
const IDS = [
  // header, search, refresh bar
  'dashTitle', 'dashSubtitle', 'searchForm', 'searchInstanceUrl', 'searchIncident', 'searchBtn', 'searchStatus',
  'refreshBar', 'refreshText', 'refreshProgress', 'refreshOrigins', 'refreshHint', 'refreshAnnounce',
  'refreshAllBtn', 'cancelRefreshBtn', 'autoRefreshToggle',
  // tabs
  'tabTickets', 'tabHistory', 'tabData', 'panelTickets', 'panelHistory', 'panelData', 'updatedAt', 'reloadBtn',
  // tickets
  // (#statusFilter is not listed: since v0.4 it is the button of a multi-select that dashboard/tickets.js
  // builds at start-up, after this registry is read; nav.js and tickets.js look it up by id when needed.)
  'nextActions', 'nextItems', 'summary', 'dayFilter', 'rowCount', 'notice',
  'incidentTable', 'tableCaption', 'incidentRows', 'emptyState', 'emptyTitle', 'emptyText', 'emptyReset',
  // history
  'historyDay', 'historySearch', 'historyCount', 'historyTable', 'historyRows', 'historyEmpty',
  'historyEmptyTitle', 'historyEmptyText',
  // data
  'jsonScope', 'jsonView', 'jsonCopyBtn', 'jsonExportBtn', 'jsonImportInput', 'jsonImportBtn', 'jsonStatus',
  'jsonNote', 'jsonSize', 'jsonTruncated',
];

export const els = Object.fromEntries(IDS.map((id) => [id, document.getElementById(id)]));

/** Ids that the markup is missing (a typo here would otherwise surface as a null dereference later). */
export function missingElements() {
  return IDS.filter((id) => !els[id]);
}
