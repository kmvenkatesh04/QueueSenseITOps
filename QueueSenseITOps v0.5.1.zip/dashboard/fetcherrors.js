// The Fetch errors view (v0.5): the tickets the last "Load all open tickets" run (manual or automatic)
// listed in the queue but could not read, even after its automatic retries. They are shown AS
// SERVICENOW'S LIST SHOWED THEM: one column per column of the classic incident list, under the list's
// own headers, with the cells the list showed for that ticket (lib/queueTracking.js lastErrors, filled by
// the run from the LIST_OPEN_INCIDENTS rows), plus what went wrong and how often it was tried.
//
// Ways forward, all through the person's own browser:
//   - "Retry all" and a "Retry" per row read the tickets again (dashboard/autorefresh.js
//     retryFailedTickets: the same background-tab fetch as every other ticket). Both are unavailable
//     (aria-disabled, so a focused button keeps focus) while a run is going.
//   - "Open these tickets in ServiceNow" is a plain link to ServiceNow's own incident list filtered to
//     exactly these numbers (incident_list.do?sysparm_query=numberIN...), in chunks of at most 100 numbers
//     so the address stays short; each Number cell links to that incident. The person clicks them: the
//     extension itself makes no request (the hard rule of the whole extension).
//
// The tab label says how many tickets are waiting: syncFetchErrorsBadge() sets #tabErrors to "Fetch
// errors" or "Fetch errors (3)"; dashboard.js calls it on every paint.
//
// The DOM is built with dom.js's create()/setText() only (every cell is untrusted ServiceNow text). The
// pure helpers (the table model, the plain-language errors, the ServiceNow links, the texts) are
// exported for tests/fetcherrors.test.mjs; the DOM is touched only inside wireFetchErrors(),
// paintFetchErrors() and syncFetchErrorsBadge().
import * as autoRefresh from './autorefresh.js';
import {
  create, errorText, externalLink, isObject, plural, setText, str,
} from './dom.js';
import { createSectionSync, formatClock } from './overview.js';
import { state } from './state.js';

/** Most numbers in one "Open these tickets in ServiceNow" link. */
export const LIST_LINK_CHUNK = 100;
const ITEMS_MAX = 500;
const COLUMNS_MAX = 20;
const CELL_MAX = 200;
const NUMBER_RE = /^[A-Za-z0-9_.-]{1,40}$/;
const FIELD_RE = /^[A-Za-z0-9_.$-]{1,100}$/;

/** Plain-language meaning of the error codes a ticket fetch can end with. */
const PLAIN_ERRORS = {
  TAB_ERROR: 'The ticket page did not load in the background tab',
  EXTRACT_FAILED: 'The ticket page loaded, but its data could not be read',
  PAGE_UNSUPPORTED: 'ServiceNow showed a page the extension cannot read',
  LOGIN_REQUIRED: 'ServiceNow asked for a login',
  NOT_FOUND: 'ServiceNow did not find this ticket',
  NO_PERMISSION: 'The extension may not open this ServiceNow address',
  TIMEOUT: 'ServiceNow took too long to answer',
  // codes the dashboard itself gives a fetch (dashboard/opentickets.js, dashboard/autorefresh.js)
  NO_RESPONSE: 'The extension\'s background worker did not answer',
  STALE_WORKER: 'The extension was updated: reload this dashboard page',
  FETCH_FAILED: 'The ticket could not be read',
  INVALID_INPUT: 'The ticket number or the ServiceNow address was not accepted',
};
const PLAIN_DEFAULT = 'The ticket could not be read';

// ---- pure helpers ----

const count = (value) => (Number.isInteger(value) && value > 0 ? value : 0);
const cut = (text, max = CELL_MAX) => (text.length > max ? `${text.slice(0, max - 1)}…` : text);

/**
 * The origin ('https://x.service-now.com') of an http(s) address; '' for anything else (javascript:,
 * data:, garbage), so no link is ever built from it.
 * @param {*} value
 * @returns {string}
 */
export function originOf(value) {
  try {
    const url = new URL(str(value));
    return url.protocol === 'https:' || url.protocol === 'http:' ? url.origin : '';
  } catch {
    return '';
  }
}

/** A ticket number as stored ('' unless it looks like one: letters, digits, _ . -). */
function cleanNumber(value) {
  const number = str(value);
  return NUMBER_RE.test(number) ? number : '';
}

/**
 * The address of one incident in ServiceNow: origin + '/incident.do?sysparm_query=number=' + number;
 * '' when the origin or the number is unusable.
 * @param {string} origin
 * @param {string} number
 * @returns {string}
 */
export function incidentUrl(origin, number) {
  const base = originOf(origin);
  const clean = cleanNumber(number);
  if (!base || !clean) return '';
  return `${base}/incident.do?sysparm_query=number=${encodeURIComponent(clean)}`;
}

/**
 * Links to ServiceNow's own incident list of exactly these tickets, at most `size` numbers per link:
 * origin + '/incident_list.do?sysparm_query=' + encodeURIComponent('numberIN' + numbers.join(',')).
 * Duplicates and anything that is not a ticket number are left out; [] without a usable origin.
 * @param {string} origin
 * @param {string[]} numbers
 * @param {number} [size]
 * @returns {{href:string, count:number, label:string, from:number, to:number}[]}
 */
export function serviceNowListLinks(origin, numbers, size = LIST_LINK_CHUNK) {
  const base = originOf(origin);
  if (!base) return [];
  const clean = [...new Set((Array.isArray(numbers) ? numbers : []).map(cleanNumber).filter(Boolean))];
  const step = Number.isInteger(size) && size > 0 ? size : LIST_LINK_CHUNK;
  const links = [];
  for (let i = 0; i < clean.length; i += step) {
    const chunk = clean.slice(i, i + step);
    links.push({
      href: `${base}/incident_list.do?sysparm_query=${encodeURIComponent(`numberIN${chunk.join(',')}`)}`,
      count: chunk.length,
      from: i + 1,
      to: i + chunk.length,
      label: '',
    });
  }
  for (const link of links) {
    link.label = links.length === 1
      ? 'Open these tickets in ServiceNow'
      : `Open tickets ${link.from}–${link.to} in ServiceNow`;
  }
  return links;
}

/**
 * An error in plain language: { plain, detail, code }. plain is what the code means ('The ticket page
 * did not load in the background tab'), detail the run's own message when it says more, code the code.
 * @param {*} code
 * @param {*} message
 * @returns {{plain:string, detail:string, code:string}}
 */
export function plainError(code, message) {
  const c = str(code).toUpperCase().slice(0, 40);
  const plain = Object.hasOwn(PLAIN_ERRORS, c) ? PLAIN_ERRORS[c] : PLAIN_DEFAULT;
  const detail = cut(str(message), 300);
  return { plain, detail: detail && detail !== plain && `${detail}.` !== `${plain}.` ? detail : '', code: c };
}

/** 'short_description' -> 'Short description' (a header for a column the list gave no label for). */
function fieldLabel(field) {
  const words = field.replace(/^.*\./, '').replace(/[_$-]+/g, ' ').trim();
  return words ? words.charAt(0).toUpperCase() + words.slice(1) : field;
}

/**
 * The table of lastErrors (lib/queueTracking.js): the list's columns in their own order (columnOrder, an
 * array of fields; without it the keys of columnLabels with Number first) and with their own headers
 * (columnLabels; a field without a label, or every field that appears in the cells when there are no
 * labels at all, is labelled from its name), a Number column always (put first when the list had none),
 * and per ticket its cells, its
 * error in plain language, its attempts and its ServiceNow address. Garbage in, a well-formed (maybe
 * empty) model out; never throws.
 * @param {*} lastErrors
 * @returns {{at:string|null, origin:string, columns:{field:string, label:string}[], numberField:string,
 *   rows:{number:string, href:string, cells:{field:string, text:string}[], error:{plain:string, detail:string, code:string}, attempts:number}[],
 *   numbers:string[], minAttempts:number, maxAttempts:number}}
 */
export function errorTableModel(lastErrors) {
  const source = isObject(lastErrors) ? lastErrors : {};
  const origin = originOf(source.origin);
  const at = typeof source.at === 'string' && Number.isFinite(Date.parse(source.at)) ? source.at : null;
  const items = [];
  const seen = new Set();
  for (const item of Array.isArray(source.items) ? source.items : []) {
    if (!isObject(item)) continue;
    const number = cleanNumber(item.number);
    if (!number || seen.has(number)) continue;
    seen.add(number);
    items.push({ number, item, cells: isObject(item.cells) ? item.cells : {} });
    if (items.length >= ITEMS_MAX) break;
  }

  const labels = isObject(source.columnLabels) ? source.columnLabels : {};
  const fields = [];
  const addField = (field) => {
    if (typeof field === 'string' && FIELD_RE.test(field) && !fields.includes(field) && fields.length < COLUMNS_MAX) fields.push(field);
  };
  // chrome.storage.local keeps an object's keys SORTED (Chrome stores it as a base::Value dictionary), so
  // the list's own column order survives only as an array: columnOrder. Without it the labels' keys are
  // used, with the Number column moved first (where ServiceNow's incident list has it).
  const ordered = Array.isArray(source.columnOrder) && source.columnOrder.some((field) => typeof field === 'string');
  if (ordered) for (const field of source.columnOrder) addField(field);
  for (const field of Object.keys(labels)) addField(field);
  if (!fields.length) {
    for (const { cells } of items) for (const field of Object.keys(cells)) addField(field);
  }
  let columns = fields.map((field) => ({ field, label: cut(str(labels[field]), 100) || fieldLabel(field) }));
  let numberColumn = columns.find((column) => column.field.toLowerCase() === 'number');
  if (!numberColumn) {
    numberColumn = { field: 'number', label: 'Number' };
    columns = [numberColumn, ...columns];
  } else if (!ordered) {
    columns = [numberColumn, ...columns.filter((column) => column !== numberColumn)];
  }

  const rows = items.map(({ number, item, cells }) => ({
    number,
    href: incidentUrl(origin, number),
    cells: columns.map((column) => {
      const text = cut(str(cells[column.field]));
      return { field: column.field, text: column === numberColumn ? text || number : text };
    }),
    error: plainError(item.code, item.message),
    attempts: count(item.attempts),
  }));
  const attempts = rows.map((row) => row.attempts);
  return {
    at,
    origin,
    columns,
    numberField: numberColumn.field,
    rows,
    numbers: rows.map((row) => row.number),
    minAttempts: attempts.length ? Math.min(...attempts) : 0,
    maxAttempts: attempts.length ? Math.max(...attempts) : 0,
  };
}

/**
 * The line under the heading: 'From the run at 10:15: 3 tickets could not be read after 3 attempts.'
 * ('after up to 4 attempts' when they differ; no attempts part when none were counted).
 * @param {object} model errorTableModel output
 * @param {Date} now
 * @param {string} [timeZone]
 * @returns {string}
 */
export function errorsHeadline(model, now, timeZone) {
  const n = model.rows.length;
  const clock = formatClock(model.at, now, timeZone);
  const when = clock ? `From the run at ${clock}: ` : 'From the last run: ';
  let tries = '';
  if (model.maxAttempts > 0) {
    tries = model.minAttempts === model.maxAttempts
      ? ` after ${plural(model.maxAttempts, 'attempt', 'attempts')}`
      : ` after up to ${model.maxAttempts} attempts`;
  }
  return `${when}${plural(n, 'ticket', 'tickets')} could not be read${tries}.`;
}

/**
 * What the view says when there is nothing to show: 'No run yet.' before the first run, else 'No fetch
 * errors in the last run (10:15).'
 * @param {*} tracking state.data.queueTracking
 * @param {Date} now
 * @param {string} [timeZone]
 * @returns {string}
 */
export function emptyErrorsText(tracking, now, timeZone) {
  const t = isObject(tracking) ? tracking : {};
  const runs = Array.isArray(t.runs) ? t.runs.filter(isObject) : [];
  const last = isObject(t.lastErrors) && typeof t.lastErrors.at === 'string' ? t.lastErrors.at : (runs[0] && runs[0].at);
  const clock = formatClock(last, now, timeZone);
  if (!clock) return 'No run yet.';
  return `No fetch errors in the last run (${clock}).`;
}

/**
 * The number of tickets waiting in lastErrors (0 for anything odd).
 * @param {*} tracking state.data.queueTracking
 * @returns {number}
 */
export function fetchErrorCount(tracking) {
  const errors = isObject(tracking) && isObject(tracking.lastErrors) ? tracking.lastErrors : null;
  return errors && Array.isArray(errors.items) ? errors.items.filter(isObject).length : 0;
}

/** The tab label: 'Fetch errors' or 'Fetch errors (3)'. */
export function badgeText(n) {
  return count(n) ? `Fetch errors (${count(n)})` : 'Fetch errors';
}

/**
 * What a retry did, in words. `waiting` is how many tickets the retry was asked for: when some were
 * waiting and the result counts none read and none still failing (the run did not start because another
 * dashboard tab is loading open tickets or the host permission was refused, it was cancelled, it stopped
 * at a login page, or it failed), the text says so instead of claiming nothing was waiting. A `reason` in the result (when the runner passes
 * one) is shown as given.
 * @param {*} result retryFailedTickets() result { ok, failed, started?, reason? }
 * @param {number} [waiting] the tickets the retry was asked for (unknown: treated as none)
 * @returns {string}
 */
export function retryResultText(result, waiting = 0) {
  const r = isObject(result) ? result : {};
  const ok = count(r.ok);
  const failed = count(r.failed);
  if (!ok && !failed) {
    const reason = cut(str(r.reason), 300).replace(/\.$/, '');
    if (r.started === false && reason) return `The retry did not run: ${reason}.`;
    if (count(waiting) || r.started === false) {
      return `No ticket was read this time${reason ? ` (${reason})` : ''}: the retry did not run (another dashboard tab may be loading open tickets), was cancelled, or ServiceNow asked for a login. See the progress panel at the top of the page, then try again.`;
    }
    return 'Nothing was retried: no ticket is waiting.';
  }
  if (!failed) return `${plural(ok, 'ticket was', 'tickets were')} read this time.`;
  if (!ok) return `${plural(failed, 'ticket', 'tickets')} still could not be read.`;
  return `${plural(ok, 'ticket was', 'tickets were')} read; ${plural(failed, 'ticket', 'tickets')} still could not be read.`;
}

// ---- module state ----

let ui = null;
let syncSection = null;
let retrying = false;
let runRunning = false;
let unsubscribe = null;

function tracking() {
  return isObject(state.data) && isObject(state.data.queueTracking) ? state.data.queueTracking : null;
}

/** Set #tabErrors to 'Fetch errors' / 'Fetch errors (N)' from the stored last errors (contract F). */
export function syncFetchErrorsBadge() {
  const tab = typeof document !== 'undefined' && document && typeof document.getElementById === 'function'
    ? document.getElementById('tabErrors')
    : null;
  if (!tab || typeof tab !== 'object' || !('textContent' in tab)) return;
  const n = fetchErrorCount(tracking());
  setText(tab, badgeText(n));
  if (tab.dataset) tab.dataset.count = String(n);
}

// ---- DOM ----

function buildSkeleton(panel) {
  const head = create('div', 'ov-head fe-head');
  const titleBox = create('div', 'ov-title');
  const heading = create('h2', 'ov-heading', 'Fetch errors');
  heading.id = 'feHeading';
  heading.tabIndex = -1;
  const headline = create('p', 'ov-note fe-headline');
  titleBox.append(heading, headline);
  head.append(titleBox);

  const message = create('p', 'fe-message');
  message.id = 'feMessage';
  message.setAttribute('role', 'status');

  const body = create('div', 'fe-body');
  const actions = create('div', 'fe-actions');
  const retryAll = create('button', 'btn btn-primary btn-sm fe-retry-all', 'Retry all');
  retryAll.type = 'button';
  retryAll.dataset.drill = 'retry-all';
  retryAll.addEventListener('click', () => void retry());
  const links = create('div', 'fe-links');
  actions.append(retryAll, links);
  const explain = create('p', 'fe-explain',
    'The table shows these tickets as ServiceNow\'s list showed them when the run read the queue. Retry reads them again in a background tab; '
    + 'the ServiceNow link opens ServiceNow\'s own list of exactly these tickets in a new tab.');
  const wrap = create('div', 'table-wrap ov-table-wrap fe-table-wrap');
  wrap.setAttribute('role', 'region');
  wrap.setAttribute('aria-labelledby', 'feHeading');
  wrap.tabIndex = -1;
  body.append(actions, explain, wrap);

  const empty = create('div', 'empty-state fe-empty');
  const emptyTitle = create('p', 'empty-title');
  const emptyText = create('p', 'empty-text',
    'When “Load all open tickets”, Refresh now or auto refresh cannot read a ticket of the queue (even after the automatic retries), it is listed here with ServiceNow\'s own columns.');
  empty.append(emptyTitle, emptyText);

  panel.replaceChildren(head, message, body, empty);
  panel.addEventListener('click', (event) => {
    const node = event.target instanceof Element ? event.target.closest('[data-retry]') : null;
    if (node && panel.contains(node)) void retry([node.dataset.retry]);
  });
  return {
    panel, heading, headline, message, body, retryAll, links, wrap, empty, emptyTitle,
  };
}

function buildLinks(model) {
  return serviceNowListLinks(model.origin, model.numbers).map((link, index) => {
    const node = externalLink(link.href, 'btn btn-secondary btn-sm btn-link fe-list-link', link.label);
    node.dataset.drill = `list:${index}`;
    node.title = `ServiceNow's incident list of ${plural(link.count, 'ticket', 'tickets')}, in a new tab`;
    return node;
  });
}

function buildTable(model) {
  const table = create('table', 'ov-table fe-table');
  table.append(create('caption', 'sr-only',
    'Tickets the last run could not read, with the columns of ServiceNow\'s incident list, the error, the attempts and a Retry button.'));
  const thead = create('thead');
  const headRow = create('tr');
  for (const column of model.columns) {
    const th = create('th', 'ov-th', column.label);
    th.scope = 'col';
    headRow.append(th);
  }
  for (const [label, className] of [['Error', 'fe-error-head'], ['Attempts', 'ov-num'], ['Retry', 'fe-action-head']]) {
    const th = create('th', `ov-th ${className}`, label);
    th.scope = 'col';
    headRow.append(th);
  }
  thead.append(headRow);
  const tbody = create('tbody');
  for (const row of model.rows) {
    const tr = create('tr');
    for (const cell of row.cells) {
      if (cell.field === model.numberField) {
        const th = create('th', 'ov-rowhead fe-number');
        th.scope = 'row';
        if (row.href) {
          const link = externalLink(row.href, 'fe-number-link', cell.text);
          link.dataset.drill = `open:${row.number}`;
          link.title = 'Open this incident in ServiceNow, in a new tab';
          th.append(link);
        } else {
          th.textContent = cell.text;
        }
        tr.append(th);
      } else {
        tr.append(create('td', `fe-cell${cell.text ? '' : ' ov-zero'}`, cell.text || '—'));
      }
    }
    const error = create('td', 'fe-error');
    error.append(create('span', 'fe-error-plain', row.error.plain));
    if (row.error.detail) error.append(create('span', 'fe-error-detail', row.error.detail));
    if (row.error.code) error.append(create('code', 'fe-error-code', row.error.code));
    tr.append(error, create('td', 'ov-num', String(row.attempts)));
    const action = create('td', 'fe-action');
    const retryBtn = create('button', 'btn btn-secondary btn-sm fe-retry', 'Retry');
    retryBtn.type = 'button';
    retryBtn.dataset.retry = row.number;
    retryBtn.dataset.drill = `retry:${row.number}`;
    retryBtn.setAttribute('aria-label', `Retry ${row.number}`);
    action.append(retryBtn);
    tr.append(action);
    tbody.append(tr);
  }
  table.append(thead, tbody);
  return [table];
}

/** Every retry button reflects whether a retry may start now (aria-disabled keeps a focused one focused). */
function syncBusy() {
  if (!ui) return;
  const busy = retrying || runRunning;
  const value = busy ? 'true' : 'false';
  for (const node of [ui.retryAll, ...ui.wrap.querySelectorAll('[data-retry]')]) {
    if (node.getAttribute('aria-disabled') !== value) node.setAttribute('aria-disabled', value);
    node.title = runRunning ? 'A refresh is running: retry when it has finished' : retrying ? 'A retry is running' : '';
  }
  ui.panel.dataset.busy = value;
}

async function retry(numbers) {
  if (!ui || retrying || runRunning) return;
  if (typeof autoRefresh.retryFailedTickets !== 'function') {
    setText(ui.message, 'Retry is not available in this build: use Load all open tickets at the top of the page.');
    return;
  }
  const list = Array.isArray(numbers) ? numbers.map(cleanNumber).filter(Boolean) : undefined;
  const waiting = list ? list.length : fetchErrorCount(tracking());
  retrying = true;
  syncBusy();
  setText(ui.message, list && list.length === 1 ? `Retrying ${list[0]}…` : 'Retrying the tickets that could not be read…');
  try {
    const result = await autoRefresh.retryFailedTickets(list);
    setText(ui.message, retryResultText(result, waiting));
  } catch (err) {
    setText(ui.message, `The retry could not run: ${errorText(err)}`);
  } finally {
    retrying = false;
    syncBusy();
  }
}

function onLoadState(status) {
  runRunning = isObject(status) && status.running === true;
  syncBusy();
}

// ---- entry points ----

/** Build the view's skeleton inside #panelErrors and attach its listeners (once). */
export function wireFetchErrors() {
  syncFetchErrorsBadge();
  if (ui) return;
  const panel = typeof document !== 'undefined' && document.getElementById ? document.getElementById('panelErrors') : null;
  if (!panel || typeof panel.replaceChildren !== 'function') return;
  syncSection = createSectionSync();
  ui = buildSkeleton(panel);
  try {
    if (typeof autoRefresh.getAutoRefreshStatus === 'function') onLoadState(autoRefresh.getAutoRefreshStatus());
    if (!unsubscribe && typeof autoRefresh.onOpenLoadState === 'function') unsubscribe = autoRefresh.onOpenLoadState(onLoadState);
  } catch {
    // retry stays available; the run itself refuses to start twice
  }
}

/**
 * Update the Fetch errors view (dashboard.js paint, while this view is active).
 * @param {Date} now
 * @param {string} timeZone
 */
export function paintFetchErrors(now, timeZone) {
  wireFetchErrors();
  if (!ui) return;
  const t = tracking();
  const model = errorTableModel(t ? t.lastErrors : null);
  const isEmpty = model.rows.length === 0;
  const focusWasInBody = isEmpty && !ui.body.hidden && ui.body.contains(document.activeElement);
  ui.body.hidden = isEmpty;
  ui.empty.hidden = !isEmpty;
  if (focusWasInBody) ui.heading.focus({ preventScroll: true });
  if (isEmpty) {
    ui.headline.hidden = true;
    setText(ui.emptyTitle, emptyErrorsText(t, now, timeZone));
    return;
  }
  ui.headline.hidden = false;
  setText(ui.headline, errorsHeadline(model, now, timeZone));
  syncSection('links', ui.links, JSON.stringify([model.origin, model.numbers]), () => buildLinks(model), ui.retryAll);
  syncSection('table', ui.wrap, JSON.stringify(model), () => buildTable(model), ui.retryAll);
  syncBusy();
}
