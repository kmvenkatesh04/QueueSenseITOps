// Settings -> "Column to field mapping": pick, per dashboard column, which ServiceNow incident field it
// reads (lib/fieldMapping.js), from a dropdown of the fields found on a real incident form, and test the
// (unsaved) choice against any incident before saving. Both "Load fields" and "Test mapping" use the
// background's PROBE_INCIDENT, which reads the incident in a background tab and stores NOTHING; the
// test values are only shown on this page. The loaded field list (names, labels and yes/no flags - never
// a value) is also kept in chrome.storage.session under 'fieldInventory', so reloading the dashboard
// does not mean opening a ServiceNow tab again just to get the dropdowns back; the session area is
// cleared when the browser closes, and if it is not available the list simply lives in memory only.
import { MAPPABLE_COLUMNS, normalizeFieldMapping } from '../lib/fieldMapping.js';
import { normalizeIncidentNumber } from '../lib/analyze.js';
import { parseInstanceUrl } from '../lib/instance.js';
import { ensureOriginPermissionConfirmed } from './confirmHost.js';
import { create, errorText, isObject, str } from './dom.js';
import { STALE_WORKER_TEXT, replyError, sendRuntimeMessage } from './messaging.js';

const $ = (id) => document.getElementById(id);

/** chrome.storage.session key of the last loaded field inventory (see the header comment). */
export const INVENTORY_SESSION_KEY = 'fieldInventory';
const ACTION_BUTTON_IDS = ['setMapLoadBtn', 'setMapTestBtn', 'setMapSave'];
const TEST_STATUSES = new Set(['ok', 'empty', 'missing']);

let inventory = []; // [{ name, label, reference, readonly, hasValue }] from the last "Load fields"
let inventorySource = null; // { incident, loadedAt } of that inventory, or null when nothing is loaded
let lastPreview = null; // per-column test results of the last "Test mapping", keyed by column
let busy = false;
let paintedKey = null; // the saved mapping the dropdowns were last filled from
let deps = { current: () => ({}), save: async () => {} };

/**
 * Keep only what the dropdowns need from a probed field inventory: the name, the label and the three
 * yes/no flags. Anything else a reply (or a stale/hostile session entry) carries is dropped, so a
 * field VALUE can never reach chrome.storage.session through this list, whatever the background sends.
 * @param {*} raw
 * @returns {Array<{name:string, label:string, reference:boolean, readonly:boolean, hasValue:boolean}>}
 */
export function cleanInventory(raw) {
  if (!Array.isArray(raw)) return [];
  const seen = new Set();
  const out = [];
  for (const field of raw) {
    if (!isObject(field) || typeof field.name !== 'string' || !field.name || seen.has(field.name)) continue;
    seen.add(field.name);
    out.push({
      name: field.name,
      label: typeof field.label === 'string' ? field.label : '',
      reference: field.reference === true,
      readonly: field.readonly === true,
      hasValue: field.hasValue === true,
    });
  }
  return out;
}

/** chrome.storage.session when this page can use it, else null (older browser, tests, odd contexts). */
function sessionArea() {
  try {
    const area = globalThis.chrome && chrome.storage ? chrome.storage.session : null;
    return area && typeof area.get === 'function' && typeof area.set === 'function' ? area : null;
  } catch {
    return null;
  }
}

/**
 * Remember the loaded inventory for this browser session; best effort, never throws. A load that listed
 * no fields clears this page's list, so it also forgets the session copy: otherwise the next dashboard
 * reload would bring back an older list that this page had already replaced with "nothing loaded".
 */
async function rememberInventory() {
  const area = sessionArea();
  if (!area) return;
  try {
    if (inventorySource && inventory.length) {
      await area.set({ [INVENTORY_SESSION_KEY]: { ...inventorySource, fields: inventory } });
    } else if (typeof area.remove === 'function') {
      await area.remove(INVENTORY_SESSION_KEY);
    }
  } catch {
    // Remembering is a convenience: the list still works for as long as this page stays open.
  }
}

/**
 * Bring back the inventory a previous dashboard page of this browser session loaded, unless this page
 * has loaded one of its own in the meantime. Never throws; a missing or malformed entry is ignored.
 * @returns {Promise<boolean>} true when an inventory was restored
 */
export async function restoreFieldInventory() {
  const area = sessionArea();
  if (!area) return false;
  let snapshot = null;
  try {
    const stored = await area.get([INVENTORY_SESSION_KEY]);
    snapshot = isObject(stored) ? stored[INVENTORY_SESSION_KEY] : null;
  } catch {
    return false;
  }
  if (!isObject(snapshot) || inventory.length) return false;
  const fields = cleanInventory(snapshot.fields);
  if (!fields.length) return false;
  inventory = fields;
  inventorySource = {
    incident: normalizeIncidentNumber(str(snapshot.incident)) || '',
    loadedAt: Number.isFinite(snapshot.loadedAt) ? snapshot.loadedAt : 0,
  };
  const body = $('setMapRows');
  if (body && body.rows && body.rows.length) paintFieldMapping(null, { keepChoices: true });
  return true;
}

function formatLoadedAt(ms) {
  if (!Number.isFinite(ms) || ms <= 0) return '';
  try {
    return new Date(ms).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
  } catch {
    return '';
  }
}

/**
 * The line under "Load fields": how many fields the dropdowns offer, and from which incident and when
 * they were read, so a list brought back from the session after a reload is not mistaken for a fresh one.
 * @param {number} count
 * @param {{incident?:string, loadedAt?:number}|null} source
 */
export function fieldsInfoText(count, source) {
  if (!count) return 'No fields loaded yet: enter an incident number and click "Load fields" to list the fields on its form.';
  const from = isObject(source) && str(source.incident) ? ` from ${str(source.incident)}` : ' from the incident form';
  const when = isObject(source) ? formatLoadedAt(source.loadedAt) : '';
  return `${count} field${count === 1 ? '' : 's'} loaded${from}${when ? ` on ${when}` : ''}. Pick a field per column, or leave it on Automatic.`;
}

/**
 * The test outcome of one column: 'ok' (a value was read), 'empty' (the field is on the form but has no
 * value on this ticket) or 'missing' (the field is not on this incident's form at all) - '' when the
 * column was not tested. Uses the preview's own `status` when the background sends one, else derives it
 * the way older backgrounds' { mapped, found, value } replies mean it.
 * @param {*} hit one entry of PROBE_INCIDENT's result.preview
 * @returns {'ok'|'empty'|'missing'|''}
 */
export function columnTestStatus(hit) {
  if (!isObject(hit)) return '';
  if (TEST_STATUSES.has(hit.status)) return hit.status;
  if (hit.mapped && !hit.found) return 'missing';
  return str(hit.value) ? 'ok' : 'empty';
}

function setStatus(stateName, message) {
  const node = $('setMapStatus');
  if (!node) return;
  node.dataset.state = stateName;
  node.textContent = message;
}

/** The mapping as currently chosen in the dropdowns (may differ from the saved one). */
export function mappingFromForm() {
  const raw = {};
  for (const column of MAPPABLE_COLUMNS) {
    const select = $(`setMap_${column.key}`);
    if (select && select.value) raw[column.key] = select.value;
  }
  return normalizeFieldMapping(raw);
}

function optionLabel(field) {
  const label = str(field.label);
  const flags = [field.reference ? 'reference' : '', field.hasValue ? '' : 'empty on that ticket'].filter(Boolean);
  return `${label ? `${label} (${field.name})` : field.name}${flags.length ? ` — ${flags.join(', ')}` : ''}`;
}

function fillSelect(select, column, chosen) {
  const options = [create('option', '', `Automatic: ${column.auto}`)];
  options[0].value = '';
  const names = new Set();
  const sorted = [...inventory].sort((a, b) => (str(a.label) || a.name).localeCompare(str(b.label) || b.name));
  for (const field of sorted) {
    names.add(field.name);
    const option = create('option', '', optionLabel(field));
    option.value = field.name;
    options.push(option);
  }
  // A saved field that the loaded list does not have (or nothing loaded yet) stays selectable.
  if (chosen && !names.has(chosen)) {
    const option = create('option', '', `${chosen} (saved)`);
    option.value = chosen;
    options.push(option);
  }
  select.replaceChildren(...options);
  select.value = chosen || '';
}

function testCell(column) {
  const td = create('td', 'settings-map-value');
  const hit = lastPreview && lastPreview.get(column.key);
  const status = columnTestStatus(hit);
  if (!status) {
    td.append(create('span', 'muted', '—'));
    return td;
  }
  td.dataset.testStatus = status;
  const field = str(hit.field);
  if (status === 'missing') {
    td.append(create('span', 'settings-map-missing', hit.mapped
      ? `Not on the form: field "${field}" is not on this incident's form`
      : `Not on the form: no automatic field found on this incident's form (${field})`));
    return td;
  }
  // 'empty' is not an error: the field exists, this one ticket simply has nothing in it. The column may
  // still show something (the User column falls back to the caller), which is then said as well.
  const value = str(hit.value);
  td.append(status === 'ok'
    ? create('span', 'settings-map-ok', value)
    : create('span', 'muted settings-map-empty', 'Empty on this ticket'));
  td.append(create('span', 'cell-note settings-map-from', ` from ${field}`));
  if (status === 'empty' && value) td.append(create('span', 'cell-note', ` (the column shows: ${value})`));
  return td;
}

/** Draw the table from the saved mapping (or keep the dropdowns' current choices with keepChoices). */
export function paintFieldMapping(saved, { keepChoices = false } = {}) {
  const body = $('setMapRows');
  if (!body) return;
  // The dashboard repaints Settings every minute and on every storage change: only refill the dropdowns
  // when the SAVED mapping changed, so choices that are being made (and not saved yet) are never reset.
  if (!keepChoices) {
    const key = JSON.stringify(normalizeFieldMapping(saved));
    if (key === paintedKey && body.rows.length) return;
    paintedKey = key;
  }
  const current = keepChoices ? mappingFromForm() : normalizeFieldMapping(saved);
  body.replaceChildren(...MAPPABLE_COLUMNS.map((column) => {
    const tr = create('tr');
    tr.dataset.column = column.key;
    const th = create('th', '', column.label);
    th.scope = 'row';
    const select = create('select', 'settings-map-select');
    select.id = `setMap_${column.key}`;
    select.setAttribute('aria-label', `ServiceNow field for the ${column.label} column`);
    fillSelect(select, column, current[column.key] || '');
    const tdSelect = create('td');
    tdSelect.append(select);
    tr.append(th, tdSelect, testCell(column));
    return tr;
  }));
  const info = $('setMapFieldsInfo');
  if (info) info.textContent = fieldsInfoText(inventory.length, inventorySource);
}

/** The ServiceNow address to use: the search box (synchronous, keeps the click's user gesture), else stored. */
async function instanceOrigin() {
  const typed = str(($('searchInstanceUrl') || {}).value);
  let parsed = typed ? parseInstanceUrl(typed) : { ok: false };
  if (!parsed.ok) {
    try {
      const stored = await chrome.storage.local.get(['instanceUrl']);
      parsed = parseInstanceUrl(str(stored.instanceUrl));
    } catch {
      parsed = { ok: false };
    }
  }
  return parsed.ok ? parsed.origin : '';
}

async function probe(inputId, fieldMapping) {
  const input = $(inputId);
  const number = normalizeIncidentNumber(str(input && input.value));
  if (!number) {
    setStatus('error', 'Enter an incident number like INC0012345 first.');
    if (input) input.focus();
    return null;
  }
  const origin = await instanceOrigin();
  if (!origin) {
    setStatus('error', 'No ServiceNow address is known yet: enter it in the search box at the top (or search for a ticket) first.');
    return null;
  }
  const permission = await ensureOriginPermissionConfirmed(origin);
  if (!permission.ok) {
    setStatus('error', permission.message);
    return null;
  }
  if (input) input.value = number;
  setStatus('loading', `Reading ${number} from ServiceNow ... a background tab opens for a moment.`);
  const message = { type: 'PROBE_INCIDENT', instanceUrl: permission.origin, incidentNumber: number };
  if (fieldMapping) message.fieldMapping = fieldMapping;
  const { reply, failure } = await sendRuntimeMessage(message);
  if (failure) {
    setStatus('error', failure);
    return null;
  }
  if (reply === undefined) {
    setStatus('error', STALE_WORKER_TEXT);
    return null;
  }
  if (!isObject(reply) || !reply.ok) {
    setStatus('error', replyError(reply, 'The incident could not be read.'));
    return null;
  }
  return { number, result: isObject(reply.result) ? reply.result : {} };
}

function activeElement() {
  try {
    return typeof document !== 'undefined' && document ? document.activeElement || null : null;
  } catch {
    return null;
  }
}

/**
 * Put keyboard focus back on the element that had it before run() disabled the buttons. Disabling the
 * focused button drops focus to <body>, so a keyboard user would otherwise have to tab in from the top
 * of the page after every Load / Test / Save. Focus is only restored when it is still lost (on <body>,
 * nowhere, or on that same element): a field the task focused on purpose (the incident box after a
 * bad number) or wherever the user moved meanwhile keeps it. Never throws.
 */
function restoreFocus(before) {
  try {
    if (!before || typeof before.focus !== 'function' || before === document.body) return;
    if (before.isConnected === false || before.disabled) return;
    const now = activeElement();
    if (now && now !== document.body && now !== before) return;
    before.focus({ preventScroll: true });
  } catch {
    // Focus is a convenience: never let it turn a finished task into an error.
  }
}

async function run(task) {
  if (busy) return;
  busy = true;
  const before = activeElement(); // read BEFORE disabling, which is what moves focus away
  for (const id of ACTION_BUTTON_IDS) if ($(id)) $(id).disabled = true;
  try {
    await task();
  } catch (err) {
    setStatus('error', `Something went wrong: ${errorText(err)}`);
  } finally {
    busy = false;
    for (const id of ACTION_BUTTON_IDS) if ($(id)) $(id).disabled = false;
    restoreFocus(before);
  }
}

function onLoad() {
  return run(async () => {
    const got = await probe('setMapLoadIncident', mappingFromForm());
    if (!got) return;
    inventory = cleanInventory(got.result.inventory);
    inventorySource = inventory.length ? { incident: got.number, loadedAt: Date.now() } : null;
    await rememberInventory();
    paintFieldMapping(null, { keepChoices: true });
    const testInput = $('setMapTestIncident');
    if (testInput && !testInput.value) testInput.value = got.number;
    setStatus(inventory.length ? 'ok' : 'warn', inventory.length
      ? `Loaded ${inventory.length} fields from ${got.number}.`
      : `${got.number} was read, but ServiceNow listed no fields on its form.`);
  });
}

function onTest() {
  return run(async () => {
    const mapping = mappingFromForm();
    const got = await probe('setMapTestIncident', mapping);
    if (!got) return;
    const preview = Array.isArray(got.result.preview) ? got.result.preview.filter(isObject) : [];
    lastPreview = new Map(preview.map((p) => [p.key, p]));
    paintFieldMapping(null, { keepChoices: true });
    setStatus(...testSummary(got.number, preview));
  });
}

/**
 * The status line after "Test mapping": a field that is not on the form at all is a warning (the mapping
 * points at nothing), a field that is merely empty on this one ticket is only mentioned, since another
 * ticket may well have a value there.
 * @returns {[string, string]} [state, message]
 */
export function testSummary(number, preview) {
  const list = Array.isArray(preview) ? preview.filter(isObject) : [];
  const labelOf = (p) => str(p.label) || str(p.key);
  const missing = list.filter((p) => columnTestStatus(p) === 'missing').map(labelOf);
  const empty = list.filter((p) => columnTestStatus(p) === 'empty').map(labelOf);
  const emptyNote = empty.length ? `; on the form but empty on this ticket: ${empty.join(', ')}` : '';
  if (missing.length) {
    return ['warn', `Tested on ${number}: these fields are not on its form: ${missing.join(', ')}${emptyNote}. Not saved yet.`];
  }
  return ['ok', `Tested on ${number}: each column shows the value it would display${emptyNote}. Not saved yet - click "Save mapping" to use it.`];
}

function onSave() {
  return run(async () => {
    const mapping = mappingFromForm();
    await deps.save(mapping);
    const count = Object.keys(mapping).length;
    setStatus('ok', count
      ? `Mapping saved (${count} column${count === 1 ? '' : 's'} mapped). Refresh tickets to read them with it.`
      : 'Mapping saved: every column is on Automatic.');
  });
}

function onAllAutomatic() {
  for (const column of MAPPABLE_COLUMNS) {
    const select = $(`setMap_${column.key}`);
    if (select) select.value = '';
  }
  setStatus('info', 'Every column set to Automatic. Click "Save mapping" to keep it.');
}

/**
 * Attach the section's listeners. `options.save(mapping)` persists a new mapping (dashboard/settings.js
 * owns the settings object and its storage).
 */
export function wireFieldMapping(options) {
  deps = { ...deps, ...(options || {}) };
  if ($('setMapLoadBtn')) $('setMapLoadBtn').addEventListener('click', () => void onLoad());
  if ($('setMapTestBtn')) $('setMapTestBtn').addEventListener('click', () => void onTest());
  if ($('setMapSave')) $('setMapSave').addEventListener('click', () => void onSave());
  if ($('setMapReset')) $('setMapReset').addEventListener('click', onAllAutomatic);
  void restoreFieldInventory();
}
