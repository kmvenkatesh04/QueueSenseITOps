// The guided follow-up message: a short yes/no question flow that composes the right message from the
// built-in generic email templates (lib/messageTemplates.js decides every sentence; this file is only the
// interface). Questions appear one at a time, each answer decides the next question, answered questions
// collapse into a one-line summary with a Change button, and a live preview shows the message that will
// be sent, with the parts that are still unanswered marked.
//
// Mount it in any element (the dashboard mounts it inside the composer row):
//   const guide = mountFollowUpGuide(host, { ctx, onChange({ answers, step, message }) {}, onUse(text) {} });
// The page must load dashboard/guide.css (this module links it itself when the page has not).
//
// Everything that reaches the page is written with createElement / textContent / setAttribute: the
// ticket text and the agent's input are never parsed as HTML. The module keeps no state between
// mounts, so several guides can live in one page. destroy() removes every listener and node.
import {
  CONTEXTS, MAX_TEAMS_CHARS, MODES, QUESTION_IDS, buildMessage, defaultAnswers, nextStep,
  setAnswer, validateAnswers,
} from '../lib/messageTemplates.js';

const DEBOUNCE_MS = 80; // typing updates the preview after this much quiet
const RESET_CONFIRM_MS = 4000;
const HEADER_IDS = ['context', 'mode']; // shown above the questions, never part of the progressive flow
const TEXT_KINDS = new Set(['text', 'textarea', 'url', 'ticket']);
const YES_NO = Object.freeze([{ value: 'yes', label: 'Yes' }, { value: 'no', label: 'No' }]);
// Follow-up questions that only exist while their parent answer is Yes (contract 12.2).
const DEPENDENTS = Object.freeze({
  education: ['educationSteps', 'ticketLink'],
  altTicket: ['altTicketNumber'],
  needInfo: ['infoRequired'],
});
const PARENT_OF = Object.freeze(Object.fromEntries(
  Object.entries(DEPENDENTS).flatMap(([parent, kids]) => kids.map((kid) => [kid, parent])),
));
const PLACEHOLDER = /\[[^[\]\n]{1,80}\]/g;
const STANDARD_TEMPLATE_ID = /^[A-F](\+[A-F])*$/;
const STYLE_WAIT_MS = 1500; // reveal the guide anyway when guide.css neither loads nor fails

const TEXT = {
  situation: 'Situation',
  mode: 'How you tried to reach the user',
  modeUnknown: 'Not known (keeps "Call/Chat/Email" in the text)',
  detected: 'Detected from the ticket',
  changed: 'Changed by you',
  useDetected: 'Use detected',
  change: 'Change',
  next: 'Up next',
  optional: 'Optional',
  optionalSuffix: '(optional detail)',
  continue: 'Continue',
  skip: 'Skip',
  enterHint: 'or press Enter',
  enterMultiHint: 'or press Ctrl+Enter',
  yesNoHint: 'Tip: press Y or N.',
  allAnswered: 'All questions answered',
  needsAttention: 'One more thing is needed',
  preview: 'Live preview',
  legend: 'Highlighted [brackets] mark parts that are not answered yet.',
  templateUsed: 'Template used: ',
  templateNone: 'Template used: not decided yet',
  composed: 'Contains wording that is not in the standard templates: ',
  edited: 'Edited manually: the message no longer follows these answers.',
  use: 'Use this message',
  useHint: 'Answer the questions to use the message.',
  stillMissing: 'Still missing: ',
  regenerate: 'Regenerate',
  reset: 'Start over',
  resetConfirm: 'Click again to clear all answers',
  ready: 'All questions answered. The message is ready to use.',
  omitted: 'Left out',
  omittedLink: 'No link: that paragraph is left out',
};

let mountCounter = 0;
const mounted = new WeakMap(); // host element -> controller, so mounting twice replaces the first guide

// ---- small DOM helpers ----

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function withAttrs(node, attrs) {
  for (const [name, value] of Object.entries(attrs)) node.setAttribute(name, value);
  return node;
}

function button(label, className, role) {
  const node = el('button', className, label);
  node.type = 'button';
  node.dataset.role = role;
  return node;
}

/** Assign text only when it changed, so live regions announce real changes only. */
function setText(node, text) {
  if (node.textContent !== text) node.textContent = text;
}

function setHidden(node, hidden) {
  if (node.hidden !== hidden) node.hidden = hidden;
}

function setAttr(node, name, value) {
  if (value === null || value === false) node.removeAttribute(name);
  else if (node.getAttribute(name) !== String(value)) node.setAttribute(name, String(value));
}

const isObject = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
const flat = (value) => String(value ?? '').replace(/\s+/g, ' ').trim();

// ---- stylesheet ----

/** Links guide.css when the page did not; the guide stays hidden until it is applied (no flash). */
function ensureStylesheet(g) {
  const href = new URL('./guide.css', import.meta.url).href;
  let link = [...document.querySelectorAll('link[rel~="stylesheet"]')]
    .find((item) => item.href === href || /(^|\/)guide\.css(\?|$)/.test(item.getAttribute('href') || ''));
  if (!link) {
    link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = href;
    link.dataset.guideStyles = '';
    document.head.append(link);
  }
  if (link.sheet) return;
  g.root.hidden = true;
  const reveal = () => {
    clearTimeout(g.revealTimer);
    if (g.destroyed || !g.root.hidden) return;
    g.root.hidden = false;
    if (g.focusPending) focusActive(g);
  };
  link.addEventListener('load', reveal, { once: true });
  link.addEventListener('error', reveal, { once: true });
  g.revealTimer = setTimeout(reveal, STYLE_WAIT_MS);
}

// ---- state ----

const FOLLOWS = ['context', 'mode', 'issue']; // answers that follow the ticket until the agent changes them

/**
 * The answers of a guide rebuilt from getSnapshot(): every answer comes back as it was, except the
 * situation, contact mode and issue the agent never touched, which follow the ticket as it is NOW (the
 * business-hours status may have changed while the guide was away). Pure: no DOM, no clock.
 * @param {object} ctx current ticket context
 * @param {object} snapshot from the controller's getSnapshot()
 * @returns {object} answers (lib/messageTemplates.js shape)
 */
export function restoreAnswers(ctx, snapshot) {
  const detected = defaultAnswers(isObject(ctx) ? ctx : {});
  const saved = isObject(snapshot) && isObject(snapshot.answers) ? snapshot.answers : {};
  const was = isObject(snapshot) && isObject(snapshot.detected) ? snapshot.detected : {};
  let answers = detected;
  for (const id of QUESTION_IDS) {
    if (typeof saved[id] !== 'string') continue;
    if (FOLLOWS.includes(id) && typeof was[id] === 'string' && saved[id] === was[id]) continue;
    answers = setAnswer(answers, id, saved[id]);
  }
  return answers;
}

function createState(host, options) {
  const ctx = isObject(options.ctx) ? options.ctx : {};
  const detected = defaultAnswers(ctx);
  const snapshot = isObject(options.snapshot) ? options.snapshot : null;
  const provided = snapshot && isObject(snapshot.answers)
    ? snapshot.answers
    : (isObject(options.initialAnswers) ? options.initialAnswers : {});
  let answers = detected;
  if (snapshot) {
    answers = restoreAnswers(ctx, snapshot);
  } else {
    for (const id of QUESTION_IDS) {
      if (typeof provided[id] === 'string') answers = setAnswer(answers, id, provided[id]);
    }
  }
  const ids = (list) => new Set((Array.isArray(list) ? list : []).filter((id) => QUESTION_IDS.includes(id)));
  return {
    uid: ++mountCounter,
    host,
    options,
    ctx,
    detected,
    answers,
    firstStep: nextStep(answers, ctx),
    snapshot,
    provided: new Set(Object.keys(provided)),
    confirmed: snapshot ? ids(snapshot.confirmed) : new Set(), // text questions the agent has moved on from (Continue / Enter)
    touched: snapshot ? ids(snapshot.touched) : new Set(), // text questions whose errors may be shown
    labels: new Map(), // question id -> label, for the "removed answers" notice
    cards: new Map(),
    editingId: snapshot && QUESTION_IDS.includes(snapshot.editingId) ? snapshot.editingId : '',
    flow: [],
    step: null,
    message: null,
    edited: false,
    timer: 0,
    resetTimer: 0,
    revealTimer: 0,
    resetPending: false,
    lastPreview: null,
    announcedReady: false,
    focusPending: false,
    notice: '',
    listeners: [],
    ready: false, // false until the first render: nothing animates on mount
    destroyed: false,
    root: null,
    refs: {},
    controller: null,
  };
}

const limitOf = (g) => {
  const given = Number(g.options.maxChars);
  if (Number.isFinite(given) && given > 0) return given;
  return g.ctx.channel === 'teams' ? MAX_TEAMS_CHARS : 0;
};

const shownText = (message) => (message.ok ? message.text : (message.previewText || ''));

function isSettled(g, q) {
  const value = g.answers[q.id];
  if (q.kind === 'yesno') return value === 'yes' || value === 'no';
  return g.confirmed.has(q.id) && !g.step.errors[q.id];
}

/**
 * The questions to draw, with the state of each: every question up to and including the first one
 * that is not settled, then the answered questions that come after it (see keepAnsweredLater). Text
 * questions only count as settled once the agent moved on from them, so the next question does not
 * jump in while they are still typing.
 */
function buildFlow(g) {
  const base = g.step.visible.filter((q) => !HEADER_IDS.includes(q.id));
  const questions = [];
  let openId = '';
  for (const q of base) {
    questions.push(q);
    if (!isSettled(g, q)) {
      openId = q.id;
      break;
    }
  }
  if (g.editingId && !questions.some((q) => q.id === g.editingId)) g.editingId = '';
  keepAnsweredLater(g, questions);
  const activeId = g.editingId || openId;
  return questions.map((q) => {
    const state = q.id === activeId ? 'active' : (isSettled(g, q) ? 'done' : 'pending');
    return { q, state };
  });
}

/**
 * The engine lists questions only up to the first one that needs an answer. When an earlier answer is
 * changed (a new follow-up question appears, or a text answer is emptied while it is retyped), the
 * questions the agent already answered after it would vanish and come back later. They stay, collapsed,
 * as long as their answers are still valid and their parent answer is still Yes.
 */
function keepAnsweredLater(g, questions) {
  if (!g.cards.size || !questions.length) return;
  const errors = validateAnswers(g.answers, g.ctx).errors || {};
  const have = new Set(questions.map((q) => q.id));
  const from = QUESTION_IDS.indexOf(questions[questions.length - 1].id);
  for (const id of QUESTION_IDS.slice(from + 1)) {
    const card = g.cards.get(id);
    if (!card || have.has(id)) continue;
    if (PARENT_OF[id] && g.answers[PARENT_OF[id]] !== 'yes') continue;
    const settled = card.q.kind === 'yesno'
      ? (g.answers[id] === 'yes' || g.answers[id] === 'no')
      : (g.confirmed.has(id) && !errors[id]);
    if (settled) questions.push(card.q);
  }
}

// ---- the shell ----

/** The context / mode question as the engine describes it, with local fallbacks. */
function setupQuestion(g, id, fallback) {
  const found = g.firstStep.visible.find((q) => q.id === id) || {};
  return {
    label: found.label || fallback.label,
    help: found.help || '',
    options: Array.isArray(found.options) && found.options.length ? found.options : fallback.options,
  };
}

function fieldSelect(g, id, setup) {
  const field = el('div', 'guide-field');
  field.dataset.q = id;
  const select = el('select', 'guide-select');
  select.id = `guide-${g.uid}-${id}`;
  select.dataset.role = 'answer';
  for (const item of setup.options) {
    const option = el('option', '', item.label);
    option.value = item.value;
    select.append(option);
  }
  const label = el('label', 'guide-field-label', setup.label);
  label.htmlFor = select.id;
  const help = el('p', 'guide-field-help');
  help.id = `${select.id}-help`;
  select.setAttribute('aria-describedby', help.id);
  field.append(label, select, help);
  return { field, select, help };
}

function buildSetup(g) {
  const context = fieldSelect(g, 'context', setupQuestion(g, 'context', {
    label: TEXT.situation, options: CONTEXTS.map((c) => ({ value: c.id, label: c.label })),
  }));
  const modeSetup = setupQuestion(g, 'mode', {
    label: TEXT.mode, options: [{ value: '', label: TEXT.modeUnknown }, ...MODES.map((m) => ({ value: m, label: m }))],
  });
  const mode = fieldSelect(g, 'mode', modeSetup);
  mode.help.textContent = modeSetup.help;
  const detected = el('span', 'guide-detected');
  detected.dataset.role = 'detected';
  const useDetected = button(TEXT.useDetected, 'guide-link', 'useDetected');
  const foot = el('div', 'guide-setup-foot');
  foot.append(detected, useDetected);
  const setup = el('div', 'guide-setup');
  setup.setAttribute('role', 'group');
  setup.setAttribute('aria-label', `${TEXT.situation} and contact mode`);
  setup.append(context.field, mode.field, foot);
  Object.assign(g.refs, { context: context.select, mode: mode.select, contextHelp: context.help, detected, useDetected });
  return setup;
}

function buildProgress(g) {
  const text = el('p', 'guide-progress');
  text.dataset.role = 'progress';
  const bar = el('progress', 'guide-bar');
  bar.max = 1;
  bar.value = 0;
  bar.setAttribute('aria-label', 'Questions answered');
  const row = el('div', 'guide-progress-row');
  row.append(text, bar);
  Object.assign(g.refs, { progress: text, bar });
  return row;
}

function buildFlowColumn(g) {
  const list = el('ol', 'guide-list');
  list.dataset.role = 'questions';
  const formError = el('p', 'guide-formerror');
  formError.dataset.role = 'error';
  formError.dataset.errorFor = '_form';
  formError.tabIndex = -1;
  formError.setAttribute('aria-live', 'polite');
  formError.hidden = true;
  const note = el('p', 'guide-note');
  note.dataset.role = 'note';
  note.setAttribute('aria-live', 'polite');
  Object.assign(g.refs, { list, formError, note });
  const column = el('div', 'guide-flow');
  column.append(buildSetup(g), buildProgress(g), list, formError, note);
  return column;
}

function buildPreview(g) {
  const title = el('p', 'guide-preview-title', TEXT.preview);
  title.id = `guide-${g.uid}-preview-title`;
  const legend = el('p', 'guide-legend', TEXT.legend);
  const head = el('div', 'guide-preview-head');
  head.append(title, legend);
  const preview = el('div', 'guide-preview');
  preview.dataset.role = 'preview';
  preview.tabIndex = 0;
  withAttrs(preview, { role: 'region', 'aria-labelledby': title.id });
  g.refs.preview = preview;
  return [head, preview];
}

function buildMeta(g) {
  const count = el('span', 'guide-count');
  count.dataset.role = 'count';
  const limit = el('span', 'guide-limit');
  limit.dataset.role = 'limitWarning';
  limit.setAttribute('aria-live', 'polite');
  const meta = el('div', 'guide-meta');
  meta.append(count, limit);
  Object.assign(g.refs, { count, limit });
  return meta;
}

function buildAsides(g) {
  const composed = el('div', 'guide-aside');
  composed.dataset.role = 'composed';
  composed.hidden = true;
  const warnings = el('div', 'guide-aside');
  warnings.dataset.role = 'warnings';
  warnings.dataset.tone = 'warn';
  warnings.hidden = true;
  const edited = el('p', 'guide-aside', TEXT.edited);
  edited.dataset.role = 'editedNote';
  edited.hidden = true;
  Object.assign(g.refs, { composed, warnings, editedNote: edited });
  return [composed, warnings, edited];
}

function buildActions(g) {
  const use = button(TEXT.use, 'guide-btn guide-btn-primary', 'use');
  const regenerate = button(TEXT.regenerate, 'guide-btn guide-btn-secondary', 'regenerate');
  regenerate.hidden = true;
  const reset = button(TEXT.reset, 'guide-btn guide-btn-quiet', 'reset');
  const hint = el('p', 'guide-use-hint');
  hint.id = `guide-${g.uid}-use-hint`;
  hint.dataset.role = 'useHint';
  use.setAttribute('aria-describedby', hint.id);
  const actions = el('div', 'guide-actions');
  actions.append(use, regenerate, reset, hint);
  Object.assign(g.refs, { use, regenerate, reset, useHint: hint });
  return actions;
}

function buildResultColumn(g) {
  const name = el('span', 'guide-badge');
  name.dataset.role = 'templateName';
  const id = el('span', 'guide-template-id');
  id.dataset.role = 'templateId';
  const template = el('div', 'guide-template');
  template.append(name, id);
  Object.assign(g.refs, { templateName: name, templateId: id });
  const column = el('div', 'guide-result');
  column.append(template, ...buildPreview(g), buildMeta(g), ...buildAsides(g), buildActions(g));
  return column;
}

function buildShell(g) {
  const root = el('section', 'guide-root');
  root.dataset.guide = '';
  root.dataset.guideId = String(g.uid);
  root.setAttribute('aria-label', 'Guided follow-up message');
  const layout = el('div', 'guide-layout');
  layout.append(buildFlowColumn(g), buildResultColumn(g));
  const announce = el('p', 'guide-sr');
  announce.dataset.role = 'announce';
  announce.setAttribute('aria-live', 'polite');
  g.refs.announce = announce;
  root.append(layout, announce);
  g.root = root;
}

// ---- one question card ----

function buildChoice(g, q, prefix) {
  const group = el('div', 'guide-seg-group');
  withAttrs(group, {
    role: 'radiogroup',
    'aria-labelledby': `${prefix}-label`,
    'aria-describedby': `${prefix}-help ${prefix}-error`,
  });
  const radios = [];
  for (const option of q.options || YES_NO) {
    const seg = el('span', 'guide-seg');
    const input = el('input', 'guide-seg-input');
    input.type = 'radio';
    input.name = `${prefix}-choice`;
    input.id = `${prefix}-${option.value}`;
    input.value = option.value;
    input.dataset.role = 'answer';
    const label = el('label', 'guide-seg-label', option.label);
    label.htmlFor = input.id;
    seg.append(input, label);
    group.append(seg);
    radios.push(input);
  }
  return { control: group, radios, input: null };
}

function buildTextControl(q, kind, prefix) {
  const input = el(kind === 'textarea' ? 'textarea' : 'input', 'guide-input');
  input.id = `${prefix}-input`;
  input.dataset.role = 'answer';
  input.placeholder = q.placeholder || '';
  withAttrs(input, { autocomplete: 'off', 'aria-describedby': `${prefix}-help ${prefix}-error` });
  if (kind === 'textarea') input.rows = 4;
  else input.type = kind === 'url' ? 'url' : 'text';
  if (kind === 'url') withAttrs(input, { inputmode: 'url', spellcheck: 'false', autocapitalize: 'off' });
  if (kind === 'ticket') withAttrs(input, { spellcheck: 'false', autocapitalize: 'characters' });
  if (q.required) input.setAttribute('aria-required', 'true');
  return { control: input, radios: null, input };
}

function buildCard(g, q) {
  const prefix = `guide-${g.uid}-${q.id}`;
  const kind = q.kind === 'yesno' ? 'yesno' : (TEXT_KINDS.has(q.kind) ? q.kind : 'text');
  const parts = kind === 'yesno' ? buildChoice(g, q, prefix) : buildTextControl(q, kind, prefix);
  const node = el('li', g.ready ? 'guide-q is-entering' : 'guide-q');
  node.dataset.q = q.id;
  node.dataset.kind = kind;
  if (q.group) node.dataset.group = q.group;
  if (PARENT_OF[q.id]) node.dataset.sub = 'true';
  node.addEventListener('animationend', () => node.classList.remove('is-entering'), { once: true });

  const mark = el('span', 'guide-q-mark');
  mark.setAttribute('aria-hidden', 'true');
  const label = el(kind === 'yesno' ? 'span' : 'label', 'guide-q-label', q.label);
  label.id = `${prefix}-label`;
  if (parts.input) label.htmlFor = parts.input.id;
  const tag = el('span', 'guide-q-tag');
  const summary = el('span', 'guide-q-summary');
  summary.dataset.role = 'summary';
  const text = el('span', 'guide-q-text');
  text.append(label, tag, summary);
  const change = button(TEXT.change, 'guide-link', 'change');
  change.setAttribute('aria-label', `${TEXT.change}: ${q.label}`);
  const head = el('div', 'guide-q-head');
  head.append(mark, text, change);

  const help = el('p', 'guide-q-help', [q.help, kind === 'yesno' ? TEXT.yesNoHint : ''].filter(Boolean).join(' '));
  help.id = `${prefix}-help`;
  const error = el('p', 'guide-q-error');
  error.id = `${prefix}-error`;
  error.dataset.role = 'error';
  error.setAttribute('aria-live', 'polite');
  const body = el('div', 'guide-q-body');
  body.append(help, parts.control, error);
  let cont = null;
  if (kind !== 'yesno') {
    cont = button(TEXT.continue, 'guide-btn guide-btn-primary', 'continue');
    const hint = el('span', 'guide-kbd-hint', kind === 'textarea' ? TEXT.enterMultiHint : TEXT.enterHint);
    const actions = el('div', 'guide-q-actions');
    actions.append(cont, hint);
    body.append(actions);
  }
  node.append(head, body);
  return { q, node, mark, label, tag, summary, change, body, error, cont, radios: parts.radios, input: parts.input };
}

function summaryOf(g, q) {
  const value = g.answers[q.id] ?? '';
  if (q.kind === 'yesno') {
    const option = (q.options || YES_NO).find((item) => item.value === value);
    return option ? option.label : value;
  }
  return flat(value) || (q.id === 'ticketLink' ? TEXT.omittedLink : TEXT.omitted);
}

const shownError = (g, q) => (TEXT_KINDS.has(q.kind) && g.touched.has(q.id) ? (g.step.errors[q.id] || '') : '');

/** Required questions are numbered 1, 2, 3 ...; an optional one shares the number before it. */
function ordinals(flow) {
  let count = 0;
  return flow.map((entry) => {
    if (entry.q.required) count += 1;
    return { n: count, optional: !entry.q.required };
  });
}

function syncCard(g, card, entry, ordinal) {
  const { q, state } = entry;
  const value = g.answers[q.id] ?? '';
  card.q = q;
  g.labels.set(q.id, q.label);
  card.node.dataset.state = state;
  setAttr(card.node, 'aria-current', state === 'active' ? 'step' : null);
  setText(card.mark, state === 'done' ? '✓' : (ordinal.optional ? '+' : String(ordinal.n)));
  setText(card.tag, state === 'pending' ? TEXT.next : (state === 'active' && !q.required ? TEXT.optional : ''));
  setText(card.summary, state === 'done' ? summaryOf(g, q) : '');
  setAttr(card.summary, 'title', state === 'done' ? String(value) : null);
  setHidden(card.summary, state !== 'done');
  setHidden(card.change, state !== 'done');
  setHidden(card.body, state !== 'active');
  if (card.radios) {
    for (const radio of card.radios) {
      const on = radio.value === value;
      if (radio.checked !== on) radio.checked = on;
    }
    return;
  }
  if (card.input.value !== value) card.input.value = value;
  const error = shownError(g, q);
  setText(card.error, error);
  setAttr(card.input, 'aria-invalid', error ? 'true' : null);
  setText(card.cont, !q.required && !flat(value) ? TEXT.skip : TEXT.continue);
}

function syncCards(g) {
  const keep = new Set();
  const numbers = ordinals(g.flow);
  g.flow.forEach((entry, index) => {
    let card = g.cards.get(entry.q.id);
    if (!card) {
      card = buildCard(g, entry.q);
      g.cards.set(entry.q.id, card);
    }
    keep.add(entry.q.id);
    if (g.refs.list.children[index] !== card.node) g.refs.list.insertBefore(card.node, g.refs.list.children[index] || null);
    syncCard(g, card, entry, numbers[index]);
  });
  for (const [id, card] of g.cards) {
    if (keep.has(id)) continue;
    card.node.remove();
    g.cards.delete(id);
  }
}

// ---- the rest of the screen ----

function syncSetup(g) {
  const { context, mode } = g.refs;
  if (context.value !== g.answers.context) context.value = g.answers.context;
  if (mode.value !== g.answers.mode) mode.value = g.answers.mode;
  const info = CONTEXTS.find((item) => item.id === g.answers.context);
  setText(g.refs.contextHelp, info ? info.help : '');
  const changed = g.answers.context !== g.detected.context || g.answers.mode !== g.detected.mode;
  setText(g.refs.detected, changed ? TEXT.changed : TEXT.detected);
  g.refs.detected.dataset.changed = String(changed);
  setHidden(g.refs.useDetected, !changed);
}

function syncProgress(g) {
  const numbers = ordinals(g.flow);
  const active = g.flow.findIndex((entry) => entry.state === 'active');
  const total = Math.max((g.step.progress && g.step.progress.total) || 0, numbers.length ? numbers[numbers.length - 1].n : 0, 1);
  let text = g.step.done ? TEXT.allAnswered : TEXT.needsAttention;
  if (active !== -1) {
    const { n, optional } = numbers[active];
    text = `Question ${Math.max(n, 1)} of ${total}${optional ? ` ${TEXT.optionalSuffix}` : ''}`;
  }
  setText(g.refs.progress, text);
  g.refs.bar.max = total;
  g.refs.bar.value = Math.min(g.flow.filter((entry) => entry.state === 'done' && entry.q.required).length, total);
}

function syncFormError(g) {
  const open = g.flow.some((entry) => entry.state !== 'done');
  const message = open ? '' : (g.step.errors._form || '');
  setText(g.refs.formError, message);
  setHidden(g.refs.formError, !message);
}

function userStrings(g) {
  const { answers, ctx } = g;
  return [answers.issue, answers.educationSteps, answers.ticketLink, answers.altTicketNumber, answers.infoRequired,
    ctx.userName, ctx.shortDescription, ctx.incidentNumber]
    .filter((value) => typeof value === 'string' && value);
}

/** Text with each unanswered [placeholder] in a <mark>; text typed by the agent is never marked. */
function renderPreview(g, text) {
  const own = userStrings(g);
  const nodes = [];
  let last = 0;
  for (const match of text.matchAll(PLACEHOLDER)) {
    if (own.some((value) => value.includes(match[0]))) continue;
    if (match.index > last) nodes.push(document.createTextNode(text.slice(last, match.index)));
    nodes.push(el('mark', 'guide-ph', match[0]));
    last = match.index + match[0].length;
  }
  if (last < text.length) nodes.push(document.createTextNode(text.slice(last)));
  g.refs.preview.replaceChildren(...nodes);
}

/** 'A' -> 'Template A'; a mix of templates ('B+C') says so; wording made for the situation says 'Composed'. */
function templateBadge(templateId) {
  if (!STANDARD_TEMPLATE_ID.test(templateId)) return 'Composed';
  return templateId.includes('+') ? `Templates ${templateId.replace(/\+/g, ' + ')} combined` : `Template ${templateId}`;
}

function syncPreview(g) {
  const text = shownText(g.message);
  if (text !== g.lastPreview) {
    renderPreview(g, text);
    g.lastPreview = text;
  }
  g.refs.preview.dataset.complete = String(Boolean(g.message.ok));
  const { templateId, templateLabel } = g.message;
  setText(g.refs.templateName, templateLabel ? `${TEXT.templateUsed}${templateLabel}` : TEXT.templateNone);
  g.refs.templateName.dataset.decided = String(Boolean(templateLabel));
  if (templateLabel && templateId) {
    setText(g.refs.templateId, templateBadge(templateId));
    g.refs.templateId.title = templateId;
  }
  setHidden(g.refs.templateId, !(templateLabel && templateId));
}

function describeLimit(g, length, limit) {
  if (!limit || length <= limit) return '';
  const over = `${length - limit} over`;
  if (g.ctx.channel === 'teams') return `${over}: Teams links are cut after ${limit} characters, so the end would be lost.`;
  return `${over}: the limit is ${limit} characters.`;
}

function syncMeta(g) {
  const length = shownText(g.message).length;
  const limit = limitOf(g);
  setText(g.refs.count, `${length}${limit ? ` / ${limit}` : ''} characters`);
  g.refs.count.dataset.over = String(Boolean(limit) && length > limit);
  setText(g.refs.limit, describeLimit(g, length, limit));
}

/** An aside made of an optional intro line and a bullet list; rebuilt only when its text changes. */
function syncList(box, items, intro) {
  const key = JSON.stringify([intro, items]);
  if (box.dataset.key === key) return;
  box.dataset.key = key;
  const nodes = [];
  if (intro) nodes.push(el('p', '', intro));
  if (items.length) {
    const list = el('ul');
    for (const text of items) list.append(el('li', '', text));
    nodes.push(list);
  }
  box.replaceChildren(...nodes);
}

function syncAsides(g) {
  const parts = Array.isArray(g.message.composedParts) ? g.message.composedParts.filter(Boolean) : [];
  syncList(g.refs.composed, parts, parts.length ? TEXT.composed : '');
  setHidden(g.refs.composed, parts.length === 0);
  const warnings = Array.isArray(g.message.warnings) ? g.message.warnings.filter(Boolean) : [];
  syncList(g.refs.warnings, warnings, '');
  setHidden(g.refs.warnings, warnings.length === 0);
  setHidden(g.refs.editedNote, !g.edited);
  setHidden(g.refs.regenerate, !g.edited);
}

function useHintText(g) {
  const missing = Array.isArray(g.message.missing) ? g.message.missing.filter(Boolean) : [];
  if (!g.step.done || !missing.length) return TEXT.useHint;
  return `${TEXT.stillMissing}${missing.map((id) => g.labels.get(id) || id).join(', ')}.`;
}

function syncActions(g) {
  const ready = Boolean(g.message.ok && g.step.done);
  if (g.refs.use.disabled === ready) g.refs.use.disabled = !ready;
  setText(g.refs.useHint, ready ? '' : useHintText(g));
  if (ready !== g.announcedReady) setText(g.refs.announce, ready ? TEXT.ready : '');
  g.announcedReady = ready;
  const sure = g.resetPending;
  setText(g.refs.reset, sure ? TEXT.resetConfirm : TEXT.reset);
  g.refs.reset.dataset.confirm = sure ? '1' : '0';
}

function syncDom(g) {
  syncSetup(g);
  syncCards(g);
  syncProgress(g);
  syncFormError(g);
  setText(g.refs.note, g.notice);
  syncPreview(g);
  syncMeta(g);
  syncAsides(g);
  syncActions(g);
}

// ---- recompute and notify ----

function clearTimer(g) {
  if (g.timer) clearTimeout(g.timer);
  g.timer = 0;
}

/** Re-evaluate everything from `answers` and `ctx`, repaint, tell the host, optionally move focus. */
function recompute(g, { emit = true, focus = false } = {}) {
  clearTimer(g);
  g.step = nextStep(g.answers, g.ctx);
  g.message = buildMessage(g.answers, g.ctx);
  if (!isObject(g.step.errors)) g.step.errors = {};
  g.flow = buildFlow(g);
  syncDom(g);
  g.ready = true;
  if (emit) notify(g);
  if (focus) focusActive(g);
}

function notify(g) {
  const handler = g.options.onChange;
  if (typeof handler !== 'function') return;
  try {
    handler({ answers: { ...g.answers }, step: g.step, message: g.message });
  } catch (err) {
    console.error('guide onChange handler failed', err);
  }
}

function schedule(g) {
  clearTimer(g);
  g.timer = setTimeout(() => {
    g.timer = 0;
    if (!g.destroyed) recompute(g);
  }, DEBOUNCE_MS);
}

function flush(g) {
  if (g.timer) recompute(g);
}

// ---- focus ----

function focusCard(card) {
  const target = card.radios ? (card.radios.find((radio) => radio.checked) || card.radios[0]) : card.input;
  if (target) target.focus();
}

/** Focus the question that needs the agent now; when everything is answered, the Use button. */
function focusActive(g) {
  if (g.root.hidden) {
    g.focusPending = true;
    return;
  }
  g.focusPending = false;
  const active = g.flow.find((entry) => entry.state === 'active');
  if (active) focusCard(g.cards.get(active.q.id));
  else if (!g.refs.formError.hidden) g.refs.formError.focus();
  else if (!g.refs.use.disabled) g.refs.use.focus();
}

// ---- actions ----

function droppedLabels(g, before) {
  return Object.keys(before)
    .filter((id) => !HEADER_IDS.includes(id) && typeof before[id] === 'string' && before[id] !== '' && g.answers[id] === '')
    .map((id) => g.labels.get(id) || id);
}

function answerChoice(g, id, value) {
  const before = g.answers;
  g.answers = setAnswer(g.answers, id, value);
  g.editingId = '';
  if (value !== 'yes') {
    for (const dependent of DEPENDENTS[id] || []) {
      g.confirmed.delete(dependent);
      g.touched.delete(dependent);
    }
  }
  const dropped = droppedLabels(g, before);
  g.notice = dropped.length ? `Removed what you entered for: ${dropped.join(', ')}.` : '';
  recompute(g, { focus: true });
}

function continueText(g, id) {
  flush(g);
  g.notice = '';
  g.touched.add(id);
  recompute(g, { emit: false });
  const card = g.cards.get(id);
  if (!card) return;
  if (g.step.errors[id]) {
    card.input.focus();
    return;
  }
  g.confirmed.add(id);
  g.editingId = '';
  recompute(g, { emit: false, focus: true });
}

function startChange(g, id) {
  flush(g);
  g.editingId = id;
  g.notice = '';
  recompute(g, { emit: false });
  const card = g.cards.get(id);
  if (card) focusCard(card);
}

function chooseSetup(g, id, value) {
  g.answers = setAnswer(g.answers, id, value);
  g.notice = '';
  recompute(g);
}

function useDetected(g) {
  let answers = g.answers;
  for (const id of HEADER_IDS) answers = setAnswer(answers, id, g.detected[id]);
  g.answers = answers;
  recompute(g);
}

function typeInto(g, id, value) {
  g.answers = setAnswer(g.answers, id, value);
  g.notice = '';
  schedule(g);
}

function useMessage(g) {
  flush(g);
  if (!(g.message.ok && g.step.done)) return;
  if (typeof g.options.onUse === 'function') g.options.onUse(g.message.text);
}

// Gives the host the text it would show live: the finished message, or the preview with [placeholders]
// while questions are still open (the host decides whether that may be sent).
function regenerate(g) {
  flush(g);
  const text = shownText(g.message);
  if (!text) return;
  const handler = typeof g.options.onRegenerate === 'function' ? g.options.onRegenerate : g.options.onUse;
  if (typeof handler === 'function') handler(text);
}

function resetNow(g, focus) {
  g.answers = g.detected;
  g.confirmed.clear();
  g.touched.clear();
  g.editingId = '';
  g.notice = '';
  g.resetPending = false;
  clearTimeout(g.resetTimer);
  recompute(g, { focus });
}

function askReset(g) {
  if (g.resetPending) {
    resetNow(g, true);
    return;
  }
  g.resetPending = true;
  syncActions(g);
  g.resetTimer = setTimeout(() => {
    g.resetPending = false;
    if (!g.destroyed) syncActions(g);
  }, RESET_CONFIRM_MS);
}

function applyCtx(g, ctx) {
  const next = isObject(ctx) ? ctx : {};
  const before = g.detected;
  const previousContext = g.answers.context;
  const detected = defaultAnswers(next);
  let answers = g.answers;
  for (const id of ['context', 'mode', 'issue']) {
    if (answers[id] === before[id] && detected[id] !== before[id]) answers = setAnswer(answers, id, detected[id]);
  }
  g.ctx = next;
  g.detected = detected;
  g.answers = answers;
  // Only a situation that really moved with the ticket is announced; one the agent chose stays quiet.
  const info = CONTEXTS.find((item) => item.id === answers.context);
  g.notice = answers.context !== previousContext && info
    ? `The detected situation changed to "${info.label}". The preview was updated.` : '';
  recompute(g);
}

function destroy(g) {
  if (g.destroyed) return;
  g.destroyed = true;
  clearTimer(g);
  clearTimeout(g.resetTimer);
  clearTimeout(g.revealTimer);
  for (const [type, handler] of g.listeners) g.root.removeEventListener(type, handler);
  g.listeners = [];
  g.root.remove();
  g.cards.clear();
  if (mounted.get(g.host) === g.controller) mounted.delete(g.host);
}

// ---- events (delegated on the root of this mount only) ----

const cardOf = (target) => (target instanceof Element ? target.closest('li[data-q]') : null);
const roleOf = (target) => (target instanceof Element ? target.closest('[data-role]') : null);
const plainKey = (event) => !(event.ctrlKey || event.metaKey || event.altKey);

function onClick(g, event) {
  const node = roleOf(event.target);
  const role = node && node.dataset.role;
  const card = cardOf(event.target);
  if (role === 'change' && card) startChange(g, card.dataset.q);
  else if (role === 'continue' && card) continueText(g, card.dataset.q);
  else if (role === 'use') useMessage(g);
  else if (role === 'regenerate') regenerate(g);
  else if (role === 'reset') askReset(g);
  else if (role === 'useDetected') useDetected(g);
  else if (role === 'answer' && node.type === 'radio' && card && g.answers[card.dataset.q] === node.value) {
    // The same answer picked again: no change event follows, so just close the editor.
    answerChoice(g, card.dataset.q, node.value);
  }
}

function onChangeEvent(g, event) {
  const node = roleOf(event.target);
  if (!node || node.dataset.role !== 'answer') return;
  const card = cardOf(node);
  if (node.type === 'radio' && card) answerChoice(g, card.dataset.q, node.value);
  else if (node.tagName === 'SELECT') {
    const field = node.closest('[data-q]');
    if (field) chooseSetup(g, field.dataset.q, node.value);
  }
}

function onInput(g, event) {
  const node = roleOf(event.target);
  const card = cardOf(event.target);
  if (!node || !card || node.dataset.role !== 'answer' || node.type === 'radio') return;
  typeInto(g, card.dataset.q, node.value);
}

/** Y / N pick Yes / No, Enter picks the focused option; arrows and Space are the browser's own. */
function radioShortcut(event, radio) {
  if (!plainKey(event)) return '';
  if (event.key === 'Enter') return radio.value;
  const key = event.key.toLowerCase();
  if (key === 'y') return 'yes';
  return key === 'n' ? 'no' : '';
}

function onKeydown(g, event) {
  const node = roleOf(event.target);
  const card = cardOf(event.target);
  if (!node || !card || node.dataset.role !== 'answer' || event.isComposing) return;
  const id = card.dataset.q;
  if (node.type === 'radio') {
    const value = radioShortcut(event, node);
    if (!value) return;
    event.preventDefault();
    answerChoice(g, id, value);
  } else if (event.key === 'Enter' && plainKey(event) && node.tagName === 'INPUT') {
    event.preventDefault();
    continueText(g, id);
  } else if (event.key === 'Enter' && (event.ctrlKey || event.metaKey) && node.tagName === 'TEXTAREA') {
    event.preventDefault();
    continueText(g, id);
  }
}

function onFocusout(g, event) {
  const node = roleOf(event.target);
  const card = cardOf(event.target);
  if (!node || !card || node.dataset.role !== 'answer' || !TEXT_KINDS.has(card.dataset.kind)) return;
  if (g.touched.has(card.dataset.q) || g.destroyed) return;
  flush(g);
  g.touched.add(card.dataset.q);
  syncCards(g);
}

function attachListeners(g) {
  const handlers = {
    click: onClick, change: onChangeEvent, input: onInput, keydown: onKeydown, focusout: onFocusout,
  };
  for (const [type, handler] of Object.entries(handlers)) {
    const bound = (event) => handler(g, event);
    g.root.addEventListener(type, bound);
    g.listeners.push([type, bound]);
  }
}

// ---- public API ----

function makeController(g) {
  const live = (fn) => (...args) => (g.destroyed ? undefined : fn(...args));
  return {
    /** A copy of the current answers (every question id, '' when unanswered). */
    getAnswers: () => ({ ...g.answers }),
    /** The message for the current answers: buildMessage() output, up to date even mid-typing. */
    getMessage: () => {
      if (!g.destroyed) flush(g);
      return g.message;
    },
    /** New ticket context (e.g. business-hours status changed). Answers the agent never changed follow it. */
    setCtx: live((ctx) => applyCtx(g, ctx)),
    /** Back to the detected defaults with no answers (no confirmation: the Start over button asks first). */
    reset: live(() => resetNow(g, false)),
    destroy: () => destroy(g),
    /** Focus the question that needs the agent (or the Use button when everything is answered). */
    focusCurrent: live(() => focusActive(g)),
    /**
     * Everything needed to rebuild this guide exactly where the agent left it (answers, the questions they
     * moved on from, the one being changed). JSON-safe; pass it back as options.snapshot.
     */
    getSnapshot: () => {
      if (!g.destroyed) flush(g);
      return {
        answers: { ...g.answers },
        detected: { context: g.detected.context, mode: g.detected.mode, issue: g.detected.issue },
        confirmed: [...g.confirmed],
        touched: [...g.touched],
        editingId: g.editingId,
      };
    },
    /** The host reports that the message was edited by hand: shows the Regenerate button. */
    setEdited: live((flag) => {
      g.edited = Boolean(flag);
      syncAsides(g);
    }),
  };
}

/**
 * Mount the question flow in `host` (replaces a guide already mounted there).
 * @param {Element} host
 * @param {{
 *   ctx?: object,
 *   initialAnswers?: object,
 *   snapshot?: object,
 *   maxChars?: number,
 *   onChange?: (change: { answers: object, step: object, message: object }) => void,
 *   onUse?: (text: string) => void,
 *   onRegenerate?: (text: string) => void
 * }} [options] ctx and initialAnswers are the lib/messageTemplates.js shapes; snapshot (from getSnapshot())
 *   restores answers AND the progress of the flow and wins over initialAnswers; maxChars overrides the
 *   Teams limit warning (which applies when ctx.channel is 'teams'); onRegenerate falls back to onUse.
 * @returns {{ getAnswers: Function, getMessage: Function, getSnapshot: Function, setCtx: Function,
 *   reset: Function, destroy: Function, focusCurrent: Function, setEdited: Function }}
 */
export function mountFollowUpGuide(host, options = {}) {
  if (!(host instanceof Element)) throw new TypeError('mountFollowUpGuide needs a host element');
  const previous = mounted.get(host);
  if (previous) previous.destroy();
  const g = createState(host, isObject(options) ? options : {});
  buildShell(g);
  attachListeners(g);
  host.append(g.root);
  ensureStylesheet(g);
  if (!g.snapshot) {
    for (const id of g.provided) {
      const question = g.firstStep.visible.find((q) => q.id === id);
      if (question && TEXT_KINDS.has(question.kind) && !(g.firstStep.errors || {})[id]) g.confirmed.add(id);
    }
  }
  recompute(g, { emit: false });
  g.controller = makeController(g);
  mounted.set(host, g.controller);
  return g.controller;
}

