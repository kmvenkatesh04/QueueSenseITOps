// The History view: every follow-up this dashboard has recorded (Teams chats opened, tickets updated,
// dry runs, failures), newest first, with a day filter and a text filter. Rows come from
// lib/dashboardModel.js (buildHistoryRows); this module only draws them.
import { buildHistoryRows } from '../lib/dashboardModel.js';
import {
  EM_DASH, button, create, externalLink, plural, safeHttpUrl, str, withField,
} from './dom.js';
import { els } from './els.js';
import { reconcile } from './table.js';
import { hooks, state } from './state.js';
import { KEY, queueWrite, storageRead } from './store.js';

const TONES = ['green', 'red', 'amber', 'grey'];

function timeCell(row) {
  const td = create('td', 'cell h-cell-when');
  td.dataset.col = 'when';
  // 'Thu 2026-10-08 19:55:00': date and clock are kept whole, so a narrow column breaks between them
  const label = str(row.atLabel);
  const cut = label.lastIndexOf(' ');
  const exact = withField(create('p', 'h-exact'), 'historyTime');
  if (cut > 0) exact.append(create('span', 'nowrap', label.slice(0, cut)), ' ', create('span', 'nowrap', label.slice(cut + 1)));
  else exact.textContent = label || EM_DASH;
  td.append(exact);
  if (str(row.ago)) td.append(create('p', 'cell-note', str(row.ago)));
  return td;
}

function ticketCell(row) {
  const th = create('th', 'cell h-cell-ticket');
  th.scope = 'row';
  th.dataset.col = 'ticket';
  const record = state.records.get(row.incidentNumber);
  const href = record ? safeHttpUrl(record.incidentUrl) : '';
  const number = href
    ? externalLink(href, 'inc-number', row.incidentNumber)
    : create('span', 'inc-number', row.incidentNumber);
  number.dataset.field = 'incidentNumber';
  if (href) number.title = 'Open in ServiceNow';
  th.append(number);
  if (record) {
    const show = button('Show ticket', 'btn-sm btn-quiet', { 'aria-label': `Show ${row.incidentNumber} in the Tickets view` });
    show.dataset.action = 'show-ticket';
    show.dataset.incident = row.incidentNumber;
    th.append(show);
  }
  return th;
}

function channelCell(row) {
  const td = create('td', 'cell h-cell-channel');
  td.dataset.col = 'channel';
  const label = withField(create('span', 'channel', str(row.channelLabel) || str(row.channel)), 'historyChannel');
  label.dataset.channel = str(row.channel);
  td.append(label);
  return td;
}

function resultCell(row) {
  const td = create('td', 'cell h-cell-result');
  td.dataset.col = 'result';
  const pill = withField(create('span', 'pill pill-soft', str(row.resultLabel)), 'historyResult');
  pill.dataset.result = str(row.resultKey);
  pill.dataset.tone = TONES.includes(row.tone) ? row.tone : 'grey';
  td.append(pill);
  return td;
}

function messageCell(row) {
  const td = create('td', 'cell h-cell-message');
  td.dataset.col = 'message';
  const preview = str(row.textPreview);
  td.append(withField(create('p', preview ? 'h-text' : 'h-text is-empty', preview || EM_DASH), 'historyText'));
  const note = str(row.note);
  if (note && note !== preview) td.append(create('p', 'cell-note', note));
  return td;
}

// ---- remove one history entry (two clicks: arm, then confirm) ----

const REMOVE_CONFIRM_MS = 6000;
let armedKey = '';
let armedTimer = 0;

// The same normalisation lib/dashboardModel.js's historyRow applies to `at` (ISO, '' when unusable).
function isoOf(value) {
  const ms = typeof value === 'number' ? value : Date.parse(str(value));
  return Number.isFinite(ms) ? new Date(ms).toISOString() : '';
}

const entryKey = (row) => `${row.index}|${str(row.at)}|${row.incidentNumber}`;

function removeButtonFor(row) {
  const armed = armedKey === entryKey(row);
  const node = button(armed ? 'Confirm remove' : 'Remove', 'btn-sm btn-quiet btn-remove', {
    'aria-label': armed ? `Confirm: remove this ${row.incidentNumber} entry from the history` : `Remove this ${row.incidentNumber} entry from the history`,
  });
  node.dataset.action = 'remove-entry';
  node.dataset.key = entryKey(row);
  if (armed) node.dataset.confirm = '1';
  node.title = 'Remove only this entry from the history on this computer. Click twice to confirm.';
  return node;
}

function disarm() {
  clearTimeout(armedTimer);
  if (!armedKey) return;
  armedKey = '';
  hooks.paint();
}

/** Delete one log entry. It is matched by position AND by its time and ticket, so an entry written
 * meanwhile (which shifts positions) can never cause a different entry to be removed. */
async function removeEntry(key) {
  const [indexText, at, incidentNumber] = key.split('|');
  const index = Number(indexText);
  let removed = false;
  await queueWrite(async () => {
    const stored = await storageRead([KEY.log]);
    const log = Array.isArray(stored[KEY.log]) ? [...stored[KEY.log]] : [];
    const entry = log[index];
    if (entry && typeof entry === 'object' && isoOf(entry.at) === at && str(entry.incidentNumber).startsWith(incidentNumber)) {
      log.splice(index, 1);
      await chrome.storage.local.set({ [KEY.log]: log });
      removed = true;
    }
  });
  if (removed) await hooks.render([KEY.log]);
  else hooks.showNotice('That history entry changed before it could be removed. Nothing was removed.', 'error');
}

function buildHistoryNode(row) {
  const tr = create('tr', 'hist-row');
  tr.dataset.logIndex = String(row.index);
  tr.dataset.incident = row.incidentNumber;
  const message = messageCell(row);
  message.append(removeButtonFor(row));
  tr.append(timeCell(row), ticketCell(row), channelCell(row), resultCell(row), message);
  return tr;
}

function emptyWording(total, filtered) {
  if (total === 0) {
    return {
      title: 'No past interactions yet',
      text: 'When you open a Teams chat or send a ticket update from the Tickets view, it is listed here.',
    };
  }
  return {
    title: 'No interactions match these filters',
    text: `${plural(total, 'interaction is', 'interactions are')} recorded in total. ${filtered ? 'Try another day or clear the search.' : ''}`.trim(),
  };
}

/** Update the History view for the current clock. */
export function paintHistory(now, timeZone) {
  let rows = [];
  try {
    rows = buildHistoryRows(state.data.log, now, { timeZone, day: state.historyDay, query: state.historyQuery });
  } catch {
    rows = [];
  }
  const total = state.data.log.length;
  const desired = rows.map((row) => ({
    key: `log:${row.index}:${row.at}`,
    sig: JSON.stringify([row, state.records.has(row.incidentNumber), armedKey === entryKey(row)]),
    build: () => buildHistoryNode(row),
  }));
  state.historyNodes = reconcile(els.historyRows, state.historyNodes, desired);

  const none = rows.length === 0;
  els.historyTable.hidden = none;
  els.historyEmpty.hidden = !none;
  if (none) {
    const words = emptyWording(total, Boolean(state.historyQuery.trim()) || state.historyDay !== 'all');
    els.historyEmptyTitle.textContent = words.title;
    els.historyEmptyText.textContent = words.text;
  }
  const filtered = rows.length !== total;
  els.historyCount.textContent = filtered ? `Showing ${rows.length} of ${total}` : plural(total, 'interaction', 'interactions');
}

/** "Show ticket" in a history row: jump to that ticket in the Tickets view. */
function onHistoryClick(event) {
  const remove = event.target.closest('button[data-action="remove-entry"]');
  if (remove) {
    const { key } = remove.dataset;
    clearTimeout(armedTimer);
    if (armedKey === key) {
      armedKey = '';
      void removeEntry(key).catch((err) => hooks.showNotice(`Could not remove the entry: ${err && err.message ? err.message : err}`, 'error'));
    } else {
      armedKey = key;
      armedTimer = setTimeout(disarm, REMOVE_CONFIRM_MS);
      hooks.paint();
    }
    return;
  }
  if (armedKey) disarm();
  const target = event.target.closest('button[data-action="show-ticket"]');
  if (target) void hooks.showTicket(target.dataset.incident, { flash: true, details: true });
}

/** Attach the History view's event listeners. */
export function wireHistory() {
  els.historyDay.addEventListener('change', () => {
    state.historyDay = els.historyDay.value;
    hooks.paint();
  });
  els.historySearch.addEventListener('input', () => {
    state.historyQuery = els.historySearch.value;
    hooks.paint();
  });
  els.historyRows.addEventListener('click', onHistoryClick);
}
