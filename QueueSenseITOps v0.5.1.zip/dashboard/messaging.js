// Talking to the extension background and to the browser: runtime messages (with a time limit),
// host permissions and opening tabs.
import { parseInstanceUrl } from '../lib/instance.js';
import { errorText, isObject, str } from './dom.js';

/** The background may need a background tab, a page load and verification: up to about half a minute. */
export const REPLY_TIMEOUT_MS = 120000;

/** Sentences for the two ways the background can fail to answer. */
export const MSG = {
  noResponse: 'No response from the extension background. Reload the extension and try again.',
  // Names both extension pages: the extension is installed in Brave AND in Chrome, and a person on
  // Chrome typing the brave:// address gets nowhere.
  staleWorker: 'The extension background is running older code than this page (or did not answer). Reload the extension on the browser\'s extensions page (brave://extensions or chrome://extensions): the Reload button on "QueueSenseITOps". Then reopen this tab.',
  timeout: 'The extension background did not answer within 2 minutes. Reload the extension and try again.',
};

/** Shown when the worker does not know a message the page sends: it runs older code than this page. */
export const STALE_WORKER_TEXT = MSG.staleWorker;


/**
 * chrome.runtime.sendMessage with a deadline.
 * @returns {Promise<{reply: *}|{failure: string}>} `failure` is a sentence for the user; the reply
 *   itself (also a missing one) is returned untouched for the caller to interpret.
 */
export async function sendRuntimeMessage(message, { timeoutMs = REPLY_TIMEOUT_MS } = {}) {
  let timer = 0;
  const deadline = new Promise((resolve) => {
    timer = setTimeout(() => resolve({ failure: MSG.timeout }), timeoutMs);
  });
  const request = (async () => {
    try {
      return { reply: await chrome.runtime.sendMessage(message) };
    } catch (err) {
      return { failure: `Could not reach the extension background: ${errorText(err)}` };
    }
  })();
  try {
    return await Promise.race([request, deadline]);
  } finally {
    clearTimeout(timer);
  }
}

/** The text of an `{ ok: false, error }` reply, or a fallback sentence. */
export function replyError(reply, fallback) {
  if (!isObject(reply)) return MSG.noResponse;
  const error = isObject(reply.error) ? reply.error : {};
  return str(error.message) || fallback;
}

/**
 * Host permission for one instance origin. Must be called straight from a click handler: the first
 * awaited work of that handler, so permissions.request still has the user gesture.
 */
export async function ensureOriginPermission(origin) {
  const parsed = parseInstanceUrl(origin);
  if (!parsed.ok) return { ok: false, message: parsed.message };
  const request = { origins: [parsed.pattern] };
  try {
    if (await chrome.permissions.contains(request)) return { ok: true, origin: parsed.origin };
    if (await chrome.permissions.request(request)) return { ok: true, origin: parsed.origin };
  } catch (err) {
    return { ok: false, message: `Could not request access to ${parsed.origin}: ${errorText(err)}` };
  }
  return { ok: false, message: `Permission to access ${parsed.origin} was not granted.` };
}

/** Ask once for every origin that is not yet permitted; never throws, the answer is advisory. */
export async function ensureOriginsPermission(origins) {
  const patterns = [...new Set(origins.map((origin) => parseInstanceUrl(origin)).filter((p) => p.ok).map((p) => p.pattern))];
  if (!patterns.length) return true;
  try {
    const request = { origins: patterns };
    return (await chrome.permissions.contains(request)) || (await chrome.permissions.request(request));
  } catch {
    return false;
  }
}

/** Open a URL in a new foreground tab (window.open as the fallback). */
export async function openUrl(url) {
  try {
    if (chrome.tabs && typeof chrome.tabs.create === 'function') {
      await chrome.tabs.create({ url, active: true });
      return;
    }
  } catch {
    // fall back to window.open below
  }
  const opened = window.open(url, '_blank');
  if (!opened) throw new Error('the browser blocked the new tab');
  opened.opener = null;
}

function fallbackCopy(text) {
  const shim = document.createElement('textarea');
  shim.className = 'clipboard-shim';
  shim.value = text;
  shim.setAttribute('readonly', '');
  document.body.append(shim);
  shim.select();
  let ok = false;
  try {
    ok = document.execCommand('copy');
  } catch {
    ok = false;
  }
  shim.remove();
  return ok;
}

/** Copy text to the clipboard (call from a click handler); false when the browser refused. */
export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return fallbackCopy(text);
  }
}
