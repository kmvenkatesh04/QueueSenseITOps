// A multi-select dropdown: a button that says what is chosen ('All', the one chosen label, or 'N
// selected') and opens a small panel of checkboxes. Used by the Tickets toolbar for every list filter;
// nothing in here knows about tickets, so the Overview (or anything else) can reuse it.
//
// Structure (all built with create(); option labels are untrusted ServiceNow text, so textContent only):
//   div.ms
//     label.ms-label[for=id]                          the visible filter name, like the other toolbar tools
//     button#id.ms-button[aria-haspopup][aria-expanded][aria-controls]
//       span.ms-value                                 the summary text
//     div.ms-panel#id-panel[hidden]                    the popover
//       fieldset > legend (the filter name) + one label > input[type=checkbox] per option
//       div.ms-actions: Select all / Clear
//
// Keyboard and pointer (WCAG 2.1.1 / 2.4.3 / 1.4.13): the button toggles the panel (Enter / Space /
// click; ArrowDown / ArrowUp open it on the first / last checkbox); inside it Tab moves between the
// checkboxes and the two actions, Escape closes it and returns focus to the button, and tabbing out of
// it closes it. A pointer press anywhere outside closes it too (focus stays where the person put it).
// Every change of the selection calls onChange(values) at once (no Apply step): a filter that applies
// as you tick is what the rest of the toolbar does. An empty selection means "no filter" (All).
//
// update({ options, selected }) is called on every repaint of the page (once a minute, and whenever
// tickets arrive). It only rebuilds the checkboxes when the options really changed, and then puts focus
// back on the same option's checkbox, so a repaint never closes the panel or loses the person's place.
import { create, setText } from './dom.js';

let panelSeq = 0;

/** String form of an option value ('' allowed; anything else that is not a string or number is dropped). */
function valueText(value) {
  if (typeof value === 'string') return value;
  if (typeof value === 'number' && Number.isFinite(value)) return String(value);
  return null;
}

/** Options as [{ value, label, count }] with string values, no duplicates. */
function cleanOptions(options) {
  const out = [];
  const seen = new Set();
  for (const option of Array.isArray(options) ? options : []) {
    if (!option || typeof option !== 'object') continue;
    const value = valueText(option.value);
    if (value === null || seen.has(value)) continue;
    seen.add(value);
    const label = typeof option.label === 'string' && option.label.trim() ? option.label.trim() : value || '(empty)';
    const count = Number.isInteger(option.count) && option.count >= 0 ? option.count : null;
    out.push({ value, label, count });
  }
  return out;
}

function cleanValues(values) {
  const out = [];
  for (const value of Array.isArray(values) ? values : []) {
    const text = valueText(value);
    if (text !== null && !out.includes(text)) out.push(text);
  }
  return out;
}

/**
 * Build one multi-select. Never throws for odd options (they are skipped).
 * @param {{id:string, label:string, allLabel?:string, options?:{value:string, label:string, count?:number}[],
 *   selected?:string[], onChange?:(values:string[]) => void, title?:string}} spec
 *   id: the button's id (the panel is `${id}-panel`); label: the filter's name (visible label and the
 *   checkbox group's legend); allLabel: the summary when nothing is chosen; title: optional hint on the button
 * @returns {{root:HTMLElement, button:HTMLElement, update:(next:{options?:object[], selected?:string[]}) => void,
 *   values:() => string[], optionValues:() => string[], clear:() => void, focus:() => void, close:() => void,
 *   isOpen:() => boolean}}
 */
export function createMultiSelect({
  id, label, allLabel = 'All', options = [], selected = [], onChange, title = '',
}) {
  panelSeq += 1;
  const panelId = `${id || `ms${panelSeq}`}-panel`;
  let current = cleanOptions(options);
  let chosen = cleanValues(selected);
  let optionsSig = '';
  const boxes = new Map(); // value -> checkbox

  const root = create('div', 'ms');
  root.dataset.ms = id;
  const labelNode = create('label', 'ms-label', label);
  labelNode.htmlFor = id;
  labelNode.id = `${id}-label`;
  const button = create('button', 'ms-button');
  button.type = 'button';
  button.id = id;
  button.setAttribute('aria-haspopup', 'true');
  button.setAttribute('aria-expanded', 'false');
  button.setAttribute('aria-controls', panelId);
  const valueNode = create('span', 'ms-value');
  valueNode.id = `${id}-value`;
  const caret = create('span', 'ms-caret', '▾');
  caret.setAttribute('aria-hidden', 'true');
  button.append(valueNode, caret);
  // "Business hours now, All" / "Priority, 2 selected": the filter's name, then what is chosen.
  button.setAttribute('aria-labelledby', `${id}-label ${id}-value`);
  if (title) button.title = title;

  const panel = create('div', 'ms-panel');
  panel.id = panelId;
  panel.hidden = true;
  const fieldset = create('fieldset', 'ms-fieldset');
  const legend = create('legend', 'ms-legend', label);
  const list = create('div', 'ms-options');
  const empty = create('p', 'ms-empty', 'Nothing to choose from yet.');
  fieldset.append(legend, list, empty);
  const actions = create('div', 'ms-actions');
  const allButton = create('button', 'btn btn-sm btn-quiet ms-action', 'Select all');
  allButton.type = 'button';
  allButton.dataset.msAction = 'all';
  const clearButton = create('button', 'btn btn-sm btn-quiet ms-action', 'Clear');
  clearButton.type = 'button';
  clearButton.dataset.msAction = 'clear';
  actions.append(allButton, clearButton);
  panel.append(fieldset, actions);
  root.append(labelNode, button, panel);

  function summary() {
    if (chosen.length === 0) return allLabel;
    if (chosen.length === 1) {
      const option = current.find((o) => o.value === chosen[0]);
      return option ? option.label : chosen[0] || '(empty)';
    }
    return `${chosen.length} selected`;
  }

  function syncSummary() {
    setText(valueNode, summary());
    button.value = chosen.length ? chosen.join(',') : 'all';
    root.classList.toggle('is-active', chosen.length > 0);
    clearButton.disabled = chosen.length === 0;
    allButton.disabled = current.length === 0 || current.every((o) => chosen.includes(o.value));
  }

  function syncChecks() {
    for (const [value, box] of boxes) box.checked = chosen.includes(value);
  }

  function emit() {
    syncChecks();
    syncSummary();
    if (typeof onChange === 'function') onChange([...chosen]);
  }

  function optionNode(option) {
    const row = create('label', 'ms-option');
    const box = create('input', 'ms-check');
    box.type = 'checkbox';
    box.value = option.value;
    box.checked = chosen.includes(option.value);
    box.addEventListener('change', () => {
      const on = box.checked === true;
      chosen = on ? [...chosen.filter((v) => v !== option.value), option.value] : chosen.filter((v) => v !== option.value);
      // keep the option order, so 'Priority: P1, P2' reads the same however it was ticked
      chosen = current.map((o) => o.value).filter((v) => chosen.includes(v)).concat(chosen.filter((v) => !current.some((o) => o.value === v)));
      emit();
    });
    boxes.set(option.value, box);
    row.append(box, create('span', 'ms-option-label', option.label));
    if (option.count !== null) {
      const count = create('span', 'ms-count', String(option.count));
      count.append(create('span', 'sr-only', option.count === 1 ? ' ticket' : ' tickets'));
      row.append(count);
    }
    if (option.count === 0) row.classList.add('is-zero');
    return row;
  }

  function isFocused(node) {
    try {
      return document.activeElement === node;
    } catch {
      return false;
    }
  }

  function focusedValue() {
    try {
      const active = document.activeElement;
      if (active && panel.contains(active) && active.classList && active.classList.contains('ms-check')) return active.value;
    } catch {
      // no document focus available (tests): nothing to restore
    }
    return null;
  }

  function rebuild() {
    const sig = JSON.stringify(current.map((o) => [o.value, o.label, o.count]));
    if (sig === optionsSig) return;
    optionsSig = sig;
    const keep = focusedValue();
    boxes.clear();
    list.replaceChildren(...current.map(optionNode));
    empty.hidden = current.length > 0;
    if (keep !== null && boxes.has(keep)) boxes.get(keep).focus({ preventScroll: true });
  }

  // ---- open / close ----

  function isOpen() {
    return panel.hidden === false;
  }

  function place() {
    // Near the right edge of the window the panel opens towards the left instead (CSS: data-align=end),
    // so it never makes the page scroll sideways; its width is clamped to the window in CSS.
    try {
      delete panel.dataset.align;
      const rect = typeof panel.getBoundingClientRect === 'function' ? panel.getBoundingClientRect() : null;
      const width = globalThis.innerWidth || (document.documentElement ? document.documentElement.clientWidth : 0);
      if (rect && width && rect.right > width - 8) panel.dataset.align = 'end';
    } catch {
      // placement is cosmetic
    }
  }

  function open(focusWhich) {
    if (!isOpen()) {
      panel.hidden = false;
      button.setAttribute('aria-expanded', 'true');
      root.classList.add('is-open');
      place();
    }
    const checks = [...boxes.values()];
    const target = focusWhich === 'last' ? checks[checks.length - 1] : focusWhich === 'first' ? checks[0] : null;
    if (target) target.focus({ preventScroll: true });
  }

  function close({ focusButton = false } = {}) {
    if (isOpen()) {
      panel.hidden = true;
      button.setAttribute('aria-expanded', 'false');
      root.classList.remove('is-open');
    }
    if (focusButton) button.focus({ preventScroll: true });
  }

  button.addEventListener('click', () => {
    if (isOpen()) close();
    else open();
  });
  button.addEventListener('keydown', (event) => {
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      event.preventDefault();
      open(event.key === 'ArrowDown' ? 'first' : 'last');
    } else if (event.key === 'Escape' && isOpen()) {
      event.preventDefault();
      close();
    }
  });
  panel.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      event.preventDefault();
      event.stopPropagation();
      close({ focusButton: true });
    }
  });
  // Tabbing out of the whole widget closes the panel. A focusout towards nothing (a click on the panel's
  // own background) is not leaving: the pointer handler below decides for pointer presses.
  root.addEventListener('focusout', (event) => {
    const next = event.relatedTarget;
    if (next && !root.contains(next)) close();
  });
  allButton.addEventListener('click', () => {
    const hadFocus = isFocused(allButton);
    chosen = current.map((o) => o.value);
    emit();
    // Select all just became disabled: a disabled button loses the focus (to <body>, where Escape and Tab
    // no longer work inside the panel), so hand it to Clear, the action that now makes sense.
    if (hadFocus && allButton.disabled && !clearButton.disabled) clearButton.focus({ preventScroll: true });
  });
  clearButton.addEventListener('click', () => {
    chosen = [];
    emit();
    const first = [...boxes.values()][0];
    if (first) first.focus({ preventScroll: true }); // the Clear button just became disabled
  });
  try {
    document.addEventListener('pointerdown', (event) => {
      if (isOpen() && event && event.target && !root.contains(event.target)) close();
    });
  } catch {
    // no document events (tests): Escape and the button still close it
  }

  rebuild();
  syncSummary();

  return {
    root,
    button,
    /** New options and/or selection (from a repaint); keeps the panel open and the focus where it is. */
    update(next = {}) {
      if (next && Array.isArray(next.options)) current = cleanOptions(next.options);
      if (next && Array.isArray(next.selected)) chosen = cleanValues(next.selected);
      rebuild();
      syncChecks();
      syncSummary();
    },
    values: () => [...chosen],
    /** The values of the options currently offered. */
    optionValues: () => current.map((o) => o.value),
    /** Empty the selection without calling onChange (the caller is the one clearing). */
    clear() {
      chosen = [];
      syncChecks();
      syncSummary();
    },
    focus: () => button.focus({ preventScroll: true }),
    close: () => close(),
    isOpen,
  };
}
