// Which view and which filters are active, and how they live in the URL hash:
//   #view=tickets|history|data & day=today|yesterday|last7|all|YYYY-MM-DD & status=a,b & inc=INC...
// The hash is a convenience (deep links, reload); the in-memory state is the truth.
//
// status is a comma list since v0.4 (the "Business hours now" filter is a multi-select); a hash written
// by an older version (status=business) reads as that one value. dashboard/tickets.js keeps its own
// filters in further params of the same hash (ticketStatus, savedView, prio, group, agent, age, upd,
// quick); writeHash() below rewrites only the params this module owns and keeps every other one, in
// its place after them, so neither module can wipe the other's part of a deep link.
import {
  formatListParam, hashFromParams, normalizeStatusList, parseListParam,
} from '../lib/ticketFilters.js';
import { els } from './els.js';
import { DAY_CHOICES, VIEWS, hooks, state } from './state.js';

const DAY_KEY = /^\d{4}-\d{2}-\d{2}$/;
const SCOPE_KEY = /^[A-Za-z0-9_-]{1,40}$/;

// Settings and Diagnostics are two further views added by the hardening pass (contract 13.6). They
// are not in lib state.js's VIEWS (owned by another module): that list stays the three original tabs,
// so this module layers the extra two on top instead of editing it. Their tab/panel elements are
// looked up directly (dashboard.html is this module's own file) rather than through the shared `els`
// registry, for the same reason.
const EXTRA_VIEWS = ['overview', 'flags', 'errors', 'diagnostics', 'settings'];
/** Every view this page can show, in tab order: Tickets, the Overview dashboard (v0.4), then the rest. */
export const ALL_VIEWS = [VIEWS[0], 'overview', 'flags', 'errors', ...VIEWS.slice(1), 'diagnostics', 'settings'];

const TAB_OF_VIEW = { tickets: 'tabTickets', history: 'tabHistory', data: 'tabData' };
const PANEL_OF_VIEW = { tickets: 'panelTickets', history: 'panelHistory', data: 'panelData' };
const EXTRA_TAB_ID = { overview: 'tabOverview', flags: 'tabFlags', errors: 'tabErrors', diagnostics: 'tabDiag', settings: 'tabSettings' };
const EXTRA_PANEL_ID = { overview: 'panelOverview', flags: 'panelFlags', errors: 'panelErrors', diagnostics: 'panelDiag', settings: 'panelSettings' };

/** The tab button of a view, whether it is one of the original three or one added later. */
function tabNode(view) {
  const id = TAB_OF_VIEW[view] || EXTRA_TAB_ID[view];
  return (TAB_OF_VIEW[view] ? els[id] : null) || document.getElementById(id);
}

/** The panel section of a view, whether it is one of the original three or one added later. */
function panelNode(view) {
  const id = PANEL_OF_VIEW[view] || EXTRA_PANEL_ID[view];
  return (PANEL_OF_VIEW[view] ? els[id] : null) || document.getElementById(id);
}

/** today | yesterday | last7 | all | YYYY-MM-DD. */
function isDayKey(value) {
  return DAY_CHOICES.includes(value) || DAY_KEY.test(value || '');
}

/** The params writeHash() owns; every other param of the hash belongs to someone else and is kept. */
const OWN_PARAMS = ['view', 'day', 'status', 'inc'];

/**
 * The "business hours now" filter as a list of statuses ([] = all), whatever shape state.status has
 * (a list since v0.4; 'all' / 'business' from a caller that still assigns one value). Never throws.
 * @returns {string[]}
 */
export function statusFilterValues() {
  return normalizeStatusList(state.status);
}

/** Load view, day, status and data scope from the URL hash (defaults when absent or invalid). */
export function readHash() {
  const params = new URLSearchParams(location.hash.replace(/^#/, ''));
  const view = params.get('view');
  const day = params.get('day');
  const scope = params.get('inc');
  state.view = ALL_VIEWS.includes(view) ? view : 'tickets';
  state.day = isDayKey(day) ? day : 'today';
  state.status = normalizeStatusList(parseListParam(params.get('status')));
  state.scope = scope && SCOPE_KEY.test(scope) ? scope : 'all';
}

/** Write the current view and filters to the URL hash without adding a history entry. Params that
 * other modules keep in the hash (see the module comment) are carried over unchanged. */
export function writeHash() {
  try {
    const params = new URLSearchParams({ view: state.view, day: state.day });
    const status = formatListParam(statusFilterValues());
    if (status) params.set('status', status);
    if (state.view === 'data' && state.scope !== 'all') params.set('inc', state.scope);
    const current = new URLSearchParams(location.hash.replace(/^#/, ''));
    for (const [key, value] of current) if (!OWN_PARAMS.includes(key)) params.append(key, value);
    history.replaceState(null, '', hashFromParams(params));
  } catch {
    // the hash is a convenience only
  }
}

/** Put the filter controls and the tabs in line with the state. The "Business hours now" multi-select
 * itself is brought in line by dashboard/tickets.js on its next paint; its button's `value` (the
 * scripted, select-like view of it: 'all' or 'business,uncertain') is set here at once. */
export function syncControls() {
  if (!els.dayFilter.querySelector(`option[value="${CSS.escape(state.day)}"]`)) {
    const option = document.createElement('option');
    option.value = state.day;
    option.textContent = state.day;
    els.dayFilter.append(option);
  }
  els.dayFilter.value = state.day;
  const statusControl = document.getElementById('statusFilter');
  if (statusControl) statusControl.value = statusFilterValues().join(',') || 'all';
  els.historyDay.value = state.historyDay;
  syncTabs();
}

/** Reflect state.view in the tabs (aria-selected, roving tabindex) and show its panel. */
function syncTabs() {
  for (const view of ALL_VIEWS) {
    const tab = tabNode(view);
    const panel = panelNode(view);
    if (!tab || !panel) continue;
    const selected = view === state.view;
    tab.setAttribute('aria-selected', String(selected));
    tab.tabIndex = selected ? 0 : -1;
    panel.hidden = !selected;
  }
}

/** Show a view; `focusTab` also moves focus to its tab. */
export function setView(view, { focusTab = false } = {}) {
  if (!ALL_VIEWS.includes(view)) return;
  state.view = view;
  syncTabs();
  writeHash();
  hooks.paint();
  if (focusTab) {
    const tab = tabNode(view);
    if (tab) tab.focus();
  }
}

/**
 * Set the "business hours now" filter (the multi-select, the summary chips, the banner, the empty-state
 * reset). `value` is a list of statuses or one status; 'all', [] or anything unknown clears the filter.
 * @param {string|string[]} value
 */
export function setStatusFilter(value) {
  state.status = normalizeStatusList(value);
  syncControls();
  writeHash();
  hooks.paint();
}

/** Set the day filter of the Tickets view. */
export function setDay(value) {
  if (!isDayKey(value)) return;
  state.day = value;
  syncControls();
  writeHash();
  hooks.paint();
}

/** Arrow keys, Home and End move between the tabs and show the tab's panel (automatic activation). */
export function onTabKeydown(event) {
  const index = ALL_VIEWS.indexOf(ALL_VIEWS.find((view) => tabNode(view) === event.target));
  if (index < 0 || event.altKey || event.ctrlKey || event.metaKey) return;
  let next = -1;
  if (event.key === 'ArrowRight') next = (index + 1) % ALL_VIEWS.length;
  else if (event.key === 'ArrowLeft') next = (index + ALL_VIEWS.length - 1) % ALL_VIEWS.length;
  else if (event.key === 'Home') next = 0;
  else if (event.key === 'End') next = ALL_VIEWS.length - 1;
  if (next < 0) return;
  event.preventDefault();
  setView(ALL_VIEWS[next], { focusTab: true });
}

/** Click on a tab. */
export function onTabClick(event) {
  const view = ALL_VIEWS.find((name) => tabNode(name) === event.currentTarget);
  if (view) setView(view);
}

/** The tab button of a view. */
export function tabElement(view) {
  return tabNode(view);
}
