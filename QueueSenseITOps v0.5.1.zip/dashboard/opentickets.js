// "Load all open tickets" (header button) and its Settings section "Open tickets to load".
//
// Phases, all through the extension background, never a request of this page's own:
//   1. LIST_OPEN_INCIDENTS: the background reads ServiceNow's classic incident list for the saved
//      queues in ONE background tab, page by page, and answers with the incident numbers whose State
//      is one of the saved states (lib/openTickets.js), plus (v0.5) each kept row's list cells. Nothing
//      is stored by that step.
//   2. Each number is fetched with the SAME pool the bulk fetch uses (dashboard/search.js runBulkFetch,
//      FETCH_INCIDENT with source 'search'), so the tickets land in the Tickets table exactly as if they
//      had been searched one by one.
//   3. (v0.5) Retry rounds: tickets whose fetch failed with an error (not "not found", not a login page,
//      not cancelled) are fetched again, openTickets.retryRounds rounds at most (default 2), 2 at a time,
//      after a pause of about 3 s each (dashboard/autorefresh.js runRetryRounds). The summary says how
//      many succeeded on retry and how many still fail (those are listed on the Fetch errors tab).
//   4. Stored tickets of the same queues that the list no longer shows (most likely resolved or closed
//      since) are re-read with FETCH_INCIDENT source 'refresh' (lib/openTickets.js ticketsNoLongerListed),
//      so their State in the table stops saying "In Progress". Skipped when the list was cut short
//      (cancel, login, the ticket limit): then "not listed" does not mean "no longer open".
//   5. (v0.5) Queue tracking (lib/queueTracking.js): applyListRun (first seen, new to the queue, moved
//      out: only a COMPLETE run may mark a ticket moved out), recordFetchResult (the tickets that still
//      fail, with their list cells, for the Fetch errors tab) and pruneQueueTracking, written with one
//      read-modify-write (dashboard/store.js persistQueueTracking).
// runOpenTicketsLoad is the ONE run function: the header button ('manual'), auto refresh ('auto': no
// permission prompt, no focus move, no view switch, no filter reset) and the Fetch errors tab's retry
// ('retry': phases 2-3 for the failed tickets only) all go through it. One run at a time per browser
// profile (a Web Lock, see dashboard/autorefresh.js withLoadLock). dashboard/autorefresh.js owns the
// status other views read and the auto refresh scheduler; this module registers itself there.
// The Settings section only edits `serviceNowSettings.openTickets`; dashboard/settings.js owns the
// settings object and its storage and passes a `save` function in (same split as dashboard/fieldmap.js).
// The auto refresh setting (openTickets.autoRefresh) is saved through that same function.
// When no queue has been saved yet, the queue box is prefilled from the assignment groups of the saved
// views (the place an owner most likely "listed the queues earlier"), clearly marked as not saved.
// Once the owner edits the form it is "dirty": no repaint refills it until it is saved.
import { parseInstanceUrl } from '../lib/instance.js';
import {
  DEFAULT_MAX_TICKETS, MAX_TICKETS_LIMIT, describeExtraQueryProblem, normalizeOpenTicketsConfig, ticketsNoLongerListed,
  ticketsStillInQueue,
} from '../lib/openTickets.js';
// A namespace import: the functions are looked up when a run ends, so a build whose
// lib/queueTracking.js lacks one simply skips that step instead of failing to load the page.
import * as queueLib from '../lib/queueTracking.js';
import { SETTINGS_STORAGE_KEY, effectiveTimeZone, normalizeServiceNowSettings } from '../lib/settings.js';
import {
  PAUSE_TEXT, RETRY_CONCURRENCY, RETRY_PAUSE_MS, autoRefreshPreflight, failedItemsOf, normalizeAutoRefreshConfig,
  normalizeRetryRounds, noteAutoRefreshConfig, noteRunAttempt, noteStatusTimeZone, queueChangeSentence, registerOpenTicketsRunner,
  reportOpenLoadState, retrySentence, runRetryRounds, setAutoRefreshPause, shortRunSummary,
  startAutoRefreshScheduler, withLoadLock,
} from './autorefresh.js';
import { ensureOriginPermissionConfirmed } from './confirmHost.js';
import { create, errorText, isObject, plural, str } from './dom.js';
import { MSG, STALE_WORKER_TEXT, replyError, sendRuntimeMessage } from './messaging.js';
import { setDay, setStatusFilter, setView } from './nav.js';
import { BULK_CONCURRENCY, runBulkFetch } from './search.js';
import { hooks, state } from './state.js';
import { KEY, persistQueueTracking, storageGet, storageRead } from './store.js';
// A namespace import, not a named one: tickets.js imports settings.js, which imports this module, and
// resetTicketFilters is looked up only when a run ends (long after every module has loaded), so the
// import cycle is harmless and a build without that export still loads (see resetTicketsView).
import * as ticketsView from './tickets.js';

/** Listing walks up to 100 list pages, each with its own 30 s page budget in the background: far
 * longer than messaging.js's default two minutes, which is sized for one ticket. */
const LIST_REPLY_TIMEOUT_MS = 15 * 60 * 1000;
/** messaging.js's own timeout sentence names its two-minute default, so this wait says its own length. */
const LIST_TIMEOUT_TEXT = 'The extension background did not finish listing the open tickets within 15 minutes. Narrow the queues or lower "Most tickets to load at once" in Settings, then try again.';

const $ = (id) => (typeof document !== 'undefined' && document && typeof document.getElementById === 'function'
  ? document.getElementById(id)
  : null);

const toInt = (value) => (Number.isInteger(value) && value >= 0 ? value : 0);

/** The progress text is a live region: rewriting it for every ticket would make a screen reader talk
 * non-stop, so it is updated at most this often, or per PROGRESS_STEP of the run (the bar moves freely). */
const PROGRESS_TEXT_MS = 2000;
const PROGRESS_STEP = 0.1;
/** An automatic run nobody started (it may run every 15 minutes while the person works elsewhere)
 * rewrites the live progress text far less often: at most every 30 s, and not per 10 % step. */
const QUIET_PROGRESS_TEXT_MS = 30 * 1000;

// ---------------------------------------------------------------------------------------------
// Pure helpers (exported for tests/opentickets.test.mjs)
// ---------------------------------------------------------------------------------------------

/**
 * The assignment groups of the saved views, cleaned the same way saved queues are (trimmed,
 * case-insensitively de-duplicated, entries with ^ dropped). Never throws.
 * @param {*} savedViews settings.savedViews
 * @returns {string[]}
 */
export function queuesFromSavedViews(savedViews) {
  const groups = [];
  if (Array.isArray(savedViews)) {
    for (const view of savedViews) {
      if (isObject(view) && Array.isArray(view.assignmentGroups)) groups.push(...view.assignmentGroups);
    }
  }
  return normalizeOpenTicketsConfig({ queues: groups }).queues;
}

const entryKey = (text) => String(text).replace(/\s+/g, ' ').trim().toLowerCase();

/** Why the extra filter was not used, per lib/openTickets.js describeExtraQueryProblem, as the status
 * line says it: the owner must learn WHAT to change, not just that the filter is gone. */
const EXTRA_QUERY_PROBLEMS = {
  'too-long': 'the extra filter was longer than 500 characters and was not used',
  'new-query': 'the extra filter was not used: "NQ" starts a second query that would ignore the queues and states',
  'or-first': 'the extra filter was not used: it starts with "OR", which would OR it with the queues (an "^OR" inside it is fine)',
  orderby: 'the extra filter was not used: it contains "ORDERBY" (the list is already sorted by number, which paging relies on)',
};

/** Why normalizeOpenTicketsConfig left a typed entry out (mirrors its rules, for the status line). */
function dropReason(entry) {
  if (entry.includes('^')) return 'contains "^"';
  if (entry.replace(/\s+/g, ' ').trim().length > 100) return 'longer than 100 characters';
  return 'over the limit of entries';
}

/** Typed entries that did not make it into `kept` (duplicates are merged, not reported as dropped). */
function droppedEntries(typed, kept) {
  const keptKeys = new Set(kept.map(entryKey));
  const reported = new Set();
  const dropped = [];
  for (const entry of typed) {
    const key = entryKey(entry);
    if (keptKeys.has(key) || reported.has(key)) continue;
    reported.add(key);
    dropped.push({ entry, reason: dropReason(entry) });
  }
  return dropped;
}

/**
 * Reads the Settings form's raw texts into a config, and says what could not be used as typed.
 * Queues are one per line; states are comma- (or line-) separated; an empty states box means "every
 * open state" (an explicit []), never the defaults.
 * @param {{queuesText?: string, statesText?: string, maxText?: string, extraQuery?: string}} form
 * @returns {{config: {queues: string[], states: string[], maxTickets: number, extraQuery: string},
 *   droppedQueues: {entry: string, reason: string}[], droppedStates: {entry: string, reason: string}[], notes: string[]}}
 */
export function parseOpenTicketsForm(form) {
  const source = isObject(form) ? form : {};
  const queues = str(source.queuesText).split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
  const states = str(source.statesText).split(/[,\r\n]+/).map((s) => s.trim()).filter(Boolean);
  const maxText = str(source.maxText).trim();
  const extraRaw = str(source.extraQuery).trim();
  const notes = [];

  let maxTickets = DEFAULT_MAX_TICKETS;
  if (maxText) {
    const n = /^\d+$/.test(maxText) ? Number(maxText) : NaN;
    if (!Number.isInteger(n)) notes.push(`"Most tickets" must be a whole number from 1 to ${MAX_TICKETS_LIMIT}; ${DEFAULT_MAX_TICKETS} is used`);
    else maxTickets = n;
  }
  // Only the four fields this form edits: the auto refresh setting and the retry rounds are carried
  // over from the saved config at save time (withRunnerSettings), never reset by this form.
  const clean = normalizeOpenTicketsConfig({ queues, states, maxTickets, extraQuery: extraRaw });
  const config = {
    queues: clean.queues, states: clean.states, maxTickets: clean.maxTickets, extraQuery: clean.extraQuery,
  };
  if (Number.isInteger(maxTickets) && maxText && config.maxTickets !== maxTickets) {
    notes.push(`"Most tickets" was limited to ${config.maxTickets}`);
  }
  // Only a real problem is reported: a filter of nothing but '^' or blanks simply means "no filter".
  const extraProblem = describeExtraQueryProblem(extraRaw);
  if (extraProblem) notes.push(EXTRA_QUERY_PROBLEMS[extraProblem]);
  return {
    config,
    droppedQueues: droppedEntries(queues, config.queues),
    droppedStates: droppedEntries(states, config.states),
    notes,
  };
}

/**
 * The status line after Save: what was saved, and every entry or value that could not be used.
 * @param {ReturnType<typeof parseOpenTicketsForm>} parsed
 * @returns {{state: 'ok'|'warn', text: string}}
 */
export function describeOpenTicketsSave(parsed) {
  const { config, droppedQueues, droppedStates, notes } = parsed;
  const parts = [];
  parts.push(config.queues.length
    ? `Saved ${plural(config.queues.length, 'queue', 'queues')}`
    : 'Saved, but with no queue: "Load all open tickets" needs at least one');
  parts.push(config.states.length ? `states: ${config.states.join(', ')}` : 'every open state is loaded');
  parts.push(`at most ${config.maxTickets} tickets per run`);
  const problems = [
    ...droppedQueues.map((d) => `queue "${d.entry}" (${d.reason})`),
    ...droppedStates.map((d) => `state "${d.entry}" (${d.reason})`),
  ];
  let text = `${parts.join('; ')}.`;
  if (problems.length) text += ` Not used: ${problems.join(', ')}.`;
  if (notes.length) text += ` Note: ${notes.join('; ')}.`;
  return { state: problems.length || notes.length || !config.queues.length ? 'warn' : 'ok', text };
}

/**
 * The end-of-run summary shown in #loadOpenResult. Total: never throws, whatever it is given.
 * @param {*} listResult the LIST_OPEN_INCIDENTS result ({numbers, listed, keptByState, skippedByState,
 *   pages, total, truncated})
 * @param {*} outcomes runBulkFetch() outcomes ({number, outcome: 'ok'|'notfound'|'login'|'cancelled'|'error'})
 * @param {{cancelled?: boolean, maxTickets?: number, rechecked?: object[], retry?: object, queue?: object,
 *   trackingFailed?: boolean}} [options] `rechecked`: the runBulkFetch() outcomes of re-reading the stored
 *   tickets the list no longer shows; `retry`: {retried, recovered, stillFailing, rounds} of the retry
 *   rounds (v0.5, autorefresh.js retrySentence); `queue`: applyListRun's {entered, movedOut, reentered};
 *   `trackingFailed`: the queue tracking could not be saved
 * @returns {string}
 */
export function summariseOpenLoad(listResult, outcomes, options = {}) {
  const list = isObject(listResult) ? listResult : {};
  const opts = isObject(options) ? options : {};
  const done = Array.isArray(outcomes) ? outcomes.filter(isObject) : [];
  const count = (kind) => done.filter((o) => o.outcome === kind).length;
  const listed = toInt(list.listed);
  const kept = toInt(list.keptByState);
  const skipped = toInt(list.skippedByState);
  const pages = toInt(list.pages);
  const lines = [];

  let first = `Listed ${plural(listed, 'open ticket', 'open tickets')}`;
  if (pages) first += ` from ${plural(pages, 'list page', 'list pages')}`;
  if (Number.isInteger(list.total) && list.total > listed) first += ` (ServiceNow reports ${list.total} in all)`;
  lines.push(`${first}.`);
  lines.push(`Kept by state: ${kept}${skipped ? ` (${skipped} skipped: their state is not one of the saved states)` : ''}.`);

  if (done.length) {
    const results = [`Fetched OK: ${count('ok')}`, `not found: ${count('notfound')}`, `errors: ${count('error')}`];
    const notFetched = count('cancelled') + count('login');
    if (notFetched) results.push(`not fetched: ${notFetched}`);
    lines.push(`${results.join(', ')}.`);
    if (count('login')) lines.push('ServiceNow asked for a login: log in to ServiceNow in a normal tab, then load again.');
  } else if (kept === 0) {
    lines.push('Nothing to fetch.');
  }
  if (isObject(opts.retry)) {
    const retryText = retrySentence(opts.retry);
    if (retryText) lines.push(retryText);
  }
  const rechecked = Array.isArray(opts.rechecked) ? opts.rechecked.filter(isObject) : [];
  if (rechecked.length) lines.push(`${recheckSentence(rechecked)}.`);
  if (isObject(opts.queue)) {
    const queueText = queueChangeSentence(opts.queue);
    if (queueText) lines.push(queueText);
  }
  if (opts.trackingFailed === true) lines.push('The queue tracking (new / moved out, fetch errors) could not be saved this time.');
  if (opts.cancelled) lines.push('Cancelled: no further tickets were started.');
  if (list.truncated === true) {
    const cap = Number.isInteger(opts.maxTickets) && opts.maxTickets > 0 ? opts.maxTickets : 0;
    const numbers = Array.isArray(list.numbers) ? list.numbers.length : 0;
    // The background stops at the cap as soon as it is full, whether or not another open ticket
    // follows: "may exist" is all that is known. Otherwise the page limit (or a list that would not
    // page) ended the run.
    lines.push(cap && Math.max(kept, numbers) >= cap
      ? `The "Most tickets to load at once" limit (${cap}) was reached; more open tickets may exist. Raise it in Settings -> "Open tickets to load", or narrow the queues.`
      : 'The list was not read to the end (the page limit was reached, or ServiceNow did not page further); more open tickets may exist. Narrow the queues, or add an extra filter in Settings -> "Open tickets to load".');
  }
  return lines.join(' ');
}

/**
 * "Re-checked 3 tickets that are no longer listed as open (1 could not be read)", from the outcomes.
 * Tickets that were never started (Cancel, or the pool stopping at a login page) are not counted as
 * re-checked or as unreadable: they were not tried, and saying so tells the owner a rerun is needed.
 */
function recheckSentence(rechecked) {
  const notTried = rechecked.filter((o) => o.outcome === 'cancelled').length;
  const login = rechecked.some((o) => o.outcome === 'login');
  const tried = rechecked.length - notTried;
  const failed = rechecked.filter((o) => o.outcome !== 'ok' && o.outcome !== 'cancelled').length;
  let text = `Re-checked ${plural(tried, 'ticket that is', 'tickets that are')} no longer listed as open`;
  if (failed) text += ` (${failed} could not be read${login ? ': ServiceNow asked for a login' : ''})`;
  if (notTried) text += `; ${notTried} not re-checked`;
  return text;
}

/** "Fetching 37 of 120 ... (5 in progress)" for the progress line; `verb` names a re-check phase. */
export function fetchProgressText({ total, done, active, verb } = {}) {
  const all = toInt(total);
  const finished = toInt(done);
  const running = Array.isArray(active) ? active.length : 0;
  const what = typeof verb === 'string' && verb ? verb : 'Fetching';
  return `${what} ${finished} of ${all} ...${running ? ` (${running} in progress)` : ''}`;
}

/**
 * Whether the progress TEXT (a live region) should be rewritten now: the first update, the last one
 * (done === total), PROGRESS_TEXT_MS after the previous one, or once the run moved on by PROGRESS_STEP
 * of its total. In between only the <progress> bar moves, which screen readers do not announce.
 * @param {{at: number, done: number} | null} last the previous text update (null = none yet)
 * @param {{total?: number, done?: number}} progress
 * @param {number} now ms
 * @param {{quiet?: boolean}} [options] `quiet` (an automatic run): at most every QUIET_PROGRESS_TEXT_MS,
 *   no 10 % steps, so a run in the background does not keep a screen reader talking for minutes
 * @returns {boolean}
 */
export function progressTextDue(last, progress, now, options = {}) {
  if (!isObject(last) || !Number.isFinite(last.at) || !Number.isFinite(now)) return true;
  const quiet = isObject(options) && options.quiet === true;
  const total = toInt(isObject(progress) ? progress.total : 0);
  const done = toInt(isObject(progress) ? progress.done : 0);
  if (total && done >= total) return true;
  if (now - last.at >= (quiet ? QUIET_PROGRESS_TEXT_MS : PROGRESS_TEXT_MS)) return true;
  return !quiet && total > 0 && (done - toInt(last.done)) / total >= PROGRESS_STEP;
}

// ---------------------------------------------------------------------------------------------
// Settings -> "Open tickets to load"
// ---------------------------------------------------------------------------------------------

let saveDeps = { save: async () => {} };
let saveWired = false; // dashboard/settings.js handed its save in (else setAutoRefresh writes storage itself)
let savingSettings = false;
// The last SAVED config this page knows of (painted from settings.js), so the header button can decide
// "no queues yet" without an await ahead of the permission request (that would lose the user gesture).
let savedConfig = null;
// What the form was last filled from. dashboard.js repaints the Settings view every minute (and on any
// storage change): refilling the form each time would wipe what the owner is typing, so it is only
// refilled when what it would show changed, or when asked to (after a save).
let paintedKey = null;
// Set by any input / change in the form, cleared by a save. While set, NOTHING refills the form, not
// even `force` (another Settings form's Save repaints every section): the owner's unsaved edit wins.
let formDirty = false;

/** The form fields whose edits count as unsaved changes. */
// setOpenRetryRounds is optional: when dashboard.html has no such field, the saved value is kept.
const FORM_FIELDS = ['setOpenQueues', 'setOpenStates', 'setOpenMax', 'setOpenExtraQuery', 'setOpenRetryRounds'];
const UNSAVED_TEXT = 'Unsaved changes - click "Save open-ticket settings" to use them.';
/** Why the default state list has both spellings; the static help under the states box cannot say it. */
const STATES_NOTE = 'On a standard ServiceNow instance "Open" is called "New" and "Pending" is called "On Hold"; '
  + 'the default states list both names, so renamed states are matched too.';

function setValue(id, value) {
  const node = $(id);
  if (node) node.value = value;
}

function valueOf(id) {
  const node = $(id);
  return node ? str(node.value) : '';
}

function setOpenStatus(stateName, message) {
  const node = $('setOpenStatus');
  if (!node) return;
  if (node.dataset) node.dataset.state = stateName;
  // Only a changed text is written: the line is a live region and a repaint must not re-announce it.
  if (node.textContent !== message) node.textContent = message;
}

/**
 * Fill the "Open tickets to load" form from the effective settings. With no saved queue the box is
 * prefilled from the saved views' assignment groups, and the hint says that this is NOT saved yet.
 * Safe to call before the panel exists (missing elements are skipped). Unless `force` is set, a form
 * already filled from the same values is left alone, so a periodic repaint never wipes unsaved typing.
 * While the owner has unsaved edits (formDirty) the form is never refilled, `force` or not: the status
 * line says that the edits still need a save instead.
 * @param {*} settings the normalised serviceNowSettings
 * @param {{force?: boolean}} [options]
 */
export function paintOpenTicketsSettings(settings, { force = false } = {}) {
  const source = isObject(settings) ? settings : {};
  const config = normalizeOpenTicketsConfig(source.openTickets);
  savedConfig = config;
  noteAutoRefreshConfig(config.autoRefresh);
  noteStatusTimeZone(effectiveTimeZone(source));
  if (formDirty) {
    setOpenStatus('warn', UNSAVED_TEXT);
    return;
  }
  const key = JSON.stringify([config, config.queues.length ? [] : queuesFromSavedViews(source.savedViews)]);
  if (!force && key === paintedKey) return;
  paintedKey = key;
  let queues = config.queues;
  let hint = config.queues.length
    ? `${plural(config.queues.length, 'queue', 'queues')} saved.`
    : 'No queue saved yet: add the assignment groups whose open tickets you want, one per line, then click "Save open-ticket settings".';
  if (!queues.length) {
    const fromViews = queuesFromSavedViews(source.savedViews);
    if (fromViews.length) {
      queues = fromViews;
      hint = 'Filled in from the assignment groups of your saved views - not saved yet. Check the list, then click "Save open-ticket settings".';
    }
  }
  hint += ` ${STATES_NOTE}`;
  setValue('setOpenQueues', queues.join('\n'));
  setValue('setOpenStates', config.states.join(', '));
  setValue('setOpenMax', String(config.maxTickets));
  setValue('setOpenExtraQuery', config.extraQuery);
  setValue('setOpenRetryRounds', String(normalizeRetryRounds(config.retryRounds)));
  const hintNode = $('setOpenQueuesHint');
  if (hintNode) hintNode.textContent = hint;
}

async function onSaveOpenTickets() {
  if (savingSettings) return;
  savingSettings = true;
  const button = $('setOpenSave');
  if (button) button.disabled = true;
  // Cleared BEFORE the save, because save() repaints the form with the saved, cleaned values (force)
  // and a dirty form would refuse that. An edit typed while the save runs sets it again.
  const wasDirty = formDirty;
  formDirty = false;
  try {
    const parsed = parseOpenTicketsForm({
      queuesText: valueOf('setOpenQueues'),
      statesText: valueOf('setOpenStates'),
      maxText: valueOf('setOpenMax'),
      extraQuery: valueOf('setOpenExtraQuery'),
    });
    await saveDeps.save(withRunnerSettings(parsed.config));
    const { state: stateName, text } = describeOpenTicketsSave(parsed);
    // An edit typed while the save ran is not part of what was saved: say so, or it looks saved.
    if (formDirty) setOpenStatus('warn', `${text} ${UNSAVED_TEXT}`);
    else setOpenStatus(stateName, text);
  } catch (err) {
    formDirty = formDirty || wasDirty; // nothing was saved: the edits are still unsaved
    setOpenStatus('error', `Could not save: ${errorText(err)}.`);
  } finally {
    savingSettings = false;
    if (button) button.disabled = false;
  }
}

/**
 * The form only holds queues, states, the maximum and the extra filter: the auto refresh setting (edited
 * on the Overview) and the retry rounds are carried over from the saved config, or a Save here would
 * quietly switch auto refresh off. An optional #setOpenRetryRounds field (0-5) wins when it exists.
 * @param {object} formConfig parseOpenTicketsForm().config
 * @returns {object} the openTickets value to save
 */
function withRunnerSettings(formConfig) {
  const out = { ...formConfig };
  if (savedConfig && isObject(savedConfig.autoRefresh)) out.autoRefresh = { ...savedConfig.autoRefresh };
  if (savedConfig && Number.isInteger(savedConfig.retryRounds)) out.retryRounds = savedConfig.retryRounds;
  const retryText = $('setOpenRetryRounds') ? valueOf('setOpenRetryRounds').trim() : '';
  if (/^\d+$/.test(retryText)) out.retryRounds = normalizeRetryRounds(Number(retryText));
  return out;
}

/**
 * Attach the section's listener. `options.save(openTickets)` persists a new config (dashboard/settings.js
 * owns the settings object and its storage) and repaints the form.
 */
export function wireOpenTicketsSettings(options) {
  saveDeps = { ...saveDeps, ...(isObject(options) ? options : {}) };
  if (isObject(options) && typeof options.save === 'function') saveWired = true;
  const button = $('setOpenSave');
  if (button) button.addEventListener('click', () => void onSaveOpenTickets());
  for (const id of FORM_FIELDS) {
    const field = $(id);
    if (!field || typeof field.addEventListener !== 'function') continue;
    field.addEventListener('input', onFormEdited);
    field.addEventListener('change', onFormEdited);
  }
}

/** Any edit marks the form dirty; the note is written once, on the first edit, not per keystroke. */
function onFormEdited() {
  if (formDirty) return;
  formDirty = true;
  setOpenStatus('warn', UNSAVED_TEXT);
}

// ---------------------------------------------------------------------------------------------
// The run: header button, auto refresh and retry
// ---------------------------------------------------------------------------------------------

let running = false; // claimed synchronously at the start of a run, before any await
let runKind = ''; // '' | 'manual' | 'auto' | 'retry'
let phase = ''; // '' | 'list' | 'fetch' | 'retry' | 'recheck': what Cancel can still stop
let cancelRequested = false;
let storedOrigin = ''; // chrome.storage.local instanceUrl, read ahead of any click (see runOpenTicketsLoad)
/** Test seam (configureOpenTicketsRunner): the pause before each retry round. */
let retryPauseMs = RETRY_PAUSE_MS;

const panel = () => ({
  btn: $('loadOpenBtn'),
  root: $('loadOpenPanel'),
  text: $('loadOpenText'),
  bar: $('loadOpenBar'),
  result: $('loadOpenResult'),
  cancel: $('loadOpenCancel'),
  close: $('loadOpenClose'),
});

/** The progress line. An automatic run says so, so a panel that appears by itself explains itself. */
function showText(message) {
  const p = panel();
  if (p.root) p.root.hidden = false;
  const text = runKind === 'auto' ? `Auto refresh: ${message}` : message;
  if (p.text && p.text.textContent !== text) p.text.textContent = text;
}

function setBar(value, max) {
  const { bar } = panel();
  if (!bar) return;
  if (value === null) {
    bar.removeAttribute('value'); // indeterminate while the list is being read
    return;
  }
  bar.max = Math.max(1, max);
  bar.value = Math.min(value, Math.max(1, max));
}

function showResult(content) {
  const { result } = panel();
  if (!result) return;
  if (typeof content === 'string') result.textContent = content;
  else result.replaceChildren(...content);
  result.hidden = false;
}

/** Focus `node` when it can take it; never throws (a missing or hidden node is simply skipped). */
function focusNode(node) {
  if (!node || node.hidden || node.disabled || typeof node.focus !== 'function') return false;
  try {
    node.focus();
    return true;
  } catch {
    return false;
  }
}

/**
 * Whether the keyboard focus is somewhere the end of a run should move it from: inside the panel, on
 * the (disabled) header button, or lost to <body> because the focused Cancel button was just hidden.
 */
function focusInRunControls() {
  if (typeof document === 'undefined' || !document) return false;
  const active = document.activeElement;
  const p = panel();
  if (!active || active === document.body) return true;
  if (active === p.btn) return true;
  return focusInPanel();
}

/** Whether the person put the focus inside the panel themselves (e.g. on Cancel during an auto run). */
function focusInPanel() {
  if (typeof document === 'undefined' || !document) return false;
  const active = document.activeElement;
  const { root } = panel();
  return Boolean(active && root && typeof root.contains === 'function' && root.contains(active));
}

/** Whether the focus is ON the header button or inside the panel (not merely lost to <body>). */
function focusOnRunControls() {
  if (typeof document === 'undefined' || !document) return false;
  const active = document.activeElement;
  if (!active || active === document.body) return false;
  return active === panel().btn || focusInPanel();
}

/** After a run: Close when the panel is open, else the header button. */
function focusAfterRun() {
  const p = panel();
  if (p.root && !p.root.hidden && focusNode(p.close)) return;
  focusNode(p.btn);
}

/** The header button and the panel's buttons while a run is (not) in progress. */
function setRunningUi(busy) {
  const p = panel();
  if (p.btn) {
    p.btn.disabled = busy;
    if (busy) p.btn.setAttribute('aria-busy', 'true');
    else p.btn.removeAttribute('aria-busy');
  }
  // No aria-busy on the panel: screen readers hold back a busy region's live updates until it is
  // done, which would silence the progress line (role=status) for the whole run.
  if (p.root) p.root.removeAttribute('aria-busy');
  if (p.cancel) {
    p.cancel.hidden = !busy;
    p.cancel.disabled = false;
  }
  if (p.close) p.close.hidden = busy;
}

function resetPanel() {
  const p = panel();
  if (p.root) p.root.hidden = false;
  if (p.result) {
    p.result.hidden = true;
    p.result.replaceChildren();
  }
  setBar(0, 1);
}

/** The message (and a way to get there) when no queue is saved: nothing else happens. */
function showNoQueues(config) {
  resetPanel();
  showText('No queues are saved for "Load all open tickets" yet.');
  const settingsLink = create('button', 'btn btn-sm btn-secondary', 'Open Settings');
  settingsLink.type = 'button';
  settingsLink.addEventListener('click', () => {
    setView('settings');
    const box = $('setOpenQueues');
    if (box) box.focus();
  });
  const fromViews = config && config.prefilled
    ? ' The assignment groups of your saved views are already filled in there, but they are not saved: check them and click "Save open-ticket settings".'
    : '';
  showResult([`Add your queues (assignment groups) in Settings -> "Open tickets to load" and click "Save open-ticket settings": only saved queues are used. Then click the button again.${fromViews} `, settingsLink]);
  const { close } = panel();
  if (close) close.hidden = false;
}

/** The instance to list: the search box when it holds a valid address, else the remembered one. */
function originNow() {
  const input = $('searchInstanceUrl');
  const typed = input ? parseInstanceUrl(input.value) : { ok: false };
  if (typed.ok) return typed.origin;
  const stored = parseInstanceUrl(storedOrigin);
  return stored.ok ? stored.origin : '';
}

/**
 * The instance an automatic run lists: the remembered address (chrome.storage.local instanceUrl, re-read
 * just before: another tab may have changed it), else the instance of the last recorded run (shared by
 * every tab), else a valid address in the search box. A half-typed address in the search box must not
 * steer a run nobody started, so it comes last.
 */
function autoOrigin() {
  const stored = parseInstanceUrl(storedOrigin);
  if (stored.ok) return stored.origin;
  const tracking = state.data && isObject(state.data.queueTracking) ? state.data.queueTracking : null;
  const runs = tracking && Array.isArray(tracking.runs) ? tracking.runs : [];
  const last = parseInstanceUrl(isObject(runs[0]) ? str(runs[0].origin) : '');
  if (last.ok) return last.origin;
  return originNow();
}

/** The instance the failed tickets of the last run came from ('' when unknown). */
function retryOrigin() {
  const errors = state.data && isObject(state.data.queueTracking) ? state.data.queueTracking.lastErrors : null;
  const parsed = parseInstanceUrl(isObject(errors) ? str(errors.origin) : '');
  return parsed.ok ? parsed.origin : '';
}

async function readStoredOrigin() {
  try {
    const stored = (await chrome.storage.local.get([KEY.instanceUrl])) || {};
    storedOrigin = str(stored[KEY.instanceUrl]);
  } catch {
    // Not readable: the search box is the only source then.
  }
  return storedOrigin;
}

async function readSavedConfig() {
  try {
    const stored = (await chrome.storage.local.get([SETTINGS_STORAGE_KEY])) || {};
    return normalizeServiceNowSettings(stored[SETTINGS_STORAGE_KEY]).openTickets;
  } catch {
    return normalizeOpenTicketsConfig(undefined);
  }
}

async function rememberInstance(origin) {
  try {
    await chrome.storage.local.set({ [KEY.instanceUrl]: origin });
    storedOrigin = origin;
  } catch {
    // A convenience only; the run does not depend on it.
  }
}

/** chrome.permissions.contains for an origin pattern; false when it cannot be asked. Never prompts. */
async function hasPermission(pattern) {
  try {
    return Boolean(await chrome.permissions.contains({ origins: [pattern] }));
  } catch {
    return false;
  }
}

/** Why an automatic run cannot start ('' when it can): address, saved queues, granted permission. */
async function autoPreflight(origin) {
  const config = savedConfig || (await readSavedConfig());
  const parsed = parseInstanceUrl(origin);
  const permitted = parsed.ok ? await hasPermission(parsed.pattern) : false;
  return autoRefreshPreflight({
    origin: parsed.ok ? parsed.origin : '', queues: config.queues, permitted, host: parsed.ok ? parsed.host : '',
  });
}

/** Phase and progress, for this panel and for dashboard/autorefresh.js's status. */
function setPhase(next, total = 0) {
  phase = next;
  reportOpenLoadState({ phase: next, done: 0, total: toInt(total) });
}

/** Phase 1. Resolves with { list } or, after showing why there is none, { error: {code, message} }. */
async function listOpenTickets(origin, config) {
  showText('Listing open tickets in ServiceNow ... a background tab opens for a while and pages through the list.');
  setBar(null);
  const { reply, failure } = await sendRuntimeMessage(
    { type: 'LIST_OPEN_INCIDENTS', instanceUrl: origin, config },
    { timeoutMs: LIST_REPLY_TIMEOUT_MS },
  );
  if (failure) {
    const text = failure === MSG.timeout ? LIST_TIMEOUT_TEXT : failure;
    showText(text);
    return { error: { code: 'NO_RESPONSE', message: text } };
  }
  if (reply === undefined) {
    showText(STALE_WORKER_TEXT);
    return { error: { code: 'STALE_WORKER', message: STALE_WORKER_TEXT } };
  }
  if (!isObject(reply) || !reply.ok || !isObject(reply.result)) {
    const text = replyError(reply, 'The open tickets could not be listed.');
    showText(text);
    const code = isObject(reply) && isObject(reply.error) ? str(reply.error.code) : '';
    return { error: { code, message: text } };
  }
  const result = reply.result;
  return { list: { ...result, numbers: Array.isArray(result.numbers) ? result.numbers.filter((n) => typeof n === 'string' && n) : [] } };
}

/**
 * A runBulkFetch fetchOne that RE-READS a stored ticket (source 'refresh': its search bookkeeping stays
 * as it is, and a failure only marks the stored record instead of replacing it). Resolves with the
 * error ({message, code}) or null, like search.js's own fetchOne.
 */
function refreshOne(origin) {
  return async (incidentNumber) => {
    const { reply, failure } = await sendRuntimeMessage({
      type: 'FETCH_INCIDENT', instanceUrl: origin, incidentNumber, source: 'refresh',
    });
    if (failure) return { message: failure, code: 'NO_RESPONSE' };
    if (isObject(reply) && reply.ok) return null;
    const error = isObject(reply) && isObject(reply.error) ? reply.error : {};
    return { message: replyError(reply, 'The incident could not be re-read.'), code: str(error.code) };
  };
}

/**
 * Phases 2 to 4: the same rolling pool as the bulk fetch, with this panel's own cancel flag. The bar
 * follows every ticket; the text (a live region) only as often as progressTextDue allows.
 */
async function fetchNumbers(origin, numbers, { verb = 'Fetching', fetchOne, concurrency = BULK_CONCURRENCY } = {}) {
  let last = null;
  const announce = (progress) => {
    const now = Date.now();
    if (!progressTextDue(last, progress, now, { quiet: runKind === 'auto' })) return;
    last = { at: now, done: toInt(progress.done) };
    showText(fetchProgressText({ ...progress, verb }));
  };
  announce({ total: numbers.length, done: 0, active: [] });
  setBar(0, numbers.length);
  reportOpenLoadState({ done: 0, total: numbers.length });
  const options = {
    isCancelled: () => cancelRequested,
    concurrency,
    onProgress: (progress) => {
      setBar(progress.done, progress.total);
      announce(progress);
      reportOpenLoadState({ done: toInt(progress.done), total: toInt(progress.total) });
    },
  };
  if (fetchOne) options.fetchOne = fetchOne;
  return runBulkFetch(numbers, origin, options);
}

/** Waits `ms`, in short steps so Cancel ends the wait early. */
async function pauseUnlessCancelled(ms) {
  const end = Date.now() + Math.max(0, ms);
  while (!cancelRequested && Date.now() < end) {
    // eslint-disable-next-line no-await-in-loop -- a cancellable sleep
    await new Promise((resolve) => { setTimeout(resolve, Math.min(200, Math.max(0, end - Date.now()))); });
  }
}

/** Phase 3: the automatic retry rounds for the tickets whose fetch failed with an error. */
function retryFailed(origin, outcomes, rounds, attempts) {
  return runRetryRounds(outcomes, {
    rounds,
    attempts,
    isStopped: () => cancelRequested,
    wait: () => pauseUnlessCancelled(retryPauseMs),
    onRound: ({ round, rounds: total, numbers, phase: step }) => {
      if (step !== 'wait') return;
      setPhase('retry', numbers.length);
      setBar(0, numbers.length);
      const seconds = Math.round(retryPauseMs / 1000);
      showText(`${plural(numbers.length, 'ticket', 'tickets')} could not be fetched: trying again${seconds ? ` in ${plural(seconds, 'second', 'seconds')}` : ''} (round ${round} of ${total}) ...`);
    },
    fetchRound: (numbers, round) => fetchNumbers(origin, numbers, {
      verb: `Retrying (round ${round} of ${rounds}):`, concurrency: RETRY_CONCURRENCY,
    }),
  });
}

/** The stored incidents, fresh from storage (phase 2 just wrote to it), else what the page holds. */
async function storedIncidents() {
  const stored = await storageGet([KEY.incidents]);
  if (stored && Object.prototype.hasOwnProperty.call(stored, KEY.incidents)) return stored[KEY.incidents];
  return state.data.incidents;
}

/** Phase 4: re-read the stored tickets of these queues that the list no longer shows. */
async function recheckUnlisted(origin, config, listed) {
  const numbers = ticketsNoLongerListed(await storedIncidents(), {
    queues: config.queues, states: config.states, listed: listed.numbers, origin, max: config.maxTickets,
  });
  if (!numbers.length || cancelRequested) return [];
  setPhase('recheck', numbers.length);
  return fetchNumbers(origin, numbers, { verb: 'Re-checking tickets no longer listed as open:', fetchOne: refreshOne(origin) });
}

/**
 * The LIST result with `kept` (ticketsStillInQueue) appended to its numbers for queue tracking only;
 * their assignment group comes from the stored ticket in listRowsForTracking.
 */
export function withKeptTickets(listed, kept) {
  if (!isObject(listed) || !Array.isArray(kept) || !kept.length) return listed;
  const numbers = Array.isArray(listed.numbers) ? listed.numbers : [];
  const have = new Set(numbers.map((n) => String(n).toUpperCase()));
  const extra = kept.filter((n) => typeof n === 'string' && !have.has(n.toUpperCase()));
  return extra.length ? { ...listed, numbers: [...numbers, ...extra] } : listed;
}

/**
 * The kept rows of the list for lib/queueTracking.js applyListRun, in list order: the LIST result's
 * rows (v0.5 background) where it has them, else the number with the stored ticket's assignment group
 * (an older background answers numbers only; with one saved queue that queue is the group).
 */
export function listRowsForTracking(listed, { queues = [], records = null } = {}) {
  const list = isObject(listed) ? listed : {};
  const numbers = Array.isArray(list.numbers) ? list.numbers.filter((n) => typeof n === 'string' && n) : [];
  const byNumber = new Map();
  for (const row of Array.isArray(list.rows) ? list.rows : []) {
    if (isObject(row) && typeof row.number === 'string' && row.number && !byNumber.has(row.number)) byNumber.set(row.number, row);
  }
  const onlyQueue = Array.isArray(queues) && queues.length === 1 ? str(queues[0]) : '';
  const storedGroup = (number) => {
    const record = records && typeof records.get === 'function' ? records.get(number) : null;
    return isObject(record) && isObject(record.details) ? str(record.details.assignmentGroup) : '';
  };
  return numbers.map((number) => {
    const row = byNumber.get(number);
    if (row) {
      return {
        number,
        assignmentGroup: str(row.assignmentGroup) || storedGroup(number) || onlyQueue,
        state: str(row.state),
        cells: isObject(row.cells) ? row.cells : {},
      };
    }
    return { number, assignmentGroup: storedGroup(number) || onlyQueue, state: '', cells: {} };
  });
}

/**
 * Phase 5: record the run in the queue tracking (one read-modify-write). Resolves with
 * { saved, changes } (changes = applyListRun's {entered, movedOut, reentered}); never rejects.
 */
async function saveListRun({ origin, config, listed, at, auto, complete, outcomes, failedItems, recovered }) {
  if (typeof queueLib.applyListRun !== 'function') return { saved: false, changes: null, skipped: true };
  const rows = listRowsForTracking(listed, { queues: config.queues, records: state.records });
  const rowsByNumber = {};
  for (const row of rows) rowsByNumber[row.number] = { cells: row.cells };
  const tried = Array.isArray(outcomes) ? outcomes.filter((o) => isObject(o) && o.outcome !== 'cancelled' && o.outcome !== 'login') : [];
  const fetchRan = tried.length > 0;
  // Listed tickets this run never really tried (Cancel, or the pool stopping at a login page).
  const untried = new Set((Array.isArray(outcomes) ? outcomes : [])
    .filter((o) => isObject(o) && (o.outcome === 'cancelled' || o.outcome === 'login')).map((o) => o.number));
  let changes = null;
  try {
    await persistQueueTracking((current) => {
      const applied = queueLib.applyListRun(current, {
        at, origin, queues: config.queues, rows, complete, auto,
      });
      if (!isObject(applied) || !isObject(applied.tracking)) return undefined;
      changes = applied;
      let next = applied.tracking;
      // A run that fetched nothing (cancelled before, every ticket skipped) says nothing about the
      // tickets that failed last time: their entries on the Fetch errors tab stay.
      if (fetchRan && typeof queueLib.recordFetchResult === 'function') {
        // recordFetchResult REPLACES the list: an earlier failure of a ticket this run listed but never
        // tried (cut short) is carried over as it was, or it would vanish without ever being fetched.
        const failedNow = new Set(failedItems.map((item) => item.number));
        const previous = isObject(current.lastErrors) && current.lastErrors.origin === origin && Array.isArray(current.lastErrors.items)
          ? current.lastErrors.items : [];
        const carried = previous.filter((item) => isObject(item) && untried.has(item.number) && !failedNow.has(item.number));
        next = queueLib.recordFetchResult(next, {
          at,
          origin,
          fetched: outcomes.filter((o) => o.outcome === 'ok').length,
          retried: recovered,
          failedItems: [...failedItems, ...carried],
          rowsByNumber,
          columnLabels: isObject(listed.columnLabels) ? listed.columnLabels : {},
          // the list's column order (an array: object keys arrive sorted through runtime messaging)
          columnOrder: Array.isArray(listed.columnOrder) ? listed.columnOrder : [],
        });
      }
      if (typeof queueLib.pruneQueueTracking === 'function') next = queueLib.pruneQueueTracking(next, new Date());
      // When the whole run ended: the auto refresh interval counts from here (autorefresh.js lastRunAtOf).
      if (isObject(next) && Array.isArray(next.runs)) {
        const finishedAt = new Date().toISOString();
        let marked = false;
        next = {
          ...next,
          runs: next.runs.map((run) => {
            if (marked || !isObject(run) || run.at !== at) return run;
            marked = true;
            return { ...run, finishedAt };
          }),
        };
      }
      return isObject(next) ? next : undefined;
    });
    return { saved: Boolean(changes), changes };
  } catch {
    return { saved: false, changes: null };
  }
}

/** resetTicketFilters (dashboard/tickets.js) when this build has it; never throws. */
function resetTicketsView() {
  try {
    if (typeof ticketsView.resetTicketFilters === 'function') ticketsView.resetTicketFilters();
  } catch {
    // A filter that cannot be reset only means fewer of the loaded tickets are visible.
  }
}

/** Every Tickets filter that could hide what was loaded: cleared, then today and every status. */
function applyLoadedFilters() {
  resetTicketsView();
  setDay('today');
  setStatusFilter('all');
}

function showLoadedButton() {
  const show = create('button', 'btn btn-sm btn-secondary', 'Show loaded tickets');
  show.type = 'button';
  show.addEventListener('click', () => {
    applyLoadedFilters();
    setView('tickets', { focusTab: true });
  });
  return show;
}

function showErrorsButton() {
  const show = create('button', 'btn btn-sm btn-secondary', 'Show fetch errors');
  show.type = 'button';
  show.addEventListener('click', () => setView('errors', { focusTab: true }));
  return show;
}

/**
 * Show what was loaded. After a run from the header button (or "Refresh now") the filters are reset,
 * but the view only changes when the owner is already on Tickets: a run takes minutes, and yanking
 * someone out of Settings or History when it ends would lose their place. Elsewhere a "Show loaded
 * tickets" button does it on request. An automatic run never touches the filters or the view: it only
 * offers the button.
 * @param {string} kind 'manual' | 'auto'
 * @returns {Promise<HTMLElement|null>} the button to add to the result, or null
 */
async function revealLoaded(kind) {
  try {
    await hooks.render();
  } catch {
    // The storage listener repaints anyway; the filters below still apply.
  }
  if (kind !== 'manual') return showLoadedButton();
  applyLoadedFilters();
  if (state.view === 'tickets') return null;
  return showLoadedButton();
}

/** The sentence #loadOpenText (role=status) ends on, so the outcome itself is announced. */
function finalText(listed, outcomes, rechecked, stoppedForLogin, failed = 0) {
  const ok = outcomes.filter((o) => o.outcome === 'ok').length;
  const all = listed.numbers.length;
  let text;
  if (!all) text = cancelRequested ? 'Cancelled before any ticket was fetched.' : 'No open tickets matched the saved queues and states.';
  else if (cancelRequested) text = `Cancelled: ${ok} of ${all} fetched.`;
  else if (stoppedForLogin) text = `Stopped: ServiceNow asked for a login. ${ok} of ${all} fetched.`;
  else if (failed) text = `Finished: ${ok} of ${all} fetched; ${failed} could not be fetched (see the Fetch errors tab).`;
  else text = `Finished: ${ok} of ${all} fetched.`;
  if (rechecked.length) text += ` ${recheckSentence(rechecked)}.`;
  return text;
}

/** Phases 1-5 for 'manual' and 'auto'. Resolves with { summary } (the one-line lastSummary). */
async function runLoadBody(origin, { kind }) {
  const auto = kind === 'auto';
  if (!auto) await rememberInstance(origin);
  const config = savedConfig || (await readSavedConfig());
  if (!config.queues.length) {
    if (auto) {
      setAutoRefreshPause('preflight', PAUSE_TEXT.noQueues);
      showText(`${PAUSE_TEXT.noQueues}.`);
      return { summary: '' };
    }
    setRunningUi(false);
    showNoQueues({ prefilled: Boolean(valueOf('setOpenQueues').trim()) });
    return { summary: '' };
  }
  if (cancelRequested) {
    showText('Cancelled: nothing was listed or fetched.');
    return { summary: 'Cancelled: nothing was listed or fetched' };
  }
  setPhase('list');
  const listing = await listOpenTickets(origin, config);
  if (listing.error) {
    if (listing.error.code === 'LOGIN_REQUIRED') setAutoRefreshPause('login', '', Date.now());
    return { summary: listing.error.message };
  }
  const listed = listing.list;
  const listedAt = new Date().toISOString();
  let outcomes = [];
  if (!cancelRequested && listed.numbers.length) {
    setPhase('fetch', listed.numbers.length);
    outcomes = await fetchNumbers(origin, listed.numbers);
  }
  const retry = await retryFailed(origin, outcomes, normalizeRetryRounds(config.retryRounds));
  outcomes = retry.outcomes;
  const stoppedForLogin = retry.stoppedForLogin;
  // "Not in the list" only means "no longer open" when the list was read to the end and every
  // listed ticket was fetched; a cut-short run would re-read tickets that are still open.
  const rechecked = cancelRequested || stoppedForLogin || listed.truncated === true
    ? []
    : await recheckUnlisted(origin, config, listed);
  const loginSeen = stoppedForLogin || rechecked.some((o) => o.outcome === 'login');
  const failedItems = failedItemsOf(outcomes, retry.attempts);
  // A list row whose number could not be read (unreadableRows, background.js) is a ticket the run did not
  // see: such a run must not mark anything moved out.
  const complete = listed.truncated !== true && !cancelRequested && !stoppedForLogin && !(Number(listed.unreadableRows) > 0);
  // A re-checked ticket that is still open in a saved queue (or could not be re-read) was missed by the
  // list (paging shift, a short list): it stays in the queue instead of being marked moved out.
  const keptNumbers = rechecked.length
    ? ticketsStillInQueue(await storedIncidents(), rechecked, {
      queues: config.queues, states: config.states, listed: listed.numbers, origin,
    })
    : [];
  const tracking = await saveListRun({
    origin, config, listed: withKeptTickets(listed, keptNumbers), at: listedAt, auto, complete, outcomes, failedItems, recovered: retry.recovered.length,
  });
  if (loginSeen) setAutoRefreshPause('login', '', Date.now());

  showText(finalText(listed, outcomes, rechecked, stoppedForLogin, failedItems.length));
  setBar(1, 1);
  const summary = summariseOpenLoad(listed, outcomes, {
    cancelled: cancelRequested,
    maxTickets: config.maxTickets,
    rechecked,
    retry: { retried: retry.retried.length, recovered: retry.recovered.length, stillFailing: failedItems.length, rounds: retry.roundsRun },
    queue: tracking.changes,
    trackingFailed: !tracking.saved && !tracking.skipped,
  });
  const fetchedAny = outcomes.some((o) => o.outcome === 'ok') || rechecked.some((o) => o.outcome === 'ok');
  const extras = [];
  const show = fetchedAny ? await revealLoaded(kind) : null;
  if (show) extras.push(show);
  if (failedItems.length) extras.push(showErrorsButton());
  showResult(extras.length ? [`${summary} `, ...extras] : summary);
  return {
    summary: shortRunSummary({
      listed: listed.numbers.length,
      fetched: outcomes.filter((o) => o.outcome === 'ok').length,
      recovered: retry.recovered.length,
      stillFailing: failedItems.length,
      notFetched: outcomes.filter((o) => o.outcome === 'cancelled' || o.outcome === 'login').length,
      cancelled: cancelRequested,
      stoppedForLogin,
      truncated: listed.truncated === true,
    }),
    ok: outcomes.filter((o) => o.outcome === 'ok').length,
    failed: failedItems.length,
  };
}

/**
 * 'retry': fetch the given failed tickets once more (one pass, 2 at a time), then the automatic retry
 * rounds, and update the Fetch errors list (resolveErrors / updateErrors). Tickets that were not tried
 * (Cancel, a login page) keep their entries as they are.
 */
async function runRetryBody(origin, requested) {
  const tracking = state.data && isObject(state.data.queueTracking) ? state.data.queueTracking : {};
  const items = isObject(tracking.lastErrors) && Array.isArray(tracking.lastErrors.items) ? tracking.lastErrors.items.filter(isObject) : [];
  const known = new Map(items.map((item) => [str(item.number), item]));
  const wanted = Array.isArray(requested) ? requested.map((n) => str(n).toUpperCase()).filter(Boolean) : [...known.keys()];
  const numbers = [...new Set(wanted)].filter(Boolean);
  if (!numbers.length) {
    showText('No ticket is waiting for a retry.');
    setBar(1, 1);
    return { summary: 'Nothing to retry', ok: 0, failed: 0 };
  }
  const config = savedConfig || (await readSavedConfig());
  setPhase('retry', numbers.length);
  const first = await fetchNumbers(origin, numbers, {
    verb: 'Retrying tickets that could not be fetched:', concurrency: RETRY_CONCURRENCY,
  });
  // Attempts so far: those recorded on the Fetch errors tab, plus this pass for every ticket tried.
  const attempts = {};
  for (const o of first) {
    const before = known.get(o.number);
    const prior = before && Number.isInteger(before.attempts) && before.attempts > 0 ? before.attempts : 1;
    if (o.outcome !== 'cancelled' && o.outcome !== 'login') attempts[o.number] = prior + 1;
    else if (prior) attempts[o.number] = prior;
  }
  const retry = await retryFailed(origin, first, normalizeRetryRounds(config.retryRounds), attempts);
  const final = retry.outcomes;
  const okNumbers = final.filter((o) => o.outcome === 'ok').map((o) => o.number);
  const stillFailing = failedItemsOf(final, retry.attempts);
  const at = new Date().toISOString();
  let saved = false;
  try {
    await persistQueueTracking((current) => {
      let next = current;
      if (okNumbers.length && typeof queueLib.resolveErrors === 'function') next = queueLib.resolveErrors(next, okNumbers, at);
      if (stillFailing.length && typeof queueLib.updateErrors === 'function') next = queueLib.updateErrors(next, stillFailing, at);
      return next === current ? undefined : next;
    });
    saved = true;
  } catch {
    saved = false;
  }
  if (retry.stoppedForLogin) setAutoRefreshPause('login', '', Date.now());
  const notTried = final.filter((o) => o.outcome === 'cancelled' || o.outcome === 'login').length;
  let text = `Retried ${plural(numbers.length, 'ticket', 'tickets')}: ${okNumbers.length} fetched`;
  if (stillFailing.length) text += `, ${stillFailing.length} still failing`;
  if (notTried) text += `, ${notTried} not tried${retry.stoppedForLogin ? ' (ServiceNow asked for a login)' : ''}`;
  text += '.';
  showText(text);
  setBar(1, 1);
  let result = text;
  if (!saved) result += ' The Fetch errors list could not be updated this time.';
  const extras = [];
  if (okNumbers.length) {
    try {
      await hooks.render();
    } catch {
      // the storage listener repaints anyway
    }
    extras.push(showLoadedButton());
  }
  showResult(extras.length ? [`${result} `, ...extras] : result);
  // `failed`: every ticket still on the Fetch errors list (still failing, or not tried this time).
  return { summary: text.replace(/\.$/, ''), ok: okNumbers.length, failed: stillFailing.length + notTried };
}

/**
 * THE run of "Load all open tickets", shared by the header button, auto refresh and the Fetch errors
 * tab's retry. One at a time per browser profile: in this tab by a flag claimed before any await,
 * across tabs by the Web Lock of dashboard/autorefresh.js.
 *   kind 'manual' (default): the header button, or autorefresh.refreshNow() with moveFocus false. May
 *     ask for the host permission, so it must be called straight from a click: the permission request
 *     is the FIRST awaited work, or the browser drops the user gesture it needs.
 *   kind 'auto': the scheduler. Never asks for a permission (a missing one, no address or no queue
 *     pauses auto refresh with a reason), never moves focus, never switches view, never resets filters.
 *   kind 'retry': `numbers` (default: every ticket on the Fetch errors tab) of the last run's origin.
 * @param {{kind?: 'manual'|'auto'|'retry', moveFocus?: boolean, numbers?: string[]}} [options]
 * @returns {Promise<{started: boolean, reason?: string, summary?: string, ok?: number, failed?: number}>}
 */
export async function runOpenTicketsLoad(options = {}) {
  const opts = isObject(options) ? options : {};
  const kind = opts.kind === 'auto' || opts.kind === 'retry' ? opts.kind : 'manual';
  const auto = kind === 'auto';
  // Only the header button moves focus to Cancel by default: "Refresh now" (Overview) and the Fetch
  // errors tab's retry are clicked in a view whose own button keeps focus (aria-disabled), so they
  // must not pull it up to the page-level panel; an automatic run never moves it.
  const moveFocus = kind === 'manual' ? opts.moveFocus !== false : (kind === 'retry' && opts.moveFocus === true);
  if (running) return { started: false, reason: 'A load of the open tickets is already running in this tab.' };
  // Decided synchronously, from what this page already knows (see the permission note above).
  const origin = kind === 'retry' ? (retryOrigin() || originNow()) : originNow();
  if (kind === 'manual' && savedConfig && !savedConfig.queues.length) {
    showNoQueues({ prefilled: Boolean(valueOf('setOpenQueues').trim()) });
    return { started: false, reason: PAUSE_TEXT.noQueues };
  }
  running = true;
  runKind = kind;
  cancelRequested = false;
  let uiStarted = false;
  let summary = null;
  const startUi = () => {
    if (uiStarted) return;
    uiStarted = true;
    // Focus that sits on the header button (about to be disabled) or inside the panel (Close is about to
    // be hidden, the previous result cleared) would drop to <body>: even a run the person did not start
    // puts it on Cancel then, the control that takes the same place. Focus anywhere else stays put.
    const rescueFocus = !moveFocus && focusOnRunControls();
    resetPanel();
    setRunningUi(true);
    // The header button is now disabled, so focus would otherwise be lost: Cancel is the next useful control.
    if (moveFocus || rescueFocus) focusNode(panel().cancel);
  };
  try {
    let runOrigin = origin;
    if (auto) {
      await readStoredOrigin();
      runOrigin = autoOrigin();
      const reason = await autoPreflight(runOrigin);
      if (reason) {
        setAutoRefreshPause('preflight', reason);
        return { started: false, reason };
      }
    } else {
      startUi();
      if (!origin) {
        showText('Enter your ServiceNow address in the search box first (for example https://yourcompany.service-now.com).');
        return { started: false, reason: PAUSE_TEXT.noOrigin };
      }
      const permission = await ensureOriginPermissionConfirmed(origin);
      if (!permission.ok) {
        showText(permission.message);
        return { started: false, reason: permission.message };
      }
      runOrigin = permission.origin;
      if (kind === 'manual') {
        const input = $('searchInstanceUrl');
        if (input) input.value = permission.origin;
      }
    }
    const locked = await withLoadLock(async () => {
      if (kind !== 'retry') noteRunAttempt(Date.now());
      reportOpenLoadState({ running: true, auto, phase: '', done: 0, total: 0 });
      startUi();
      return kind === 'retry' ? runRetryBody(runOrigin, opts.numbers) : runLoadBody(runOrigin, { kind });
    });
    if (!locked.acquired) {
      if (auto) setAutoRefreshPause('busy', PAUSE_TEXT.busy);
      else showText(`${PAUSE_TEXT.busy}. Try again when it has finished.`);
      return { started: false, reason: PAUSE_TEXT.busy };
    }
    const value = isObject(locked.value) ? locked.value : {};
    if (typeof value.summary === 'string' && value.summary) summary = value.summary;
    return { started: true, ...value };
  } catch (err) {
    const text = `Loading the open tickets failed: ${errorText(err)}`;
    if (uiStarted) showText(text);
    summary = text;
    return { started: true, reason: text };
  } finally {
    // Read before setRunningUi hides Cancel: a focused Cancel that disappears leaves focus on <body>.
    // A run the person did not start moves focus only when they put it inside the panel themselves.
    const moveFocusAfter = uiStarted && (moveFocus ? focusInRunControls() : focusInPanel());
    if (uiStarted) setRunningUi(false);
    running = false;
    runKind = '';
    phase = '';
    cancelRequested = false;
    reportOpenLoadState(summary === null
      ? { running: false, auto: false, phase: '' }
      : { running: false, auto: false, phase: '', lastSummary: summary });
    if (moveFocusAfter) focusAfterRun();
  }
}

/**
 * Save serviceNowSettings.openTickets.autoRefresh (dashboard/autorefresh.js setAutoRefresh) through the
 * same save the Settings section uses, so every other setting (saved views, field mapping, the rest of
 * openTickets) is kept. Rejects when the settings could not be read or written.
 */
async function saveAutoRefresh(autoRefresh) {
  const clean = normalizeAutoRefreshConfig(autoRefresh);
  const readSettings = async () => normalizeServiceNowSettings((await storageRead([SETTINGS_STORAGE_KEY]))[SETTINGS_STORAGE_KEY]);
  if (saveWired) {
    const current = savedConfig || (await readSettings()).openTickets;
    await saveDeps.save({ ...current, autoRefresh: clean });
    return;
  }
  const settings = await readSettings(); // a failed read throws: never write over a guess
  await chrome.storage.local.set({
    [SETTINGS_STORAGE_KEY]: normalizeServiceNowSettings({ ...settings, openTickets: { ...settings.openTickets, autoRefresh: clean } }),
  });
}

registerOpenTicketsRunner({ run: runOpenTicketsLoad, save: saveAutoRefresh });

/**
 * Test seam: shorten the pause before each retry round (tests and the dev/e2e mock only).
 * @param {{retryPauseMs?: number}} options
 */
export function configureOpenTicketsRunner(options) {
  if (isObject(options) && Number.isFinite(options.retryPauseMs) && options.retryPauseMs >= 0) retryPauseMs = options.retryPauseMs;
}

function onCancel() {
  if (!running) return;
  cancelRequested = true;
  const { cancel } = panel();
  if (cancel) cancel.disabled = true;
  // The listing runs in the background worker and cannot be interrupted: say so instead of promising
  // a stop that only happens once the list has been read.
  if (phase === 'fetch' || phase === 'recheck' || phase === 'retry') showText('Cancelling: no new tickets will start; the ones already being fetched will finish ...');
  else if (phase === 'list') showText('Cancelling: the ServiceNow list is still being read (that step cannot be interrupted); no ticket will be fetched afterwards ...');
  else showText('Cancelling ...');
}

function onClose() {
  if (running) return;
  const { root, btn } = panel();
  if (root) root.hidden = true;
  focusNode(btn); // the focused Close button just disappeared with the panel
}

/**
 * Attach the header button and the progress panel's listeners, and start the auto refresh scheduler
 * (dashboard/autorefresh.js; it only runs when auto refresh is switched on). The button part is a
 * no-op when the markup is missing.
 */
export function wireLoadOpenTickets() {
  startAutoRefreshScheduler();
  // Read ahead so a click with an empty search box can still request the permission at once.
  void readStoredOrigin();
  const p = panel();
  if (!p.btn) return;
  p.btn.addEventListener('click', () => void runOpenTicketsLoad({ kind: 'manual' }));
  if (p.cancel) p.cancel.addEventListener('click', onCancel);
  if (p.close) p.close.addEventListener('click', onClose);
}
