// The Overview view (v0.4): a dashboard of every OPEN ticket stored in this browser. Top to bottom:
// a heading with what the numbers mean and a "Queues" scope picker (assignment groups, multi-select),
// six KPI tiles, the Status split, the Last-updated buckets, a Ticket-age-by-priority table and a
// By-agent table (last-updated buckets, age buckets and the agent's own updates split into the user's
// business / off hours). Every number is a button that opens the Tickets table filtered to exactly
// those tickets (dashboard/tickets.js applyTicketFilters).
//
// Data flow: dashboard.js paint() calls paintOverview(now, timeZone, rowsOfDay, businessHours). The rows
// it passes are filtered by the Tickets view's "Searched" day filter, but the Overview must cover EVERY
// stored open ticket, so this module builds its own rows (lib/dashboardModel.js buildRows with day
// 'all'), cached until the stored incidents (by identity), the minute, the time zone or the business
// hours change; lib/metrics.js computeOverview turns them into counts. Both are pure; this module only
// turns their output into DOM.
//
// The DOM is built with dom.js's create()/setText() only (ServiceNow text is untrusted: textContent and
// setAttribute, never HTML). The page repaints every 60 seconds, so each section keeps a signature of
// what it shows and is rebuilt only when that changes; when it is rebuilt, focus goes back to the same
// logical control (data-drill keys), and the scrolling table wrappers are kept, so their sideways
// scroll position survives too. Bar lengths and heat shading are CSS custom properties set through the
// CSSOM (element.style.setProperty), which the extension's CSP allows; no inline style attributes.
//
// The pure helpers (cache, share rounding, drill filters, table models) are exported for
// tests/overview.test.mjs. This module touches the DOM only inside wireOverview()/paintOverview(), so it
// can be imported under node with a stub document.
//
// v0.5 adds, above the v0.4 content:
//  - the "Auto refresh" bar: an on/off switch, the interval (15 minutes to 2 hours in steps of 15), what
//    the last refresh did and when the next one is due, live progress while a run is going, and a
//    "Refresh now" button. The scheduler and the run itself live in dashboard/autorefresh.js (the only
//    module this view talks to for it); this view only shows its status and forwards the person's
//    choices. The status line is a role=status region, but the parts that move by themselves (the
//    "12 min ago" and the running counts) are aria-hidden children, so the 60-second repaint and every
//    fetched ticket do not make a screen reader talk: only a real change (a run starts, ends, pauses,
//    the next time moves) is announced. The <progress> next to it carries the counts for anyone who asks.
//  - four more tiles: tickets that entered the queue in the past 24 hours and tickets that moved out of
//    it (lib/queueTracking.js, through lib/metrics.js computeOverview), the unassigned tickets, and the
//    number of agents with a red flag (dashboard/redflags.js), which switches to the Red flags tab.
// The rows are built with the queue tracking object (state.data.queueTracking), so a ticket that moved
// out of the queue is not counted as open anywhere on this page (computeOverview leaves it out).
import { buildRows } from '../lib/dashboardModel.js';
import {
  AGE_BUCKETS, AGE_UNKNOWN, UPDATED_BUCKETS, UPDATED_NONE, computeOverview,
} from '../lib/metrics.js';
// Namespace imports, not named ones (same reasoning as dashboard/opentickets.js): every export of these
// is looked up only when it is used, so a build where one of them is missing still loads this view.
// autorefresh.js is the auto refresh scheduler and the shared "Load all open tickets" run; redflags.js
// imports this module, so the cycle is harmless only because neither touches the other at load time.
import * as autoRefresh from './autorefresh.js';
import { create, errorText, isObject, plural, setText, str } from './dom.js';
import { createMultiSelect } from './multiselect.js';
import { setView } from './nav.js';
import * as redFlagsView from './redflags.js';
import { hooks, state } from './state.js';
// A namespace import, not a named one (same reasoning as dashboard/opentickets.js): applyTicketFilters
// is looked up only when a drill button is clicked, so a tickets.js without it still loads this view.
import * as ticketsView from './tickets.js';

/** localStorage key of the chosen queues (a per-viewer convenience, never chrome.storage). */
export const OVERVIEW_QUEUES_STORAGE = 'snicOverviewQueues';
/** Most queue names remembered, and the longest name kept (garbage in localStorage stays bounded). */
const STORED_GROUPS_MAX = 200;
const STORED_GROUP_CHARS = 200;

const NO_GROUP_LABEL = 'No assignment group';
const UNASSIGNED_LABEL = 'Unassigned';
const DRILL_HINT = 'Opens the Tickets table showing these tickets.';
const DRILL_TITLE = 'Show these tickets in the Tickets table';

/** Short column headings of the By-agent table (the full label is read to screen readers). */
const UPDATED_SHORT = { h24: 'Past 24h', h48: '24–48h', d5: '2–5 days', older: '>5 days', none: 'None' };
const AGE_SHORT = { lt3: '<3d', d3to5: '3–5d', d5to10: '5–10d', d10to30: '10–30d', gt30: '>30d', unknown: 'Unknown' };
/** Colour of each Last-updated bar (always next to its label and count, never the only signal). */
const UPDATED_TONE = { h24: 'green', h48: 'amber', d5: 'red', older: 'red', none: 'grey' };
const SPLIT_COLUMNS = [
  { key: 'business', label: 'Business hours' },
  { key: 'off', label: 'Off hours' },
  { key: 'unknown', label: 'Unknown' },
];

// ---- pure helpers ----

const count = (value) => (Number.isFinite(value) && value > 0 ? Math.floor(value) : 0);
const listOf = (value) => (Array.isArray(value) ? value : []);

/**
 * Share of `part` in `total` as a percentage for a bar's length: 0..100, 0 when total is not positive.
 * @param {number} part
 * @param {number} total
 * @returns {number}
 */
export function sharePercent(part, total) {
  const p = count(part);
  const t = count(total);
  if (!t) return 0;
  return Math.min(100, (p / t) * 100);
}

/**
 * Share as text: whole percent, but never '0%' for a non-zero part ('<1%') and never '100%' for a
 * part smaller than the total ('>99%'), so the text cannot contradict the count next to it.
 * @param {number} part
 * @param {number} total
 * @returns {string}
 */
export function shareText(part, total) {
  const p = count(part);
  const t = count(total);
  if (!t || !p) return '0%';
  if (p >= t) return '100%';
  const rounded = Math.round((p / t) * 100);
  if (rounded < 1) return '<1%';
  if (rounded > 99) return '>99%';
  return `${rounded}%`;
}

/**
 * Heat of one table cell, 0..1 in steps of 0.05 (0 for an empty cell): the cell's count against the
 * largest count of the table. A non-zero count is at least 0.1, so it is always visibly shaded.
 * @param {number} value
 * @param {number} max
 * @returns {number}
 */
export function heatLevel(value, max) {
  const v = count(value);
  const m = count(max);
  if (!v || !m) return 0;
  return Math.max(0.1, Math.round(Math.min(1, v / m) * 20) / 20);
}

/** Stable text of a business-hours setting (sorted keys), '' for nothing usable. */
function businessHoursSignature(businessHours) {
  try {
    return JSON.stringify(businessHours, (key, value) => (isObject(value)
      ? Object.fromEntries(Object.keys(value).sort().map((k) => [k, value[k]]))
      : value)) || '';
  } catch {
    return '';
  }
}

/**
 * Key of the rows cache besides the incidents' identity: the minute of `now`, the time zone and the
 * business hours. Ages and "updated N hours ago" move with the clock, so a new minute rebuilds.
 * @param {Date} now
 * @param {string} timeZone
 * @param {object} businessHours
 * @returns {string}
 */
export function rowsCacheKey(now, timeZone, businessHours) {
  const time = now instanceof Date ? now.getTime() : NaN;
  const minute = Number.isFinite(time) ? Math.floor(time / 60000) : 'x';
  return `${minute}|${str(timeZone)}|${businessHoursSignature(businessHours)}`;
}

/** A fresh, empty rows cache (one per page; tests make their own). */
export function createRowsCache() {
  return { incidents: undefined, queueTracking: undefined, key: '', rows: [] };
}

/**
 * Rows of EVERY stored ticket (day 'all'), rebuilt only when the stored incidents object or the queue
 * tracking object (by identity: store.js replaces them, never mutates them), the minute, the zone or the
 * business hours changed. The sixth argument is buildRows (a function, injectable for tests) or
 * { build, queueTracking }; the queue tracking object is passed to the builder as opts.queueTracking
 * (left out when there is none, so the rows then carry no queue information). Never throws: a failing
 * build gives [].
 * @returns {object[]}
 */
export function cachedRows(cache, incidents, now, timeZone, businessHours, options = buildRows) {
  const opts = typeof options === 'function' ? { build: options } : isObject(options) ? options : {};
  const build = typeof opts.build === 'function' ? opts.build : buildRows;
  const { queueTracking } = opts;
  const key = rowsCacheKey(now, timeZone, businessHours);
  if (cache.incidents === incidents && cache.queueTracking === queueTracking && cache.key === key) return cache.rows;
  let rows;
  try {
    const buildOpts = { businessHours, timeZone, day: 'all' };
    if (queueTracking !== undefined) buildOpts.queueTracking = queueTracking;
    rows = build(incidents, now, buildOpts);
  } catch {
    rows = [];
  }
  cache.incidents = incidents;
  cache.queueTracking = queueTracking;
  cache.key = key;
  cache.rows = Array.isArray(rows) ? rows : [];
  return cache.rows;
}

/**
 * The queues read back from localStorage: an array of distinct strings, bounded; [] for anything else.
 * @param {string|null} text
 * @returns {string[]}
 */
export function parseStoredGroups(text) {
  let value;
  try {
    value = JSON.parse(typeof text === 'string' ? text : 'null');
  } catch {
    return [];
  }
  if (!Array.isArray(value)) return [];
  const seen = new Set();
  for (const item of value) {
    if (typeof item !== 'string' || item.length > STORED_GROUP_CHARS) continue;
    seen.add(item);
    if (seen.size >= STORED_GROUPS_MAX) break;
  }
  return [...seen];
}

/**
 * The chosen queues that still exist among the open tickets, in the order of `available`. A remembered
 * queue with no open ticket right now is ignored (not forgotten: it counts again once tickets return),
 * and nothing left means all queues.
 * @param {string[]} chosen
 * @param {{name:string}[]} available computeOverview's `groups`
 * @returns {string[]}
 */
export function effectiveGroups(chosen, available) {
  const wanted = new Set(listOf(chosen).filter((name) => typeof name === 'string'));
  if (!wanted.size) return [];
  return listOf(available)
    .map((group) => (isObject(group) ? group.name : undefined))
    .filter((name) => typeof name === 'string' && wanted.has(name));
}

/**
 * The filter object for applyTicketFilters: always open tickets only, in the chosen queues (none =
 * all), plus `extra` (e.g. { age: ['gt30'] }). A fresh object every time.
 * @param {string[]} groups
 * @param {object} [extra]
 * @returns {object}
 */
export function drillFilter(groups, extra = {}) {
  // notMovedOut: the Overview's numbers leave out tickets that moved out of the queue (lib/metrics.js),
  // openOnly alone would also list a ticket that moved out but is still open (reassigned, left the list).
  const filter = { openOnly: true, queue: ['notMovedOut'] };
  const chosen = listOf(groups).filter((name) => typeof name === 'string');
  if (chosen.length) filter.group = [...chosen];
  for (const [key, value] of Object.entries(isObject(extra) ? extra : {})) {
    filter[key] = Array.isArray(value) ? [...value] : isObject(value) ? { ...value } : value;
  }
  return filter;
}

// The State / group / agent values a drill sends are the rows' own trimmed text: lib/metrics.js groups by
// exactly the text lib/ticketFilters.js matches, so a count and the list it opens always agree.

/**
 * The Tickets "agent" filter value of one computeOverview agent entry: its key, which is the row's
 * assignedTo text ('' for the Unassigned bucket, the Tickets filter's value for "Unassigned"). An entry
 * without a string key falls back to its display name ('Unassigned' meaning '').
 * @param {{key?:string, agent?:string}} entry
 * @returns {string}
 */
export function agentFilterValue(entry) {
  if (!isObject(entry)) return '';
  if (typeof entry.key === 'string') return entry.key.trim();
  const name = str(entry.agent);
  return name === UNASSIGNED_LABEL ? '' : name;
}

/**
 * computeOverview's output with every field present and of the right type, so the painters below never
 * have to guard (lib/metrics.js is written to never throw, but this view must not blank out if a field
 * is missing or a newer/older shape comes through).
 * @param {object} raw
 * @returns {object}
 */
export function normalizeOverview(raw) {
  const o = isObject(raw) ? raw : {};
  const ageing = isObject(o.ageing) ? o.ageing : {};
  const totals = isObject(ageing.totals) ? ageing.totals : {};
  const split = (value) => {
    const s = isObject(value) ? value : {};
    return { business: count(s.business), off: count(s.off), unknown: count(s.unknown) };
  };
  const buckets = (value) => (isObject(value) ? value : {});
  return {
    total: count(o.total),
    vip: count(o.vip),
    followUpNow: count(o.followUpNow),
    negative: count(o.negative),
    // `value` is the State text itself ('' = no State, labelled 'No status'): the drill-down's filter value
    byStatus: listOf(o.byStatus).filter(isObject).map((s) => ({
      label: str(s.label) || 'No status', value: typeof s.value === 'string' ? s.value : str(s.label), count: count(s.count),
    })),
    updated: listOf(o.updated).filter(isObject).map((b) => ({ key: str(b.key), label: str(b.label), count: count(b.count) })),
    priorities: listOf(o.priorities).filter(isObject).map((p) => ({
      key: str(p.key), label: str(p.label) || str(p.key), rank: Number.isFinite(p.rank) ? p.rank : null,
    })).filter((p) => p.key),
    ageing: {
      rows: listOf(ageing.rows).filter(isObject).map((r) => ({
        key: str(r.key), label: str(r.label), byPriority: buckets(r.byPriority), total: count(r.total),
      })),
      totals: { byPriority: buckets(totals.byPriority), total: count(totals.total) },
    },
    agents: listOf(o.agents).filter(isObject).map((a) => ({
      key: typeof a.key === 'string' ? a.key : undefined,
      agent: str(a.agent) || UNASSIGNED_LABEL,
      total: count(a.total),
      updated: buckets(a.updated),
      ageing: buckets(a.ageing),
      updateSplit: split(a.updateSplit),
    })),
    updateSplit: split(o.updateSplit),
    groups: listOf(o.groups).filter(isObject).map((g) => ({ name: typeof g.name === 'string' ? g.name : '', count: count(g.count) })),
    // v0.5 (queue tracking): counts, or the lists of numbers they were counted from
    unassigned: countOrLength(o.unassigned),
    entered24h: countOrLength(o.entered24h),
    movedOut24h: countOrLength(o.movedOut24h),
    enteredLastRun: countOrLength(o.enteredLastRun),
    movedOutLastRun: countOrLength(o.movedOutLastRun),
    lastRunAt: isoOrNull(o.lastRunAt),
    previousRunAt: isoOrNull(o.previousRunAt),
    baselineAt: isoOrNull(o.baselineAt),
    tracked: o.tracked === true,
  };
}

/** A count given as a number or as the list it was counted from. */
function countOrLength(value) {
  return Array.isArray(value) ? value.length : count(value);
}

/** A usable instant as its ISO text, null otherwise. */
function isoOrNull(value) {
  return typeof value === 'string' && Number.isFinite(Date.parse(value)) ? value : null;
}

/** Milliseconds of an ISO text (or Date), null when unusable. */
function msOf(value) {
  if (value instanceof Date) return Number.isFinite(value.getTime()) ? value.getTime() : null;
  if (typeof value !== 'string' || !value) return null;
  const ms = Date.parse(value);
  return Number.isFinite(ms) ? ms : null;
}

/**
 * The filter object of a queue-change drill: { queue: [key] } in the chosen queues, and deliberately
 * NOT openOnly: a ticket that entered the queue and a ticket that moved out of it may both be resolved
 * by now, and they are counted all the same. A fresh object every time.
 * @param {string[]} groups
 * @param {'entered24h'|'movedOut24h'|'new'|'movedOut'|'inQueue'} key
 * @returns {object}
 */
export function queueDrillFilter(groups, key) {
  const filter = {};
  const chosen = listOf(groups).filter((name) => typeof name === 'string');
  if (chosen.length) filter.group = [...chosen];
  filter.queue = [key];
  return filter;
}

/**
 * The hint under the "Entered the queue" / "Moved out" counts: what the last refresh added, or why
 * there is nothing to compare yet. The first COMPLETE refresh of a queue is its baseline: every ticket
 * it finds was simply there already, so it does not count as entered.
 * @param {object} overview normalizeOverview output
 * @param {number} sinceLast enteredLastRun or movedOutLastRun
 * @returns {string}
 */
export function queueChangeHint(overview, sinceLast) {
  if (!overview.tracked) return 'Not refreshed yet';
  if (!overview.baselineAt) return 'No complete refresh yet';
  const baseline = msOf(overview.baselineAt);
  const last = msOf(overview.lastRunAt);
  if (!overview.previousRunAt || (baseline !== null && last !== null && baseline >= last)) return 'First refresh: baseline';
  return `+${count(sinceLast)} since the previous refresh`;
}

/**
 * The v0.5 tiles: entered the queue (past 24 h), moved out (past 24 h), unassigned and red flags.
 * The first three drill into the Tickets table; the red flags tile carries `view: 'flags'` instead of a
 * filter (it switches to the Red flags tab).
 * @param {object} overview normalizeOverview output
 * @param {string[]} groups the effective queues
 * @param {number} flaggedAgents distinct agents with a red flag (dashboard/redflags.js)
 * @returns {{key:string, label:string, count:number, hint:string, tone:string, title:string, filter?:object, view?:string}[]}
 */
export function queueTiles(overview, groups, flaggedAgents = 0) {
  const flagged = count(flaggedAgents);
  return [
    {
      key: 'entered', label: 'Entered the queue · past 24 h', count: overview.entered24h,
      hint: queueChangeHint(overview, overview.enteredLastRun), tone: 'green',
      title: 'Tickets that appeared in the saved queues in the past 24 hours, compared with the earlier refreshes (the first complete refresh is the baseline: nothing in it counts as new)',
      filter: queueDrillFilter(groups, 'entered24h'),
    },
    {
      key: 'movedOut', label: 'Moved out · past 24 h', count: overview.movedOut24h,
      hint: queueChangeHint(overview, overview.movedOutLastRun), tone: 'grey',
      title: 'Tickets a complete refresh no longer found in the saved queues in the past 24 hours (resolved, reassigned or no longer in a saved state)',
      filter: queueDrillFilter(groups, 'movedOut24h'),
    },
    {
      key: 'unassigned', label: 'Unassigned', count: overview.unassigned,
      hint: `${shareText(overview.unassigned, overview.total)} of open`, tone: 'amber',
      title: 'Open tickets in the queue with nobody in Assigned to',
      filter: drillFilter(groups, { agent: [''] }),
    },
    {
      key: 'redFlags', label: 'Red flags', count: flagged,
      hint: flagged ? `${flagged === 1 ? 'agent' : 'agents'} flagged · see Red flags` : 'No agent flagged',
      tone: flagged ? 'red' : 'green',
      title: 'Agents with many ageing tickets, tickets not updated daily, or most updates outside business hours. Opens the Red flags tab',
      view: 'flags',
    },
  ];
}

// ---- auto refresh: pure text helpers ----

/** The interval choices when autorefresh.js does not provide them (15 minutes to 2 hours, steps of 15). */
const DEFAULT_REFRESH_MINUTES = Object.freeze([15, 30, 45, 60, 75, 90, 105, 120]);

/**
 * An interval as the select shows it: 15 -> '15 min', 60 -> '1 hour', 75 -> '1 h 15 min',
 * 120 -> '2 hours'. Never throws ('' for anything that is not a positive whole number).
 * @param {number} minutes
 * @returns {string}
 */
export function intervalLabel(minutes) {
  if (!Number.isInteger(minutes) || minutes <= 0) return '';
  const hours = Math.floor(minutes / 60);
  const rest = minutes % 60;
  if (!hours) return `${rest} min`;
  if (!rest) return hours === 1 ? '1 hour' : `${hours} hours`;
  return `${hours} h ${rest} min`;
}

/**
 * The interval <select> options: autorefresh.js's AUTO_REFRESH_MINUTES (the defaults when that is not a
 * usable list), as { value: '15', label: '15 min' }.
 * @param {*} [minutesList]
 * @returns {{value:string, label:string}[]}
 */
export function intervalOptions(minutesList) {
  const list = Array.isArray(minutesList) && minutesList.some((m) => Number.isInteger(m) && m > 0)
    ? minutesList.filter((m) => Number.isInteger(m) && m > 0)
    : DEFAULT_REFRESH_MINUTES;
  return [...new Set(list)].map((minutes) => ({ value: String(minutes), label: intervalLabel(minutes) }));
}

const CLOCK_OPTIONS = { hour: '2-digit', minute: '2-digit', hourCycle: 'h23' };
const DAY_OPTIONS = { weekday: 'short', day: 'numeric', month: 'short' };

function formatIn(date, options, timeZone) {
  try {
    return new Intl.DateTimeFormat('en-GB', { ...options, timeZone: timeZone || undefined }).format(date);
  } catch {
    return new Intl.DateTimeFormat('en-GB', options).format(date); // an unknown zone: the browser's own
  }
}

/**
 * An instant as a clock time in `timeZone`: '10:15' on the same calendar day as `now` there, 'Tue 27 Oct
 * 10:15' on any other day; '' when the instant is unusable. Never throws.
 * @param {string|Date} value
 * @param {Date} now
 * @param {string} [timeZone]
 * @returns {string}
 */
export function formatClock(value, now, timeZone) {
  const ms = msOf(value);
  if (ms === null) return '';
  const date = new Date(ms);
  const clock = formatIn(date, CLOCK_OPTIONS, timeZone);
  const nowMs = msOf(now);
  if (nowMs !== null && formatIn(date, DAY_OPTIONS, timeZone) === formatIn(new Date(nowMs), DAY_OPTIONS, timeZone)) return clock;
  return `${formatIn(date, DAY_OPTIONS, timeZone).replace(/,/g, '')} ${clock}`;
}

/**
 * How long ago an instant was: 'just now', '12 min ago', '2 h ago', '2 h 5 min ago', '3 days ago'.
 * An instant in the future (another tab's clock) is 'just now'; '' when unusable. Never throws.
 * @param {string|Date} value
 * @param {Date} now
 * @returns {string}
 */
export function agoText(value, now) {
  const ms = msOf(value);
  const nowMs = msOf(now);
  if (ms === null || nowMs === null) return '';
  const minutes = Math.floor((nowMs - ms) / 60000);
  if (minutes < 1) return 'just now';
  if (minutes < 60) return `${minutes} min ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return minutes % 60 ? `${hours} h ${minutes % 60} min ago` : `${hours} h ago`;
  const days = Math.floor(hours / 24);
  return `${days} ${days === 1 ? 'day' : 'days'} ago`;
}

/**
 * autorefresh.js getAutoRefreshStatus() output with every field present and typed (this view must not
 * break when that module is missing or older). Never throws.
 * @param {*} raw
 * @returns {object}
 */
export function normalizeAutoStatus(raw) {
  const s = isObject(raw) ? raw : {};
  const minutes = Number.isInteger(s.minutes) && s.minutes > 0 ? s.minutes : 60;
  return {
    enabled: s.enabled === true,
    minutes,
    lastRunAt: isoOrNull(s.lastRunAt),
    nextRunAt: isoOrNull(s.nextRunAt),
    running: s.running === true,
    auto: s.auto === true,
    phase: ['list', 'fetch', 'retry', 'recheck'].includes(s.phase) ? s.phase : '',
    done: count(s.done),
    total: count(s.total),
    pausedReason: str(s.pausedReason),
    lastSummary: str(s.lastSummary),
  };
}

/**
 * The auto refresh status line, in parts: `lead` and `tail` are announced (role=status) and change only
 * when something really happens; `volatile` (the "12 min ago", the running counts) moves by itself and is
 * shown but never announced; `summary` is what the last run found; `progress` is { value, max } while a
 * run is going (max 0 = not known yet), else null.
 *   idle:    'Last refresh 10:15' + ' (12 min ago)' + ' · next at 11:15'
 *   running: 'Refreshing' + ': 120 of 275 fetched'
 *   paused:  'Auto refresh paused: ServiceNow asked for a login …'
 * @param {object} status normalizeAutoStatus output
 * @param {Date} now
 * @param {string} [timeZone]
 * @returns {{lead:string, volatile:string, tail:string, summary:string, progress:{value:number, max:number}|null}}
 */
export function autoStatusText(status, now, timeZone) {
  const s = normalizeAutoStatus(status);
  const summary = s.lastSummary;
  if (s.running) {
    const counts = s.total ? `${Math.min(s.done, s.total)} of ${s.total}` : '';
    const progress = { value: s.total ? Math.min(s.done, s.total) : 0, max: s.total };
    const kind = s.auto ? 'Auto refresh running' : 'Refreshing'; // 'Auto refresh' alone reads as a label
    if (s.phase === 'list') return { lead: `${kind}: reading the queue list in ServiceNow`, volatile: '', tail: '', summary, progress };
    if (s.phase === 'retry') return { lead: `${kind}: retrying failed tickets`, volatile: counts ? ` (${counts})` : '', tail: '', summary, progress };
    if (s.phase === 'recheck') {
      return { lead: `${kind}: re-checking tickets no longer listed`, volatile: counts ? ` (${counts})` : '', tail: '', summary, progress };
    }
    return { lead: kind, volatile: counts ? `: ${counts} fetched` : '', tail: '', summary, progress };
  }
  if (s.enabled && s.pausedReason) return { lead: `Auto refresh paused: ${s.pausedReason}`, volatile: '', tail: '', summary, progress: null };
  const lastClock = formatClock(s.lastRunAt, now, timeZone);
  const lead = lastClock ? `Last refresh ${lastClock}` : 'Not refreshed yet';
  const ago = lastClock ? agoText(s.lastRunAt, now) : '';
  let tail = '';
  if (!s.enabled) {
    tail = s.pausedReason ? ` · ${s.pausedReason}` : ' · auto refresh is off';
  } else {
    const next = msOf(s.nextRunAt);
    const nowMs = msOf(now);
    if (next !== null && nowMs !== null && next <= nowMs) tail = ' · next refresh due now';
    else if (next !== null) tail = ` · next at ${formatClock(s.nextRunAt, now, timeZone)}`;
  }
  return { lead, volatile: ago ? ` (${ago})` : '', tail, summary, progress: null };
}

/** Count of bucket `key` in a list of { key, count }. */
function bucketCount(list, key) {
  const found = listOf(list).find((item) => item.key === key);
  return found ? found.count : 0;
}

/**
 * The six KPI tiles: label, count, a hint line (share of the open tickets), a tone for the accent bar
 * and the drill filter.
 * @param {object} overview normalizeOverview output
 * @param {string[]} groups the effective queues
 * @returns {{key:string, label:string, count:number, hint:string, tone:string, title:string, filter:object}[]}
 */
export function kpiTiles(overview, groups) {
  const total = overview.total;
  const over30 = overview.ageing.rows.find((r) => r.key === 'gt30');
  const share = (value) => `${shareText(value, total)} of open`;
  const scope = groups.length ? plural(groups.length, 'queue', 'queues') : 'All queues';
  const tile = (key, label, value, tone, extra, hint, title = '') => ({
    key, label, count: value, hint, tone, title, filter: drillFilter(groups, extra),
  });
  const updated24 = bucketCount(overview.updated, 'h24');
  const aged = over30 ? over30.total : 0;
  return [
    tile('open', 'Open tickets', total, '', {}, scope),
    tile('vip', 'VIP users', overview.vip, 'amber', { quick: { vip: true } }, share(overview.vip)),
    tile('followUpNow', 'Follow up now', overview.followUpNow, 'urgent', { quick: { followUpNow: true } }, share(overview.followUpNow),
      'Assigned tickets whose user is in business hours now, where the user replied after the agent or the agent has not updated for 24 hours or more'),
    tile('updated24', 'Updated in past 24 hours', updated24, 'green', { updated: ['h24'] }, share(updated24)),
    tile('over30', 'Over 30 days old', aged, 'amber', { age: ['gt30'] }, share(aged)),
    tile('negative', 'Negative sentiment', overview.negative, 'red', { quick: { negative: true } }, share(overview.negative)),
  ];
}

/**
 * Bars of a split: one per item, with its share of `total`.
 * @param {{key:string, label:string, count:number}[]} items
 * @param {number} total
 * @returns {{key:string, label:string, count:number, share:number, shareText:string}[]}
 */
export function barsModel(items, total) {
  return listOf(items).map((item) => ({
    key: item.key,
    label: item.label,
    count: item.count,
    share: sharePercent(item.count, total),
    shareText: shareText(item.count, total),
  }));
}

/**
 * The Ticket-age-by-priority table: rows = age buckets (as computeOverview gives them: the five always,
 * 'unknown' only when present), columns = the priorities present, each cell with its count, heat and
 * drill filter; row totals, column totals and the grand total drill too.
 * @param {object} overview normalizeOverview output
 * @param {string[]} groups
 */
export function ageingTableModel(overview, groups) {
  const columns = overview.priorities.map((p) => ({ key: p.key, label: p.label }));
  let max = 0;
  for (const row of overview.ageing.rows) {
    for (const column of columns) max = Math.max(max, count(row.byPriority[column.key]));
  }
  const rows = overview.ageing.rows.map((row) => ({
    key: row.key,
    label: row.label,
    total: row.total,
    filter: drillFilter(groups, { age: [row.key] }),
    cells: columns.map((column) => {
      const value = count(row.byPriority[column.key]);
      return {
        key: column.key, count: value, heat: heatLevel(value, max),
        filter: drillFilter(groups, { age: [row.key], priority: [column.key] }),
      };
    }),
  }));
  const totals = {
    total: overview.ageing.totals.total,
    filter: drillFilter(groups),
    cells: columns.map((column) => ({
      key: column.key,
      count: count(overview.ageing.totals.byPriority[column.key]),
      filter: drillFilter(groups, { priority: [column.key] }),
    })),
  };
  return { columns, rows, totals, max };
}

/**
 * The By-agent table: the Last-updated columns (the four, plus 'None' when any open ticket has no
 * update recorded), the Age columns (the five, plus 'Unknown' when present) and the agent-updates
 * split; one row per agent and a totals row (all agents in scope).
 * @param {object} overview normalizeOverview output
 * @param {string[]} groups
 */
export function agentTableModel(overview, groups) {
  const hasNone = overview.updated.some((b) => b.key === UPDATED_NONE.key && b.count > 0);
  const hasUnknown = overview.ageing.rows.some((r) => r.key === AGE_UNKNOWN.key && r.total > 0);
  const updatedColumns = [...UPDATED_BUCKETS, ...(hasNone ? [UPDATED_NONE] : [])]
    .map((b) => ({ key: b.key, label: b.label, short: UPDATED_SHORT[b.key] || b.label }));
  const ageColumns = [...AGE_BUCKETS, ...(hasUnknown ? [AGE_UNKNOWN] : [])]
    .map((b) => ({ key: b.key, label: b.label, short: AGE_SHORT[b.key] || b.label }));
  const rows = overview.agents.map((agent) => {
    const value = agentFilterValue(agent);
    const name = agent.agent;
    return {
      key: `${value === '' ? 'unassigned' : 'agent'}:${value}`,
      name,
      value,
      total: agent.total,
      filter: drillFilter(groups, { agent: [value] }),
      updated: updatedColumns.map((column) => ({
        key: column.key, count: count(agent.updated[column.key]),
        filter: drillFilter(groups, { agent: [value], updated: [column.key] }),
      })),
      ageing: ageColumns.map((column) => ({
        key: column.key, count: count(agent.ageing[column.key]),
        filter: drillFilter(groups, { agent: [value], age: [column.key] }),
      })),
      split: SPLIT_COLUMNS.map((column) => ({ key: column.key, count: agent.updateSplit[column.key] })),
    };
  });
  const ageTotal = (key) => {
    const found = overview.ageing.rows.find((r) => r.key === key);
    return found ? found.total : 0;
  };
  const totals = {
    total: overview.total,
    filter: drillFilter(groups),
    updated: updatedColumns.map((column) => ({
      key: column.key, count: bucketCount(overview.updated, column.key), filter: drillFilter(groups, { updated: [column.key] }),
    })),
    ageing: ageColumns.map((column) => ({
      key: column.key, count: ageTotal(column.key), filter: drillFilter(groups, { age: [column.key] }),
    })),
    split: SPLIT_COLUMNS.map((column) => ({ key: column.key, count: overview.updateSplit[column.key] })),
  };
  return { updatedColumns, ageColumns, splitColumns: SPLIT_COLUMNS, rows, totals };
}

/**
 * The note under the heading. `allOpen` is the open tickets of every queue, `total` those in scope.
 * @returns {string}
 */
export function overviewNote(total, allOpen, groups, tracked = false) {
  const scope = groups.length
    ? `${plural(total, 'open ticket', 'open tickets')} in ${groups.length === 1 ? 'the chosen queue' : `the ${groups.length} chosen queues`}, of ${allOpen} stored in this browser`
    : `${plural(total, 'open ticket', 'open tickets')} stored in this browser`;
  return `${scope} (not Resolved, Closed or Canceled${tracked ? ', and not moved out of the queue' : ''}). `
    + 'Last updated = newest update written by a person; '
    + "tickets without readable activity use ServiceNow's Updated time. Business / off hours = the user's "
    + 'business hours at the moment of the update.';
}

// ---- remembered queues (localStorage, try/catch: a private window or blocked site data is fine) ----

function readStoredGroups() {
  try {
    return parseStoredGroups(globalThis.localStorage ? globalThis.localStorage.getItem(OVERVIEW_QUEUES_STORAGE) : null);
  } catch {
    return [];
  }
}

function storeGroups(groups) {
  try {
    if (!globalThis.localStorage) return;
    if (groups.length) globalThis.localStorage.setItem(OVERVIEW_QUEUES_STORAGE, JSON.stringify(groups));
    else globalThis.localStorage.removeItem(OVERVIEW_QUEUES_STORAGE);
  } catch {
    // a convenience only: the in-memory choice still applies for this page's lifetime
  }
}

// ---- module state ----

const rowsCache = createRowsCache();
const overviewMemo = { rows: null, queueTracking: undefined, key: '', value: null };
let chosenGroups = null; // read from localStorage on first use
let ui = null; // the skeleton's persistent nodes, built once
const syncSection = createSectionSync(); // section name -> signature of what it shows
let lastTimeZone = ''; // the zone of the last paint, for status updates between paints
let autoPending = null; // { enabled, minutes } while a setAutoRefresh is being saved
let unsubscribeAuto = null;

function chosen() {
  if (chosenGroups === null) chosenGroups = readStoredGroups();
  return chosenGroups;
}

/** The stored queue tracking object (lib/queueTracking.js, normalised by store.js), or undefined. */
function queueTracking() {
  return isObject(state.data) && isObject(state.data.queueTracking) ? state.data.queueTracking : undefined;
}

/**
 * The rows of every stored ticket (day 'all', with queue information), cached: the Overview and the Red
 * flags view (dashboard/redflags.js) share this one cache, so the rows are built once per minute.
 * @param {Date} now
 * @param {string} timeZone
 * @param {object} businessHours
 * @returns {object[]}
 */
export function overviewRows(now, timeZone, businessHours) {
  return cachedRows(rowsCache, state.data.incidents, now, timeZone, businessHours, { queueTracking: queueTracking() });
}

/** computeOverview, memoised per rows identity / minute / queues; never throws (an empty overview). */
function overviewOf(rows, now, groups) {
  const tracking = queueTracking();
  const key = `${rowsCacheKey(now, '', null)}|${JSON.stringify(groups)}`;
  if (overviewMemo.rows === rows && overviewMemo.queueTracking === tracking && overviewMemo.key === key) return overviewMemo.value;
  let value;
  try {
    value = normalizeOverview(computeOverview(rows, now, { groups, queueTracking: tracking }));
  } catch {
    value = normalizeOverview(null);
  }
  overviewMemo.rows = rows;
  overviewMemo.queueTracking = tracking;
  overviewMemo.key = key;
  overviewMemo.value = value;
  return value;
}

// ---- DOM: small builders ----

/** A drill-down button: data-drill is its stable logical key (focus restore), data-filter its filter. */
function drillButton(className, drillKey, filter, label) {
  const node = create('button', className);
  node.type = 'button';
  node.dataset.drill = drillKey;
  node.dataset.filter = JSON.stringify(filter);
  node.setAttribute('aria-describedby', 'ovDrillHint');
  node.title = DRILL_TITLE;
  if (label) node.setAttribute('aria-label', label);
  return node;
}

/** A count in a table cell: a drill button when non-zero, a muted 0 otherwise. */
function countCell(tag, value, drillKey, filter, label, className = '') {
  const cell = create(tag, `ov-num ${className}`.trim());
  if (value > 0 && filter) {
    const node = drillButton('ov-cell-btn', drillKey, filter, label);
    node.textContent = String(value);
    cell.append(node);
  } else {
    cell.append(create('span', 'ov-zero', String(value)));
  }
  return cell;
}

/** A header cell whose short visible text is read out as its full label. */
function shortHeader(short, full, attrs = {}) {
  const th = create('th', 'ov-th');
  for (const [name, value] of Object.entries(attrs)) th.setAttribute(name, value);
  if (short === full) {
    th.textContent = full;
  } else {
    const visible = create('span', '', short);
    visible.setAttribute('aria-hidden', 'true');
    th.title = full;
    th.append(visible, create('span', 'sr-only', full));
  }
  return th;
}

/** One card: a heading, a one-line explanation and the content host. */
function buildCard(id, title, sub, { table = false, className = '' } = {}) {
  const section = create('section', `ov-card ${className}`.trim());
  section.id = id;
  const heading = create('h3', 'ov-card-title', title);
  heading.id = `${id}Title`;
  heading.tabIndex = -1; // a fallback focus target when a rebuilt control no longer exists
  section.setAttribute('aria-labelledby', heading.id);
  const subNode = create('p', 'ov-card-sub', sub);
  let content;
  if (table) {
    // dashboard.js syncScrollRegions makes a .table-wrap a keyboard stop only while it overflows
    content = create('div', 'table-wrap ov-table-wrap');
    content.setAttribute('role', 'region');
    content.setAttribute('aria-labelledby', heading.id);
    content.tabIndex = -1;
  } else {
    content = create('div', 'ov-card-body');
  }
  section.append(heading, subNode, content);
  return { section, heading, sub: subNode, content };
}

// ---- DOM: the skeleton (built once) ----

function buildSkeleton(panel) {
  const head = create('div', 'ov-head');
  const titleBox = create('div', 'ov-title');
  const heading = create('h2', 'ov-heading', 'Open tickets overview');
  heading.id = 'ovHeading';
  const note = create('p', 'ov-note');
  note.id = 'ovNote';
  titleBox.append(heading, note);
  const scope = create('div', 'ov-scope');
  const picker = createMultiSelect({
    id: 'overviewQueues',
    label: 'Queues',
    allLabel: 'All queues',
    options: [],
    selected: chosen(),
    onChange: (values) => {
      chosenGroups = listOf(values).filter((name) => typeof name === 'string');
      storeGroups(chosenGroups);
      hooks.paint();
    },
  });
  scope.append(picker.root);
  head.append(titleBox, scope);

  const hint = create('p', 'sr-only', DRILL_HINT);
  hint.id = 'ovDrillHint';

  const empty = create('div', 'empty-state ov-empty');
  empty.hidden = true;
  const emptyTitle = create('p', 'empty-title', 'No open tickets stored yet');
  const emptyText = create('p', 'empty-text');
  const emptyBtn = create('button', 'btn btn-secondary', 'Go to “Load all open tickets”');
  emptyBtn.type = 'button';
  emptyBtn.addEventListener('click', () => {
    const target = document.getElementById('loadOpenBtn');
    if (!target) return;
    target.scrollIntoView({ block: 'nearest' });
    target.focus();
  });
  empty.append(emptyTitle, emptyText, emptyBtn);

  const body = create('div', 'ov-body');
  const kpis = create('ul', 'ov-kpis');
  kpis.setAttribute('aria-label', 'Key numbers of the open tickets');
  const grid = create('div', 'ov-grid');
  const status = buildCard('ovStatus', 'Status', 'Open tickets by their ServiceNow State.');
  const updated = buildCard('ovUpdated', 'Last updated',
    'Time since the newest update written by a person (ServiceNow\'s Updated time when no activity could be read).');
  const ageing = buildCard('ovAgeing', 'Ticket age by priority', 'Time since the ticket was opened, by priority.', { table: true });
  grid.append(status.section, updated.section, ageing.section);
  const agents = buildCard('ovAgents', 'By agent',
    'Open tickets per assigned agent. Agent updates = the agent\'s own updates on these tickets, judged against each user\'s business hours.',
    { table: true, className: 'ov-card-full' });
  body.append(kpis, grid, agents.section);

  const auto = buildAutoBar();
  // the queue-change tiles stay visible when no open ticket is left: "moved out" is exactly that case
  const queueKpis = create('ul', 'ov-kpis ov-kpis-queue');
  queueKpis.setAttribute('aria-label', 'Queue changes, unassigned tickets and red flags');

  panel.replaceChildren(head, auto.root, hint, queueKpis, empty, body);
  panel.addEventListener('click', onPanelClick);
  return {
    panel, note, picker, pickerSig: '', empty, emptyTitle, emptyText, emptyBtn, body, kpis, status, updated, ageing, agents,
    auto, queueKpis,
  };
}

/** The Auto refresh bar: switch, interval, status line (+ progress), Refresh now, and the note. */
function buildAutoBar() {
  const root = create('section', 'ov-auto');
  root.setAttribute('aria-label', 'Auto refresh');
  const controls = create('div', 'ov-auto-controls');

  const switchLabel = create('label', 'switch ov-auto-switch');
  switchLabel.htmlFor = 'ovAutoRefresh';
  const toggle = create('input');
  toggle.type = 'checkbox';
  toggle.id = 'ovAutoRefresh';
  toggle.setAttribute('role', 'switch');
  toggle.setAttribute('aria-describedby', 'ovAutoNote');
  const switchUi = create('span', 'switch-ui');
  switchUi.setAttribute('aria-hidden', 'true');
  const switchText = create('span', 'switch-text');
  switchText.append(create('strong', '', 'Auto refresh'));
  switchLabel.append(toggle, switchUi, switchText);
  toggle.addEventListener('change', () => void saveAuto({ enabled: toggle.checked }));

  const every = create('div', 'ov-auto-every');
  const everyLabel = create('label', 'ov-auto-label', 'Every');
  everyLabel.htmlFor = 'ovAutoEvery';
  const select = create('select', 'ov-auto-select');
  select.id = 'ovAutoEvery';
  for (const option of intervalOptions(autoRefresh.AUTO_REFRESH_MINUTES)) {
    const node = create('option', '', option.label);
    node.value = option.value;
    select.append(node);
  }
  select.addEventListener('change', () => void saveAuto({ minutes: Number(select.value) }));
  every.append(everyLabel, select);

  const now = create('button', 'btn btn-secondary btn-sm ov-auto-now', 'Refresh now');
  now.type = 'button';
  now.id = 'ovRefreshNow';
  now.title = 'Load all open tickets of the saved queues now (the same as the Load all open tickets button)';
  now.addEventListener('click', onRefreshNow);
  controls.append(switchLabel, every, now);

  const line = create('div', 'ov-auto-line');
  // role=status: only lead + tail + summary are read out; the moving parts are aria-hidden (module comment)
  const status = create('p', 'ov-auto-status');
  status.id = 'ovAutoStatus';
  status.setAttribute('role', 'status');
  const lead = create('span', 'ov-auto-lead');
  const moving = create('span', 'ov-auto-moving');
  moving.setAttribute('aria-hidden', 'true');
  const tail = create('span', 'ov-auto-tail');
  // the summary is a block of its own on screen; for a screen reader it would run straight on from the
  // line before it ("... auto refresh is offListed 9 ..."), so a hidden full stop separates the two
  const summarySep = create('span', 'sr-only', '. ');
  const summary = create('span', 'ov-auto-summary');
  status.append(lead, moving, tail, summarySep, summary);
  const bar = create('progress', 'ov-auto-bar');
  bar.setAttribute('aria-label', 'Refresh progress');
  bar.hidden = true;
  line.append(status, bar);

  const note = create('p', 'ov-auto-note', 'Runs while this dashboard is open in any tab.');
  note.id = 'ovAutoNote';
  root.append(controls, line, note);
  return {
    root, toggle, select, now, lead, moving, tail, summarySep, summary, bar,
  };
}

// ---- DOM: sections ----

/** The data-drill key of the focused control inside `host` (which is about to be emptied), else null. */
function focusKeyIn(host) {
  const active = document.activeElement;
  if (!active || active === host || !host.contains(active)) return null;
  return (active.dataset && active.dataset.drill) || '';
}

/**
 * A section reconciler for a view that repaints every minute: sync(name, host, sig, build, fallback)
 * rebuilds `host`'s children (build() -> nodes) only when `sig` changed since the last call for `name`,
 * and then puts focus back on the control with the same data-drill key (or on `fallback` when that
 * control is gone). Shared by the Overview, the Red flags and the Fetch errors views; each makes its own.
 * @returns {(name:string, host:HTMLElement, sig:string, build:() => Node[], fallback?:HTMLElement) => void}
 */
export function createSectionSync() {
  const sigs = new Map();
  return function sync(name, host, sig, build, fallback) {
    if (sigs.get(name) === sig) return;
    const focusKey = focusKeyIn(host);
    host.replaceChildren(...build());
    sigs.set(name, sig);
    if (focusKey === null) return;
    const match = [...host.querySelectorAll('[data-drill]')].find((node) => node.dataset.drill === focusKey);
    const target = match || fallback;
    if (target) target.focus({ preventScroll: true });
  };
}

// The v0.4 tiles are button.ov-kpi with data-drill 'kpi:<key>'; the v0.5 queue tiles look the same but
// are button.ov-tile with 'queue:<key>', so anything that counts the v0.4 tiles still finds exactly six.
function buildKpis(tiles, prefix = 'kpi') {
  const className = prefix === 'kpi' ? 'ov-kpi' : 'ov-tile';
  return tiles.map((tile) => {
    const li = create('li', 'ov-kpi-item');
    let node;
    if (tile.view) {
      // switches to another tab instead of filtering the Tickets table
      node = create('button', className);
      node.type = 'button';
      node.dataset.drill = `${prefix}:${tile.key}`;
      node.dataset.view = tile.view;
      if (tile.title) node.title = tile.title;
    } else {
      node = drillButton(className, `${prefix}:${tile.key}`, tile.filter);
      if (tile.title) node.title = `${tile.title}. ${DRILL_TITLE}`;
    }
    if (tile.tone) node.dataset.tone = tile.tone;
    node.append(
      create('span', 'ov-kpi-label', tile.label),
      create('span', 'ov-kpi-value', String(tile.count)),
      create('span', 'ov-kpi-hint', tile.hint),
    );
    li.append(node);
    return li;
  });
}

function buildBars(prefix, bars, filterOf, toneOf, emptyText) {
  if (!bars.length) return [create('p', 'ov-none', emptyText)];
  const list = create('ul', 'ov-bars');
  for (const bar of bars) {
    const li = create('li', 'ov-bar-item');
    const label = `${bar.label || 'No status'}: ${plural(bar.count, 'ticket', 'tickets')}, ${bar.shareText}`;
    const node = drillButton('ov-bar', `${prefix}:${bar.key}`, filterOf(bar), label);
    const tone = toneOf(bar);
    if (tone) node.dataset.tone = tone;
    const track = create('span', 'ov-track');
    track.setAttribute('aria-hidden', 'true');
    const fill = create('span', 'ov-fill');
    fill.style.setProperty('--ov-share', String(Math.round(bar.share * 10) / 10));
    if (bar.count > 0) fill.classList.add('is-some');
    track.append(fill);
    node.append(
      create('span', 'ov-bar-label', bar.label || 'No status'),
      track,
      create('span', 'ov-bar-count', String(bar.count)),
      create('span', 'ov-bar-share', bar.shareText),
    );
    li.append(node);
    list.append(li);
  }
  return [list];
}

function buildAgeingTable(model) {
  if (!model.rows.length) return [create('p', 'ov-none', 'No open tickets in the chosen queues.')];
  const table = create('table', 'ov-table ov-ageing');
  const caption = create('caption', 'sr-only',
    'Open tickets by age (time since opened) and priority. Each count opens the Tickets table showing those tickets.');
  const thead = create('thead');
  const headRow = create('tr');
  const corner = create('th', 'ov-th ov-rowhead', 'Age');
  corner.scope = 'col';
  headRow.append(corner);
  for (const column of model.columns) {
    const th = create('th', 'ov-th ov-num', column.label);
    th.scope = 'col';
    headRow.append(th);
  }
  const totalHead = create('th', 'ov-th ov-num ov-total', 'Total');
  totalHead.scope = 'col';
  headRow.append(totalHead);
  thead.append(headRow);

  const tbody = create('tbody');
  for (const row of model.rows) {
    const tr = create('tr');
    const th = create('th', 'ov-rowhead', row.label);
    th.scope = 'row';
    tr.append(th);
    row.cells.forEach((cell, index) => {
      const column = model.columns[index];
      const td = countCell('td', cell.count, `age:${row.key}:${cell.key}`, cell.filter,
        `${plural(cell.count, 'ticket', 'tickets')}, age ${row.label}, priority ${column.label}`, 'ov-heat');
      td.style.setProperty('--ov-heat', String(cell.heat));
      if (cell.heat > 0) td.dataset.heat = 'on';
      tr.append(td);
    });
    tr.append(countCell('td', row.total, `age:${row.key}:total`, row.filter,
      `${plural(row.total, 'ticket', 'tickets')}, age ${row.label}, all priorities`, 'ov-total'));
    tbody.append(tr);
  }
  const tfoot = create('tfoot');
  const totalRow = create('tr', 'ov-total-row');
  const totalTh = create('th', 'ov-rowhead', 'Total');
  totalTh.scope = 'row';
  totalRow.append(totalTh);
  model.totals.cells.forEach((cell, index) => {
    const column = model.columns[index];
    totalRow.append(countCell('td', cell.count, `age:total:${cell.key}`, cell.filter,
      `${plural(cell.count, 'ticket', 'tickets')}, priority ${column.label}, any age`));
  });
  totalRow.append(countCell('td', model.totals.total, 'age:total:total', model.totals.filter,
    `${plural(model.totals.total, 'open ticket', 'open tickets')} in all`, 'ov-total'));
  tfoot.append(totalRow);
  table.append(caption, thead, tbody, tfoot);
  return [table];
}

function buildAgentTable(model) {
  if (!model.rows.length) return [create('p', 'ov-none', 'No open tickets in the chosen queues.')];
  const table = create('table', 'ov-table ov-agents');
  const caption = create('caption', 'sr-only',
    'Open tickets per agent: when each was last updated, how old it is, and how many of the agent\'s own updates fell in the user\'s business hours or off hours.');
  const colgroups = [];
  const single = () => {
    const group = create('colgroup');
    group.append(create('col'));
    return group;
  };
  const spanning = (span, className) => {
    const group = create('colgroup', className);
    group.span = span;
    return group;
  };
  colgroups.push(single(), single(),
    spanning(model.updatedColumns.length, 'ov-cg-updated'),
    spanning(model.ageColumns.length, 'ov-cg-age'),
    spanning(model.splitColumns.length, 'ov-cg-split'));

  const thead = create('thead');
  const top = create('tr');
  const agentTh = create('th', 'ov-th ov-rowhead ov-sticky', 'Agent');
  agentTh.scope = 'col';
  agentTh.rowSpan = 2;
  const openTh = create('th', 'ov-th ov-num', 'Open');
  openTh.scope = 'col';
  openTh.rowSpan = 2;
  top.append(agentTh, openTh);
  for (const [label, span, className] of [
    ['Last updated', model.updatedColumns.length, 'ov-group-start'],
    ['Age', model.ageColumns.length, 'ov-group-start'],
    ['Agent updates', model.splitColumns.length, 'ov-group-start'],
  ]) {
    const th = create('th', `ov-th ov-group ${className}`, label);
    th.scope = 'colgroup';
    th.colSpan = span;
    top.append(th);
  }
  const sub = create('tr');
  const subHeaders = [
    ...model.updatedColumns.map((column, i) => [column, i === 0]),
    ...model.ageColumns.map((column, i) => [column, i === 0]),
    ...model.splitColumns.map((column, i) => [{ ...column, short: column.label }, i === 0]),
  ];
  for (const [column, first] of subHeaders) {
    const th = shortHeader(column.short, column.label, { scope: 'col' });
    th.classList.add('ov-num');
    if (first) th.classList.add('ov-group-start');
    sub.append(th);
  }
  thead.append(top, sub);

  const tbody = create('tbody');
  for (const row of model.rows) {
    const tr = create('tr');
    const th = create('th', 'ov-rowhead ov-sticky');
    th.scope = 'row';
    const name = drillButton('ov-name-btn', `${row.key}`, row.filter,
      `${row.name}: ${plural(row.total, 'open ticket', 'open tickets')}`);
    name.textContent = row.name;
    if (row.value === '') name.classList.add('is-unassigned');
    th.append(name);
    tr.append(th);
    tr.append(countCell('td', row.total, `${row.key}:open`, row.filter,
      `${row.name}: ${plural(row.total, 'open ticket', 'open tickets')}`, 'ov-total'));
    row.updated.forEach((cell, i) => {
      const column = model.updatedColumns[i];
      tr.append(countCell('td', cell.count, `${row.key}:upd:${cell.key}`, cell.filter,
        `${row.name}: ${plural(cell.count, 'ticket', 'tickets')}, last updated ${column.label}`, i === 0 ? 'ov-group-start' : ''));
    });
    row.ageing.forEach((cell, i) => {
      const column = model.ageColumns[i];
      tr.append(countCell('td', cell.count, `${row.key}:age:${cell.key}`, cell.filter,
        `${row.name}: ${plural(cell.count, 'ticket', 'tickets')}, age ${column.label}`, i === 0 ? 'ov-group-start' : ''));
    });
    row.split.forEach((cell, i) => {
      // update counts, not tickets: plain numbers (the Tickets table cannot show "updates")
      tr.append(create('td', `ov-num${i === 0 ? ' ov-group-start' : ''}${cell.count ? '' : ' ov-zero'}`, String(cell.count)));
    });
    tbody.append(tr);
  }

  const tfoot = create('tfoot');
  const totals = create('tr', 'ov-total-row');
  const totalsTh = create('th', 'ov-rowhead ov-sticky', 'All agents');
  totalsTh.scope = 'row';
  totals.append(totalsTh);
  totals.append(countCell('td', model.totals.total, 'agents:total:open', model.totals.filter,
    `All agents: ${plural(model.totals.total, 'open ticket', 'open tickets')}`, 'ov-total'));
  model.totals.updated.forEach((cell, i) => {
    totals.append(countCell('td', cell.count, `agents:total:upd:${cell.key}`, cell.filter,
      `All agents: ${plural(cell.count, 'ticket', 'tickets')}, last updated ${model.updatedColumns[i].label}`, i === 0 ? 'ov-group-start' : ''));
  });
  model.totals.ageing.forEach((cell, i) => {
    totals.append(countCell('td', cell.count, `agents:total:age:${cell.key}`, cell.filter,
      `All agents: ${plural(cell.count, 'ticket', 'tickets')}, age ${model.ageColumns[i].label}`, i === 0 ? 'ov-group-start' : ''));
  });
  model.totals.split.forEach((cell, i) => {
    totals.append(create('td', `ov-num${i === 0 ? ' ov-group-start' : ''}${cell.count ? '' : ' ov-zero'}`, String(cell.count)));
  });
  tfoot.append(totals);
  table.append(caption, ...colgroups, thead, tbody, tfoot);
  return [table];
}

// ---- events ----

/**
 * Open the Tickets table with the filter of a clicked drill button (data-filter JSON) inside `panel`.
 * Returns true when `node` was such a button. When the panel is hidden afterwards, focus moves to the
 * Tickets tab (a focused control inside a hidden panel would leave focus nowhere visible). Shared by the
 * Overview and the Red flags view.
 * @param {Element} node the clicked [data-drill][data-filter] element
 * @param {HTMLElement} panel the view's panel
 * @returns {boolean}
 */
export function openDrill(node, panel) {
  if (!node || !panel || !panel.contains(node) || !node.dataset || !node.dataset.filter) return false;
  let filter;
  try {
    filter = JSON.parse(node.dataset.filter);
  } catch {
    return false;
  }
  if (!isObject(filter)) return false;
  if (typeof ticketsView.applyTicketFilters === 'function') ticketsView.applyTicketFilters(filter);
  else setView('tickets');
  if (panel.hidden && panel.contains(document.activeElement)) {
    const tab = document.getElementById('tabTickets');
    if (tab) tab.focus();
  }
  return true;
}

/** A drill button: open the Tickets table with its filter; the Red flags tile: switch to that tab. */
function onPanelClick(event) {
  if (!ui || !(event.target instanceof Element)) return;
  const goto = event.target.closest('[data-view]');
  if (goto && ui.panel.contains(goto) && goto.dataset.view === 'flags') {
    // the Red flags view opens on the same queues the Overview counted
    if (typeof redFlagsView.showRedFlagsFor === 'function') redFlagsView.showRedFlagsFor(effectiveGroups(chosen(), overviewMemo.value ? overviewMemo.value.groups : []));
    else setView('flags', { focusTab: true });
    return;
  }
  openDrill(event.target.closest('[data-drill][data-filter]'), ui.panel);
}

// ---- auto refresh ----

/** getAutoRefreshStatus(), normalised; a missing or failing autorefresh.js reads as "off". */
function currentAutoStatus(now = new Date()) {
  try {
    return normalizeAutoStatus(typeof autoRefresh.getAutoRefreshStatus === 'function' ? autoRefresh.getAutoRefreshStatus(now) : null);
  } catch {
    return normalizeAutoStatus(null);
  }
}

/** Save a change of the switch or the interval (the other value is kept). */
async function saveAuto(change) {
  if (!ui) return;
  const current = currentAutoStatus();
  const next = {
    enabled: typeof change.enabled === 'boolean' ? change.enabled : (autoPending ? autoPending.enabled : current.enabled),
    minutes: Number.isInteger(change.minutes) && change.minutes > 0 ? change.minutes : (autoPending ? autoPending.minutes : current.minutes),
  };
  autoPending = next; // until it is stored, a repaint must not put the old value back into the controls
  try {
    if (typeof autoRefresh.setAutoRefresh !== 'function') throw new Error('auto refresh is not available in this build');
    await autoRefresh.setAutoRefresh(next);
  } catch (err) {
    hooks.showNotice(`Auto refresh could not be saved: ${errorText(err)}`, 'error');
  } finally {
    if (autoPending === next) autoPending = null;
    syncAuto(currentAutoStatus());
  }
}

function onRefreshNow() {
  if (!ui || ui.auto.now.getAttribute('aria-disabled') === 'true') return;
  if (typeof autoRefresh.refreshNow !== 'function') {
    hooks.showNotice('Refresh now is not available in this build: use Load all open tickets at the top of the page.', 'error');
    return;
  }
  // aria-disabled, not disabled, while a run is going: the button keeps focus (a disabled button drops it)
  ui.auto.now.setAttribute('aria-disabled', 'true');
  // called synchronously inside the click: the first run may have to ask for the host permission, which
  // needs the click's user activation
  let run;
  try {
    run = Promise.resolve(autoRefresh.refreshNow());
  } catch (err) {
    run = Promise.reject(err);
  }
  run
    .then((result) => {
      // { started: false, reason } when a run is already going on (here or in another dashboard tab)
      if (isObject(result) && result.started === false && str(result.reason)) hooks.showNotice(str(result.reason), 'info');
    })
    .catch((err) => hooks.showNotice(`The refresh could not run: ${errorText(err)}`, 'error'))
    .finally(() => syncAuto(currentAutoStatus()));
}

/** Put the bar in line with a status (getAutoRefreshStatus output). Text is set only when it changed. */
function syncAuto(rawStatus, now = new Date()) {
  if (!ui) return;
  const status = normalizeAutoStatus(rawStatus);
  const a = ui.auto;
  const shown = autoPending || status;
  if (a.toggle.checked !== shown.enabled) a.toggle.checked = shown.enabled;
  const minutes = String(shown.minutes);
  if (![...a.select.options].some((option) => option.value === minutes)) {
    const option = create('option', '', intervalLabel(shown.minutes));
    option.value = minutes;
    a.select.append(option);
  }
  if (a.select.value !== minutes) a.select.value = minutes;
  const text = autoStatusText(status, now, lastTimeZone);
  setText(a.lead, text.lead);
  setText(a.moving, text.volatile);
  setText(a.tail, text.tail);
  setText(a.summary, text.summary);
  a.summary.hidden = !text.summary;
  a.summarySep.hidden = !text.summary;
  a.bar.hidden = !text.progress;
  if (text.progress) {
    if (text.progress.max > 0) {
      a.bar.max = text.progress.max;
      a.bar.value = text.progress.value;
    } else {
      a.bar.removeAttribute('value'); // not known yet: an indeterminate bar
    }
  }
  const busy = status.running ? 'true' : 'false';
  if (a.now.getAttribute('aria-disabled') !== busy) a.now.setAttribute('aria-disabled', busy);
  a.now.title = status.running
    ? 'A refresh is already running'
    : 'Load all open tickets of the saved queues now (the same as the Load all open tickets button)';
  a.root.dataset.running = busy;
}

// ---- entry points ----

/** Build the Overview's skeleton inside #panelOverview and attach its listeners (once). */
export function wireOverview() {
  if (ui) return;
  const panel = typeof document !== 'undefined' && document.getElementById ? document.getElementById('panelOverview') : null;
  if (!panel || typeof panel.replaceChildren !== 'function') return;
  ui = buildSkeleton(panel);
  try {
    if (!unsubscribeAuto && typeof autoRefresh.onOpenLoadState === 'function') {
      unsubscribeAuto = autoRefresh.onOpenLoadState((status) => syncAuto(status));
    }
  } catch {
    // the bar still follows the status on every repaint
  }
  syncAuto(currentAutoStatus());
}

/**
 * Update the Overview. `rowsOfDay` (the Tickets view's day-filtered rows) is deliberately ignored: the
 * Overview covers every stored open ticket, from its own cached rows.
 * @param {Date} now
 * @param {string} timeZone
 * @param {object[]} rowsOfDay
 * @param {object} businessHours
 */
export function paintOverview(now, timeZone, rowsOfDay, businessHours) {
  wireOverview();
  if (!ui) return;
  lastTimeZone = str(timeZone);
  syncAuto(currentAutoStatus(now), now);
  const rows = overviewRows(now, timeZone, businessHours);
  let overview = overviewOf(rows, now, chosen());
  const groups = effectiveGroups(chosen(), overview.groups);
  // a remembered queue that has no open ticket now: count the queues that still exist (or all)
  if (JSON.stringify(groups) !== JSON.stringify(chosen())) overview = overviewOf(rows, now, groups);
  const allOpen = overview.groups.reduce((sum, group) => sum + group.count, 0) || overview.total;

  syncPicker(overview.groups, groups);
  setText(ui.note, overviewNote(overview.total, allOpen, groups, overview.tracked));

  let flagged = 0;
  try {
    if (typeof redFlagsView.flaggedAgentsFor === 'function') flagged = redFlagsView.flaggedAgentsFor(rows, now, groups);
  } catch {
    flagged = 0;
  }
  const qTiles = queueTiles(overview, groups, flagged);
  syncSection('queueKpis', ui.queueKpis, JSON.stringify(qTiles), () => buildKpis(qTiles, 'queue'), ui.auto.now);

  const isEmpty = allOpen === 0;
  // The last open tickets just went away (resolved by a refresh, cleared from the Data tab) while a
  // count had focus: hiding the body would drop focus on <body>, so it moves to the empty state's button.
  const focusWasInBody = isEmpty && !ui.body.hidden && ui.body.contains(document.activeElement);
  ui.empty.hidden = !isEmpty;
  ui.body.hidden = isEmpty;
  if (focusWasInBody && ui.emptyBtn) ui.emptyBtn.focus({ preventScroll: true });
  if (isEmpty) {
    const stored = rows.length;
    setText(ui.emptyTitle, stored ? 'No open tickets among the stored tickets' : 'No open tickets stored yet');
    setText(ui.emptyText, stored
      ? `All ${plural(stored, 'stored ticket is', 'stored tickets are')} Resolved, Closed or Canceled. Use “Load all open tickets” at the top of the page to bring in the open tickets of your queues, or search for a ticket by number.`
      : 'Use “Load all open tickets” at the top of the page to bring in every open ticket of your queues (set them in Settings), or search for tickets by number. The overview counts every stored ticket that is not Resolved, Closed or Canceled.');
    return;
  }

  const tiles = kpiTiles(overview, groups);
  syncSection('kpis', ui.kpis, JSON.stringify(tiles), () => buildKpis(tiles), ui.status.heading);

  const statusBars = barsModel(overview.byStatus.map((s) => ({ key: s.value, label: s.label, count: s.count })), overview.total);
  syncSection('status', ui.status.content, JSON.stringify([statusBars, groups]),
    () => buildBars('status', statusBars, (bar) => drillFilter(groups, { ticketStatus: [bar.key] }), () => '', 'No open tickets in the chosen queues.'),
    ui.status.heading);

  const updatedBars = barsModel(overview.updated, overview.total);
  syncSection('updated', ui.updated.content, JSON.stringify([updatedBars, groups]),
    () => buildBars('updated', updatedBars, (bar) => drillFilter(groups, { updated: [bar.key] }), (bar) => UPDATED_TONE[bar.key] || '', 'No open tickets in the chosen queues.'),
    ui.updated.heading);

  const ageing = ageingTableModel(overview, groups);
  syncSection('ageing', ui.ageing.content, JSON.stringify(ageing), () => buildAgeingTable(ageing), ui.ageing.content);

  const agents = agentTableModel(overview, groups);
  const split = overview.updateSplit;
  setText(ui.agents.sub, `Open tickets per assigned agent. Agent updates = the agent's own updates on these tickets, judged against each user's business hours: ${split.business} in business hours, ${split.off} off hours, ${split.unknown} unknown (no usable location or time).`);
  syncSection('agents', ui.agents.content, JSON.stringify(agents), () => buildAgentTable(agents), ui.agents.content);
}

/** Give the Queues picker the queues present and the effective choice, only when either changed. */
function syncPicker(available, groups) {
  const options = available.map((group) => ({
    value: group.name, label: group.name || NO_GROUP_LABEL, count: group.count,
  }));
  const sig = JSON.stringify([options, groups]);
  if (ui.pickerSig === sig) return;
  ui.pickerSig = sig;
  try {
    ui.picker.update({ options, selected: groups });
  } catch {
    // the picker is a convenience; the counts below still follow the remembered choice
  }
}
