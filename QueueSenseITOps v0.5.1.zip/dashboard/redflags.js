// The Red flags view (v0.5): the agents whose open tickets need a lead's attention, in three cards, plus
// the unassigned tickets. Top to bottom: a heading with a short note on how each flag is decided, a
// "Queues" scope picker (assignment groups; remembered in localStorage, and on first use the Overview's
// remembered choice), the unassigned-tickets line and three cards, each with a real <table>:
//   - Most ageing tickets: per agent, the open tickets at least N days old (N = 5, 10 or 30, picked in
//     the card, default 10), the open total, the share and the oldest age. Flagged: 2 or more such
//     tickets and more than the team average.
//   - Not updating tickets daily: per agent, the open tickets (opened 24 working hours or more ago) where the
//     agent has not written an update in the past 24 WORKING hours (Saturday and Sunday do not count).
//     Flagged: half or more of the agent's open tickets, or 3 or more.
//   - Mostly following up outside business hours: per agent, how many of the agent's own updates fell
//     inside / outside the user's business hours. Flagged: at least 4 judged updates and more than half
//     of them off hours.
// The numbers come from lib/metrics.js computeRedFlags over the same rows the Overview counts
// (dashboard/overview.js overviewRows: every stored ticket, with queue information), so a ticket that
// moved out of the queue is never counted here either. A flagged row says so in words with an icon
// ("Flagged"), never by colour alone. Every agent name, and every ticket count, is a button that opens
// the Tickets table filtered to exactly those tickets (dashboard/tickets.js applyTicketFilters through
// overview.js openDrill).
//
// The DOM is built with dom.js's create()/setText() only (agent names are untrusted ServiceNow text).
// The page repaints every 60 seconds; each section keeps a signature of what it shows and is rebuilt only
// when that changes, with focus put back on the same logical control (overview.js createSectionSync).
//
// The pure helpers (threshold choice, drill filters, quiet-time text, table models) are exported for
// tests/redflags.test.mjs. This module touches the DOM only inside wireRedFlags()/paintRedFlags() and
// showRedFlagsFor(), so it can be imported under node with a stub document. overview.js imports this
// module (for the Red flags tile) and this module imports overview.js: neither uses the other at load
// time, so the cycle is harmless.
import { AGE_BUCKETS } from '../lib/metrics.js';
// A namespace import: computeRedFlags is looked up when the view paints, so a lib/metrics.js without it
// still loads the page (the view then shows that nothing could be computed).
import * as metricsLib from '../lib/metrics.js';
import { create, isObject, plural, setText, str } from './dom.js';
import { createMultiSelect } from './multiselect.js';
import { setView } from './nav.js';
import {
  OVERVIEW_QUEUES_STORAGE, agentFilterValue, createSectionSync, effectiveGroups, openDrill, overviewRows,
  parseStoredGroups, shareText,
} from './overview.js';
import { hooks } from './state.js';

/** localStorage keys of the chosen queues and the ageing threshold (per-viewer conveniences). */
export const REDFLAGS_QUEUES_STORAGE = 'snicRedFlagsQueues';
export const REDFLAGS_AGEING_STORAGE = 'snicRedFlagsAgeing';

/** The ageing thresholds offered, in days, and the default. */
export const AGEING_CHOICES = Object.freeze([5, 10, 30]);
export const DEFAULT_AGEING_DAYS = 10;

const NO_GROUP_LABEL = 'No assignment group';
const DRILL_HINT = 'Opens the Tickets table showing these tickets.';
const DRILL_TITLE = 'Show these tickets in the Tickets table';
const FLAG_ICON = '⚑'; // ⚑, always next to the word "Flagged"

/** The lower bound, in days, of each lib/metrics.js age bucket. */
const AGE_BUCKET_FROM = { lt3: 0, d3to5: 3, d5to10: 5, d10to30: 10, gt30: 30 };

// ---- pure helpers ----

const count = (value) => (Number.isFinite(value) && value > 0 ? Math.floor(value) : 0);
const listOf = (value) => (Array.isArray(value) ? value : []);

/**
 * An ageing threshold as one of AGEING_CHOICES (a number or its text); the default (10) for anything else.
 * @param {*} value
 * @returns {number}
 */
export function normalizeAgeingDays(value) {
  const number = typeof value === 'string' && value.trim() ? Number(value) : value;
  return AGEING_CHOICES.includes(number) ? number : DEFAULT_AGEING_DAYS;
}

/**
 * The lib/metrics.js age bucket keys that hold the tickets at least `days` old: 5 -> d5to10, d10to30,
 * gt30; 10 -> d10to30, gt30; 30 -> gt30 (the bucket boundaries are exactly the thresholds offered).
 * @param {number} days one of AGEING_CHOICES (anything else is read as the default)
 * @returns {string[]}
 */
export function ageBucketsFrom(days) {
  const threshold = normalizeAgeingDays(days);
  return AGE_BUCKETS.map((bucket) => bucket.key).filter((key) => key in AGE_BUCKET_FROM && AGE_BUCKET_FROM[key] >= threshold);
}

/**
 * The queues this view starts with: its own remembered choice when one was stored (even an empty one,
 * meaning "all queues"), else the Overview's remembered choice.
 * @param {string|null} ownText localStorage value of REDFLAGS_QUEUES_STORAGE
 * @param {string|null} overviewText localStorage value of the Overview's queues
 * @returns {string[]}
 */
export function initialGroups(ownText, overviewText) {
  if (typeof ownText === 'string') {
    try {
      if (Array.isArray(JSON.parse(ownText))) return parseStoredGroups(ownText);
    } catch {
      // garbage: fall back to the Overview's choice
    }
  }
  return parseStoredGroups(overviewText);
}

/**
 * The queue picker's options: every assignment group among the open rows that are still in the queue
 * (a row that moved out is not counted), with its count, by name. '' is "no assignment group".
 * @param {object[]} rows dashboard rows
 * @returns {{name:string, count:number}[]}
 */
export function groupOptions(rows) {
  const counts = new Map();
  for (const row of listOf(rows)) {
    if (!isObject(row) || row.isOpen === false) continue;
    if (isObject(row.queue) && row.queue.movedOut === true) continue;
    const group = isObject(row.details) && typeof row.details.assignmentGroup === 'string' ? row.details.assignmentGroup.trim() : '';
    counts.set(group, (counts.get(group) || 0) + 1);
  }
  return [...counts].map(([name, n]) => ({ name, count: n }))
    .sort((a, b) => (a.name.toLowerCase() < b.name.toLowerCase() ? -1 : a.name.toLowerCase() > b.name.toLowerCase() ? 1 : 0));
}

/** One agent entry: key (the assignedTo text), display name, flagged. */
function agentBase(entry) {
  const key = agentFilterValue(entry);
  return { key, agent: str(entry.agent) || key || 'Unassigned', flagged: entry.flagged === true };
}

const numberOrNull = (value) => (typeof value === 'number' && Number.isFinite(value) && value >= 0 ? value : null);

/**
 * computeRedFlags output with every field present and typed, so the painters never have to guard (the
 * agent lists drop non-objects and the Unassigned bucket). Shares are recomputed from the counts so the
 * text always agrees with the numbers next to it. Never throws.
 * @param {*} raw
 * @returns {object}
 */
export function normalizeRedFlags(raw) {
  const r = isObject(raw) ? raw : {};
  const ageing = isObject(r.ageing) ? r.ageing : {};
  const stale = isObject(r.stale) ? r.stale : {};
  const off = isObject(r.offHours) ? r.offHours : {};
  const agents = (list, map) => listOf(list).filter(isObject).map((entry) => ({ ...agentBase(entry), ...map(entry) }))
    .filter((entry) => entry.key !== '');
  return {
    total: count(r.total),
    unassigned: count(r.unassigned),
    ageing: {
      thresholdDays: normalizeAgeingDays(ageing.thresholdDays),
      teamAverage: numberOrNull(ageing.teamAverage) ?? 0,
      agents: agents(ageing.agents, (a) => ({
        ageing: count(a.ageing), total: count(a.total), oldestDays: numberOrNull(a.oldestDays),
      })),
    },
    stale: {
      hours: count(stale.hours) || 24,
      agents: agents(stale.agents, (a) => ({
        stale: count(a.stale), total: count(a.total), maxQuietHours: numberOrNull(a.maxQuietHours), neverUpdated: count(a.neverUpdated),
      })),
    },
    offHours: {
      threshold: typeof off.threshold === 'number' && off.threshold >= 0 && off.threshold <= 1 ? off.threshold : 0.5,
      minUpdates: count(off.minUpdates) || 4,
      agents: agents(off.agents, (a) => ({ business: count(a.business), off: count(a.off), unknown: count(a.unknown) })),
    },
    flaggedAgents: count(r.flaggedAgents),
  };
}

/**
 * computeRedFlags for these rows, normalised; an empty result when lib/metrics.js has no computeRedFlags
 * yet or it fails. `compute` is injectable for tests.
 * @returns {object}
 */
export function redFlagsOf(rows, now, groups, ageingDays, compute = metricsLib.computeRedFlags) {
  try {
    if (typeof compute !== 'function') return normalizeRedFlags(null);
    return normalizeRedFlags(compute(rows, now, { groups: listOf(groups), ageingDays: normalizeAgeingDays(ageingDays) }));
  } catch {
    return normalizeRedFlags(null);
  }
}

/** The common part of every drill: open tickets, in the chosen queues (none = all). */
function baseFilter(groups) {
  // notMovedOut: computeRedFlags leaves out tickets that moved out of the queue; openOnly alone would
  // list one that moved out but is still open.
  const filter = { openOnly: true, queue: ['notMovedOut'] };
  const chosen = listOf(groups).filter((name) => typeof name === 'string');
  if (chosen.length) filter.group = [...chosen];
  return filter;
}

/**
 * The Tickets filter of a red-flag drill (a fresh object every time):
 *   'ageing'      { openOnly, group?, agent: [key], age: the buckets at least `ageingDays` old }
 *   'stale'       { openOnly, group?, agent: [key], flags: ['agentStale'] }
 *   'offHours'    { openOnly, group?, agent: [key], flags: ['agentOffHours'] }
 *   'agent'       { openOnly, group?, agent: [key] }   (every open ticket of that agent)
 *   'unassigned'  { openOnly, group?, agent: [''] }
 * @param {'ageing'|'stale'|'offHours'|'agent'|'unassigned'} kind
 * @param {string} agentKey the agent's assignedTo text
 * @param {string[]} groups the effective queues
 * @param {number} [ageingDays]
 * @returns {object}
 */
export function flagDrill(kind, agentKey, groups, ageingDays = DEFAULT_AGEING_DAYS) {
  const filter = baseFilter(groups);
  if (kind === 'unassigned') {
    filter.agent = [''];
    return filter;
  }
  filter.agent = [typeof agentKey === 'string' ? agentKey : ''];
  if (kind === 'ageing') filter.age = ageBucketsFrom(ageingDays);
  else if (kind === 'stale') filter.flags = ['agentStale'];
  else if (kind === 'offHours') filter.flags = ['agentOffHours'];
  return filter;
}

/**
 * The longest quiet time of an agent, in words: null hours -> 'never updated' (with how many tickets
 * when known) or '—'; under 24 working hours -> '5 working hours'; else whole working days ('1 working
 * day', '3 working days'). A working day is 24 working hours (weekends excluded by lib/dashboardModel.js).
 * @param {number|null} hours
 * @param {number} [neverUpdated] tickets the agent never updated
 * @returns {string}
 */
export function quietText(hours, neverUpdated = 0) {
  const never = count(neverUpdated);
  if (typeof hours !== 'number' || !Number.isFinite(hours) || hours < 0) {
    return never ? `never updated (${plural(never, 'ticket', 'tickets')})` : '—';
  }
  if (hours < 24) {
    const whole = Math.floor(hours);
    return `${whole} working ${whole === 1 ? 'hour' : 'hours'}`;
  }
  const days = Math.floor(hours / 24);
  const text = `${days} working ${days === 1 ? 'day' : 'days'}`;
  return never ? `${text}; ${plural(never, 'ticket', 'tickets')} never updated` : text;
}

/** '1 day' / '12 days' (whole days, rounded down); '—' when unknown. */
export function daysText(days) {
  if (typeof days !== 'number' || !Number.isFinite(days) || days < 0) return '—';
  const whole = Math.floor(days);
  return `${whole} ${whole === 1 ? 'day' : 'days'}`;
}

/** The team average as text: '2.5' / '3' (one decimal at most). */
export function averageText(value) {
  const n = typeof value === 'number' && Number.isFinite(value) && value > 0 ? value : 0;
  return String(Math.round(n * 10) / 10);
}

/**
 * The three tables' models: one row per agent with its counts, texts, flag and drill filters.
 * @param {object} flags normalizeRedFlags output
 * @param {string[]} groups the effective queues
 * @returns {{ageing:object[], stale:object[], offHours:object[]}}
 */
export function redFlagTables(flags, groups) {
  const days = flags.ageing.thresholdDays;
  return {
    ageing: flags.ageing.agents.filter((a) => a.ageing > 0).map((a) => ({
      key: `ageing:${a.key}`,
      name: a.agent,
      flagged: a.flagged,
      count: a.ageing,
      total: a.total,
      share: shareText(a.ageing, a.total),
      oldest: daysText(a.oldestDays),
      filter: flagDrill('ageing', a.key, groups, days),
      totalFilter: flagDrill('agent', a.key, groups),
    })),
    stale: flags.stale.agents.filter((a) => a.stale > 0).map((a) => ({
      key: `stale:${a.key}`,
      name: a.agent,
      flagged: a.flagged,
      count: a.stale,
      total: a.total,
      share: shareText(a.stale, a.total),
      quiet: quietText(a.maxQuietHours, a.neverUpdated),
      filter: flagDrill('stale', a.key, groups),
      totalFilter: flagDrill('agent', a.key, groups),
    })),
    offHours: flags.offHours.agents.filter((a) => a.business + a.off > 0).map((a) => ({
      key: `off:${a.key}`,
      name: a.agent,
      flagged: a.flagged,
      business: a.business,
      off: a.off,
      unknown: a.unknown,
      share: shareText(a.off, a.business + a.off),
      filter: flagDrill('offHours', a.key, groups),
    })),
  };
}

/**
 * The explanation under each card's heading, with the thresholds actually used.
 * @param {object} flags normalizeRedFlags output
 * @returns {{ageing:string, stale:string, offHours:string}}
 */
export function cardNotes(flags) {
  const days = flags.ageing.thresholdDays;
  const percent = Math.round(flags.offHours.threshold * 100);
  return {
    ageing: `Open tickets at least ${days} days old (since opened), per agent. Flagged: 2 or more of them and more than the team average of ${averageText(flags.ageing.teamAverage)} per agent with open tickets.`,
    stale: `Open tickets, opened 24 working hours or more ago, where the assigned agent has not written an update in the past ${flags.stale.hours} working hours (Saturday and Sunday do not count). Flagged: half or more of the agent's open tickets, or 3 or more.`,
    offHours: `The agent's own updates on their open tickets, judged against each user's business hours at the moment of the update. Flagged: at least ${flags.offHours.minUpdates} judged updates and more than ${percent}% of them outside business hours.`,
  };
}

/** 'No agent is flagged' / '1 agent flagged' / '3 agents flagged'. */
export function flaggedText(rows) {
  const n = listOf(rows).filter((row) => row && row.flagged).length;
  return n ? `${plural(n, 'agent', 'agents')} flagged` : 'No agent is flagged';
}

// ---- remembered choices (localStorage, try/catch: a private window or blocked site data is fine) ----

function readStored(key) {
  try {
    return globalThis.localStorage ? globalThis.localStorage.getItem(key) : null;
  } catch {
    return null;
  }
}

function writeStored(key, value) {
  try {
    if (globalThis.localStorage) globalThis.localStorage.setItem(key, value);
  } catch {
    // a convenience only: the in-memory choice still applies for this page's lifetime
  }
}

// ---- module state ----

let chosenGroups = null; // read from localStorage on first use
let ageingDays = null;
let ui = null;
let syncSection = null;
const memo = { rows: null, key: '', value: null, byKey: new Map() };

function chosen() {
  if (chosenGroups === null) chosenGroups = initialGroups(readStored(REDFLAGS_QUEUES_STORAGE), readStored(OVERVIEW_QUEUES_STORAGE));
  return chosenGroups;
}

function currentAgeingDays() {
  if (ageingDays === null) ageingDays = normalizeAgeingDays(readStored(REDFLAGS_AGEING_STORAGE));
  return ageingDays;
}

/** redFlagsOf, memoised per rows identity / minute / queues / threshold (a few entries per rows). */
function memoFlags(rows, now, groups, days) {
  if (memo.rows !== rows) {
    memo.rows = rows;
    memo.byKey = new Map();
  }
  const minute = now instanceof Date && Number.isFinite(now.getTime()) ? Math.floor(now.getTime() / 60000) : 'x';
  const key = `${minute}|${days}|${JSON.stringify(groups)}`;
  if (memo.byKey.has(key)) return memo.byKey.get(key);
  const value = redFlagsOf(rows, now, groups, days);
  if (memo.byKey.size > 8) memo.byKey.clear();
  memo.byKey.set(key, value);
  return value;
}

/**
 * The number of distinct flagged agents for the Overview's Red flags tile: the same computation this
 * view shows (with its remembered ageing threshold), over the Overview's rows and queues.
 * @param {object[]} rows
 * @param {Date} now
 * @param {string[]} groups
 * @returns {number}
 */
export function flaggedAgentsFor(rows, now, groups) {
  return memoFlags(rows, now, listOf(groups), currentAgeingDays()).flaggedAgents;
}

/**
 * Show this view on exactly these queues (the Overview's Red flags tile), remember the choice and move
 * focus to the Red flags tab (the Overview panel that held focus is hidden now).
 * @param {string[]} groups
 */
export function showRedFlagsFor(groups) {
  chosenGroups = listOf(groups).filter((name) => typeof name === 'string');
  writeStored(REDFLAGS_QUEUES_STORAGE, JSON.stringify(chosenGroups));
  if (ui) ui.pickerSig = '';
  setView('flags', { focusTab: true });
}

// ---- DOM ----

function drillButton(className, drillKey, filter, label) {
  const node = create('button', className);
  node.type = 'button';
  node.dataset.drill = drillKey;
  node.dataset.filter = JSON.stringify(filter);
  node.setAttribute('aria-describedby', 'rfDrillHint');
  node.title = DRILL_TITLE;
  if (label) node.setAttribute('aria-label', label);
  return node;
}

function buildCard(id, title) {
  const section = create('section', 'ov-card rf-card');
  section.id = id;
  const head = create('div', 'rf-card-head');
  const heading = create('h3', 'ov-card-title', title);
  heading.id = `${id}Title`;
  heading.tabIndex = -1;
  section.setAttribute('aria-labelledby', heading.id);
  head.append(heading);
  const sub = create('p', 'ov-card-sub');
  const status = create('p', 'rf-card-status');
  const content = create('div', 'table-wrap ov-table-wrap rf-table-wrap');
  content.setAttribute('role', 'region');
  content.setAttribute('aria-labelledby', heading.id);
  content.tabIndex = -1;
  section.append(head, sub, status, content);
  return {
    section, head, heading, sub, status, content,
  };
}

function buildSkeleton(panel) {
  const head = create('div', 'ov-head rf-head');
  const titleBox = create('div', 'ov-title');
  const heading = create('h2', 'ov-heading', 'Red flags');
  heading.id = 'rfHeading';
  const note = create('p', 'ov-note',
    'Agents whose open tickets need attention: many ageing tickets, tickets not updated daily, or follow-ups mostly outside the user\'s business hours. '
    + 'Only open tickets still in the queue count. Each card says how its flag is decided; a flagged agent is marked "Flagged".');
  titleBox.append(heading, note);
  const scope = create('div', 'ov-scope');
  const picker = createMultiSelect({
    id: 'redFlagsQueues',
    label: 'Queues',
    allLabel: 'All queues',
    options: [],
    selected: chosen(),
    onChange: (values) => {
      chosenGroups = listOf(values).filter((name) => typeof name === 'string');
      writeStored(REDFLAGS_QUEUES_STORAGE, JSON.stringify(chosenGroups));
      hooks.paint();
    },
  });
  scope.append(picker.root);
  head.append(titleBox, scope);

  const hint = create('p', 'sr-only', DRILL_HINT);
  hint.id = 'rfDrillHint';

  const empty = create('div', 'empty-state rf-empty');
  empty.hidden = true;
  empty.append(
    create('p', 'empty-title', 'No open tickets in the queue'),
    create('p', 'empty-text', 'Use “Load all open tickets” at the top of the page (or Refresh now on the Overview) to bring in the open tickets of your queues. The red flags are worked out from those tickets.'),
  );

  const body = create('div', 'ov-body rf-body');
  const unassigned = create('p', 'rf-unassigned');
  const cards = create('div', 'rf-cards');
  const ageing = buildCard('rfAgeing', 'Most ageing tickets');
  const thresholdBox = create('div', 'rf-threshold');
  const thresholdLabel = create('label', 'rf-threshold-label', 'Aged at least');
  thresholdLabel.htmlFor = 'rfAgeingDays';
  const threshold = create('select', 'rf-threshold-select');
  threshold.id = 'rfAgeingDays';
  for (const days of AGEING_CHOICES) {
    const option = create('option', '', `${days} days`);
    option.value = String(days);
    threshold.append(option);
  }
  threshold.value = String(currentAgeingDays());
  threshold.addEventListener('change', () => {
    ageingDays = normalizeAgeingDays(threshold.value);
    writeStored(REDFLAGS_AGEING_STORAGE, String(ageingDays));
    hooks.paint();
  });
  thresholdBox.append(thresholdLabel, threshold);
  ageing.head.append(thresholdBox);
  const stale = buildCard('rfStale', 'Not updating tickets daily');
  const offHours = buildCard('rfOffHours', 'Mostly following up outside business hours');
  cards.append(ageing.section, stale.section, offHours.section);
  body.append(unassigned, cards);

  panel.replaceChildren(head, hint, empty, body);
  panel.addEventListener('click', (event) => {
    if (event.target instanceof Element) openDrill(event.target.closest('[data-drill][data-filter]'), panel);
  });
  return {
    panel, note, picker, pickerSig: '', empty, body, unassigned, threshold, ageing, stale, offHours,
  };
}

/** The flag cell: an icon and the word "Flagged" (never colour alone), or a muted dash. */
function flagCell(flagged) {
  const td = create('td', 'rf-flag-cell');
  if (flagged) {
    const marker = create('span', 'rf-flag');
    marker.dataset.tone = 'red';
    const icon = create('span', 'rf-flag-icon', FLAG_ICON);
    icon.setAttribute('aria-hidden', 'true');
    marker.append(icon, create('span', '', 'Flagged'));
    td.append(marker);
  } else {
    const dash = create('span', 'ov-zero', '—');
    dash.setAttribute('aria-hidden', 'true');
    td.append(dash, create('span', 'sr-only', 'Not flagged'));
  }
  return td;
}

function headerRow(columns) {
  const thead = create('thead');
  const tr = create('tr');
  for (const [label, numeric] of columns) {
    const th = create('th', `ov-th${numeric ? ' ov-num' : ''}`, label);
    th.scope = 'col';
    tr.append(th);
  }
  thead.append(tr);
  return thead;
}

function nameCell(row, filter, label) {
  const th = create('th', 'ov-rowhead');
  th.scope = 'row';
  const name = drillButton('ov-name-btn', `${row.key}:name`, filter, label);
  name.textContent = row.name;
  th.append(name);
  return th;
}

function countCell(value, drillKey, filter, label) {
  const td = create('td', 'ov-num');
  if (value > 0 && filter) {
    const node = drillButton('ov-cell-btn', drillKey, filter, label);
    node.textContent = String(value);
    td.append(node);
  } else {
    td.append(create('span', 'ov-zero', String(value)));
  }
  return td;
}

function plainCell(text, numeric = false, muted = false) {
  return create('td', `${numeric ? 'ov-num' : ''}${muted ? ' ov-zero' : ''}`.trim(), text);
}

function buildTable(className, caption, columns, rows, buildRow) {
  const table = create('table', `ov-table rf-table ${className}`);
  table.append(create('caption', 'sr-only', caption), headerRow(columns));
  const tbody = create('tbody');
  for (const row of rows) {
    const tr = buildRow(row);
    if (row.flagged) tr.dataset.flagged = 'true';
    tbody.append(tr);
  }
  table.append(tbody);
  return table;
}

function buildAgeingTable(rows, days) {
  if (!rows.length) return [create('p', 'ov-none', `No agent has open tickets aged ${days} days or more.`)];
  return [buildTable('rf-ageing', `Agents by open tickets aged ${days} days or more. Each name and count opens those tickets in the Tickets table.`,
    [['Agent', false], ['Flag', false], [`Aged ${days}+ days`, true], ['Open', true], ['Share', true], ['Oldest', true]],
    rows, (row) => {
      const tr = create('tr');
      tr.append(
        nameCell(row, row.filter, `${row.name}: ${plural(row.count, 'ticket', 'tickets')} aged ${days} days or more`),
        flagCell(row.flagged),
        countCell(row.count, `${row.key}:count`, row.filter, `${row.name}: ${plural(row.count, 'ticket', 'tickets')} aged ${days} days or more`),
        countCell(row.total, `${row.key}:total`, row.totalFilter, `${row.name}: ${plural(row.total, 'open ticket', 'open tickets')}`),
        plainCell(row.share, true),
        plainCell(row.oldest, true),
      );
      return tr;
    })];
}

function buildStaleTable(rows) {
  if (!rows.length) return [create('p', 'ov-none', 'Every agent updated each of their open tickets in the past 24 working hours.')];
  return [buildTable('rf-stale', 'Agents by open tickets they have not updated in the past 24 working hours. Each name and count opens those tickets in the Tickets table.',
    [['Agent', false], ['Flag', false], ['Not updated daily', true], ['Open', true], ['Share', true], ['Longest quiet', true]],
    rows, (row) => {
      const tr = create('tr');
      tr.append(
        nameCell(row, row.filter, `${row.name}: ${plural(row.count, 'ticket', 'tickets')} not updated daily`),
        flagCell(row.flagged),
        countCell(row.count, `${row.key}:count`, row.filter, `${row.name}: ${plural(row.count, 'ticket', 'tickets')} not updated daily`),
        countCell(row.total, `${row.key}:total`, row.totalFilter, `${row.name}: ${plural(row.total, 'open ticket', 'open tickets')}`),
        plainCell(row.share, true),
        plainCell(row.quiet, true),
      );
      return tr;
    })];
}

function buildOffHoursTable(rows) {
  if (!rows.length) return [create('p', 'ov-none', 'No agent update on the open tickets could be judged against the user\'s business hours.')];
  return [buildTable('rf-offhours', 'Agents by how many of their own updates fell inside or outside the user\'s business hours. Each name opens that agent\'s tickets with mostly off-hours updates.',
    [['Agent', false], ['Flag', false], ['Business hours', true], ['Off hours', true], ['Unknown', true], ['Off-hours share', true]],
    rows, (row) => {
      const tr = create('tr');
      tr.append(
        nameCell(row, row.filter, `${row.name}: tickets with mostly off-hours updates`),
        flagCell(row.flagged),
        plainCell(String(row.business), true, !row.business),
        plainCell(String(row.off), true, !row.off),
        plainCell(String(row.unknown), true, !row.unknown),
        plainCell(row.share, true),
      );
      return tr;
    })];
}

function buildUnassigned(flags, groups) {
  const nodes = [create('strong', 'rf-unassigned-label', 'Unassigned tickets: ')];
  if (flags.unassigned > 0) {
    const node = drillButton('ov-cell-btn rf-unassigned-btn', 'unassigned', flagDrill('unassigned', '', groups),
      `${plural(flags.unassigned, 'unassigned open ticket', 'unassigned open tickets')}`);
    node.textContent = String(flags.unassigned);
    node.dataset.tone = 'amber';
    nodes.push(node, create('span', 'rf-unassigned-text', ` of ${plural(flags.total, 'open ticket', 'open tickets')} have nobody in Assigned to.`));
  } else {
    nodes.push(create('span', 'rf-unassigned-text', `none: every one of the ${plural(flags.total, 'open ticket', 'open tickets')} is assigned.`));
  }
  return nodes;
}

// ---- entry points ----

/** Build the view's skeleton inside #panelFlags and attach its listeners (once). */
export function wireRedFlags() {
  if (ui) return;
  const panel = typeof document !== 'undefined' && document.getElementById ? document.getElementById('panelFlags') : null;
  if (!panel || typeof panel.replaceChildren !== 'function') return;
  syncSection = createSectionSync();
  ui = buildSkeleton(panel);
}

/**
 * Update the Red flags view (dashboard.js paint, while this view is active).
 * @param {Date} now
 * @param {string} timeZone
 * @param {object} businessHours
 */
export function paintRedFlags(now, timeZone, businessHours) {
  wireRedFlags();
  if (!ui) return;
  const rows = overviewRows(now, timeZone, businessHours);
  const available = groupOptions(rows);
  const groups = effectiveGroups(chosen(), available);
  const days = currentAgeingDays();
  if (ui.threshold.value !== String(days)) ui.threshold.value = String(days);
  syncPicker(available, groups);
  const flags = memoFlags(rows, now, groups, days);

  const isEmpty = flags.total === 0;
  const focusWasInBody = isEmpty && !ui.body.hidden && ui.body.contains(document.activeElement);
  ui.empty.hidden = !isEmpty;
  ui.body.hidden = isEmpty;
  if (focusWasInBody) {
    const tab = document.getElementById('tabFlags');
    if (tab) tab.focus({ preventScroll: true });
  }
  if (isEmpty) return;

  syncSection('unassigned', ui.unassigned, JSON.stringify([flags.unassigned, flags.total, groups]), () => buildUnassigned(flags, groups), ui.ageing.heading);
  const tables = redFlagTables(flags, groups);
  const notes = cardNotes(flags);
  setText(ui.ageing.sub, notes.ageing);
  setText(ui.stale.sub, notes.stale);
  setText(ui.offHours.sub, notes.offHours);
  for (const [card, list] of [[ui.ageing, tables.ageing], [ui.stale, tables.stale], [ui.offHours, tables.offHours]]) {
    const text = flaggedText(list);
    setText(card.status, text);
    card.status.dataset.flagged = String(text !== 'No agent is flagged');
  }
  syncSection('ageing', ui.ageing.content, JSON.stringify([tables.ageing, days]), () => buildAgeingTable(tables.ageing, days), ui.ageing.heading);
  syncSection('stale', ui.stale.content, JSON.stringify(tables.stale), () => buildStaleTable(tables.stale), ui.stale.heading);
  syncSection('offHours', ui.offHours.content, JSON.stringify(tables.offHours), () => buildOffHoursTable(tables.offHours), ui.offHours.heading);
}

/** Give the Queues picker the queues present and the effective choice, only when either changed. */
function syncPicker(available, groups) {
  const options = available.map((group) => ({ value: group.name, label: group.name || NO_GROUP_LABEL, count: group.count }));
  const sig = JSON.stringify([options, groups]);
  if (ui.pickerSig === sig) return;
  ui.pickerSig = sig;
  try {
    ui.picker.update({ options, selected: groups });
  } catch {
    // the picker is a convenience; the tables still follow the remembered choice
  }
}
