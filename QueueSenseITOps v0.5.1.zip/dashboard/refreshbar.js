// The refresh bar: progress of a "refresh all tickets" job (run by the background, state in
// chrome.storage.local 'refreshJob'), the ServiceNow session of every instance, and the controls.
// What the job says comes from lib/dashboardModel.js (describeRefreshJob); this module draws it and
// sends REFRESH_ALL / CANCEL_REFRESH.
import { describeRefreshJob } from '../lib/dashboardModel.js';
import { ensureOriginsPermissionConfirmed } from './confirmHost.js';
import {
  MIDDOT, create, externalLink, hostOf, isObject, setText, str,
} from './dom.js';
import { els } from './els.js';
import {
  MSG, replyError, sendRuntimeMessage,
} from './messaging.js';
import { hooks, state } from './state.js';
import { persistRefreshSettings } from './store.js';

const DEFAULT_TEXT = {
  none: 'Not refreshed yet. Refresh all re-reads every stored ticket from ServiceNow with your logged-in session.',
  running: 'Refreshing ...',
  stalled: 'The last refresh stopped responding. You can start a new one.',
  done: 'Refresh finished.',
  cancelled: 'Refresh cancelled.',
};

const NEEDS_ATTENTION = ['login-required', 'no-permission', 'error'];

function describeSafely(now) {
  try {
    const info = describeRefreshJob(state.data.refreshJob, now);
    if (isObject(info)) return info;
  } catch {
    // fall through to the neutral description
  }
  return { state: 'none', text: '', done: 0, total: 0, failed: 0, skipped: 0, percent: 0, current: '', origins: [] };
}

function storedOrigins() {
  const origins = new Set();
  for (const record of state.records.values()) {
    try {
      const url = new URL(str(record.incidentUrl));
      if (url.protocol === 'https:' || url.protocol === 'http:') origins.add(url.origin);
    } catch {
      // a record without a usable address has no origin to refresh
    }
  }
  return [...origins];
}

// ---- drawing ----

// The model's label names the origin and what to do; the badge itself stays short, the full sentence
// is its tooltip.
const ORIGIN_WORDS = {
  active: 'session active',
  'login-required': 'login required',
  'no-permission': 'no permission',
  checking: 'checking',
  error: 'error',
};

function originBadge(origin) {
  const li = create('li', 'origin-badge');
  li.dataset.origin = str(origin.origin);
  li.dataset.state = str(origin.state);
  li.append(create('span', 'origin-host', hostOf(origin.origin)), ` ${MIDDOT} ${ORIGIN_WORDS[origin.state] || str(origin.state)}`);
  li.title = [str(origin.label), str(origin.message)].filter(Boolean).join(' - ');
  return li;
}

function paintOrigins(origins) {
  const list = Array.isArray(origins) ? origins.filter(isObject) : [];
  const sig = JSON.stringify(list);
  if (els.refreshOrigins.dataset.sig === sig) return;
  els.refreshOrigins.dataset.sig = sig;
  els.refreshOrigins.replaceChildren(...list.map(originBadge));
  els.refreshOrigins.hidden = list.length === 0;
}

function guidanceFor(origins) {
  const list = Array.isArray(origins) ? origins.filter(isObject) : [];
  const login = list.filter((o) => o.state === 'login-required');
  const denied = list.filter((o) => o.state === 'no-permission');
  const pieces = [];
  if (login.length) {
    pieces.push({ before: 'Not logged in: open ', origins: login, after: ' in a normal tab, log in, then press Refresh all.' });
  }
  if (denied.length) {
    pieces.push({ before: 'No permission for ', origins: denied, after: '. Press Refresh all and allow access when the browser asks.' });
  }
  return pieces;
}

function paintHint(info) {
  const message = state.refreshMessage;
  const pieces = message ? [] : guidanceFor(info.origins);
  const sig = JSON.stringify([message, pieces.map((p) => [p.before, p.origins.map((o) => o.origin)])]);
  if (els.refreshHint.dataset.sig === sig) return;
  els.refreshHint.dataset.sig = sig;
  els.refreshHint.replaceChildren();
  if (message) {
    els.refreshHint.dataset.state = message.state;
    els.refreshHint.textContent = message.text;
  } else if (pieces.length) {
    els.refreshHint.dataset.state = 'warn';
    pieces.forEach((piece, index) => {
      if (index) els.refreshHint.append(' ');
      els.refreshHint.append(piece.before);
      piece.origins.forEach((origin, i) => {
        if (i) els.refreshHint.append(', ');
        els.refreshHint.append(externalLink(str(origin.origin), 'hint-link', hostOf(origin.origin)));
      });
      els.refreshHint.append(piece.after);
    });
  }
  els.refreshHint.hidden = !message && !pieces.length;
}

function announce(info, job) {
  const key = `${info.state}|${isObject(job) ? str(job.id) : ''}`;
  if (state.announced === key) return;
  const first = state.announced === '';
  state.announced = key;
  if (first) return;
  const sentences = {
    running: 'Refresh started.',
    done: `Refresh finished. ${str(info.text)}`,
    cancelled: 'Refresh cancelled.',
    stalled: 'The refresh seems stuck. You can start a new one.',
  };
  if (sentences[info.state]) els.refreshAnnounce.textContent = sentences[info.state];
}

/** Update the bar for the current clock (the "stalled" check depends on it). */
export function paintRefreshBar(now) {
  const info = describeSafely(now);
  const running = info.state === 'running';
  if (state.refreshMessage && state.refreshMessage.whileRunning && !running) state.refreshMessage = null;
  const busy = running || state.refreshStarting;

  els.refreshBar.dataset.state = info.state;
  setText(els.refreshText, str(info.text) || DEFAULT_TEXT[info.state] || DEFAULT_TEXT.none);
  els.refreshProgress.hidden = !running;
  if (running) {
    els.refreshProgress.value = Math.max(0, Math.min(100, Number(info.percent) || 0));
    els.refreshProgress.setAttribute('aria-valuetext', `${info.done} of ${info.total} tickets`);
  }
  paintOrigins(info.origins);
  paintHint(info);

  setText(els.refreshAllBtn, busy ? 'Refreshing...' : 'Refresh all');
  els.refreshAllBtn.disabled = busy;
  if (busy) els.refreshAllBtn.setAttribute('aria-busy', 'true');
  else els.refreshAllBtn.removeAttribute('aria-busy');
  els.cancelRefreshBtn.hidden = !running;
  els.autoRefreshToggle.checked = state.data.refreshSettings.onStartup;
  announce(info, state.data.refreshJob);
}

// ---- actions ----

function adoptJob(job) {
  const stored = state.data.refreshJob;
  if (isObject(job) && (!stored || stored.id !== job.id)) state.data = { ...state.data, refreshJob: job };
}

async function onRefreshAll() {
  if (els.refreshAllBtn.disabled) return;
  state.refreshStarting = true;
  state.refreshMessage = null;
  els.refreshAllBtn.disabled = true; // at once: the permission prompt below can take a while
  // First awaited work of the click handler: permissions.request needs the user gesture. The answer
  // is advisory; the background reports an instance without permission itself.
  await ensureOriginsPermissionConfirmed(storedOrigins());
  hooks.paint();
  const { reply, failure } = await sendRuntimeMessage({ type: 'REFRESH_ALL', reason: 'manual' });
  state.refreshStarting = false;
  if (failure) {
    state.refreshMessage = { state: 'error', text: failure };
  } else if (!isObject(reply) || !reply.ok) {
    state.refreshMessage = { state: 'error', text: replyError(reply, 'The refresh could not be started.') };
  } else {
    adoptJob(reply.job);
    if (reply.started === false) state.refreshMessage = { state: 'info', text: 'A refresh is already running.', whileRunning: true };
  }
  hooks.paint();
}

async function onCancelRefresh() {
  els.cancelRefreshBtn.disabled = true;
  const { reply, failure } = await sendRuntimeMessage({ type: 'CANCEL_REFRESH' }, { timeoutMs: 15000 });
  els.cancelRefreshBtn.disabled = false;
  if (failure || !isObject(reply) || !reply.ok) {
    state.refreshMessage = { state: 'error', text: failure || replyError(reply, MSG.noResponse) };
  } else {
    state.refreshMessage = { state: 'info', text: 'Cancelling after the ticket that is being read.', whileRunning: true };
  }
  hooks.paint();
}

function onAutoRefreshChange() {
  const onStartup = els.autoRefreshToggle.checked;
  state.data = { ...state.data, refreshSettings: { ...state.data.refreshSettings, onStartup } };
  persistRefreshSettings({ onStartup }).catch(() => {});
}

/** Attach the refresh bar's event listeners. */
export function wireRefreshBar() {
  els.refreshAllBtn.addEventListener('click', () => void onRefreshAll());
  els.cancelRefreshBtn.addEventListener('click', () => void onCancelRefresh());
  els.autoRefreshToggle.addEventListener('change', onAutoRefreshChange);
}
