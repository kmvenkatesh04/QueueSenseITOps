// The search panel: look a ticket up by its number through the background (FETCH_INCIDENT, source
// 'search'), then reveal its row. Same validation and permission handling as the popup.
import { normalizeIncidentNumber } from '../lib/analyze.js';
import { parseInstanceUrl } from '../lib/instance.js';
import { ensureOriginPermissionConfirmed } from './confirmHost.js';
import { create, errorText, isObject, str } from './dom.js';
import { els } from './els.js';
import { replyError, sendRuntimeMessage } from './messaging.js';
import { hooks, state } from './state.js';
import { KEY, storageGet } from './store.js';

const NUMBER_HELP = 'Enter an incident number like INC0012345 (INC followed by at least 6 digits).';
const IDLE_TEXT = 'Look up a ticket by its number. It is added to the table below.';

function setStatus(stateName, message, code = '') {
  els.searchStatus.dataset.state = stateName;
  els.searchStatus.textContent = message;
  if (code) els.searchStatus.dataset.code = code;
  else delete els.searchStatus.dataset.code;
}

function clearInvalid(input) {
  input.removeAttribute('aria-invalid');
  input.removeAttribute('aria-describedby');
}

function invalidInput(input, message) {
  setStatus('error', message, 'INVALID_INPUT');
  input.setAttribute('aria-invalid', 'true');
  input.setAttribute('aria-describedby', 'searchStatus');
  input.focus();
}

function setBusy(busy) {
  state.searchBusy = busy;
  els.searchInstanceUrl.disabled = busy;
  els.searchIncident.disabled = busy;
  els.searchBtn.disabled = busy;
  els.searchForm.setAttribute('aria-busy', String(busy));
  if (busy) els.searchBtn.setAttribute('aria-busy', 'true');
  else els.searchBtn.removeAttribute('aria-busy');
}

async function requestRecord(instanceUrl, incidentNumber) {
  const { reply, failure } = await sendRuntimeMessage({
    type: 'FETCH_INCIDENT', instanceUrl, incidentNumber, source: 'search',
  });
  if (failure) return { error: { message: failure, code: 'NO_RESPONSE' } };
  if (isObject(reply) && reply.ok) return { error: null };
  const error = isObject(reply) && isObject(reply.error) ? reply.error : {};
  return { error: { message: replyError(reply, 'The incident could not be fetched.'), code: str(error.code) } };
}

async function rememberInstance(origin) {
  try {
    await chrome.storage.local.set({ [KEY.instanceUrl]: origin });
  } catch {
    // Remembering the address is a convenience; the lookup does not depend on it.
  }
}

function focusIncidentInput() {
  const active = document.activeElement;
  if (active && active !== document.body && !active.disabled) return;
  // preventScroll: a bare focus() would otherwise snap the window back to this field, silently
  // overriding the just-revealed row's own scrollIntoView (dashboard.js:170 and search.js's own
  // bulkEls.panel.focus() below already use the same option for exactly this reason).
  els.searchIncident.focus({ preventScroll: true });
  els.searchIncident.select();
}

async function onSearch(event) {
  event.preventDefault();
  if (state.searchBusy) return;
  clearInvalid(els.searchIncident);
  clearInvalid(els.searchInstanceUrl);
  const incidentNumber = normalizeIncidentNumber(els.searchIncident.value);
  if (!incidentNumber) {
    invalidInput(els.searchIncident, NUMBER_HELP);
    return;
  }
  const parsed = parseInstanceUrl(els.searchInstanceUrl.value);
  if (!parsed.ok) {
    invalidInput(els.searchInstanceUrl, parsed.message);
    return;
  }

  setBusy(true);
  try {
    // First awaited work of the submit handler: permissions.request needs the user gesture.
    const permission = await ensureOriginPermissionConfirmed(parsed.origin);
    if (!permission.ok) {
      setStatus('error', permission.message, 'NO_PERMISSION');
      return;
    }
    els.searchInstanceUrl.value = permission.origin;
    els.searchIncident.value = incidentNumber;
    setStatus('loading', `Looking up ${incidentNumber} in ServiceNow ... a background tab opens for a moment.`);
    const { error } = await requestRecord(permission.origin, incidentNumber);
    if (error) {
      setStatus('error', error.message, error.code);
      return;
    }
    await rememberInstance(permission.origin);
    await hooks.showTicket(incidentNumber, { flash: true });
    setStatus('success', `${incidentNumber} fetched`);
  } catch (err) {
    setStatus('error', `The search failed: ${errorText(err)}`);
  } finally {
    setBusy(false);
    focusIncidentInput();
  }
}

/** Fill the instance box: the stored address, else the origin of the newest stored ticket. */
export async function prefillSearch() {
  const stored = (await storageGet([KEY.instanceUrl])) || {};
  const saved = str(stored[KEY.instanceUrl]);
  let origin = saved;
  if (!origin) {
    for (const record of state.records.values()) {
      try {
        origin = new URL(str(record.incidentUrl)).origin;
        break;
      } catch {
        // try the next record
      }
    }
  }
  // The user may have started typing while storage was being read.
  if (origin && !els.searchInstanceUrl.value) els.searchInstanceUrl.value = origin;
}

/** Attach the search form's event listeners. */
export function wireSearch() {
  els.searchForm.addEventListener('submit', (event) => void onSearch(event));
  for (const input of [els.searchInstanceUrl, els.searchIncident]) {
    input.addEventListener('input', () => {
      clearInvalid(input);
      if (els.searchStatus.dataset.state === 'error' && els.searchStatus.dataset.code === 'INVALID_INPUT') {
        setStatus('idle', IDLE_TEXT);
      }
    });
  }
}

// ---- bulk fetch (contract 15.1 / 16.6) ----
// Up to 50 incident numbers, pasted or read from a .txt/.csv file, fetched through the SAME
// FETCH_INCIDENT message (source 'search') and the same permission-check-in-click-handler flow as the
// single search above (requestRecord, ensureOriginPermissionConfirmed): this is UI-side orchestration of
// N calls to the existing message, not a new background message type. Each call opens its own
// background tab (background.js has no global lock: only its storage writes are queued), so tickets
// are fetched in PARALLEL through a rolling pool of BULK_CONCURRENCY workers - as soon as one ticket
// finishes the next one starts, instead of waiting for a whole batch. Consecutive launches are
// staggered by BULK_LAUNCH_GAP_MS so five tabs do not all open in the same instant.
//
// Stop rules (unchanged in spirit from the batch version): a LOGIN_REQUIRED or a cancel request stops
// any NEW ticket from starting, every ticket already in flight still gets its own real result, and the
// rest are reported as not fetched. Outcomes are stored at each ticket's input position (never pushed
// in completion order), so the results list and the final count are exact under real concurrency.
//
// While a run is in progress the input area collapses to a one-line summary with a progress bar; it
// stays collapsed afterwards (showing the results) until the person clicks "Edit list".

const BULK_MAX = 50;
const BULK_SPLIT_RE = /[\s,]+/;
/** Tickets fetched at the same time by a bulk fetch. */
export const BULK_CONCURRENCY = 5;
/** Minimum gap between two ticket launches, so the pool's tabs do not all open at once. */
export const BULK_LAUNCH_GAP_MS = 300;

const bulkEls = {
  btn: document.getElementById('bulkFetchBtn'),
  panel: document.getElementById('bulkFetchPanel'),
  inputArea: document.getElementById('bulkInputArea'),
  input: document.getElementById('bulkFetchInput'),
  file: document.getElementById('bulkFetchFile'),
  count: document.getElementById('bulkCount'),
  preview: document.getElementById('bulkPreview'),
  overflow: document.getElementById('bulkOverflow'),
  runSummary: document.getElementById('bulkRunSummary'),
  runText: document.getElementById('bulkRunText'),
  bar: document.getElementById('bulkProgressBar'),
  go: document.getElementById('bulkFetchGo'),
  edit: document.getElementById('bulkEditBtn'),
  cancel: document.getElementById('bulkCancelBtn'),
  close: document.getElementById('bulkFetchClose'),
  progress: document.getElementById('bulkProgress'),
  results: document.getElementById('bulkResults'),
};

let bulkRunning = false;
let bulkCancelRequested = false;

/** Tokens of the bulk textarea: recognised (normalizeIncidentNumber, deduped, in input order) and
 * rejected ({ token, reason }); never silently drops a token from either list. */
function parseBulkTokens(text) {
  const tokens = String(text || '').split(BULK_SPLIT_RE).map((token) => token.trim()).filter(Boolean);
  const seen = new Set();
  const recognised = [];
  const rejected = [];
  for (const token of tokens) {
    const normalized = normalizeIncidentNumber(token);
    if (!normalized) rejected.push({ token, reason: 'not a valid incident number' });
    else if (!seen.has(normalized)) {
      seen.add(normalized);
      recognised.push(normalized);
    }
  }
  return { recognised, rejected };
}

/** Live preview: recognised vs rejected tokens, the 50-item hard cap, and the explicit "not fetched"
 * list for anything past it (contract 15.1: "never silently dropped without saying so"). */
function renderBulkPreview() {
  const { recognised, rejected } = parseBulkTokens(bulkEls.input.value);
  const queued = recognised.slice(0, BULK_MAX);
  const overflow = recognised.slice(BULK_MAX);

  const rows = [
    ...queued.map((number) => create('p', 'bulk-row bulk-row-ok', number)),
    ...rejected.map((item) => create('p', 'bulk-row bulk-row-bad', `${item.token} — ${item.reason}`)),
  ];
  bulkEls.preview.replaceChildren(...rows);

  bulkEls.count.textContent = recognised.length > BULK_MAX
    ? `${recognised.length} recognised (${BULK_MAX} will be fetched; the rest are ignored)`
    : `${recognised.length} recognised${rejected.length ? `, ${rejected.length} rejected` : ''}`;

  bulkEls.overflow.hidden = overflow.length === 0;
  bulkEls.overflow.textContent = overflow.length
    ? `Not fetched (over the ${BULK_MAX} limit): ${overflow.join(', ')}`
    : '';

  bulkEls.go.disabled = bulkRunning || queued.length === 0;
  return { queued, rejected, overflow };
}

/** Largest list file the bulk fetch reads (a list of 50 ticket numbers is well under 1 KB). */
export const BULK_FILE_MAX_BYTES = 1024 * 1024;

/**
 * Why a chosen list file is refused before it is read, or '' when it may be read: a file larger than
 * BULK_FILE_MAX_BYTES is never loaded into the page.
 * @param {{size?: number}|null|undefined} file
 * @returns {string}
 */
export function bulkFileProblem(file) {
  const size = file && Number.isFinite(file.size) ? file.size : 0;
  if (size <= BULK_FILE_MAX_BYTES) return '';
  return `The file is too large (${(size / (1024 * 1024)).toFixed(1)} MB). Choose a text or CSV file of at most 1 MB.`;
}

async function onBulkFile() {
  const file = bulkEls.file.files && bulkEls.file.files[0];
  if (!file) return;
  try {
    const problem = bulkFileProblem(file);
    if (problem) {
      bulkEls.progress.hidden = false;
      bulkEls.progress.textContent = problem;
      return;
    }
    const text = await file.text();
    const existing = bulkEls.input.value.trim();
    bulkEls.input.value = existing ? `${existing}\n${text}` : text;
  } catch (err) {
    bulkEls.progress.hidden = false;
    bulkEls.progress.textContent = `The file could not be read: ${errorText(err)}`;
  } finally {
    bulkEls.file.value = '';
    renderBulkPreview();
  }
}

function bulkSetProgress(text) {
  if (!bulkEls.progress) return;
  bulkEls.progress.hidden = !text;
  bulkEls.progress.textContent = text || '';
}

/** The collapsed one-line summary: "Fetching 12 tickets ... 7 done, 5 in progress (INC..., ...)". */
function bulkSetRun({ total, done, active, ok }) {
  if (bulkEls.bar) {
    bulkEls.bar.max = Math.max(1, total);
    bulkEls.bar.value = done;
  }
  if (!bulkEls.runText) return;
  const inProgress = active.length ? `, ${active.length} in progress (${active.join(', ')})` : '';
  bulkEls.runText.textContent = done < total
    ? `Fetching ${total} ${total === 1 ? 'ticket' : 'tickets'}: ${done} done${inProgress} ...`
    : `${ok} of ${total} fetched.`;
}

const OUTCOME_GROUPS = [
  ['ok', 'Fetched OK'],
  ['notfound', 'Not found'],
  ['login', 'Stopped: login required'],
  ['cancelled', 'Not fetched (cancelled)'],
  ['error', 'Errors'],
];

/** Results grouped by outcome, each with its own message (contract 15.1: "a results summary grouped
 * by outcome at the end"). */
function renderBulkResults(outcomes) {
  const groups = OUTCOME_GROUPS
    .map(([key, label]) => ({ key, label, items: outcomes.filter((o) => o.outcome === key) }))
    .filter((group) => group.items.length);
  const sections = groups.map((group) => {
    const section = create('div', 'bulk-result-group');
    const heading = create('h3', 'bulk-result-heading', `${group.label} (${group.items.length})`);
    const list = create('ul', 'bulk-result-list');
    list.append(...group.items.map((item) => {
      const row = create('li', `bulk-result bulk-result-${item.outcome}`);
      row.append(create('strong', '', item.number), ` — ${item.message}`);
      return row;
    }));
    section.append(heading, list);
    return section;
  });
  bulkEls.results.replaceChildren(...sections);
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/** One ticket's outcome, from a settled requestRecord() call. Exported for direct unit testing
 * (tests/bulkfetch.test.mjs). Since v0.5 the background's error code is kept (`code`, '' for a ticket
 * that was fetched or an error without one): the Fetch errors tab shows it, and the open-ticket loader's
 * retry rounds pick the 'error' outcomes by it. */
export function outcomeOf(number, error) {
  if (!error) return { number, outcome: 'ok', message: 'Fetched.', code: '' };
  const code = str(error.code);
  const message = str(error.message);
  if (code === 'LOGIN_REQUIRED') return { number, outcome: 'login', message: message || 'Login required.', code };
  if (code === 'NOT_FOUND') return { number, outcome: 'notfound', message: message || 'Not found.', code };
  return { number, outcome: 'error', message: message || 'Could not be fetched.', code };
}

/** Code of a ticket whose fetchOne threw in this page (not an answer of the background). */
export const DASHBOARD_ERROR_CODE = 'DASHBOARD_ERROR';

/** Fetch `numbers` from `origin` through a rolling pool of up to `concurrency` (default
 * BULK_CONCURRENCY) tickets in flight. A worker picks the next ticket as soon as its current one
 * settles; launches are at least `launchGapMs` apart. Outcomes are returned in INPUT order.
 * A LOGIN_REQUIRED, or `isCancelled()` turning true, stops new launches; tickets already in flight
 * still report their own result, the rest are 'cancelled'.
 *
 * `fetchOne`/`isCancelled`/`onProgress`/`launchGapMs` are injectable so tests/bulkfetch.test.mjs can
 * check the pool, ordering and stop rules directly (no chrome.*, no DOM, no real waiting). A fetchOne
 * that throws counts as an 'error' outcome for that ticket only. */
export async function runBulkFetch(numbers, origin, {
  fetchOne = (number) => requestRecord(origin, number).then(({ error }) => error),
  isCancelled = () => bulkCancelRequested,
  onProgress = () => {},
  concurrency = BULK_CONCURRENCY,
  launchGapMs = BULK_LAUNCH_GAP_MS,
} = {}) {
  const list = Array.isArray(numbers) ? numbers : [];
  const outcomes = new Array(list.length);
  const active = new Set();
  let next = 0;
  let done = 0;
  let ok = 0;
  let stopReason = ''; // '' | 'login' | 'cancel'
  let lastLaunch = -Infinity;
  let launchChain = Promise.resolve();

  const report = () => onProgress({ total: list.length, done, ok, active: [...active] });

  // Launches go through one chain so the gap between any two of them holds across all workers.
  const waitForLaunchSlot = () => {
    const slot = launchChain.then(async () => {
      const wait = lastLaunch + launchGapMs - Date.now();
      if (wait > 0) await sleep(wait);
      lastLaunch = Date.now();
    });
    launchChain = slot;
    return slot;
  };

  const stopped = () => {
    if (!stopReason && isCancelled()) stopReason = 'cancel';
    return Boolean(stopReason);
  };

  async function worker() {
    while (next < list.length) {
      if (stopped()) return;
      const index = next;
      next += 1;
      // eslint-disable-next-line no-await-in-loop -- each worker runs its tickets one after another
      await waitForLaunchSlot();
      if (stopped()) return; // this ticket was never started: it is reported as not fetched below
      const number = list[index];
      active.add(number);
      report();
      let outcome;
      try {
        // eslint-disable-next-line no-await-in-loop -- see above; the pool runs `concurrency` workers
        outcome = outcomeOf(number, await fetchOne(number));
      } catch (err) {
        outcome = { number, outcome: 'error', message: `Could not be fetched: ${errorText(err)}`, code: DASHBOARD_ERROR_CODE };
      }
      active.delete(number);
      outcomes[index] = outcome;
      done += 1;
      if (outcome.outcome === 'ok') ok += 1;
      if (outcome.outcome === 'login' && !stopReason) stopReason = 'login';
      report();
    }
  }

  const workers = Math.max(1, Math.min(concurrency, list.length));
  await Promise.all(Array.from({ length: workers }, () => worker()));

  const notFetched = stopReason === 'login'
    ? 'Not fetched: the run stopped after a login was required.'
    : 'Cancelled before this ticket was fetched.';
  for (let i = 0; i < list.length; i += 1) {
    if (!outcomes[i]) outcomes[i] = { number: list[i], outcome: 'cancelled', message: notFetched, code: '' };
  }
  return outcomes;
}

/** Collapse the input area to the run summary (true), or open it again (false). */
function setBulkCollapsed(collapsed) {
  if (bulkEls.inputArea) bulkEls.inputArea.hidden = collapsed;
  if (bulkEls.runSummary) bulkEls.runSummary.hidden = !collapsed;
  if (bulkEls.edit) bulkEls.edit.hidden = !collapsed || bulkRunning;
  bulkEls.go.hidden = collapsed;
  bulkEls.panel.dataset.collapsed = collapsed ? '1' : '0';
}

function setBulkBusy(busy) {
  bulkRunning = busy;
  bulkEls.go.disabled = busy || parseBulkTokens(bulkEls.input.value).recognised.length === 0;
  bulkEls.input.disabled = busy;
  bulkEls.file.disabled = busy;
  bulkEls.cancel.hidden = !busy;
  bulkEls.close.disabled = busy;
  if (bulkEls.edit) bulkEls.edit.hidden = busy || bulkEls.panel.dataset.collapsed !== '1';
  bulkEls.panel.setAttribute('aria-busy', String(busy));
}

async function onBulkGo(event) {
  event.preventDefault();
  if (bulkRunning) return;
  const { queued } = renderBulkPreview();
  if (!queued.length) return;
  const parsed = parseInstanceUrl(els.searchInstanceUrl.value);
  if (!parsed.ok) {
    bulkSetProgress(parsed.message);
    return;
  }
  bulkCancelRequested = false;
  setBulkBusy(true);
  bulkEls.results.replaceChildren();
  bulkSetProgress('');
  try {
    // First awaited work of the click handler: permissions.request needs the user gesture, same as
    // the single search's onSearch above.
    const permission = await ensureOriginPermissionConfirmed(parsed.origin);
    if (!permission.ok) {
      bulkSetProgress(permission.message);
      renderBulkResults(queued.map((number) => ({ number, outcome: 'error', message: 'Permission was not granted.' })));
      return;
    }
    els.searchInstanceUrl.value = permission.origin;
    await rememberInstance(permission.origin);
    setBulkCollapsed(true);
    bulkSetRun({ total: queued.length, done: 0, ok: 0, active: [] });
    const outcomes = await runBulkFetch(queued, permission.origin, { onProgress: bulkSetRun });
    renderBulkResults(outcomes);
    const ok = outcomes.filter((o) => o.outcome === 'ok').length;
    bulkSetRun({ total: queued.length, done: queued.length, ok, active: [] });
    const stoppedForLogin = outcomes.some((o) => o.outcome === 'login');
    bulkSetProgress(bulkCancelRequested
      ? `Cancelled: ${ok} of ${queued.length} fetched.`
      : stoppedForLogin
        ? `Stopped: ServiceNow asked for a login. ${ok} of ${queued.length} fetched.`
        : `Finished: ${ok} of ${queued.length} fetched.`);
  } catch (err) {
    bulkSetProgress(`The bulk fetch failed: ${errorText(err)}`);
  } finally {
    setBulkBusy(false);
    bulkCancelRequested = false;
  }
}

function onBulkCancel() {
  bulkCancelRequested = true;
  bulkSetProgress('Cancelling: no new tickets will start; the ones already being fetched will finish ...');
}

function onBulkEdit() {
  if (bulkRunning) return;
  setBulkCollapsed(false);
  renderBulkPreview();
  bulkEls.input.focus({ preventScroll: true });
}

function openBulkPanel() {
  bulkEls.panel.hidden = false;
  if (!bulkRunning && bulkEls.panel.dataset.collapsed !== '1') renderBulkPreview();
  bulkEls.panel.focus({ preventScroll: true });
}

function closeBulkPanel() {
  if (bulkRunning) return;
  bulkEls.panel.hidden = true;
}

/** Attach the bulk-fetch panel's event listeners. A no-op when the markup is missing (defensive,
 * same convention as the rest of this pass). */
export function wireBulkFetch() {
  if (!bulkEls.btn || !bulkEls.panel) return;
  bulkEls.btn.addEventListener('click', openBulkPanel);
  bulkEls.close.addEventListener('click', closeBulkPanel);
  bulkEls.input.addEventListener('input', renderBulkPreview);
  bulkEls.file.addEventListener('change', () => void onBulkFile());
  bulkEls.go.addEventListener('click', (event) => void onBulkGo(event));
  bulkEls.cancel.addEventListener('click', onBulkCancel);
  if (bulkEls.edit) bulkEls.edit.addEventListener('click', onBulkEdit);
}
