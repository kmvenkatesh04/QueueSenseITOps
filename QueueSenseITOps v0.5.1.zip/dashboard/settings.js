// The Settings tab (contract 13.1 / 13.6): ServiceNow display time zone, default country code,
// default business hours, which contact to prefer when a ticket has both a caller and a different
// impacted user, weekend-by-country, data retention, the service desk name used in the guided follow-up
// messages. Persisted to chrome.storage.local under
// lib/settings.js's SETTINGS_STORAGE_KEY ('serviceNowSettings').
//
// Normalisation, defaults and the effective time zone / business hours all come from lib/settings.js,
// the same module the background uses. This file used to load it with a dynamic import and carry an
// inline "equivalent" normaliser for when it was missing; that copy had drifted (it trimmed and
// accepted lower-case zones, turned '91' into '+91', dropped bad business-hours days instead of
// falling back, read inherited properties), so the page and the worker could disagree on what was
// saved. dashboard/opentickets.js already imports lib/settings.js statically, so the page can never
// run without it: one static import, one normaliser, nothing left to drift.
//
// Saving (or a change made in another tab) repaints the ticket table so business-hours / time-zone
// computations pick it up at once: dashboard.js reads effectiveBusinessHours() / effectiveTimeZone()
// into its buildRows() call on every paint.
import { DEFAULT_BUSINESS_HOURS } from '../lib/config.js';
import {
  DEFAULT_SERVICENOW_SETTINGS,
  SETTINGS_STORAGE_KEY,
  effectiveBusinessHours as libEffectiveBusinessHours,
  effectiveTimeZone as libEffectiveTimeZone,
  normalizeServiceDeskName,
  normalizeServiceNowSettings,
} from '../lib/settings.js';
import { create, isObject, str } from './dom.js';
import { paintFieldMapping, wireFieldMapping } from './fieldmap.js';
import { paintOpenTicketsSettings, wireOpenTicketsSettings } from './opentickets.js';
import { hooks, state } from './state.js';

const DAY_LABELS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

/** The one normaliser this page uses (exported so the tests can pin "the page == lib/settings.js"). */
export function normalize(raw) {
  return normalizeServiceNowSettings(raw);
}

function storageKey() {
  return SETTINGS_STORAGE_KEY;
}

function defaults() {
  return DEFAULT_SERVICENOW_SETTINGS;
}

// ---- module state: the effective settings this page currently uses ----
let settings = normalize(null);

/** The normalised settings currently in effect (read-only use by other modules). */
export function currentSettings() {
  return settings;
}

/** Business hours to use right now: the owner's setting, else lib/config.js's default. */
export function effectiveBusinessHours() {
  return libEffectiveBusinessHours(settings);
}

/** IANA zone to read ServiceNow's times in: the owner's setting, else the browser's own zone. */
export function effectiveTimeZone(browserZone) {
  return libEffectiveTimeZone(settings, browserZone);
}

/** True when no ServiceNow time zone has been set (times are read as the browser's own zone). */
export function isTimeZoneAssumed() {
  return !settings.timeZone;
}

// ---- DOM ----

function setById(id, value) {
  const node = document.getElementById(id);
  if (node) node.value = value;
}

function checkedById(id, value) {
  const node = document.getElementById(id);
  if (node) node.checked = Boolean(value);
}

function valueOf(id) {
  const node = document.getElementById(id);
  return node ? node.value : '';
}

function checkedOf(id) {
  const node = document.getElementById(id);
  return Boolean(node && node.checked);
}

let zoneListFilled = false;

function fillTimeZoneList() {
  if (zoneListFilled) return;
  const list = document.getElementById('setTimeZoneList');
  if (!list) return;
  let zones = [];
  try {
    zones = typeof Intl.supportedValuesOf === 'function' ? Intl.supportedValuesOf('timeZone') : [];
  } catch {
    zones = [];
  }
  const frag = document.createDocumentFragment();
  for (const zone of zones) {
    const option = document.createElement('option');
    option.value = zone;
    frag.append(option);
  }
  list.replaceChildren(frag);
  zoneListFilled = true;
}

function browserZone() {
  try {
    return new Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
  } catch {
    return 'UTC';
  }
}

function setStatus(stateName, message) {
  const node = document.getElementById('settingsStatus');
  if (!node) return;
  node.dataset.state = stateName;
  node.textContent = message;
}

let paintedFormKey = null; // the saved values the main form fields were last filled from

/**
 * Fill the Settings tab from `settings`. Safe to call before the panel has ever been shown. `force`
 * refills the MAIN form only (after its own Save / Reset). The other sections keep their own rules: the
 * field mapping and "Open tickets to load" refill only when their saved values changed (and the latter
 * also leaves unsaved edits alone), so saving the main form never wipes what is being typed in a
 * section that has its own save button - only that section's save may force it.
 */
export function paintSettings({ force = false } = {}) {
  fillTimeZoneList();
  // The main form refills its fields only when the SAVED values changed (or `force`), so
  // the per-minute repaint never wipes an edit that has not been saved yet.
  const formKey = JSON.stringify([settings.timeZone, settings.defaultCountryCode, settings.businessHours,
    settings.userSource, settings.weekendByCountry, settings.retentionDays, settings.serviceDeskName]);
  if (force || formKey !== paintedFormKey) {
    paintedFormKey = formKey;
    paintMainForm();
  }
  paintViewSettings();
  paintFieldMapping(settings.fieldMapping);
  paintOpenTicketsSettings(settings);
}

function paintMainForm() {
  const bh = settings.businessHours || DEFAULT_BUSINESS_HOURS;
  setById('setTimeZone', settings.timeZone);
  setById('setDefaultCountry', settings.defaultCountryCode);
  setById('setBhStart', bh.start);
  setById('setBhEnd', bh.end);
  for (let day = 0; day <= 6; day += 1) checkedById(`setDay${day}`, bh.days.includes(day));
  setById('setUserSource', settings.userSource);
  checkedById('setWeekendByCountry', settings.weekendByCountry);
  setById('setRetentionDays', String(settings.retentionDays));
  setById('setDeskName', settings.serviceDeskName);
  const note = document.getElementById('setTimeZoneBrowser');
  if (note) {
    const zone = browserZone();
    note.textContent = settings.timeZone
      ? `Browser zone: ${zone}. Using the zone set above.`
      : `Using the browser's own zone: ${zone}. Set it above if ServiceNow shows a different zone.`;
  }
}

// ---- View settings: predefined Tickets-table filters (contract 16.5) ----
// Kept local to this module (not lib/settings.js, which only owns normalisation/storage): reads
// state.records directly for the live Status/Assignment group values, the same "distinct values seen
// in the stored tickets" approach dashboard/tickets.js's own statusValueFilter already uses, duplicated
// here (not imported from tickets.js) to avoid a circular import (tickets.js already imports this
// module for isTimeZoneAssumed/currentSettings).

/** Distinct ServiceNow Status / Assignment group display values currently stored, sorted. Reads
 * record.details.* directly (the raw stored record shape, same field path as the Tickets table's rows
 * - lib/analyze.js's buildRecord already puts details on the stored record itself, contract 16.1). */
function distinctDetailValues(field) {
  const values = new Set();
  for (const record of state.records.values()) {
    const details = isObject(record) && isObject(record.details) ? record.details : {};
    const value = str(details[field]);
    if (value) values.add(value);
  }
  return [...values].sort((a, b) => a.localeCompare(b));
}

/** Fill a <select multiple> with one <option> per value, keeping any values the form already has
 * selected even if they are no longer among the live values (so picking a status that later
 * disappears from the stored tickets does not silently lose the user's in-progress selection). */
function fillMultiSelect(id, values) {
  const select = document.getElementById(id);
  if (!select) return;
  const kept = new Set([...select.selectedOptions].map((o) => o.value));
  const all = [...new Set([...values, ...kept])].sort((a, b) => a.localeCompare(b));
  select.replaceChildren(...all.map((value) => {
    const option = create('option', '', value);
    option.value = value;
    option.selected = kept.has(value);
    return option;
  }));
}

function viewRowText(view) {
  const parts = [];
  if (view.statuses.length) parts.push(`Status: ${view.statuses.join(', ')}`);
  if (view.assignmentGroups.length) parts.push(`Assignment group: ${view.assignmentGroups.join(', ')}`);
  return parts.length ? parts.join(' · ') : 'Any status, any assignment group';
}

function paintViewSettingsList() {
  const list = document.getElementById('setViewsList');
  if (!list) return;
  const views = Array.isArray(settings.savedViews) ? settings.savedViews : [];
  if (!views.length) {
    list.replaceChildren(create('li', 'settings-views-empty', 'No saved views yet.'));
    return;
  }
  list.replaceChildren(...views.map((view) => {
    const row = create('li', 'settings-view-row');
    row.dataset.viewId = view.id;
    const label = create('span', 'settings-view-name', view.name);
    label.title = viewRowText(view);
    const detail = create('span', 'settings-view-detail', viewRowText(view));
    const remove = create('button', 'btn btn-sm btn-quiet', 'Remove');
    remove.type = 'button';
    remove.dataset.action = 'removeView';
    remove.setAttribute('aria-label', `Remove saved view "${view.name}"`);
    row.append(label, detail, remove);
    return row;
  }));
}

/** Fill the view-settings form's two multi-selects and repaint the saved-views list. Safe to call
 * before the panel has ever been shown (the form/list elements may not exist yet). */
function paintViewSettings() {
  fillMultiSelect('setViewStatuses', distinctDetailValues('state'));
  fillMultiSelect('setViewGroups', distinctDetailValues('assignmentGroup'));
  paintViewSettingsList();
}

function setViewsStatus(stateName, message) {
  const node = document.getElementById('setViewsStatus');
  if (!node) return;
  node.dataset.state = stateName;
  node.textContent = message;
}

function selectedValues(id) {
  const select = document.getElementById(id);
  return select ? [...select.selectedOptions].map((o) => o.value) : [];
}

/** Persist `nextViews` as the saved-views list (through the full normaliser, so a freshly-added entry
 * gets a clean id the same way any other saved value would). */
async function persistSavedViews(nextViews, successMessage) {
  const next = normalize({ ...settings, savedViews: nextViews });
  try {
    await persist(next);
  } catch (err) {
    setViewsStatus('error', `Could not save: ${(err && err.message) || err}.`);
    return;
  }
  settings = next;
  paintViewSettings();
  setViewsStatus('ok', successMessage);
  hooks.paint(); // the Tickets toolbar's saved-view options depend on settings.savedViews
}

async function onAddView(event) {
  event.preventDefault();
  const name = str(valueOf('setViewName'));
  if (!name) {
    setViewsStatus('error', 'Give the view a name first.');
    const input = document.getElementById('setViewName');
    if (input) input.focus();
    return;
  }
  const raw = {
    name,
    statuses: selectedValues('setViewStatuses'),
    assignmentGroups: selectedValues('setViewGroups'),
  };
  await persistSavedViews([...(settings.savedViews || []), raw], `Saved view "${name}".`);
  setById('setViewName', '');
}

async function onRemoveView(event) {
  const removeBtn = event.target.closest('button[data-action="removeView"]');
  if (!removeBtn) return;
  const row = removeBtn.closest('li[data-view-id]');
  const id = row && row.dataset.viewId;
  if (!id) return;
  const view = (settings.savedViews || []).find((v) => v.id === id);
  await persistSavedViews((settings.savedViews || []).filter((v) => v.id !== id), view ? `Removed "${view.name}".` : 'Removed.');
}

function readFormDays() {
  const days = [];
  for (let day = 0; day <= 6; day += 1) if (checkedOf(`setDay${day}`)) days.push(day);
  return days;
}

function rawFromForm() {
  return {
    timeZone: valueOf('setTimeZone').trim(),
    defaultCountryCode: valueOf('setDefaultCountry').trim(),
    businessHours: { start: valueOf('setBhStart'), end: valueOf('setBhEnd'), days: readFormDays() },
    userSource: valueOf('setUserSource'),
    weekendByCountry: checkedOf('setWeekendByCountry'),
    retentionDays: Number(valueOf('setRetentionDays')),
    serviceDeskName: valueOf('setDeskName'),
    // Kept as they are: these have their own sections and save buttons (not form fields here).
    savedViews: settings.savedViews,
    fieldMapping: settings.fieldMapping,
    openTickets: settings.openTickets,
  };
}

/** Fields the raw input asked for that normalisation could not use (shown so nothing is silently dropped). */
function invalidFieldNames(raw, normalized) {
  const names = [];
  if (raw.timeZone && raw.timeZone !== normalized.timeZone) names.push('ServiceNow time zone (not a recognised zone)');
  if (raw.defaultCountryCode && raw.defaultCountryCode !== normalized.defaultCountryCode) names.push('default country code');
  const rawBh = raw.businessHours;
  if (rawBh && (rawBh.start || rawBh.end || rawBh.days.length) && !normalized.businessHours) {
    names.push('business hours (need a start before the end, and at least one working day)');
  }
  if (Number.isFinite(raw.retentionDays) && raw.retentionDays < 0 && normalized.retentionDays === 0) {
    names.push('retention days');
  }
  const deskTyped = typeof raw.serviceDeskName === 'string' ? raw.serviceDeskName.replace(/\s+/g, ' ').trim() : '';
  if (deskTyped && normalizeServiceDeskName(deskTyped) !== deskTyped) {
    names.push(`service desk name (now "${normalized.serviceDeskName}")`);
  }
  return names;
}

async function persist(next) {
  await chrome.storage.local.set({ [storageKey()]: next });
}

async function onSave(event) {
  event.preventDefault();
  const raw = rawFromForm();
  const normalized = normalize(raw);
  const invalid = invalidFieldNames(raw, normalized);
  try {
    await persist(normalized);
  } catch (err) {
    setStatus('error', `Settings could not be saved: ${(err && err.message) || err}.`);
    return;
  }
  settings = normalized;
  paintSettings({ force: true });
  setStatus(invalid.length ? 'warn' : 'ok', invalid.length
    ? `Saved. These values were not usable and were reset: ${invalid.join('; ')}.`
    : 'Settings saved.');
  hooks.paint();
}

/** What "Reset to defaults" stores: the main form's values back to the defaults, while the sections that
 * have their own save buttons (saved views, column-to-field mapping, open tickets to load) are kept -
 * resetting the time zone must not silently delete the owner's saved views or queues. */
export function resetMainForm(current) {
  const keep = isObject(current) ? current : {};
  return normalize({
    ...defaults(),
    savedViews: keep.savedViews,
    fieldMapping: keep.fieldMapping,
    openTickets: keep.openTickets,
  });
}

/** Status line after a reset, naming what was deliberately kept. */
export const RESET_STATUS_TEXT = 'Settings reset to defaults. Saved views, the column to field mapping and the open tickets to load were kept (each has its own section).';

async function onReset() {
  const next = resetMainForm(settings);
  try {
    await persist(next);
  } catch (err) {
    setStatus('error', `Settings could not be reset: ${(err && err.message) || err}.`);
    return;
  }
  settings = next;
  paintSettings({ force: true });
  setStatus('ok', RESET_STATUS_TEXT);
  hooks.paint();
}

function onStorageChanged(changes, area) {
  if (area !== 'local' || !(storageKey() in changes)) return;
  settings = normalize(changes[storageKey()].newValue);
  paintSettings();
  hooks.paint();
}

/** Load the stored settings and start watching for changes. */
export async function initSettings() {
  try {
    const stored = await chrome.storage.local.get([storageKey()]);
    settings = normalize(stored[storageKey()]);
  } catch {
    settings = normalize(null);
  }
  paintSettings();
  if (globalThis.chrome && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener(onStorageChanged);
  }
}

/** Attach the Settings form's event listeners. */
export function wireSettings() {
  const form = document.getElementById('settingsForm');
  const reset = document.getElementById('settingsReset');
  if (form) form.addEventListener('submit', (event) => void onSave(event));
  if (reset) reset.addEventListener('click', () => void onReset());

  const viewsForm = document.getElementById('setViewsForm');
  if (viewsForm) viewsForm.addEventListener('submit', (event) => void onAddView(event));
  const viewsList = document.getElementById('setViewsList');
  if (viewsList) viewsList.addEventListener('click', (event) => void onRemoveView(event));

  wireFieldMapping({
    save: async (fieldMapping) => {
      const next = normalize({ ...settings, fieldMapping });
      await persist(next);
      settings = next;
      paintFieldMapping(settings.fieldMapping);
    },
  });

  wireOpenTicketsSettings({
    save: async (openTickets) => {
      const next = normalize({ ...settings, openTickets });
      await persist(next);
      settings = next;
      paintOpenTicketsSettings(settings, { force: true }); // show the saved, cleaned values
    },
  });
}

// Exported for the static-scan test's sanity check and for readability in the console only.
export const DAY_NAMES = DAY_LABELS;
