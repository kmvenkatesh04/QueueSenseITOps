// Shared mutable state of the dashboard page and the hooks the modules call back into. The page has
// exactly one instance of everything, so a module-level object is the simplest honest model.
import { normalizeSettings } from '../lib/followup.js';
import { emptyQueueTracking } from '../lib/queueTracking.js';

/** The three views, in tab order. */
export const VIEWS = ['tickets', 'history', 'data'];
/** Values of the "business hours now" filter ('all' = no filter; the others can be combined, v0.4). */
export const STATUS_FILTERS = ['all', 'business', 'non-business', 'uncertain', 'unknown'];
/** Named values of the day filter (a YYYY-MM-DD date is also accepted). */
export const DAY_CHOICES = ['today', 'yesterday', 'last7', 'all'];

/** Everything the page remembers; chrome.storage.local is the only durable copy. */
export const state = {
  view: 'tickets',
  day: 'today',
  // The "business hours now" filter: the chosen statuses (any of them matches), [] = all. Since v0.4 a
  // list; older callers that still assign a single value ('all', 'business') keep working, because
  // every reader goes through nav.js's statusFilterValues() / lib/ticketFilters.js normalizeStatusList.
  status: [],
  scope: 'all', // Data view: 'all' or one incident number
  historyDay: 'all',
  historyQuery: '',

  // what chrome.storage.local holds (normalised); replaced, never mutated in place
  data: {
    incidents: {},
    log: [],
    settings: normalizeSettings(null),
    refreshJob: null,
    refreshSettings: { onStartup: true },
    queueTracking: emptyQueueTracking(), // lib/queueTracking.js (v0.5): queue membership + last fetch errors
  },
  records: new Map(), // incident number -> stored record (object records only)

  rowsByNumber: new Map(), // every row of the selected day (before the status filter)
  composer: null, // the one open composer, or null
  composerSeq: 0,
  guides: new Map(), // incident number -> { snapshot, wanted }: the guide of a composer, kept across repaints and reopening
  details: new Set(), // incident numbers whose details drawer is open
  refreshing: new Set(), // incident numbers with a FETCH_INCIDENT in flight
  notes: new Map(), // incident number -> { state, message } shown in the row
  noteTimers: new Map(),
  nodes: new Map(), // reconcile cache of the ticket table: key -> { sig, node }
  historyNodes: new Map(), // reconcile cache of the history table
  pendingFocus: null, // { incident, action } to focus once that button is usable
  justFetched: '', // incident number to flash after a search
  justFetchedTimer: 0,

  writeChain: Promise.resolve(), // serialises every storage write of this page
  pendingWrites: 0,
  loadSeq: 0,
  noticeTimer: 0,
  changeTimer: 0,
  pendingKeys: new Set(), // stored keys whose newest value has not been read into state.data yet

  searchBusy: false,
  refreshStarting: false, // REFRESH_ALL request in flight
  refreshMessage: null, // { state, text } shown in the refresh bar after a failed request
  announced: '', // last refresh state announced to screen readers
  jsonCache: { source: null, scope: '', text: '' },
  importBusy: false,
};

/**
 * Late-bound entry points of dashboard.js, so that the feature modules can ask for a repaint
 * without importing the module that imports them.
 */
export const hooks = {
  paint() {},
  render: async () => {},
  showNotice() {},
  showTicket() {},
  showJson() {},
  refreshRow: async () => {},
};
