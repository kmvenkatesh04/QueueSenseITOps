// chrome.storage.local access of the dashboard. Reads are normalised into state.data; every write of
// this page goes through one queue (read-modify-write inside it), so rapid clicks lose nothing.
// v0.5: 'queueTracking' (lib/queueTracking.js) is watched like the other keys and written only through
// persistQueueTracking (by dashboard/opentickets.js after a "Load all open tickets" run or a retry).
import { STORAGE_KEYS } from '../lib/config.js';
import { FOLLOW_UP_STORAGE_KEYS, appendFollowUp, normalizeSettings } from '../lib/followup.js';
import { QUEUE_TRACKING_STORAGE_KEY, normalizeQueueTracking } from '../lib/queueTracking.js';
import { isObject, str } from './dom.js';
import { state } from './state.js';

/** chrome.storage.local keys this page reads or writes. */
export const KEY = {
  incidents: STORAGE_KEYS.incidents,
  log: FOLLOW_UP_STORAGE_KEYS.log,
  settings: FOLLOW_UP_STORAGE_KEYS.settings,
  refreshJob: FOLLOW_UP_STORAGE_KEYS.refreshJob,
  refreshSettings: FOLLOW_UP_STORAGE_KEYS.refreshSettings,
  instanceUrl: STORAGE_KEYS.instanceUrl,
  queueTracking: QUEUE_TRACKING_STORAGE_KEY,
};

/** Keys whose change repaints the page. */
export const WATCHED_KEYS = [KEY.incidents, KEY.log, KEY.settings, KEY.refreshJob, KEY.refreshSettings, KEY.queueTracking];

const FIELD_OF_KEY = {
  [KEY.incidents]: 'incidents',
  [KEY.log]: 'log',
  [KEY.settings]: 'settings',
  [KEY.refreshJob]: 'refreshJob',
  [KEY.refreshSettings]: 'refreshSettings',
  [KEY.queueTracking]: 'queueTracking',
};

const NORMALIZE = {
  incidents: (value) => (isObject(value) || Array.isArray(value) ? value : {}),
  log: (value) => (Array.isArray(value) ? value : []),
  settings: (value) => normalizeSettings(value),
  refreshJob: (value) => (isObject(value) ? value : null),
  refreshSettings: (value) => ({ onStartup: !(isObject(value) && value.onStartup === false) }),
  queueTracking: (value) => normalizeQueueTracking(value),
};

/** chrome.storage.local.get; null when storage cannot be read (the caller keeps what it has). */
export async function storageGet(keys) {
  try {
    return (await chrome.storage.local.get(keys)) || {};
  } catch {
    return null;
  }
}

// Read-modify-write jobs must not write after a failed read: that would replace stored data with a
// guess. A failed read throws and the write is abandoned.
export async function storageRead(keys) {
  return (await chrome.storage.local.get(keys)) || {};
}

/**
 * True when the worker's stored `lastIncident` (a full copy of the last searched record, see
 * background.js saveRecord) is ticket `number`: deleting or removing that ticket must remove this copy
 * too, or "deleted from this computer" would not be true.
 * @param {*} value the stored lastIncident
 * @param {string} number
 * @returns {boolean}
 */
export function isLastIncidentOf(value, number) {
  return isObject(value) && typeof number === 'string' && number !== '' && value.incidentNumber === number;
}

/** Stored records by incident number (non-objects are skipped; the record's own number wins over its key). */
function indexRecords(incidents) {
  const entries = Array.isArray(incidents) ? incidents.map((record) => ['', record]) : Object.entries(incidents || {});
  const records = new Map();
  for (const [key, record] of entries) {
    if (!isObject(record)) continue;
    const number = str(record.incidentNumber) || key;
    if (number) records.set(number, record);
  }
  return records;
}

function setField(field, value) {
  state.data = { ...state.data, [field]: NORMALIZE[field](value) };
  if (field === 'incidents') state.records = indexRecords(state.data.incidents);
}

/** Apply what a storage.get returned for `keys` (a missing key becomes its default). */
export function applyStored(stored, keys = Object.keys(FIELD_OF_KEY)) {
  for (const key of keys) {
    if (Object.hasOwn(FIELD_OF_KEY, key)) setField(FIELD_OF_KEY[key], stored[key]);
  }
}

// ---- writes ----

/** Run a storage write after every earlier one of this page; resolves with the job's result. */
export function queueWrite(job) {
  state.pendingWrites += 1;
  const run = state.writeChain.then(job);
  state.writeChain = run.catch(() => {}).finally(() => {
    state.pendingWrites -= 1;
  });
  return run;
}

/** Add a follow-up log entry (newest first, capped) to storage. */
export function persistFollowUp(entry) {
  const key = KEY.log;
  return queueWrite(async () => {
    const stored = await storageRead([key]);
    await chrome.storage.local.set({ [key]: appendFollowUp(stored[key], entry) });
  });
}

function persistObject(key, patch) {
  return queueWrite(async () => {
    const stored = await storageRead([key]);
    const current = isObject(stored[key]) ? stored[key] : {};
    await chrome.storage.local.set({ [key]: { ...current, ...patch } });
  });
}

/** Merge a patch into followUpSettings ({ dryRun, noteType }); other keys stay. */
export function persistSettings(patch) {
  return persistObject(KEY.settings, patch);
}

/** Merge a patch into refreshSettings ({ onStartup }). */
export function persistRefreshSettings(patch) {
  return persistObject(KEY.refreshSettings, patch);
}

/**
 * Read-modify-write of the queue tracking object (lib/queueTracking.js, v0.5) inside this page's write
 * queue. `updater(current)` gets the freshly read, normalised value and returns the new one (never the
 * same object mutated: lib/queueTracking.js functions return new objects); a non-object return writes
 * nothing. A failed read rejects and writes nothing (never a write over a guess); so does an updater
 * that throws. On success state.data.queueTracking is updated at once, so the auto refresh scheduler
 * sees the new run before the storage listener repaints.
 * @param {(current: object) => object} updater
 * @returns {Promise<object>} the value written (or the unchanged current value)
 */
export function persistQueueTracking(updater) {
  const key = KEY.queueTracking;
  return queueWrite(async () => {
    const stored = await storageRead([key]);
    const current = normalizeQueueTracking(stored[key]);
    const next = typeof updater === 'function' ? updater(current) : undefined;
    if (!isObject(next)) return current;
    await chrome.storage.local.set({ [key]: next });
    setField('queueTracking', next);
    return next;
  });
}
