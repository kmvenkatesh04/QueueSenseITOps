// Cells and buttons of one ticket row, plus the keyed reconcile and the focus bookkeeping that keep an
// open composer (and whatever has focus) alive across repaints. All text from ServiceNow is untrusted
// and goes in through textContent only.
import {
  buildMailtoLink, buildTeamsChatUrl, primaryAction, recommendationText, statusPillLabel, statusTone,
} from '../lib/followup.js';
import { getZoneParts } from '../lib/timeUtils.js';
import {
  EM_DASH, MIDDOT, button, capitalize, create, externalLink, idPart, isObject, safeHttpUrl, str, withField,
} from './dom.js';

// Row-level warnings and the business-hours-source tooltip below depend on fields contract 13.4 adds
// to lib/dashboardModel.js's rows (row.warnings, row.contactPerson, row.impactedName,
// row.preferredContactFromLabel, lastContact.kind/.timeProblem/.streamRead), which another engineer is
// landing in parallel. Every read of them below is a strict check against the exact value the
// contract defines (never a plain truthy/falsy coercion of `undefined`), so the row renders exactly as
// it does today until those fields exist, and lights up automatically once they do.

/** Columns of the ticket table (composer and details rows span them). Was 6 before the Status and
 * Assignment group columns (contract 15.4). */
export const TABLE_COLUMNS = 8;

// Status text that reads as "this ticket is done" (contract 15.4: muted, text-only, never colour-only).
const CLOSED_STATE_RE = /\b(closed|resolved|cancelled|canceled|complete|completed)\b/i;
const STATUSES = ['business', 'non-business', 'uncertain', 'unknown'];
const TONES = ['green', 'red', 'amber', 'grey'];
const LOCAL_TIME = /^([A-Za-z]{3}) \d{4}-\d{2}-\d{2} (\d{2}:\d{2}):\d{2} \((GMT[^)]*)\)$/;
const CONTACT_FORMAT = new Intl.DateTimeFormat('en-GB', {
  weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
});

const normStatus = (status) => (STATUSES.includes(status) ? status : 'unknown');
const toneFor = (status, given) => (TONES.includes(given) ? given : statusTone(status));

/** Id of a row's recommendation sentence (target of aria-describedby). */
function recommendationId(number) {
  return `rec-${idPart(number)}`;
}

/** Id of a row's details drawer (target of aria-controls). */
export function detailsId(number) {
  return `details-${idPart(number)}`;
}

// ---- small pieces ----

/** 'Thu 2026-10-08 10:30:00 (GMT+5:30)' -> 'Thu 10:30 (GMT+5:30)'; anything else is shown as it is. */
function compactLocalTime(text) {
  const match = LOCAL_TIME.exec(str(text));
  return match ? `${match[1]} ${match[2]} (${match[3]})` : str(text);
}

/** Appends 'Thu 10:30 (GMT+2)' so the '(GMT+2)' part never breaks across two lines. */
function appendLocalTime(parent, text) {
  const index = text.indexOf(' (');
  if (index < 0) {
    parent.append(text);
    return;
  }
  parent.append(text.slice(0, index + 1), create('span', 'nowrap', text.slice(index + 1)));
}

function formatContactTime(iso) {
  const date = new Date(typeof iso === 'string' ? iso : NaN);
  return Number.isNaN(date.getTime()) ? '' : CONTACT_FORMAT.format(date).replace(/,/g, '');
}

/** kind 'contact' = the big solid pill about a past moment, 'now' = the soft pill about the present. */
function makePill(kind, fieldName, status, tone, title) {
  const key = normStatus(status);
  const pill = withField(create('span', `pill pill-${kind}`, statusPillLabel(key, kind)), fieldName);
  pill.dataset.status = key;
  pill.dataset.tone = tone;
  if (title) pill.title = title;
  return pill;
}

function cell(tag, className, column) {
  const node = create(tag, `cell ${className}`);
  node.dataset.col = column;
  return node;
}

// ---- ticket cell ----

function refreshBadge(row) {
  const error = isObject(row.refreshError) ? row.refreshError : null;
  if (!error) return null;
  const login = str(error.code) === 'LOGIN_REQUIRED';
  const wrap = create('p', 'refresh-state');
  wrap.dataset.code = str(error.code);
  const badge = withField(create('span', 'badge badge-warn', login ? 'Login needed' : 'Refresh failed'), 'refreshState');
  badge.title = str(error.message) || (login ? 'ServiceNow asked for a login.' : 'The last refresh did not work.');
  const stale = str(row.fetchedAtLabel);
  wrap.append(badge, stale ? ` Showing data from ${stale}` : ' Showing the data from the last successful read');
  return wrap;
}

// Priority order and plain-word labels for row.warnings (contract 13.3/13.4 codes). A code outside
// this list (future additions) still renders, using its own code as the label, after the known ones.
const WARNING_PRIORITY = [
  'REF_DISPLAY_MISSING', 'STREAM_NOT_READ', 'PHONE_ACL_EMPTY', 'LABEL_NOT_FOUND', 'NO_LOCATION',
  'DATE_UNPARSED', 'DATE_AMBIGUOUS', 'TIME_ZONE_ASSUMED', 'ASSIGNEE_NOT_IN_STREAM',
  'IMPACTED_USER_DIFFERS', 'COUNTRY_ASSUMED',
];
const WARNING_WORDS = {
  REF_DISPLAY_MISSING: 'A reference field could not be shown by name',
  STREAM_NOT_READ: 'Activity stream not read',
  PHONE_ACL_EMPTY: 'No phone number was readable',
  LABEL_NOT_FOUND: 'A labelled field was not found',
  NO_LOCATION: 'No location could be determined',
  DATE_UNPARSED: 'A date could not be read',
  DATE_AMBIGUOUS: 'A date format is ambiguous',
  TIME_ZONE_ASSUMED: 'ServiceNow time zone assumed',
  ASSIGNEE_NOT_IN_STREAM: "The assigned agent's update was not found in the stream",
  IMPACTED_USER_DIFFERS: 'Impacted user differs from the caller',
  COUNTRY_ASSUMED: 'Country assumed from the default setting',
};

/** Warning chips [data-field="warnings"]: text + icon, title = the full message, in priority order. */
function warningsNode(row) {
  const list = Array.isArray(row.warnings) ? row.warnings.filter((w) => isObject(w) || typeof w === 'string') : [];
  if (!list.length) return null;
  const codeOf = (w) => (isObject(w) ? str(w.code) : str(w));
  const known = WARNING_PRIORITY.filter((code) => list.some((w) => codeOf(w) === code))
    .map((code) => list.find((w) => codeOf(w) === code));
  const rest = list.filter((w) => !WARNING_PRIORITY.includes(codeOf(w)));
  const wrap = withField(create('div', 'warn-chips'), 'warnings');
  for (const warning of [...known, ...rest]) {
    const code = codeOf(warning);
    const message = isObject(warning) ? str(warning.message) : '';
    const chip = create('span', 'warn-chip', WARNING_WORDS[code] || code || 'Warning');
    const icon = create('span', 'warn-icon', '⚠');
    icon.setAttribute('aria-hidden', 'true');
    chip.prepend(icon);
    chip.title = message || WARNING_WORDS[code] || code;
    wrap.append(chip);
  }
  return wrap;
}

// ---- user engagement + negative sentiment (lib/engagement.js via row.engagement) ----

// 'sporadic' is green, not amber: the user IS responding, which is the same good news the green user
// name tells (userSentiment below); an amber pill next to a green name read as two different verdicts.
const ENGAGEMENT_TONES = { frustrated: 'red', sporadic: 'green', none: 'grey' };

/** "Frustrated · 6 updates" / "Sporadic response · 2 updates" / "No response"; null when unknown. */
function engagementPill(row) {
  const engagement = isObject(row.engagement) ? row.engagement : {};
  const tone = ENGAGEMENT_TONES[engagement.level];
  if (!tone || !str(engagement.label)) return null;
  const updates = Number(engagement.callerUpdates) || 0;
  const label = engagement.level === 'none'
    ? engagement.label
    : `${engagement.label} ${MIDDOT} ${updates} ${updates === 1 ? 'update' : 'updates'}`;
  const pill = withField(create('span', 'pill pill-soft engagement-pill', label), 'engagement');
  pill.dataset.tone = tone;
  pill.dataset.level = engagement.level;
  const peak = Number(engagement.peak24h) || 0;
  const parts = [
    `The user has updated this ticket ${updates} ${updates === 1 ? 'time' : 'times'}.`,
    peak > 1 ? `Most in one day: ${peak}.` : '',
    str(engagement.lastCallerUpdate) ? `Last update by the user: ${str(engagement.lastCallerUpdate)}.` : '',
  ];
  pill.title = parts.filter(Boolean).join(' ');
  return pill;
}

/** A red "negative sentiment" icon when someone other than the assignee used negative wording. */
function sentimentIcon(row) {
  const engagement = isObject(row.engagement) ? row.engagement : {};
  const hits = Array.isArray(engagement.negativeHits) ? engagement.negativeHits : [];
  if (engagement.negative !== true || !hits.length) return null;
  const icon = withField(create('span', 'sentiment-icon', '☹'), 'negativeSentiment');
  icon.setAttribute('role', 'img');
  const terms = hits.map((hit) => str(hit.term)).filter(Boolean);
  icon.setAttribute('aria-label', `Negative sentiment: ${terms.join(', ')}`);
  icon.title = ['Negative sentiment (comments by people other than the assignee):',
    ...hits.map((hit) => `• "${str(hit.term)}" by ${str(hit.author) || 'unknown'}: ${str(hit.snippet)}`)].join('\n');
  return icon;
}

// ---- queue membership (v0.5: row.queue from lib/dashboardModel.js + lib/queueTracking.js) ----
//
// row.queue is null for a ticket that no "Load all open tickets" run has seen in a saved queue, else
// { inQueue, firstSeenAt, enteredAt, movedOutAt, isNew, movedOut, movedOutReason, movedTo, group }. Two
// pills under the ticket's summary say what changed: "New to queue" (entered within the last 24 hours,
// after the queue's first complete run) and "Moved out <time> · <reason>". The words carry the meaning;
// the colour only repeats it (WCAG 1.4.1).

const pad2 = (n) => String(n).padStart(2, '0');
const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTH_NAMES = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

const ISO_INSTANT = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/;

/** Clock parts of an ISO instant in `timeZone` (the browser's zone when that is unusable); null. Only an
 * ISO-8601 instant counts (Date.parse would read '5' as a year in 2001). */
function zoneParts(iso, timeZone) {
  const time = typeof iso === 'string' && ISO_INSTANT.test(iso.trim()) ? Date.parse(iso) : NaN;
  if (!Number.isFinite(time)) return null;
  const date = new Date(time);
  for (const zone of [str(timeZone) || undefined, undefined]) {
    try {
      const parts = getZoneParts(date, zone); // undefined = the system zone
      if (parts && Number.isFinite(parts.year)) return parts;
    } catch {
      // try the browser's zone next
    }
  }
  return null;
}

/**
 * 'YYYY-MM-DD' of an instant on the clock of `timeZone` ('' when unusable). tickets.js passes today's key
 * in each row's ctx, so a queue time of today reads '10:15' and an older one 'Wed 28 Oct 10:15' -- and the
 * row repaints once at midnight, not on every tick.
 * @param {Date|string} at
 * @param {string} timeZone
 * @returns {string}
 */
export function dayKeyIn(at, timeZone) {
  const iso = at instanceof Date ? (Number.isNaN(at.getTime()) ? '' : at.toISOString()) : str(at);
  const p = zoneParts(iso, timeZone);
  return p ? `${String(p.year).padStart(4, '0')}-${pad2(p.month)}-${pad2(p.day)}` : '';
}

/**
 * A queue time for the table: 'HH:MM' when it falls on `today` (a dayKeyIn key), else 'Wed 28 Oct HH:MM';
 * `full` always gives the long form. '' for anything unusable. Never throws.
 * @param {string} iso
 * @param {string} timeZone
 * @param {string} [today]
 * @param {boolean} [full]
 * @returns {string}
 */
export function queueTimeLabel(iso, timeZone, today = '', full = false) {
  const p = zoneParts(iso, timeZone);
  if (!p) return '';
  const clock = `${pad2(p.hour)}:${pad2(p.minute)}`;
  const key = `${String(p.year).padStart(4, '0')}-${pad2(p.month)}-${pad2(p.day)}`;
  if (!full && today && key === today) return clock;
  return `${WEEKDAYS[p.weekday] || ''} ${p.day} ${MONTH_NAMES[p.month - 1] || p.month} ${clock}`;
}

/**
 * Why a ticket left the queue, in words: short (the table pill: 'resolved' / 'moved to Network' / 'no
 * longer listed') or long (the details drawer). '' when the row did not move out or the reason is unknown.
 * @param {object|null} queue row.queue
 * @param {{long?:boolean}} [opts]
 * @returns {string}
 */
export function movedOutWords(queue, { long = false } = {}) {
  if (!isObject(queue) || queue.movedOut !== true) return '';
  const movedTo = str(queue.movedTo);
  if (queue.movedOutReason === 'resolved') {
    if (!long) return 'resolved';
    return movedTo ? `the ticket is ${movedTo}` : 'the ticket is no longer open';
  }
  if (queue.movedOutReason === 'reassigned') {
    if (movedTo) return long ? `reassigned to ${movedTo}` : `moved to ${movedTo}`;
    return long ? 'reassigned to a group outside the saved queues' : 'moved to another group';
  }
  if (queue.movedOutReason === 'left-list') {
    // movedTo is the ticket's State then (lib/dashboardModel.js): usually a state the saved states leave out
    if (!long) return 'no longer listed';
    return movedTo
      ? `no longer listed in the saved queues (its state is now ${movedTo})`
      : 'no longer listed in the saved queues (for example its state is not one of the saved states)';
  }
  return '';
}

/** The "New to queue" / "Moved out ..." pills of a row, or null when neither applies. */
function queueBadges(row, ctx) {
  const queue = isObject(row.queue) ? row.queue : null;
  if (!queue) return null;
  const context = isObject(ctx) ? ctx : {};
  const zone = str(context.timeZone);
  const today = str(context.today);
  const line = withField(create('p', 'queue-state'), 'queueState');
  if (queue.isNew === true && queue.movedOut !== true) {
    const pill = create('span', 'queue-pill queue-new');
    pill.dataset.queue = 'new';
    const icon = create('span', 'queue-icon', '+');
    icon.setAttribute('aria-hidden', 'true');
    pill.append(icon, 'New to queue');
    const at = queueTimeLabel(str(queue.enteredAt), zone, today, true);
    pill.title = at ? `Entered the queue at ${at}` : 'Entered the queue in the past 24 hours';
    line.append(pill);
    if (at) line.append(create('span', 'sr-only', `, entered the queue at ${at}`));
  }
  if (queue.movedOut === true) {
    const pill = create('span', 'queue-pill queue-out');
    pill.dataset.queue = 'movedOut';
    pill.dataset.reason = str(queue.movedOutReason) || 'unknown';
    const icon = create('span', 'queue-icon', '→');
    icon.setAttribute('aria-hidden', 'true');
    const at = queueTimeLabel(str(queue.movedOutAt), zone, today);
    const why = movedOutWords(queue);
    pill.append(icon, ['Moved out', at].filter(Boolean).join(' ') + (why ? ` ${MIDDOT} ${why}` : ''));
    const full = queueTimeLabel(str(queue.movedOutAt), zone, today, true);
    const long = movedOutWords(queue, { long: true });
    pill.title = `Moved out of the service desk queue${full ? ` at ${full}` : ''}${long ? `: ${long}` : ''}.`;
    line.append(pill);
  }
  return line.children.length ? line : null;
}

function ticketCell(row, ctx) {
  const th = cell('th', 'col-incident', 'incident');
  th.scope = 'row';
  const href = safeHttpUrl(row.incidentUrl);
  const number = withField(create(href ? 'a' : 'span', 'inc-number', row.incidentNumber), 'incidentNumber');
  if (href) {
    number.href = href;
    number.target = '_blank';
    number.rel = 'noopener noreferrer';
    number.title = 'Open in ServiceNow';
  }
  const sentiment = sentimentIcon(row);
  const description = str(row.shortDescription);
  const summary = withField(create('p', 'inc-desc', description || EM_DASH), 'shortDescription');
  summary.classList.toggle('is-empty', !description);
  if (description) summary.title = description;

  const meta = create('p', 'cell-note inc-meta');
  const searched = str(row.searchedAtLabel) || str(row.fetchedAtLabel);
  if (searched) {
    const times = Number(row.searchCount) > 1 ? ` (${row.searchCount} times)` : '';
    meta.append(withField(create('span', '', `Searched ${searched}${times}`), 'searchedAt'));
  }
  const opened = str(row.openedAgo);
  if (opened) meta.append(searched ? ` ${MIDDOT} ` : '', create('span', '', `Opened ${opened}`));
  th.append(number);
  if (sentiment) th.append(' ', sentiment);
  th.append(summary, meta);
  const queue = queueBadges(row, ctx);
  if (queue) th.append(queue);
  const badge = refreshBadge(row);
  if (badge) th.append(badge);
  const warnings = warningsNode(row);
  if (warnings) th.append(warnings);
  return th;
}

// ---- status and assignment group (contract 15.4) ----

// These two columns read row.details.state / row.details.assignmentGroup, the shape contract 13.4
// gives lib/dashboardModel.js's rows (same field path as record.details.state/assignmentGroup,
// which lib/analyze.js's buildRecord is expected to add). That work had not landed in
// lib/analyze.js / lib/dashboardModel.js as of this pass (neither file exposes `details` yet; both
// are outside this pass's file set), so every read below is defensive (isObject(row.details) ? ... :
// {}) and renders the existing empty convention ('—') until it does -- never a guess, never a throw.

// ---- priority (v0.4: row.priority = { key, label, rank } from lib/dashboardModel.js) ----

const PRIORITY_SHORT_MAX = 12;

/** row.priority when well formed, else one read from row.details.priority ('2 - High'); null = none. */
function priorityInfo(row) {
  const given = isObject(row.priority) ? row.priority : null;
  if (given && str(given.key) && str(given.key) !== 'none') {
    const rank = Number.isInteger(given.rank) && given.rank >= 1 && given.rank <= 5 ? given.rank : null;
    return { key: str(given.key), label: str(given.label) || str(given.key), rank };
  }
  if (given) return null; // the model said: no priority
  const label = isObject(row.details) ? str(row.details.priority) : '';
  if (!label) return null;
  const match = /^p?([1-5])(?!\d)/i.exec(label);
  return match ? { key: `p${match[1]}`, label, rank: Number(match[1]) } : { key: 'other', label, rank: null };
}

/**
 * A small priority pill next to the Status text: 'P2' (the full label, '2 - High', in its title and in
 * sr-only text, so a screen reader hears "Priority 2 - High" and nothing reads only a colour). A label
 * without a leading digit ('Critical') is shown itself, shortened. Null when the ticket has no priority.
 */
function priorityPill(row) {
  const info = priorityInfo(row);
  if (!info) return null;
  const short = info.rank ? `P${info.rank}` : (info.label.length > PRIORITY_SHORT_MAX ? `${info.label.slice(0, PRIORITY_SHORT_MAX - 1)}…` : info.label);
  const pill = withField(create('span', 'prio-pill'), 'priority');
  pill.dataset.prio = info.rank ? `p${info.rank}` : 'other';
  pill.title = `Priority: ${info.label}`;
  const visible = create('span', 'prio-short', short);
  visible.setAttribute('aria-hidden', 'true');
  pill.append(visible, create('span', 'sr-only', `Priority ${info.label}`));
  return pill;
}

/** Plain-text Status cell; closed/resolved/cancelled-looking values (or details.active falsy) are
 * muted, a text-only distinction (never colour-coded), per contract 15.4. The priority pill (v0.4)
 * sits next to it, outside [data-field="status"] so that keeps reading as the State text alone. */
function statusCell(row) {
  const td = cell('td', 'col-status', 'status');
  const details = isObject(row.details) ? row.details : {};
  const text = str(details.state);
  const activeFalsy = details.active === false || details.active === 'false';
  const done = activeFalsy || CLOSED_STATE_RE.test(text);
  const node = withField(create('p', `status-text${done ? ' is-done' : ''}${text ? '' : ' is-empty'}`, text || EM_DASH), 'status');
  if (done) node.title = 'This ticket looks closed, resolved or cancelled.';
  const pill = priorityPill(row);
  if (pill) {
    const line = create('div', 'status-line');
    line.append(node, pill);
    td.append(line);
  } else {
    td.append(node);
  }
  return td;
}

/** Plain-text Assignment group cell (contract 15.4). */
function assignmentGroupCell(row) {
  const td = cell('td', 'col-assignment-group', 'assignmentGroup');
  const details = isObject(row.details) ? row.details : {};
  const text = str(details.assignmentGroup);
  td.append(withField(create('p', `assign-group${text ? '' : ' is-empty'}`, text || EM_DASH), 'assignmentGroup'));
  return td;
}

// ---- user cell ----

// ---- where the user's location came from (phone, or the incident's Location field) ----

/** A small pill of text for the user cell: `kind` 'info' | 'warn' | 'soft'; the icon is decoration only. */
function locationChip(kind, field, text, title, icon) {
  const chip = withField(create('span', `loc-chip loc-${kind}`), field);
  if (icon) {
    const mark = create('span', 'loc-icon', icon);
    mark.setAttribute('aria-hidden', 'true');
    chip.append(mark);
  }
  chip.append(create('span', 'loc-text', text));
  if (title) chip.title = title;
  return chip;
}

/**
 * The extras under the country: where the time zone came from when it was not the phone number alone,
 * a conflict between phone and Location, a Location that only roughly matched, or one that could not
 * be recognised. Every chip says it in words and has an icon, so colour is never the only signal.
 */
function locationNodes(row) {
  const text = str(row.locationText);
  const source = str(row.locationSource);
  const nodes = [];
  if (source === 'location-field' && text) {
    nodes.push(locationChip('info', 'locationSource', `via Location field: ${text}`,
      'There is no usable phone number, so the country and time zone come from the Location field of the incident.', ''));
  } else if (source === 'phone+location' && text) {
    nodes.push(locationChip('info', 'locationSource', `time zone from Location field: ${text}`,
      'The country comes from the phone number; the time zone inside it comes from the Location field of the incident.', ''));
  }
  const conflict = str(row.locationConflict);
  if (conflict) nodes.push(locationChip('warn', 'locationConflict', conflict, conflict, '\u26A0'));
  if (str(row.locationConfidence) === 'low') {
    const note = str(row.locationNote);
    nodes.push(locationChip('soft', 'locationConfidence', note || 'Location only roughly matched',
      note || 'The Location text was only roughly matched, so the time zone may be off.', '\u2248'));
  }
  if (!str(row.country) && text) {
    nodes.push(locationChip('plain', 'locationUnknown', `Location "${text}" not recognised`,
      'The Location field could not be turned into a country, so business hours are unknown.', ''));
  }
  return nodes;
}

/** 'Contact: Hans Weber (caller: Priya S)' when the impacted user differs from the caller and their
 * details are the ones being used (contract 13.4 contactPerson / impactedName; defensive until those
 * fields exist on the row). */
function contactPersonLine(row) {
  const impacted = str(row.impactedName);
  const callerName = str(row.callerName);
  if (row.contactPerson !== 'impacted' || !impacted || impacted === callerName) return null;
  const line = withField(create('p', 'user-contact'), 'contactPerson');
  line.append(`Contact: ${impacted} (caller: ${callerName || EM_DASH})`);
  line.title = "The impacted user on this ticket differs from the caller; their contact details and business hours are used instead of the caller's.";
  return line;
}

/**
 * The location + current-local-time pair, visually grouped as one emphasised unit (contract 15.3):
 * a bordered/tinted sub-block (existing CSS tokens, text+symbol, never colour-only) wrapping exactly
 * the country/location text and the local time there, with the existing source/conflict/confidence
 * chips kept inside the same block so they read together.
 */
function locationEmphasisBlock(row, where, clock) {
  const box = withField(create('div', 'loc-emphasis'), 'locationEmphasis');
  const icon = create('span', 'loc-emphasis-icon', '\u{1F310}'); // globe: decoration only, text carries the meaning
  icon.setAttribute('aria-hidden', 'true');
  const stack = create('div', 'loc-emphasis-stack');
  stack.append(where, clock);
  const extras = locationNodes(row);
  if (extras.length) {
    const chips = create('div', 'loc-chips');
    chips.append(...extras);
    stack.append(chips);
  }
  box.append(icon, stack);
  return box;
}

/** A small gold star next to the user's name when details.vip === true (contract 16.4). The star glyph
 * itself (not colour alone) carries the meaning, plus title/aria-label text for screen readers. */
function vipStar(row) {
  const details = isObject(row.details) ? row.details : {};
  if (details.vip !== true) return null;
  const star = withField(create('span', 'vip-star', '★'), 'vip');
  star.setAttribute('role', 'img');
  star.setAttribute('aria-label', 'VIP user');
  star.title = 'VIP user';
  return star;
}

const SENTIMENT_WORDS = {
  negative: 'Negative: the user updates the ticket often (frustrated), or wrote negative wording',
  positive: 'Positive: the user is responding, without negative wording',
  neutral: 'Neutral: no response from the user yet',
};

// The short word a screen reader hears right after the name, so the name's colour is never the only
// signal (WCAG 1.4.1). Kept short: it is read on every row.
const SENTIMENT_SPOKEN = {
  negative: 'sentiment: negative',
  positive: 'sentiment: positive',
  neutral: 'sentiment: neutral',
};

/**
 * Did THE USER (the contact person) write negative wording? lib/engagement.js answers this directly
 * with engagement.userNegative; records stored before that field existed only carry negativeHits, so
 * the authors of the hits are also compared with the user's name (case-insensitively). Only `true` is
 * taken as final: lib/dashboardModel.js's buildEngagement turns a MISSING field into `false`, so on a
 * row a `false` cannot tell "not by the user" from "an old record" -- trusting it would switch the
 * fallback off for exactly the rows it exists for. For a new record the fallback cannot contradict the
 * analyser: it compared every entry's author with the same caller name, with a looser (token-set) match.
 */
function userWroteNegative(row, engagement) {
  if (engagement.userNegative === true) return true;
  const name = isObject(row) ? str(row.callerName).trim().toLowerCase() : '';
  if (!name) return false;
  const hits = Array.isArray(engagement.negativeHits) ? engagement.negativeHits : [];
  return hits.some((hit) => isObject(hit) && str(hit.author).trim().toLowerCase() === name);
}

/**
 * The user's sentiment, which colours their name. red = the user is frustrated (engagement level
 * 'frustrated': frequent updates, the user's own definition) or wrote negative wording themselves;
 * green = responding ('sporadic') without negative wording of their own; grey = no response yet / not
 * known. Negative wording by OTHER people (a manager, a colleague) says nothing about this user's mood,
 * so it no longer colours the name -- it still shows as the ☹ icon next to the ticket number.
 */
export function userSentiment(row) {
  const engagement = isObject(row) && isObject(row.engagement) ? row.engagement : {};
  if (engagement.level === 'frustrated' || userWroteNegative(row, engagement)) return 'negative';
  if (engagement.level === 'sporadic') return 'positive';
  return 'neutral';
}

function userCell(row) {
  const td = cell('td', 'col-user', 'user');
  const name = str(row.callerName) || str(row.callerEmail);
  const caller = withField(create('p', 'user-name', name || EM_DASH), 'callerName');
  caller.classList.toggle('is-empty', !name);
  const sentiment = userSentiment(row);
  caller.dataset.sentiment = sentiment;
  caller.title = [str(row.callerEmail), `Sentiment: ${SENTIMENT_WORDS[sentiment]}`].filter(Boolean).join('\n');
  const star = vipStar(row);
  if (star) caller.append(' ', star);
  // A sibling of the name, not a child: [data-field="callerName"] must keep reading as the name alone
  // (the e2e row readers and every check built on them compare it with the exact name).
  const spoken = withField(create('span', 'sr-only user-sentiment-word', `, ${SENTIMENT_SPOKEN[sentiment]}`), 'userSentiment');
  spoken.dataset.sentiment = sentiment;
  const contact = contactPersonLine(row);
  const country = str(row.country);
  const where = withField(create('p', country ? 'user-where' : 'user-where is-empty', country || 'Location unknown'), 'country');
  if (!country) where.title = str(row.locationText) ? 'The country could not be determined from the contact number or the Location field.' : 'The country could not be determined from the contact number.';
  const status = isObject(row.nowStatus) ? row.nowStatus : {};
  const time = compactLocalTime(status.localTime);
  const clock = create('p', time ? 'user-time' : 'user-time is-empty');
  const clockText = withField(create('span'), 'localTime');
  if (time) appendLocalTime(clockText, time);
  else clockText.textContent = 'Local time unknown';
  clockText.title = "Current local time at the user's location";
  clock.append(clockText);
  const zones = Array.isArray(status.zones) ? status.zones.length : 0;
  if (zones > 1) {
    const note = create('span', 'zone-note', `${MIDDOT} ${zones} zones`);
    note.title = `The country spans ${zones} time zones; ${str(row.timeZone)} is shown.`;
    clock.append(' ', note);
  }
  td.append(caller, spoken);
  if (row.contactPerson === 'impacted') {
    const who = create('p', 'cell-note user-role', 'Impacted User');
    if (str(row.reportedByName)) who.textContent = `Impacted User ${MIDDOT} reported by ${str(row.reportedByName)}`;
    td.append(withField(who, 'contactPerson'));
  }
  const engagement = engagementPill(row);
  if (engagement) {
    const line = create('p', 'user-engagement');
    line.append(engagement);
    td.append(line);
  }
  if (contact) td.append(contact);
  td.append(locationEmphasisBlock(row, where, clock));
  return td;
}

// ---- last update by the assigned agent (the column the user reads first) ----

function contactTitle(atContact) {
  const parts = [capitalize(str(atContact.reason)), compactLocalTime(atContact.localTime)].filter(Boolean);
  return `At the moment of the last update: ${parts.join(' - ')}`;
}

/** 'Times read as Europe/Berlin (assumed: set it in Settings).' appended to a pill's title. */
function zoneSuffix(ctx) {
  if (!ctx || !ctx.timeZone) return '';
  return ` Times read as ${ctx.timeZone}${ctx.timeZoneAssumed ? ' (assumed: set it in Settings)' : ''}.`;
}

/** No stored update from the assignee: grey when the stream was read and simply has none, amber
 * ("Activity stream not read") when lastContact.streamRead is explicitly false (contract 13.6 ROWS;
 * defensive until that field exists: absent/undefined keeps today's plain grey wording). */
function noUpdateCell(td, row, ctx) {
  const last = isObject(row.lastContact) ? row.lastContact : {};
  const unread = last.streamRead === false;
  td.dataset.tone = unread ? 'amber' : 'grey';
  const pill = withField(create('span', `pill pill-contact is-none${unread ? ' is-unread' : ''}`, unread ? 'Activity stream not read' : 'No update yet'), 'lastContactPill');
  pill.dataset.tone = unread ? 'amber' : 'grey';
  pill.title = (unread
    ? "The activity stream could not be read, so the assigned person's last update is unknown."
    : 'The assigned person has not written an update on this ticket.') + zoneSuffix(ctx);
  const assigned = str(row.assignedTo);
  td.append(pill, create('p', 'lc-line', assigned ? `Assigned to ${assigned}` : 'Not assigned'));
  const opened = str(row.openedAgo);
  if (opened) td.append(create('p', 'cell-note', `Opened ${opened}`));
  return td;
}

/** 'via Work note' / 'via Additional comments' underneath the exact time (contract 13.4 lastContact.kind). */
function lastContactKindLine(last) {
  const kind = str(last.kind);
  return kind ? create('p', 'cell-note', `via ${kind}`) : null;
}

function lastContactTimeLine(last) {
  const raw = str(last.timeLabel) || str(last.timeRaw);
  const node = withField(create('span', 'lc-time'), 'lastContactTime');
  const problem = str(last.timeProblem);
  if (problem === 'unrecognised' || problem === 'ambiguous') {
    node.classList.add('is-problem');
    node.append(`time format not understood (raw: ${raw || EM_DASH})`);
  } else if (raw) {
    node.append(raw, create('span', 'lc-suffix', ' (ServiceNow time)'));
  } else {
    node.append(formatContactTime(last.iso) || EM_DASH);
  }
  const line = create('p', 'lc-line');
  line.append(node);
  return line;
}

function userTimeLine(last, atContact) {
  const then = str(last.localTimeAtContact) || (atContact ? str(atContact.localTime) : '');
  if (!then) return null;
  const value = withField(create('span', 'lc-local'), 'lastContactLocalTime');
  appendLocalTime(value, then);
  const line = create('p', 'lc-line');
  line.append(create('span', 'lc-label', "User's time then"), ' ', value);
  return line;
}

function lastContactCell(row, ctx) {
  const td = cell('td', 'col-last', 'lastContact');
  const last = isObject(row.lastContact) ? row.lastContact : {};
  if (!last.has) return noUpdateCell(td, row, ctx);
  const atContact = isObject(last.atContact) ? last.atContact : null;
  const status = atContact ? normStatus(atContact.status) : 'unknown';
  const tone = toneFor(status, last.tone);
  td.dataset.tone = tone;
  const pill = makePill('contact', 'lastContactPill', status, tone, (atContact
    ? contactTitle(atContact)
    : "The time of the last update could not be read, so the user's business hours at that moment are unknown.") + zoneSuffix(ctx));

  const ago = str(last.ago);
  const main = create('p', 'lc-main');
  main.append(
    withField(create('span', ago ? 'lc-ago' : 'lc-ago is-empty', ago || EM_DASH), 'lastContactAgo'),
    ` ${MIDDOT} by `,
    withField(create('span', 'lc-author', str(last.author) || 'assigned agent'), 'lastContactAuthor'),
  );
  td.append(pill, main, lastContactTimeLine(last));
  const kindLine = lastContactKindLine(last);
  if (kindLine) td.append(kindLine);
  const local = userTimeLine(last, atContact);
  if (local) td.append(local);
  return td;
}

// ---- business hours now: ending-soon priority alert (16.2) and off-hours countdown pill (16.3) ----

/** 125 -> '2h 5m', 45 -> '45m', 0 -> '0m'. Negative/non-finite input never fabricates a number.
 * Exported for direct unit testing (contract 16.3, tests/table.test.mjs). */
export function humanizeMinutes(totalMinutes) {
  if (!Number.isFinite(totalMinutes) || totalMinutes < 0) return '';
  const whole = Math.floor(totalMinutes);
  const hours = Math.floor(whole / 60);
  const minutes = whole % 60;
  if (hours <= 0) return `${minutes}m`;
  if (minutes === 0) return `${hours}h`;
  return `${hours}h ${minutes}m`;
}

/** Priority-alert banner (contract 16.2): shown only when nowStatus.endingSoon is strictly true. Icon +
 * text carry the meaning (never colour alone); row.js colours the whole row to match via data-urgent. */
function endingSoonAlert(status) {
  if (status.endingSoon !== true) return null;
  const minutes = Number.isInteger(status.minutesRemaining) ? status.minutesRemaining : null;
  const node = withField(create('p', 'priority-alert'), 'endingSoon');
  node.setAttribute('role', 'status');
  node.dataset.tone = 'urgent';
  const icon = create('span', 'priority-icon', '⏰'); // alarm clock: decoration only, text carries the meaning
  icon.setAttribute('aria-hidden', 'true');
  const text = minutes !== null ? `Ends in ${minutes}m — follow up now` : 'Ending soon — follow up now';
  node.append(icon, ` ${text}`);
  node.title = "This user's business hours end in under 2 hours: follow up now while they are still available.";
  return node;
}

/** Off-hours "back in ..." pill (contract 16.3): only ever rendered when resumesInMinutes is an actual
 * number (never for 'uncertain'/'unknown' rows, whose four nowStatus fields are null/false by design -
 * no pill there at all, never a fabricated "0m"). Reuses the pill look via makePill's own CSS classes,
 * but with its own text (not statusPillLabel, which only knows the four business-hours statuses). */
function resumesPill(status) {
  if (typeof status.resumesInMinutes !== 'number' || !Number.isFinite(status.resumesInMinutes)) return null;
  const human = humanizeMinutes(status.resumesInMinutes);
  if (!human) return null;
  const pill = withField(create('span', 'pill pill-resumes', `back in ${human}`), 'resumesIn');
  pill.dataset.tone = 'grey';
  const at = str(status.resumesAt);
  const atDate = at ? new Date(at) : null;
  pill.title = atDate && !Number.isNaN(atDate.getTime())
    ? `Business hours resume in about ${human} (around ${atDate.toLocaleString()} in this browser's zone).`
    : `Business hours resume in about ${human}.`;
  return pill;
}

function nowCell(row) {
  const td = cell('td', 'col-now', 'businessNow');
  const status = isObject(row.nowStatus) ? row.nowStatus : {};
  const key = normStatus(status.status);
  td.append(
    makePill('now', 'nowPill', key, toneFor(key, status.tone), "Business hours right now at the user's location"),
    create('p', 'cell-note', capitalize(str(status.reason))),
  );
  const alert = endingSoonAlert(status);
  if (alert) td.append(alert);
  const resumes = key === 'non-business' ? resumesPill(status) : null;
  if (resumes) td.append(resumes);
  return td;
}

/** 'teams' | 'email' | 'phone' | '' from the ticket's preferred-contact text ('Teams chat', 'E-mail' ...). */
export function contactKind(method) {
  const text = str(method).toLowerCase();
  if (/teams/.test(text)) return 'teams';
  if (/e-?mail|\bmail\b/.test(text)) return 'email';
  if (/phone|\bcall\b|mobile|\btel\b|telephone|cell/.test(text)) return 'phone';
  return '';
}

/** The preferred-contact action: Teams message (deep link to a chat with the user), Email (mailto:), or
 * the phone number itself. Without the address/number the method is shown with the reason. */
function preferredAction(row, method) {
  const kind = contactKind(method);
  const email = str(row.callerEmail);
  const number = str(row.contactNumber);
  // Who the link reaches, for its accessible name: "Teams message" / "Email" alone are ambiguous when
  // a screen reader lists every link of the table. Same name the User column shows.
  const who = str(row.callerName) || email;
  const missing = (text) => withField(create('p', 'cell-note pref-missing', text), 'preferredContactMissing');
  // What the ticket says ("Teams chat", "E-mail", "Phone") stays visible above the action.
  const label = () => withField(create('p', 'cell-note pref-kind', method), 'preferredContactMethod');
  if (kind === 'teams') {
    const href = buildTeamsChatUrl(email);
    if (!href) return [label(), missing('No email address for a Teams chat.')];
    const link = withField(externalLink(href, 'pref-link pref-teams', 'Teams message'), 'preferredContactLink');
    link.title = `Open a Teams chat with ${email}`;
    // Starts with the visible text (WCAG 2.5.3 label in name), and says it opens a new tab (target=_blank).
    link.setAttribute('aria-label', `Teams message with ${who} (opens in a new tab)`);
    link.dataset.kind = 'teams';
    return [label(), link, create('p', 'cell-note pref-address', email)];
  }
  if (kind === 'email') {
    const href = buildMailtoLink(email);
    if (!href) return [label(), missing('No email address on the user record.')];
    const link = withField(create('a', 'pref-link pref-email', 'Email'), 'preferredContactLink');
    link.href = href;
    link.title = `Write an email to ${email}`;
    link.setAttribute('aria-label', `Email ${who}`);
    link.dataset.kind = 'email';
    return [label(), link, create('p', 'cell-note pref-address', email)];
  }
  if (kind === 'phone') {
    if (!number) return [label(), missing('No phone number on the user record.')];
    const phone = withField(create('p', 'pref-phone', number), 'contactNumber');
    phone.dataset.kind = 'phone';
    phone.title = `${method}: ${number}`;
    return [label(), phone];
  }
  return null;
}

function preferredCell(row) {
  const td = cell('td', 'col-pref', 'preferred');
  const method = str(row.preferredContactMethod);
  const action = method ? preferredAction(row, method) : null;
  if (action) {
    td.append(...action);
  } else {
    td.append(withField(create('p', method ? 'pref-method' : 'pref-method is-empty', method || EM_DASH), 'preferredContactMethod'));
    const number = str(row.contactNumber);
    if (number) td.append(withField(create('p', 'cell-note', number), 'contactNumber'));
  }
  // contract 13.6 ROWS; defensive until lib/dashboardModel.js sets preferredContactFromLabel (strict
  // === false, never a truthy/falsy read of `undefined`, so nothing shows until that field exists).
  if (row.preferredContactFromLabel === false) {
    const source = str(row.preferredContactSource) || 'a fallback field';
    const badge = withField(
      create('p', 'badge badge-warn', `Field "Preferred Contact Method(Impacted User)" not found: showing ${source}`),
      'preferredContactLabelMissing',
    );
    badge.title = 'The labelled field for the preferred contact method was not found on the incident form, so this value comes from a fallback field instead.';
    td.append(badge);
  }
  return td;
}

// ---- next step: the recommendation and the buttons ----

function actionButton(action, label, ariaLabel, primary) {
  const node = button(label, `btn-sm ${primary ? 'btn-primary' : 'btn-secondary'}`, { 'aria-label': ariaLabel });
  node.dataset.action = action;
  return node;
}

function teamsButton(row, ctx, primary, describedBy) {
  const who = str(row.callerName) || 'the user';
  const node = actionButton('teams', 'Send Teams message', `Send Teams message to ${who} about ${row.incidentNumber}`, primary);
  node.setAttribute('aria-expanded', String(ctx.composer === 'teams'));
  if (ctx.composer === 'teams') node.setAttribute('aria-controls', 'composerRow');
  if (primary) node.setAttribute('aria-describedby', describedBy);
  node.title = 'Open a Teams chat with a prefilled message; you press Send in Teams.';
  if (!row.canTeams) {
    node.disabled = true;
    node.title = 'This user has no usable email address, so a Teams chat cannot be opened.';
  }
  return node;
}

function ticketButton(row, ctx, primary, describedBy, suggested) {
  const label = primary ? 'Send update (email)' : 'Update ticket';
  const aria = primary
    ? `Send update by email for ${row.incidentNumber}: add a comment ServiceNow normally emails to the user`
    : `Update ticket ${row.incidentNumber}`;
  const node = actionButton('ticket', label, aria, primary);
  node.setAttribute('aria-expanded', String(ctx.composer === 'ticket'));
  if (ctx.composer === 'ticket') node.setAttribute('aria-controls', 'composerRow');
  if (primary) node.setAttribute('aria-describedby', describedBy);
  if (suggested) node.classList.add('is-suggested');
  // Softened per contract 13.6: ServiceNow sends the email only when the notification is active on
  // the instance, which this page cannot know; the confirm step (owned by the composer hardening
  // pass) says this plainly before anything is posted.
  node.title = 'Update this ticket. You choose between a comment ServiceNow normally emails to the user (if the notification is active) and an internal work note, and confirm before anything is saved.';
  return node;
}

function quietButton(action, label, ariaLabel) {
  const node = button(label, 'btn-sm btn-quiet', { 'aria-label': ariaLabel });
  node.dataset.action = action;
  return node;
}

function detailsButton(row, ctx) {
  const node = quietButton('details', ctx.detailsOpen ? 'Hide details' : 'Details', `${ctx.detailsOpen ? 'Hide' : 'Show'} the timeline of ${row.incidentNumber}`);
  node.setAttribute('aria-expanded', String(ctx.detailsOpen));
  if (ctx.detailsOpen) node.setAttribute('aria-controls', detailsId(row.incidentNumber));
  node.title = 'Activity of the assigned agent, your follow-ups and your searches for this ticket';
  return node;
}

function jsonButton(row) {
  const node = quietButton('json', 'View JSON', `View the stored JSON of ${row.incidentNumber}`);
  node.title = 'Show everything stored about this ticket as JSON';
  return node;
}

function refreshButton(row, ctx) {
  const node = quietButton('refresh', ctx.refreshing ? 'Refreshing...' : 'Refresh', `Refresh ${row.incidentNumber} from ServiceNow`);
  if (ctx.refreshing) {
    node.disabled = true;
    node.setAttribute('aria-busy', 'true');
  } else if (!row.instanceOrigin) {
    node.disabled = true;
    node.title = 'No ServiceNow address is stored for this ticket.';
  } else {
    node.title = 'Read this ticket again from ServiceNow';
  }
  return node;
}

function removeButton(row, ctx) {
  const armed = ctx.removeArmed === true;
  const node = quietButton('remove', armed ? `Confirm remove ${row.incidentNumber}` : 'Remove',
    armed ? `Confirm: remove ${row.incidentNumber} from this list` : `Remove ${row.incidentNumber} from this list`);
  node.classList.add('btn-remove');
  if (armed) node.dataset.confirm = '1';
  node.title = 'Remove this ticket from your searched tickets on this computer. Your follow-up history is kept. Click twice to confirm.';
  return node;
}

function openLink(row) {
  const href = safeHttpUrl(row.incidentUrl);
  if (!href) return null;
  const node = externalLink(href, 'btn btn-sm btn-quiet btn-link', 'Open');
  node.dataset.action = 'open';
  node.setAttribute('aria-label', `Open ${row.incidentNumber} in ServiceNow`);
  return node;
}

/**
 * 'Follow up now' badge (v0.4, row.followUp.now): the ticket is open and assigned, the user is in
 * business hours right now, and the user replied after the agent's last update or the agent has not
 * updated it for a day. The reason sentence (row.followUp.text) is its title and, as sr-only text right
 * after it, what a screen reader hears; the clock icon is decoration only. Null when not due.
 */
function followUpBadge(row) {
  const followUp = isObject(row.followUp) ? row.followUp : {};
  if (followUp.now !== true) return null;
  const reason = str(followUp.text) || 'Follow up now: the user is in business hours and waiting for an update.';
  const line = withField(create('p', 'followup-now'), 'followUpNow');
  const badge = create('span', 'badge badge-followup');
  const icon = create('span', 'followup-icon', '⏱');
  icon.setAttribute('aria-hidden', 'true');
  badge.append(icon, ' Follow up now');
  badge.title = reason;
  line.append(badge, create('span', 'sr-only', `. ${reason.replace(/^follow up now:\s*/i, '')}`));
  return line;
}

function nextStepCell(row, ctx) {
  const td = cell('td', 'col-actions', 'actions');
  const due = followUpBadge(row);
  if (due) td.append(due);
  const nowStatus = isObject(row.nowStatus) ? row.nowStatus : {};
  const status = normStatus(nowStatus.status);
  const primary = row.primaryAction === 'teams' || row.primaryAction === 'ticket' ? row.primaryAction : primaryAction(status);
  const actions = Array.isArray(row.actions) ? row.actions : [];
  const describedBy = recommendationId(row.incidentNumber);
  const teamsBlocked = actions.includes('teams') && !row.canTeams;

  const recommendation = withField(create('p', 'recommendation', str(row.recommendation) || recommendationText(status)), 'recommendation');
  recommendation.id = describedBy;
  recommendation.dataset.tone = toneFor(status, nowStatus.tone);
  td.append(recommendation);

  const main = create('div', 'actions');
  const teams = actions.includes('teams') ? teamsButton(row, ctx, primary === 'teams', describedBy) : null;
  const ticket = actions.includes('ticket')
    ? ticketButton(row, ctx, primary === 'ticket', describedBy, primary === 'teams' && teamsBlocked)
    : null;
  main.append(...(primary === 'teams' ? [teams, ticket] : [ticket, teams]).filter(Boolean));
  td.append(main);
  if (teamsBlocked) td.append(create('p', 'cell-note', 'Teams is not possible: no usable email address. Update the ticket instead.'));

  const quiet = create('div', 'actions actions-quiet');
  quiet.append(detailsButton(row, ctx), jsonButton(row), refreshButton(row, ctx));
  const link = openLink(row);
  if (link) quiet.append(link);
  quiet.append(removeButton(row, ctx));
  td.append(quiet);

  if (ctx.followUp) td.append(withField(create('p', 'cell-note follow-up', `Last follow-up: ${ctx.followUp}`), 'lastFollowUp'));
  if (ctx.note) {
    const note = withField(create('p', 'row-note', ctx.note.message), 'rowMessage');
    note.setAttribute('role', 'status');
    note.dataset.state = ctx.note.state;
    td.append(note);
  }
  return td;
}

/** The <tr> of one ticket. `ctx` = { composer, detailsOpen, followUp, refreshing, note, flash,
 * timeZone, timeZoneAssumed, removeArmed, today } (today: dayKeyIn(now, timeZone), v0.5 queue pills). */
export function buildRowNode(row, ctx) {
  const urgent = isObject(row.nowStatus) && row.nowStatus.endingSoon === true;
  const classes = ['inc-row', ctx.composer ? 'has-composer' : '', ctx.detailsOpen ? 'has-details' : '', urgent ? 'is-urgent' : ''];
  const tr = create('tr', classes.filter(Boolean).join(' '));
  tr.dataset.incident = row.incidentNumber;
  if (urgent) tr.dataset.urgent = '1';
  if (ctx.flash) tr.dataset.justFetched = '1';
  tr.append(
    ticketCell(row, ctx), statusCell(row), assignmentGroupCell(row), userCell(row),
    lastContactCell(row, ctx), nowCell(row), preferredCell(row), nextStepCell(row, ctx),
  );
  return tr;
}

// ---- keyed reconcile ----

/**
 * Bring `container`'s children in line with `desired` ([{ key, sig, build }]) without touching nodes
 * whose signature did not change, so focus and scroll inside them survive. Returns the new cache.
 */
export function reconcile(container, cache, desired) {
  const next = new Map();
  const nodes = desired.map(({ key, sig, build }) => {
    const cached = cache.get(key);
    const entry = cached && cached.sig === sig ? cached : { sig, node: build() };
    next.set(key, entry);
    return entry.node;
  });
  const keep = new Set(nodes);
  for (const child of [...container.children]) if (!keep.has(child)) child.remove();
  let cursor = container.firstElementChild;
  for (const node of nodes) {
    if (node === cursor) cursor = cursor.nextElementSibling;
    else container.insertBefore(node, cursor);
  }
  return next;
}

// ---- focus bookkeeping ----

/** The <tr> of a ticket inside the table body, or null. */
export function rowElement(container, number) {
  return container.querySelector(`tr[data-incident="${CSS.escape(number)}"]`);
}

/** True when nothing useful has focus any more (removed from the DOM or the body). */
function focusLost() {
  const active = document.activeElement;
  return !active || active === document.body || !active.isConnected;
}

/** What has focus inside the table, in terms that survive a rebuilt DOM; null when nothing does. */
export function captureFocus(container) {
  const active = document.activeElement;
  if (!active || active === document.body || !container.contains(active)) return null;
  if (active.closest('[data-guide]')) return null; // the guide keeps its own focus (its cards are never replaced)
  const tr = active.closest('tr[data-incident]');
  if (tr && active.dataset.action) return { kind: 'row', incident: tr.dataset.incident, action: active.dataset.action };
  // A focused line of a details drawer's timeline (dashboard/details.js), or something inside its popover
  // (Chrome makes a scrolling popover text focusable): the drawer is rebuilt when its content changes
  // (the "2h ago" texts, once a minute), so focus goes back to the same update's line -- found by its
  // key (time + author) first, since a newly read update shifts every index, else by its index.
  const drawer = active.closest('tr[data-details-for]');
  const item = drawer ? active.closest('.tl-item') : null;
  const line = item ? item.querySelector('.tl-line') : null;
  if (line && line.dataset.tlIndex !== undefined) {
    return { kind: 'details', incident: drawer.dataset.detailsFor, index: line.dataset.tlIndex, key: line.dataset.tlKey };
  }
  const composerTr = active.closest('tr[data-composer-for]');
  if (composerTr && active.dataset.role) {
    return { kind: 'composer', role: active.dataset.role, start: active.selectionStart, end: active.selectionEnd };
  }
  return null;
}

function focusableAction(tr, action) {
  const exact = tr.querySelector(`[data-action="${action}"]`);
  return exact && !exact.disabled ? exact : tr.querySelector('button[data-action]:not(:disabled)');
}

/** Put focus back where it was before the repaint, if the repaint dropped it. */
export function restoreFocus(container, saved, composer, pendingFocus) {
  if (!saved || !focusLost()) return;
  if (saved.kind === 'composer') {
    const target = composer && composer.node && composer.node.querySelector(`[data-role="${saved.role}"]`);
    if (!target || target.disabled) return;
    target.focus({ preventScroll: true });
    if (saved.start !== null && typeof target.setSelectionRange === 'function') target.setSelectionRange(saved.start, saved.end);
    return;
  }
  if (saved.kind === 'details') {
    const drawer = container.querySelector(`tr[data-details-for="${CSS.escape(saved.incident)}"]`);
    const byKey = drawer && typeof saved.key === 'string' ? drawer.querySelector(`[data-tl-key="${CSS.escape(saved.key)}"]`) : null;
    const line = byKey || (drawer && (drawer.querySelector(`[data-tl-index="${CSS.escape(saved.index)}"]`) || drawer.querySelector('[data-tl-index="0"]')));
    if (line) line.focus({ preventScroll: true });
    return;
  }
  if (pendingFocus && pendingFocus.incident === saved.incident && pendingFocus.action === saved.action) return;
  const tr = rowElement(container, saved.incident);
  const target = tr && focusableAction(tr, saved.action);
  if (target) target.focus({ preventScroll: true });
}

/** Focus the button a finished action asked for. Returns the pending request that is still open (or null). */
export function applyPendingFocus(container, pending) {
  if (!pending) return null;
  if (!focusLost()) return null;
  const tr = rowElement(container, pending.incident);
  if (!tr) return null;
  const exact = tr.querySelector(`[data-action="${pending.action}"]`);
  if (exact && exact.disabled) return pending; // still busy: try again after the next paint
  const target = exact || tr.querySelector('button[data-action]:not(:disabled)');
  if (target) target.focus({ preventScroll: true });
  return null;
}
