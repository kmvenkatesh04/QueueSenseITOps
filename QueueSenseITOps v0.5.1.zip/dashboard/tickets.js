// The Tickets view: summary strip, the "recommended now" banner, the filters, the table and its row
// actions. The table is a pure function of (stored data, new Date(), filters); paintTickets rebuilds the
// model from the cached data and the CURRENT clock and reconciles rows by key, so an open composer (and
// the focus inside it) survives every repaint.
import { STORAGE_KEYS } from '../lib/config.js';
import { summarizeRecommendations, summarizeRows } from '../lib/dashboardModel.js';
import { describeFollowUp } from '../lib/followup.js';
import {
  DEFAULT_PAGE_SIZE, normalizePageSize, pageOfIndex, pageRows, pagerText, paginate,
} from '../lib/pagination.js';
import {
  formatListParam, hashFromParams, isFollowUpNowRow, isNegativeRow, isOpenRow, isVipRow, matchesSavedView as rowMatchesView,
  matchesTicketFilters, normalizeList, normalizeStatusList, normalizeTicketFilters, parseListParam, ticketFilterOptions,
} from '../lib/ticketFilters.js';
import {
  composerNodeFor, focusNewComposer, onComposerChange, onComposerClick, onComposerInput, onComposerKeydown,
  openComposer, syncActiveComposer,
} from './composer.js';
import { ensureOriginPermissionConfirmed } from './confirmHost.js';
import { buildDetailsNode, factsOf, timelineItems } from './details.js';
import {
  create, isObject, plural, setText, str,
} from './dom.js';
import { els } from './els.js';
import { replyError, sendRuntimeMessage } from './messaging.js';
import { createMultiSelect } from './multiselect.js';
import {
  setDay, setStatusFilter, setView, statusFilterValues, syncControls,
} from './nav.js';
import { currentSettings, effectiveBusinessHours, isTimeZoneAssumed } from './settings.js';
import { hooks, state } from './state.js';
import { KEY, isLastIncidentOf, queueWrite, storageRead } from './store.js';
import {
  applyPendingFocus, buildRowNode, captureFocus, dayKeyIn, reconcile, restoreFocus, rowElement,
} from './table.js';

const NOTE_TTL_MS = 12000;
const DONE_NOTE_TTL_MS = 4000;
const FLASH_MS = 4000;

const DAY_FORMAT = new Intl.DateTimeFormat('en-GB', {
  weekday: 'long', day: 'numeric', month: 'long', year: 'numeric',
});

// ---- the filters (v0.4) ----
//
// Every Tickets filter except two lives in this module: the free-text query, the multi-select lists
// (Ticket status, Priority, Assignment group, Assigned agent, Age, Last updated, Saved view, and since
// v0.5 Queue and Red flags) and the
// quick filters (VIP users, Follow up now, Negative sentiment, Open only). The other two belong to
// nav.js: the "Searched" day (it decides which rows exist at all: dashboard.js builds `all` with it) and
// "Business hours now" (state.status, shared with the summary chips and the banner); this module only
// draws the latter's multi-select. The matching itself is lib/ticketFilters.js (pure, unit-tested):
// within one filter any chosen value matches, across filters all must hold.
//
// Each filter has its own URL-hash param (a comma list, lib/ticketFilters.js parseListParam): the two
// that existed before v0.4 keep their names and still read an old single value (ticketStatus=On Hold,
// savedView=<id>). nav.js's writeHash keeps these params; syncFilterHash re-asserts them after every
// paint anyway, so a hash rewritten by anyone else is put right on the next paint.

/** The multi-select list filters of the toolbar, in toolbar order. `key` = the filter (lib/ticketFilters.js
 * names, 'savedView' = the chosen view ids), `id` = the button's id, `mount` = its slot in dashboard.html,
 * `param` = its hash param (null: business hours is nav.js's `status`). */
const LIST_FILTERS = [
  { key: 'businessHours', id: 'statusFilter', mount: 'statusFilterTool', param: null, label: 'Business hours now', title: "Whether it is business hours at the user's location right now" },
  { key: 'ticketStatus', id: 'statusValueFilter', mount: 'statusValueFilterTool', param: 'ticketStatus', label: 'Ticket status', title: 'The State of the ticket in ServiceNow' },
  { key: 'priority', id: 'priorityFilter', mount: 'priorityFilterTool', param: 'prio', label: 'Priority', title: 'The Priority of the ticket in ServiceNow' },
  { key: 'group', id: 'groupFilter', mount: 'groupFilterTool', param: 'group', label: 'Assignment group', title: 'The assignment group of the ticket' },
  { key: 'agent', id: 'agentFilter', mount: 'agentFilterTool', param: 'agent', label: 'Assigned agent', title: 'The agent the ticket is assigned to' },
  { key: 'age', id: 'ageFilter', mount: 'ageFilterTool', param: 'age', label: 'Age', title: 'Time since the ticket was opened' },
  { key: 'updated', id: 'updatedFilter', mount: 'updatedFilterTool', param: 'upd', label: 'Last updated', title: "Time since the newest update written by a person (or, when none was read, the record's own update time)" },
  { key: 'savedView', id: 'savedViewFilter', mount: 'savedViewFilterTool', param: 'savedView', label: 'Saved view', allLabel: 'All tickets', title: 'Views defined in Settings; choosing several shows the tickets of any of them' },
  // v0.5: queue membership (lib/queueTracking.js, from the "Load all open tickets" runs) and the
  // per-ticket red flags of the assigned agent (lib/dashboardModel.js row.agentStale / row.updateSplit).
  { key: 'queue', id: 'queueFilter', mount: 'queueFilterTool', param: 'queue', label: 'Queue', title: 'Whether the ticket entered or left the saved queues, as seen by Load all open tickets and auto refresh' },
  { key: 'flags', id: 'flagsFilter', mount: 'flagsFilterTool', param: 'flags', label: 'Red flags', title: "Tickets whose assigned agent has not updated them for a working day, or updated them mostly outside the user's business hours" },
];

/** The fixed options of the Queue filter (lib/ticketFilters.js filters.queue values), in menu order. */
export const QUEUE_FILTER_OPTIONS = Object.freeze([
  { value: 'new', label: 'New to queue (24 h)' },
  { value: 'entered24h', label: 'Entered in past 24 h' },
  { value: 'movedOut24h', label: 'Moved out in past 24 h' },
  { value: 'movedOut', label: 'Moved out' },
  { value: 'inQueue', label: 'In queue' },
  { value: 'notMovedOut', label: 'Not moved out' },
]);

/** The fixed options of the Red flags filter (lib/ticketFilters.js filters.flags values), in menu order. */
export const FLAG_FILTER_OPTIONS = Object.freeze([
  { value: 'agentStale', label: 'Agent not updating daily' },
  { value: 'agentOffHours', label: 'Agent mostly off hours' },
]);
const QUICK_PARAM = 'quick';
// quick filter key -> its token in the hash
const QUICK_TOKENS = { vip: 'vip', followUpNow: 'followUpNow', negative: 'negative', open: 'open' };

function emptyFilterValues() {
  return {
    ticketStatus: [], priority: [], group: [], agent: [], age: [], updated: [], savedView: [], queue: [], flags: [],
    quick: { vip: false, followUpNow: false, negative: false }, openOnly: false,
  };
}

let ticketQuery = '';
let filterValues = emptyFilterValues();

function readFiltersFromHash() {
  const values = emptyFilterValues();
  try {
    const params = new URLSearchParams(location.hash.replace(/^#/, ''));
    for (const spec of LIST_FILTERS) if (spec.param) values[spec.key] = parseListParam(params.get(spec.param));
    const quick = parseListParam(params.get(QUICK_PARAM));
    values.quick = { vip: quick.includes('vip'), followUpNow: quick.includes('followUpNow'), negative: quick.includes('negative') };
    values.openOnly = quick.includes('open');
  } catch {
    // an unreadable hash means no filters
  }
  return values;
}

filterValues = readFiltersFromHash();

function quickTokens() {
  return [
    ...Object.keys(filterValues.quick).filter((key) => filterValues.quick[key]).map((key) => QUICK_TOKENS[key]),
    ...(filterValues.openOnly ? [QUICK_TOKENS.open] : []),
  ];
}

/** Re-assert this module's params in the hash (after nav.js or anyone else rewrote it). */
function syncFilterHash() {
  try {
    const params = new URLSearchParams(location.hash.replace(/^#/, ''));
    for (const spec of LIST_FILTERS) {
      if (!spec.param) continue;
      const value = formatListParam(filterValues[spec.key]);
      if (value) params.set(spec.param, value);
      else params.delete(spec.param);
    }
    const quick = formatListParam(quickTokens());
    if (quick) params.set(QUICK_PARAM, quick);
    else params.delete(QUICK_PARAM);
    const next = hashFromParams(params);
    if (next !== location.hash) history.replaceState(null, '', next);
  } catch {
    // the hash is a convenience only
  }
}

function savedViews() {
  const list = currentSettings().savedViews;
  return Array.isArray(list) ? list.filter(isObject) : [];
}

/** The chosen saved views that still exist (a view removed in Settings or another tab simply drops out). */
function chosenViews(views = savedViews()) {
  return filterValues.savedView.map((id) => views.find((view) => view.id === id)).filter(Boolean);
}

/**
 * Does a row match the chosen saved view(s)? Several chosen views are a union (any of them). No view
 * chosen, or only views that no longer exist, matches every row (show everything rather than nothing).
 * `deps` is overridable for direct unit testing (tests/savedview.test.mjs): getValue() returns the chosen
 * id(s) (a list, one id, or 'all'), getViews() the defined views.
 */
export function matchesSavedView(row, deps = {}) {
  const ids = deps.getValue ? normalizeList(deps.getValue()) : filterValues.savedView;
  if (!ids.length) return true;
  const views = deps.getViews ? deps.getViews() : savedViews();
  const chosen = ids.map((id) => (Array.isArray(views) ? views : []).find((view) => isObject(view) && view.id === id)).filter(Boolean);
  if (!chosen.length) return true;
  return chosen.some((view) => rowMatchesView(row, view));
}

/** Every Tickets filter in lib/ticketFilters.js form (normalised once per call). */
function currentFilters() {
  return normalizeTicketFilters({
    businessHours: statusFilterValues(),
    ticketStatus: filterValues.ticketStatus,
    priority: filterValues.priority,
    group: filterValues.group,
    agent: filterValues.agent,
    age: filterValues.age,
    updated: filterValues.updated,
    savedViews: chosenViews(),
    queue: filterValues.queue,
    flags: filterValues.flags,
    quick: filterValues.quick,
    openOnly: filterValues.openOnly,
    query: ticketQuery,
  });
}

/** Which kinds of filter are on: { status, others, any } (the day is not a filter here: it is the scope). */
function activeFilters() {
  const status = statusFilterValues().length > 0;
  const others = Boolean(ticketQuery.trim()) || filterValues.openOnly
    || Object.values(filterValues.quick).some(Boolean)
    || LIST_FILTERS.some((spec) => spec.param && filterValues[spec.key].length > 0);
  return { status, others, any: status || others };
}

// ---- the multi-select controls ----

const multis = new Map(); // filter key -> multi-select (built by wireTickets)

/** The selection a filter's control shows. */
function selectedOf(key) {
  return key === 'businessHours' ? statusFilterValues() : filterValues[key];
}

/** Change one list filter (from its multi-select, or a scripted value + change on its button). */
function setListFilter(key, values) {
  if (key === 'businessHours') {
    setStatusFilter(values); // nav.js: state, hash, repaint
    return;
  }
  filterValues = { ...filterValues, [key]: normalizeList(values) };
  syncFilterHash();
  hooks.paint();
}

/**
 * The select-like scripted view of a multi-select's button: its `value` is 'all' or the chosen values
 * joined by commas, and assigning a value then dispatching 'change' on the button applies it (what a
 * test harness or a bookmarklet does with a <select>). A value that is exactly one option is that option,
 * even when it contains a comma ('Kumar, Ravi'); otherwise it is read as a comma list.
 */
function scriptedValues(spec, value) {
  const text = typeof value === 'string' ? value.trim() : '';
  if (!text || text === 'all') return [];
  const ms = multis.get(spec.key);
  const known = ms ? ms.optionValues() : [];
  if (known.includes(text)) return [text];
  return parseListParam(text);
}

function mirrorValue(spec, values) {
  try {
    const node = document.getElementById(spec.id);
    if (node) node.value = values.join(',') || 'all';
  } catch {
    // the mirror is a convenience for scripts only
  }
}

/** Bring every multi-select in line with the rows (options, counts) and the current selection. */
function syncFilterControls(all, now) {
  let options = null;
  try {
    options = ticketFilterOptions(all, now, currentFilters());
  } catch {
    options = null;
  }
  const views = savedViews();
  // a chosen view that no longer exists drops out of the selection (and so out of the hash)
  const existing = filterValues.savedView.filter((id) => views.some((view) => view.id === id));
  if (existing.length !== filterValues.savedView.length) filterValues = { ...filterValues, savedView: existing };
  for (const spec of LIST_FILTERS) {
    const selected = selectedOf(spec.key);
    const ms = multis.get(spec.key);
    if (ms) {
      let list;
      if (spec.key === 'savedView') list = views.map((view) => ({ value: str(view.id), label: str(view.name) || 'Unnamed view' }));
      else if (spec.key === 'queue' || spec.key === 'flags') list = fixedFilterOptions(spec.key, all, now, options && options[spec.key]);
      else list = (options && options[spec.key]) || [];
      ms.update({ options: list, selected });
    }
    mirrorValue(spec, selected);
  }
}

/**
 * The Queue / Red flags options with their counts over `rows` (every row of the selected day, like the
 * other filters), in this module's toolbar wording. The counts are lib/ticketFilters.js's own: taken
 * from its ticketFilterOptions result (`counted`) when it has that value, else its matching applied to
 * that one value -- either way a count and the rows that ticking it shows can never disagree. Never
 * throws: a row that cannot be classified is not counted.
 * @param {'queue'|'flags'} key
 * @param {object[]} rows dashboard rows
 * @param {Date} now
 * @param {{value:string, count:number}[]} [counted] ticketFilterOptions(...)[key]
 * @returns {{value:string, label:string, count:number}[]}
 */
export function fixedFilterOptions(key, rows, now, counted) {
  const defs = key === 'queue' ? QUEUE_FILTER_OPTIONS : key === 'flags' ? FLAG_FILTER_OPTIONS : [];
  const list = Array.isArray(rows) ? rows : [];
  const known = new Map((Array.isArray(counted) ? counted : [])
    .filter((option) => isObject(option) && Number.isInteger(option.count) && option.count >= 0)
    .map((option) => [option.value, option.count]));
  return defs.map((def) => {
    if (known.has(def.value)) return { value: def.value, label: def.label, count: known.get(def.value) };
    let count = 0;
    try {
      const filters = normalizeTicketFilters({ [key]: [def.value] });
      // An older lib/ticketFilters.js without this filter would match every row: show 0, not "all".
      if (Array.isArray(filters[key]) && filters[key].includes(def.value)) {
        for (const row of list) if (matchesTicketFilters(row, filters, now)) count += 1;
      }
    } catch {
      count = 0;
    }
    return { value: def.value, label: def.label, count };
  });
}

// ---- quick filters ----

const QUICK_TESTS = {
  vip: isVipRow, followUpNow: isFollowUpNowRow, negative: isNegativeRow, open: isOpenRow,
};

function quickPressed(key) {
  return key === 'open' ? filterValues.openOnly : filterValues.quick[key] === true;
}

/** Live counts (over every row of the selected day) and pressed states of the quick-filter chips, and the
 * "Clear all filters" button, shown only while some filter is on. */
function paintQuickFilters(all) {
  const group = document.getElementById('quickFilters');
  if (!group) return;
  for (const chip of group.querySelectorAll('[data-quick]')) {
    const key = chip.dataset.quick;
    const test = QUICK_TESTS[key];
    if (!test) continue;
    let count = 0;
    for (const row of all) if (test(row)) count += 1;
    const node = group.querySelector(`[data-quick-count="${key}"]`);
    if (node) setText(node, String(count));
    chip.setAttribute('aria-pressed', String(quickPressed(key)));
  }
  const clear = document.getElementById('clearFilters');
  if (clear) clear.hidden = !activeFilters().any;
}

function toggleQuick(key) {
  if (key === 'open') filterValues = { ...filterValues, openOnly: !filterValues.openOnly };
  else if (key in filterValues.quick) filterValues = { ...filterValues, quick: { ...filterValues.quick, [key]: !filterValues.quick[key] } };
  else return;
  syncFilterHash();
  hooks.paint();
}

function onQuickFiltersClick(event) {
  const target = event.target && typeof event.target.closest === 'function' ? event.target.closest('button') : null;
  if (!target) return;
  if (target.id === 'clearFilters') {
    clearAllFilters();
    // the button hides itself: put focus on the first quick filter rather than letting it fall to <body>
    const first = document.getElementById('quickFilters');
    const chip = first ? first.querySelector('[data-quick]') : null;
    if (chip && typeof chip.focus === 'function') chip.focus({ preventScroll: true });
    return;
  }
  if (target.dataset.quick) toggleQuick(target.dataset.quick);
}

// ---- paging (lib/pagination.js does the arithmetic; this module only keeps the viewer's choice) ----
// The page number lives in memory only: it is meaningless across reloads (rows change). The page SIZE is
// a per-viewer convenience, so it is remembered in localStorage (never chrome.storage: those keys are
// allowlisted by the e2e health check and must stay the documented data keys only).
const PAGE_SIZE_STORAGE = 'snicPageSize';

function readStoredPageSize() {
  try {
    return normalizePageSize(globalThis.localStorage ? globalThis.localStorage.getItem(PAGE_SIZE_STORAGE) : null);
  } catch {
    return DEFAULT_PAGE_SIZE; // private window / blocked site data: the default is fine
  }
}

function storePageSize(size) {
  try {
    if (globalThis.localStorage) globalThis.localStorage.setItem(PAGE_SIZE_STORAGE, String(size));
  } catch {
    // a convenience only: the in-memory size still applies for this page's lifetime
  }
}

let ticketPage = 1;
let ticketPageSize = readStoredPageSize();
let pagingFilterSig = null;

/**
 * Every filter that decides WHICH rows the table lists, as one comparable string. paintTickets resets
 * to page 1 whenever it changes, so every filter path -- this module's own controls, nav.js's
 * setDay/setStatusFilter (summary chips, the banner, the empty-state reset), a hashchange (back/forward,
 * deep link), dashboard.js's showTicket and the Overview's drill-down -- gets the reset without each
 * caller knowing about paging.
 */
function filterSignature() {
  return JSON.stringify([state.day, statusFilterValues(), ticketQuery.trim().toLowerCase(), filterValues]);
}

/** The current page and size, for tests and diagnostics. */
export function ticketPaging() {
  return { page: ticketPage, pageSize: ticketPageSize };
}

/** Put the free-text control and every multi-select in line with the in-memory values (never throws). */
function syncFilterInputs() {
  try {
    const text = document.getElementById('ticketFilter');
    if (text) text.value = ticketQuery;
  } catch {
    // a control that cannot be set still has the in-memory value
  }
  for (const spec of LIST_FILTERS) {
    const selected = selectedOf(spec.key);
    const ms = multis.get(spec.key);
    try {
      if (ms) ms.update({ selected });
    } catch {
      // the next paint brings it in line
    }
    mirrorValue(spec, selected);
  }
}

function repaint() {
  try {
    hooks.paint();
  } catch {
    // the next paint (60-second tick, storage change) shows the change
  }
}

/**
 * Clear the filters this module owns -- the free-text query, every multi-select list (Ticket status,
 * Priority, Assignment group, Assigned agent, Age, Last updated, Saved view, Queue, Red flags) and the
 * quick filters --
 * together with their controls and their hash params, then repaint. For callers outside this module that
 * need "show me everything" (dashboard/opentickets.js after Load all open tickets: freshly loaded tickets
 * hidden behind a leftover filter read as "nothing was loaded"). The day and business-hours filters
 * belong to nav.js and are left alone. Never throws: a missing control or an unwritable hash only skips
 * that part.
 */
export function resetTicketFilters() {
  ticketQuery = '';
  filterValues = emptyFilterValues();
  syncFilterInputs();
  syncFilterHash();
  repaint();
}

/** "Clear all filters": resetTicketFilters plus the business-hours filter (not the Searched day). */
function clearAllFilters() {
  ticketQuery = '';
  filterValues = emptyFilterValues();
  syncFilterInputs();
  syncFilterHash();
  try {
    setStatusFilter([]); // nav.js: the business-hours filter, the hash, one repaint
  } catch {
    repaint();
  }
}

/**
 * Show the Tickets view with exactly these filters (the Overview's drill-down: "the 4 P2 tickets of Ravi
 * Kumar that are 5-10 days old"). EVERY Tickets filter is cleared first (including the free text and
 * "Business hours now"), the given ones are applied, the Searched day is set to 'all' (the Overview counts
 * every stored ticket), then the view switches to Tickets and repaints. Never throws.
 * @param {{businessHours?:string[], ticketStatus?:string[], priority?:string[], group?:string[],
 *   agent?:string[], age?:string[], updated?:string[], queue?:string[], flags?:string[],
 *   quick?:{vip?:boolean, followUpNow?:boolean, negative?:boolean}, openOnly?:boolean}} filters lists of
 *   values (row.priority.key, the assignment group text, the assignedTo text with '' = Unassigned,
 *   lib/metrics.js bucket keys; v0.5: queue = 'new' | 'entered24h' | 'movedOut24h' | 'movedOut' |
 *   'inQueue', flags = 'agentStale' | 'agentOffHours', see lib/ticketFilters.js)
 * @param {{focusTab?:boolean}} [opts] focusTab (default true): move focus to the Tickets tab, since the
 *   control that asked (in the Overview panel) is about to be hidden
 */
export function applyTicketFilters(filters, { focusTab = true } = {}) {
  try {
    const f = isObject(filters) ? filters : {};
    const quick = isObject(f.quick) ? f.quick : {};
    ticketQuery = '';
    filterValues = {
      ...emptyFilterValues(),
      ticketStatus: normalizeList(f.ticketStatus),
      priority: normalizeList(f.priority),
      group: normalizeList(f.group),
      agent: normalizeList(f.agent),
      age: normalizeList(f.age),
      updated: normalizeList(f.updated),
      queue: normalizeList(f.queue),
      flags: normalizeList(f.flags),
      quick: { vip: quick.vip === true, followUpNow: quick.followUpNow === true, negative: quick.negative === true },
      openOnly: f.openOnly === true,
    };
    state.status = normalizeStatusList(f.businessHours);
    state.day = 'all';
    // A drill-down always starts on page 1, even when it asks for exactly the filters already shown (the
    // filter signature would not change then, so paintTickets would keep the current page).
    ticketPage = 1;
    syncFilterInputs();
    syncFilterHash();
    syncControls();
    setView('tickets', { focusTab }); // writes the hash (keeping this module's params) and repaints
  } catch {
    repaint();
  }
}

// ---- announcing page changes ----
// #pagerInfo is visible text only: it is rewritten on EVERY paint (tickets arriving during Load all,
// the 60-second tick), so as a live region it chattered. #pagerAnnounce (sr-only, role=status) is
// written only from the pager buttons and the page-size select, i.e. only when the person asked.
let lastPagerTotal = 0;
let lastPaging = null;

function announcePage() {
  const node = document.getElementById('pagerAnnounce');
  if (!node) return;
  setText(node, pagerText(lastPagerTotal, lastPaging));
}

// True only while a paint asked for by the person themselves runs (a pager button, the page size, a
// jump to a ticket's page). Such a page change must never be held back by the focused-row pin below:
// focus is normally on the pager by then, but an activation that does not move focus (a screen
// reader's browse-mode click, a script calling .click()) would otherwise carry the old row onto the
// new page as an extra row.
let explicitPaging = false;

/** Repaint for a page change the person asked for (see explicitPaging). */
function paintPageChange() {
  explicitPaging = true;
  try {
    hooks.paint();
  } finally {
    explicitPaging = false;
  }
}

/** The incident whose row (or the details drawer / composer under it) holds keyboard focus, or ''.
 * Read before every reconcile so that row stays on the page while it has focus (see paintTickets). */
function focusedIncident() {
  try {
    const active = document.activeElement;
    if (!active || active === document.body || typeof active.closest !== 'function') return '';
    if (!els.incidentRows.contains(active)) return '';
    const row = active.closest('tr[data-incident]');
    if (row) return str(row.dataset.incident);
    const details = active.closest('tr[data-details-for]');
    if (details) return str(details.dataset.detailsFor);
    const composer = active.closest('tr[data-composer-for]');
    return composer ? str(composer.dataset.composerFor) : '';
  } catch {
    return '';
  }
}

// ---- wording ----

function dayWords(now) {
  if (state.day === 'today') return `today, ${DAY_FORMAT.format(now)}`;
  if (state.day === 'yesterday') return 'yesterday';
  if (state.day === 'last7') return 'in the last 7 days';
  if (state.day === 'all') return 'on any day';
  return `on ${state.day}`;
}

/** How many separate filters are on (the empty state names a lone text filter by its text). */
function currentFiltersCount() {
  let count = statusFilterValues().length ? 1 : 0;
  if (ticketQuery.trim()) count += 1;
  if (filterValues.openOnly) count += 1;
  count += Object.values(filterValues.quick).filter(Boolean).length;
  count += LIST_FILTERS.filter((spec) => spec.param && filterValues[spec.key].length > 0).length;
  return count;
}

function emptyTitleFor(hiddenByStatus) {
  if (hiddenByStatus) return 'No tickets match this filter';
  if (state.day === 'all') return 'No tickets searched yet';
  if (state.day === 'today' || state.day === 'yesterday') return `No tickets searched ${state.day}`;
  if (state.day === 'last7') return 'No tickets searched in the last 7 days';
  return `No tickets searched on ${state.day}`;
}

// ---- the recommended-now banner (four chips, updated in place so focus on one is never lost) ----

const NEXT_CHIPS = [
  { key: 'teams', filter: 'business', tone: 'green', label: 'Teams message', hint: '(business hours)' },
  { key: 'ticket', filter: 'non-business', tone: 'red', label: 'Update ticket / email', hint: '(off hours)' },
  { key: 'uncertain', filter: 'uncertain', tone: 'amber', label: 'Update ticket / email', hint: '(uncertain)' },
  { key: 'unknown', filter: 'unknown', tone: 'grey', label: 'Update ticket / email', hint: '(unknown)' },
];

function nextChip(spec) {
  const chip = create('button', 'next-chip');
  chip.type = 'button';
  chip.dataset.next = spec.key;
  chip.dataset.filter = spec.filter;
  chip.dataset.tone = spec.tone;
  const count = create('strong', 'next-count');
  chip.append(count, create('span', 'next-label', ` x ${spec.label} `), create('span', 'next-hint', spec.hint));
  return chip;
}

function ensureNextChips() {
  if (els.nextItems.children.length) return;
  const empty = create('p', 'next-empty');
  empty.dataset.role = 'nextEmpty';
  els.nextItems.append(...NEXT_CHIPS.map(nextChip), empty);
}

function paintNextActions(all, summary) {
  ensureNextChips();
  const recommended = summarizeRecommendations(all);
  const counts = {
    teams: recommended.teams,
    ticket: summary['non-business'],
    uncertain: summary.uncertain,
    unknown: summary.unknown,
  };
  for (const spec of NEXT_CHIPS) {
    const chip = els.nextItems.querySelector(`[data-next="${spec.key}"]`);
    chip.hidden = counts[spec.key] === 0;
    setText(chip.querySelector('.next-count'), String(counts[spec.key]));
    const statuses = statusFilterValues();
    chip.setAttribute('aria-pressed', String(statuses.includes(spec.filter)));
    chip.title = statuses.length === 1 && statuses[0] === spec.filter
      ? 'Click to show all tickets again'
      : `Show only these tickets (${spec.hint.slice(1, -1)})`;
  }
  const empty = els.nextItems.querySelector('[data-role="nextEmpty"]');
  empty.hidden = recommended.total > 0;
  setText(empty, 'Nothing to follow up: there are no tickets in this view.');
}

// ---- model -> nodes ----

/** Newest successful follow-up; a dry run only counts when nothing real exists, a failure only as a last resort. */
function lastFollowUp(number) {
  let dry = null;
  let failed = null;
  for (const entry of state.data.log) {
    if (!isObject(entry) || entry.incidentNumber !== number) continue;
    if (entry.ok === false) failed = failed || entry;
    else if (entry.dryRun === true) dry = dry || entry;
    else return entry;
  }
  return dry || failed;
}

function rowContext(row, timeCtx) {
  const entry = lastFollowUp(row.incidentNumber);
  const { composer } = state;
  return {
    composer: composer && composer.incidentNumber === row.incidentNumber ? composer.channel : null,
    detailsOpen: state.details.has(row.incidentNumber),
    followUp: entry ? describeFollowUp(entry) : '',
    refreshing: state.refreshing.has(row.incidentNumber),
    note: state.notes.get(row.incidentNumber) || null,
    flash: state.justFetched === row.incidentNumber,
    removeArmed: removeArmedFor === row.incidentNumber,
    ...timeCtx,
  };
}

/** Rows to show: the rows every filter lets through (lib/ticketFilters.js), plus the row of an open
 * composer so it never vanishes underneath it. `now` places the age / last-updated buckets. */
function selectVisible(all, now) {
  const filters = currentFilters();
  const pinned = state.composer ? state.composer.incidentNumber : '';
  return all.filter((row) => row.incidentNumber === pinned || matchesTicketFilters(row, filters, now));
}

/** The rows the Tickets table currently shows (every active filter applied): day (baked into `all`
 * by dashboard.js's paint()), then every Tickets filter. Used by the Excel export (contract 15.2/15.6)
 * so it exports exactly what is on screen, from any view. */
export function visibleTicketRows() {
  return selectVisible([...state.rowsByNumber.values()], new Date());
}

function detailsDesired(row, now, timeZone) {
  const record = state.records.get(row.incidentNumber) || {};
  // The same business hours the rows use (dashboard.js passes effectiveBusinessHours() to buildRows), so
  // a timeline dot and the row's update split never disagree about one update.
  const items = timelineItems(row, record, state.data.log, now, { businessHours: effectiveBusinessHours(), timeZone });
  // row.queue (v0.5) adds the queue facts (in queue since, entered, moved out); `now` dates their "ago".
  const opts = { timeZone, queue: isObject(row.queue) ? row.queue : null, now };
  // the row's names decide the "assigned agent" / "user" marks of the timeline lines
  const names = [row.assignedTo, row.callerName, row.impactedName];
  return {
    key: `details:${row.incidentNumber}`,
    sig: JSON.stringify([items, factsOf(record, opts), names]),
    build: () => buildDetailsNode(row, record, items, opts),
  };
}

function desiredNodes(visible, now, timeZone) {
  const desired = [];
  // Threaded into each row's ctx so the "times read as <zone>" tooltip (contract 13.6 ROWS) reflects
  // the Settings tab; it also means a settings change busts every row's reconcile signature, so the
  // table repaints at once (dashboard.js's paint() already recomputes `timeZone` from settings.js).
  // `today` (v0.5): the queue pills print a time of today as '10:15' and an older one with its day; a
  // day key (not `now`) keeps the row signatures stable between ticks.
  const timeCtx = { timeZone, timeZoneAssumed: isTimeZoneAssumed(), today: dayKeyIn(now, timeZone) };
  for (const row of visible) {
    const ctx = rowContext(row, timeCtx);
    desired.push({ key: `row:${row.incidentNumber}`, sig: JSON.stringify([row, ctx]), build: () => buildRowNode(row, ctx) });
    const { composer } = state;
    if (composer && composer.incidentNumber === row.incidentNumber) {
      desired.push({
        key: `composer:${row.incidentNumber}`,
        sig: `composer:${composer.id}`,
        build: () => composerNodeFor(composer),
      });
    }
    if (ctx.detailsOpen) desired.push(detailsDesired(row, now, timeZone));
  }
  return desired;
}

// ---- painting ----

function paintSummary(all, visible, now, summary, paging) {
  for (const node of els.summary.querySelectorAll('[data-summary]')) {
    node.textContent = String(summary[node.dataset.summary] ?? 0);
  }
  const statuses = statusFilterValues();
  for (const chip of els.summary.querySelectorAll('[data-filter]')) {
    const pressed = chip.dataset.filter === 'all' ? statuses.length === 0 : statuses.includes(chip.dataset.filter);
    chip.setAttribute('aria-pressed', String(pressed));
  }
  // Every row-narrowing filter counts here (not only the business-hours and text filters), so #rowCount
  // always agrees with the pager's "of N" and with what the Excel export writes.
  const unfiltered = !activeFilters().any;
  els.rowCount.textContent = unfiltered
    ? plural(all.length, 'ticket', 'tickets')
    : `Showing ${visible.length} of ${all.length}`;
  // The caption is what a screen reader announces for the table: when paged, say which rows the table
  // actually holds rather than claiming every filtered row is shown.
  const shown = paging.pageCount > 1
    ? `${visible.length} listed, rows ${paging.start + 1} to ${paging.end} shown (page ${paging.page} of ${paging.pageCount})`
    : `${visible.length} shown`;
  els.tableCaption.textContent = `Tickets searched ${dayWords(now)}, newest search first. ${shown}.`;
}

/** The pager under the table. Looked up by id rather than through els.js's registry, which another
 * module owns; every element is optional so an older dashboard.html simply has no pager. */
function paintPager(total, paging) {
  const pager = document.getElementById('ticketPager');
  if (!pager) return;
  pager.hidden = total === 0;
  const info = document.getElementById('pagerInfo');
  if (info) setText(info, pagerText(total, paging));
  const atFirst = paging.page <= 1;
  const atLast = paging.page >= paging.pageCount;
  for (const [id, disabled] of [['pagerFirst', atFirst], ['pagerPrev', atFirst], ['pagerNext', atLast], ['pagerLast', atLast]]) {
    const button = document.getElementById(id);
    if (button) button.disabled = disabled;
  }
  const size = document.getElementById('pageSize');
  if (size && size.value !== String(paging.pageSize)) size.value = String(paging.pageSize);
}

function paintEmpty(all, visible) {
  const none = visible.length === 0;
  els.incidentTable.hidden = none;
  els.emptyState.hidden = !none;
  if (!none) return;
  const hiddenByStatus = all.length > 0;
  const stored = state.records.size;
  els.emptyTitle.textContent = emptyTitleFor(hiddenByStatus);
  // Only the business-hours filter on: "Show all statuses" (as before v0.4); anything else: clear them all.
  const active = activeFilters();
  const onlyStatus = active.status && !active.others;
  if (hiddenByStatus) {
    const onlyQuery = !active.status && ticketQuery.trim() && currentFiltersCount() === 1;
    let by = 'the active filters';
    if (onlyStatus) by = 'the "Business hours now" filter';
    else if (onlyQuery) by = `the ticket filter ("${ticketQuery.trim()}")`;
    els.emptyText.textContent = `${all.length} ${all.length === 1 ? 'ticket is' : 'tickets are'} hidden by ${by}.`;
  } else if (stored > 0 && state.day !== 'all') {
    els.emptyText.textContent = `${plural(stored, 'ticket is', 'tickets are')} stored on this computer from other days.`;
  } else {
    els.emptyText.textContent = 'Search for a ticket above and it is listed here. Everything stays on this computer.';
  }
  els.emptyReset.hidden = !hiddenByStatus && (state.day === 'all' || stored === 0);
  if (!hiddenByStatus) els.emptyReset.dataset.reset = 'day';
  else els.emptyReset.dataset.reset = onlyStatus ? 'status' : 'filters';
  els.emptyReset.textContent = { day: 'Show all days', status: 'Show all statuses', filters: 'Clear all filters' }[els.emptyReset.dataset.reset];
}

/** Update the Tickets view for `all` (the rows of the selected day). */
export function paintTickets(now, timeZone, all) {
  const summary = summarizeRows(all);
  syncFilterControls(all, now);
  syncFilterHash();
  paintQuickFilters(all);
  const visible = selectVisible(all, now);
  const sig = filterSignature();
  if (sig !== pagingFilterSig) {
    pagingFilterSig = sig;
    ticketPage = 1;
  }
  const paging = paginate(visible.length, ticketPage, ticketPageSize);
  ticketPage = paging.page; // remember the clamped page, so Prev after rows vanished moves from a real page
  const pinned = state.composer ? state.composer.incidentNumber : '';
  // The row that holds keyboard focus is pinned too: tickets arriving during Load all (newest first)
  // push rows down and off the page, and removing the focused row from the DOM would drop the focus on
  // <body> mid-task. It stays (appended like the composer row) until focus leaves it; paging with the
  // pager moves focus to the pager first, and a deliberate page change (paintPageChange) skips the pin
  // outright, so it is never held back by this.
  const focused = explicitPaging ? '' : focusedIncident();
  // Summary, #rowCount, the empty state and the Excel export count every filtered row; only the
  // reconcile below is limited to the page (plus the open composer's row and the focused row).
  const onPage = pageRows(visible, paging, (row) => (Boolean(pinned) && row.incidentNumber === pinned)
    || (Boolean(focused) && row.incidentNumber === focused));
  lastPagerTotal = visible.length;
  lastPaging = paging;
  const saved = captureFocus(els.incidentRows);
  paintSummary(all, visible, now, summary, paging);
  paintNextActions(all, summary);
  state.nodes = reconcile(els.incidentRows, state.nodes, desiredNodes(onPage, now, timeZone));
  syncActiveComposer();
  paintEmpty(all, visible);
  paintPager(visible.length, paging);
  restoreFocus(els.incidentRows, saved, state.composer, state.pendingFocus);
  state.pendingFocus = applyPendingFocus(els.incidentRows, state.pendingFocus);
  focusNewComposer();
}

// ---- row notes and the per-row refresh ----

function setRowNote(number, noteState, message, ttl) {
  clearTimeout(state.noteTimers.get(number));
  state.notes.set(number, { state: noteState, message });
  if (!ttl) return;
  state.noteTimers.set(number, setTimeout(() => {
    state.notes.delete(number);
    hooks.paint();
  }, ttl));
}

async function requestRefresh(row) {
  const permission = await ensureOriginPermissionConfirmed(row.instanceOrigin);
  if (!permission.ok) return { ok: false, message: permission.message };
  const { reply, failure } = await sendRuntimeMessage({
    type: 'FETCH_INCIDENT',
    instanceUrl: permission.origin,
    incidentNumber: row.incidentNumber,
    source: 'refresh',
  });
  if (failure) return { ok: false, message: failure };
  if (isObject(reply) && reply.ok) return { ok: true, message: '' };
  return { ok: false, message: replyError(reply, 'The ticket could not be refreshed.') };
}

/** Read one ticket again from ServiceNow (source 'refresh': a failure keeps the stored data). */
export async function refreshRow(row) {
  const number = row.incidentNumber;
  if (state.refreshing.has(number)) return;
  state.refreshing.add(number);
  setRowNote(number, 'working', 'Refreshing from ServiceNow ...', 0);
  hooks.paint();
  const outcome = await requestRefresh(row);
  state.refreshing.delete(number);
  if (outcome.ok) setRowNote(number, 'ok', 'Refreshed', DONE_NOTE_TTL_MS);
  else setRowNote(number, 'error', `Refresh failed: ${outcome.message}`, NOTE_TTL_MS);
  hooks.paint();
}

// ---- reveal a ticket (after a search, or from the history) ----

/** Flash a row for a few seconds so the eye finds it. */
export function flashRow(number) {
  clearTimeout(state.justFetchedTimer);
  state.justFetched = number;
  state.justFetchedTimer = setTimeout(() => {
    state.justFetched = '';
    hooks.paint();
  }, FLASH_MS);
}

/** Switch the table to the page that holds `number` (repainting at once) when it is on another page,
 * so a search or History's "Show ticket" lands on the row instead of on a page that does not show it.
 * The filter signature is refreshed first: a caller that just changed filters (dashboard.js's
 * showTicket) must not have this repaint reset the page straight back to 1. */
function showPageOf(number) {
  const index = visibleTicketRows().findIndex((row) => row.incidentNumber === number);
  if (index < 0) return;
  pagingFilterSig = filterSignature();
  const wanted = pageOfIndex(index, ticketPageSize);
  if (wanted === ticketPage) return;
  ticketPage = wanted;
  paintPageChange();
}

/** Scroll a ticket row to the middle of the window; false when the row is not shown. Deferred a tick:
 * every caller (search.js's onSearch, history.js's onHistoryClick) returns focus to a field further up
 * the page right after this runs, and a plain focus() call (no { preventScroll: true }) makes the
 * browser scroll that field into view on its own -- which, run synchronously right after this, would
 * silently cancel the centering below before the next paint. Queuing the actual scroll as its own task
 * lets it run after that focus-driven scroll has already happened, so it is the one the person sees. */
export function scrollRowIntoView(number) {
  showPageOf(number);
  const tr = rowElement(els.incidentRows, number);
  if (tr) setTimeout(() => { if (tr.isConnected) tr.scrollIntoView({ block: 'center' }); }, 0);
  return Boolean(tr);
}

// ---- remove one searched ticket (two clicks: arm, then confirm) ----

const REMOVE_CONFIRM_MS = 6000;
let removeArmedFor = '';
let removeTimer = 0;

function disarmRemove() {
  clearTimeout(removeTimer);
  if (!removeArmedFor) return;
  removeArmedFor = '';
  hooks.paint();
}

/** Drop one ticket from the stored incidents. Its follow-up history (the History view) is kept: that
 * is a record of what was actually sent, not of what was searched. */
async function removeTicket(number) {
  setRowNote(number, 'working', `Removing ${number} ...`, 0);
  hooks.paint();
  try {
    await queueWrite(async () => {
      const stored = await storageRead([KEY.incidents, STORAGE_KEYS.lastIncident]);
      const incidents = isObject(stored[KEY.incidents]) ? { ...stored[KEY.incidents] } : {};
      delete incidents[number];
      await chrome.storage.local.set({ [KEY.incidents]: incidents });
      // The worker's copy of the last searched record goes too when it is this ticket.
      if (isLastIncidentOf(stored[STORAGE_KEYS.lastIncident], number)) await chrome.storage.local.remove(STORAGE_KEYS.lastIncident);
    });
    state.details.delete(number);
    clearTimeout(state.noteTimers.get(number));
    state.notes.delete(number);
    if (state.scope === number) state.scope = 'all';
    hooks.showNotice(`Removed ${number} from your searched tickets. Its follow-up history was kept.`, 'info');
    await hooks.render([KEY.incidents]);
  } catch (err) {
    setRowNote(number, 'error', `Could not remove ${number}: ${err && err.message ? err.message : err}`, NOTE_TTL_MS);
    hooks.paint();
  }
}

function onRemoveClick(row) {
  const number = row.incidentNumber;
  if (removeArmedFor === number) {
    clearTimeout(removeTimer);
    removeArmedFor = '';
    void removeTicket(number);
    return;
  }
  clearTimeout(removeTimer);
  removeArmedFor = number;
  removeTimer = setTimeout(disarmRemove, REMOVE_CONFIRM_MS);
  state.pendingFocus = { incident: number, action: 'remove' };
  hooks.paint();
}

// ---- events ----

function toggleDetails(row) {
  const number = row.incidentNumber;
  if (state.details.has(number)) state.details.delete(number);
  else state.details.add(number);
  state.pendingFocus = { incident: number, action: 'details' };
  hooks.paint();
}

/** Delegated click handler of the ticket table body. */
function onTableClick(event) {
  const target = event.target.closest('button');
  if (!target || target.disabled || !els.incidentRows.contains(target)) return;
  if (target.closest('tr[data-composer-for]')) {
    // The real click event is passed through so the composer's own confirm button can tell a
    // genuine click from the second event of a double click (event.detail > 1).
    onComposerClick(target, event);
    return;
  }
  const tr = target.closest('tr[data-incident]');
  const row = tr && state.rowsByNumber.get(tr.dataset.incident);
  if (!row) return;
  const { action } = target.dataset;
  if (action === 'teams' || action === 'ticket') {
    openComposer(row, action);
  } else if (action === 'refresh') {
    state.pendingFocus = { incident: row.incidentNumber, action: 'refresh' };
    void refreshRow(row);
  } else if (action === 'details') {
    toggleDetails(row);
  } else if (action === 'json') {
    hooks.showJson(row.incidentNumber);
  } else if (action === 'remove') {
    onRemoveClick(row);
  }
  if (action !== 'remove' && removeArmedFor) disarmRemove();
}

/** A summary chip or banner count shows ONLY that status ('All' clears the filter); clicking the one
 * status that is already the whole selection clears it again. The multi-select can combine several. */
function onFilterChipClick(event) {
  const chip = event.target.closest('[data-filter]');
  if (!chip) return;
  const wanted = chip.dataset.filter;
  const statuses = statusFilterValues();
  if (wanted === 'all' || (statuses.length === 1 && statuses[0] === wanted)) setStatusFilter([]);
  else setStatusFilter([wanted]);
}

/** The reset button of the empty state: all days, all statuses, or every filter. */
function onEmptyReset() {
  const { reset } = els.emptyReset.dataset;
  if (reset === 'day') setDay('all');
  else if (reset === 'filters') clearAllFilters();
  else setStatusFilter([]);
}

function onTicketFilterInput(event) {
  ticketQuery = event.target.value;
  hooks.paint();
}

/** First/Prev/Next/Last. `last` asks for a page past any real one; paginate() clamps it. */
const PAGER_STEPS = {
  pagerFirst: () => 1,
  pagerPrev: (page) => page - 1,
  pagerNext: (page) => page + 1,
  pagerLast: () => Number.MAX_SAFE_INTEGER,
};
// When a click disables the very button that was clicked (Next on reaching the last page), focus would
// fall to <body>; move it to the button that still makes sense instead.
const PAGER_FALLBACK = { pagerFirst: 'pagerNext', pagerPrev: 'pagerNext', pagerNext: 'pagerPrev', pagerLast: 'pagerPrev' };

function onPagerClick(event) {
  const button = event.currentTarget;
  const step = button && PAGER_STEPS[button.id];
  if (!step || button.disabled) return;
  // An activation that did not move focus (a screen reader's browse-mode click, a script's .click())
  // can leave it in a row of the page being left; that row is not carried along (paintPageChange), so
  // focus would fall to <body> with it. Noted before the paint, put on the clicked button after it.
  const fromRow = focusedIncident() !== '';
  ticketPage = step(ticketPage);
  paintPageChange();
  announcePage();
  revealTableTop();
  const active = document.activeElement;
  const lost = fromRow && (!active || active === document.body || active.isConnected === false);
  if (!button.disabled && !lost) return;
  if (!button.disabled && typeof button.focus === 'function') {
    button.focus({ preventScroll: true });
    return;
  }
  const fallback = document.getElementById(PAGER_FALLBACK[button.id]);
  if (fallback && !fallback.disabled && typeof fallback.focus === 'function') fallback.focus({ preventScroll: true });
}

/** The pager sits under the table: after paging from it, bring the new page's first rows back into
 * view when the table's top has scrolled off screen (never scrolls when it is already visible). */
function revealTableTop() {
  try {
    const table = els.incidentTable;
    if (table && typeof table.getBoundingClientRect === 'function' && table.getBoundingClientRect().top < 0) {
      table.scrollIntoView({ block: 'start' });
    }
  } catch {
    // scrolling is cosmetic
  }
}

function onPageSizeChange(event) {
  ticketPageSize = normalizePageSize(event.target.value);
  ticketPage = 1;
  storePageSize(ticketPageSize);
  paintPageChange();
  announcePage();
}

/** Build the multi-select of every list filter into its slot in dashboard.html (a missing slot simply
 * has no control), and accept the scripted select-like `value` + 'change' on each button. */
function buildFilterControls() {
  multis.clear();
  for (const spec of LIST_FILTERS) {
    const mount = document.getElementById(spec.mount);
    if (mount) {
      const ms = createMultiSelect({
        id: spec.id,
        label: spec.label,
        allLabel: spec.allLabel || 'All',
        title: spec.title || '',
        selected: selectedOf(spec.key),
        onChange: (values) => setListFilter(spec.key, values),
      });
      mount.replaceChildren(ms.root);
      multis.set(spec.key, ms);
    }
    const button = document.getElementById(spec.id);
    if (button && typeof button.addEventListener === 'function') {
      button.addEventListener('change', (event) => {
        if (event && event.target !== button) return;
        setListFilter(spec.key, scriptedValues(spec, button.value));
      });
    }
  }
}

/** Attach the Tickets view's event listeners. */
export function wireTickets() {
  els.dayFilter.addEventListener('change', () => setDay(els.dayFilter.value));
  buildFilterControls();
  const filter = document.getElementById('ticketFilter');
  if (filter) filter.addEventListener('input', onTicketFilterInput);
  const quick = document.getElementById('quickFilters');
  if (quick) quick.addEventListener('click', onQuickFiltersClick);
  // A deep link or the browser's back/forward button can change this module's params without nav.js
  // knowing about them (dashboard.js's hashchange handler repaints right after this; it re-reads nav.js's
  // own params, this re-reads the rest so that repaint uses what the hash says).
  window.addEventListener('hashchange', () => {
    filterValues = readFiltersFromHash();
  });
  // Paging. Filter changes need no listener here: paintTickets resets to page 1 whenever
  // filterSignature() changes, whichever module changed the filter.
  for (const id of Object.keys(PAGER_STEPS)) {
    const button = document.getElementById(id);
    if (button) button.addEventListener('click', onPagerClick);
  }
  const pageSize = document.getElementById('pageSize');
  if (pageSize) {
    pageSize.value = String(ticketPageSize);
    pageSize.addEventListener('change', onPageSizeChange);
  }
  els.summary.addEventListener('click', onFilterChipClick);
  els.nextItems.addEventListener('click', onFilterChipClick);
  els.emptyReset.addEventListener('click', onEmptyReset);
  els.incidentRows.addEventListener('click', onTableClick);
  els.incidentRows.addEventListener('input', onComposerInput);
  els.incidentRows.addEventListener('change', onComposerChange);
  els.incidentRows.addEventListener('keydown', onComposerKeydown);
}
